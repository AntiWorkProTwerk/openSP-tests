"""Load only authenticated role helper bodies, without ordinary kit imports."""
import importlib.abc
import importlib.util
import sys
from pathlib import Path

class OwnedSourceLoader(importlib.abc.Loader):
    def __init__(self,path,body):self.path=path;self.body=body
    def create_module(self,spec):return None
    def exec_module(self,module):
        module.__file__=str(self.path)
        exec(compile(self.body,str(self.path),'exec'),module.__dict__)

class OwnedSourceFinder(importlib.abc.MetaPathFinder):
    def __init__(self,root,bodies):self.root=root;self.bodies=bodies
    def find_spec(self,name,path=None,target=None):
        if name not in self.bodies:return None
        return importlib.util.spec_from_loader(name,OwnedSourceLoader(self.root/(name+'.py'),self.bodies[name]))

def install(root,authority,role,check_sources):
    root=Path(root).resolve();check_sources(authority,role,root)
    names=authority['roles'][role]['helpers']
    bodies={name:(root/(name+'.py')).read_bytes() for name in names}
    for name in names:sys.modules.pop(name,None)
    sys.meta_path.insert(0,OwnedSourceFinder(root,bodies))
    return tuple(names)
