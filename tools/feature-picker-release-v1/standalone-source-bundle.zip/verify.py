"""Verify current fresh ELF/source/config/native/R3/B2/package bytes without history reads."""
import hashlib,json,struct,zlib
from pathlib import Path

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def need(condition, message):
    if not condition:
        raise ValueError(message)

def unique(pairs):
    value = {}
    for key, item in pairs:
        need(key not in value, 'Duplicate contract JSON field')
        value[key] = item
    return value

def read(path):
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=unique)

def linked_binary(raw, sections, selected):
    """Reproduce objcopy section load-address placement without executing tools."""
    offset = struct.unpack_from('<I', raw, 28)[0]
    stride, count = struct.unpack_from('<HH', raw, 42)
    need(stride==32 and offset+stride*count<=len(raw), 'ELF load segment table differs')
    loads = [struct.unpack_from('<8I', raw, offset+stride*i) for i in range(count)]
    loads = [r for r in loads if r[0]==1]
    pieces = []
    for name in selected:
        section = sections.get(name)
        if not section or section['type']==8 or not section['size']:
            continue
        address, size = section['address'], section['size']
        owners = [r for r in loads if r[2]<=address and address+size<=r[2]+r[4]]
        need(len(owners)==1, 'ELF section load owner differs: '+name)
        owner = owners[0]
        pieces.append((owner[3]+address-owner[2], section['payload']))
    need(pieces, 'ELF binary has no selected sections')
    start = min(a for a, _ in pieces)
    end = max(a+len(b) for a, b in pieces)
    need(0<end-start<=0x37f000, 'ELF binary extent exceeds bounded APP1')
    image = bytearray(end-start)
    for address, body in pieces:
        image[address-start:address-start+len(body)] = body
    return start, bytes(image)

def verify_selected(kit,run,official,authority):
    import portable_r3 as r3, portable_package as package, selection_config as selection_api, module_compiler as compiler
    inventory={'inputs':{name:pin['sha256'] for name,pin in authority['roles']['selected']['members'].items() if pin['original']}}
    selected=selection_api.generate((run/'selection.json').read_bytes(),kit/'inputs/catalog')
    need((run/'config.bin').read_bytes()==selected['blob'], 'Canonical linked configuration differs')
    report=read(run/'REPORT.json');boundary=read(run/'READ_BOUNDARY.json');compile_report=read(run/'module/REPORT.json')
    need(report['feature_mask']==selected['mask'] and report['policy_id']==f'{selected["policy"]:08X}' and
         report['session_marker']==selected['marker'] and report['chooser_label']==selected['chooser_label'],
         'Configuration marker/mask/policy binding differs')
    need(report['delivery']=='DO_NOT_DELIVER' and all(report[k] is False for k in
         ('historical_artifact_read','retained_candidate_read','captured_image_read','source_redistribution_reviewed',
          'public_ready','native_hardware_qualified','device_operations')), 'Build report scope promoted')
    plan=read(run/'selected-plan.json');expected_plan=read(kit/'inputs/module-plan.json')
    expected_plan['inputs']['sources/features/generated_config.c']=sha(selected['source'])
    for command in expected_plan['compile_commands']:
        for i,arg in enumerate(command):
            if arg.startswith('-DSP_RELEASE_COMPILED_FEATURES='):command[i]=f'-DSP_RELEASE_COMPILED_FEATURES={selected["mask"]}'
            if arg.startswith('-DSP_RELEASE_PROFILE_POLICY='):command[i]=f'-DSP_RELEASE_PROFILE_POLICY=0x{selected["policy"]:08X}u'
    need(plan==expected_plan, 'Selected compiler/source contract differs from reviewed derivation')
    compiler.validate_commands(plan)
    need(len(plan['inputs'])==345 and compile_report['plan_sha256']==sha((run/'selected-plan.json').read_bytes()) and
         compile_report['compile_units']==151 and compile_report['temporary_official_copy_removed'] is True,
         'Fresh compile report/plan differs')
    for name,digest in plan['inputs'].items():
        body=(run/'module/source'/name).read_bytes()
        need(sha(body)==digest and (run/'selected-source'/name).read_bytes()==body,'Compiled source copies differ')
    objects=[command[command.index('-o')+1] for command in plan['compile_commands']]
    need(len(objects)==151 and len(set(objects))==151 and
         set(objects)=={p.relative_to(run/'module').as_posix() for p in (run/'module/objects').glob('*.o')},
         'Fresh object ledger differs')
    for name in objects:need((run/'module'/name).stat().st_size>0,'Empty fresh object')
    need(boundary['status']=='PASS' and boundary['python_reads_outside_boundary']==0 and
         all('inputs/module-source/'+name in boundary['accessed_files'] for name in plan['inputs']) and
         all(inventory['inputs'][name]==digest for name,digest in boundary['code_sha256'].items()),
         'Recorded source/code read boundary differs')
    stock,_=r3.official_app1(official)
    for row in plan['native_intervals']:
        fragment=stock[row['official_offset']:row['official_offset']+row['bytes']]
        need(len(fragment)==row['bytes'] and sha(fragment)==row['sha256'], 'Official native interval differs')
    need(len(plan['native_intervals'])==241, 'Kit06 must authenticate all 241 native interval rows')
    for name,offset,size in [('native_cold_v552.inc',144368,8),('native_publish_v552.inc',151188,28)]:
        source='sources/u/f0f9c46b7b6e/'+name
        need((run/'module/source'/source).read_bytes()==f'.incbin "official-app1.local.bin", {offset}, {size}\n'.encode(),
             'Included fragment is not extracted from bounded owner-official interval')
        rows=[row for row in plan['native_intervals'] if row.get('source')==source]
        need(len(rows)==1 and rows[0]['official_offset']==offset and rows[0]['bytes']==size,
             'Included extraction source/preimage binding differs')
    elf=(run/'module/module.elf').read_bytes();sections=r3.elf_sections(elf);symbols=package.symbols(run/'module/module.elf')
    start,module=linked_binary(elf,sections,['.text','.rodata','.ARM.extab','.ARM.exidx'])
    need(start==0x60310000 and module==(run/'module/module.bin').read_bytes(), 'ELF/module BIN composition differs')
    config_address,config_size,_=symbols['sp_release_config_blob_v1']
    need(config_size==128 and config_address%32==0 and
         module[config_address-start:config_address-start+128]==selected['blob'],
         'Config is not exactly embedded/aligned in fresh ELF')
    acquire,acquire_size,_=symbols['sp_synth_storage_v552_acquire'];acquire&=~1
    acquire_code=module[acquire-start:acquire-start+acquire_size]
    requests=[]
    for at in range(0,len(acquire_code)-1,2):
        opcode=struct.unpack_from('<H',acquire_code,at)[0]
        if opcode&0xF800==0x4800 and (opcode>>8)&7==1:
            literal=((acquire+at+4)&~3)+(opcode&255)*4
            if start<=literal and literal+4<=start+len(module):
                requests.append(struct.unpack_from('<I',module,literal-start)[0])
    need(142399 in requests and b'\xda\x1d' in acquire_code and b'\x22\xf0\x07\x02' in acquire_code,
         'Reviewed allocator request/alignment sequence differs')
    r3_elf=(run/'r3/spin.elf').read_bytes();r3_sections=r3.elf_sections(r3_elf);base=bytearray(stock)
    for name,address,offset,size,expected_hash in r3.PATCHES:
        if name=='menu':
            need(stock[offset:offset+size]==b'UTILITY MENU\0', 'Official Utility title preimage differs')
            data=b'ASCII SPIN3!\0'
        else:
            section=r3_sections[name]
            need(section['address']==address and section['type']==1, 'Original R3 section mapping differs')
            data=section['payload']
            if name=='.ram_patch':data=data.ljust(size,b'\0')
            if name=='.flash_patch':need(not any(stock[offset:]), 'Official trailing padding occupied')
        need(len(data)==size and sha(data)==expected_hash, 'Original R3 patch extent/output differs')
        base[offset:offset+size]=data
    base=bytes(base)
    need(base==(run/'r3/baseline-r3.disabled.bin').read_bytes() and sha(base)==r3.R3_SHA,
         'Original source-built R3 ELF-to-baseline replay differs')
    source,writes=package.derive_recipe(base,stock,run/'module/module.elf',read(kit/'inputs/native-contract.json'))
    need(source==(run/'source-app1.disabled.bin').read_bytes() and len(writes)==269 and
         writes==read(run/'DERIVED_RECIPE.json')['patches'], 'Fresh ELF native recipe replay differs')
    bridge=(run/'b2/usb_bridge_b2.elf').read_bytes();bridge_sections=r3.elf_sections(bridge)
    bridge_contract=read(kit/'inputs/b2-contract.json')
    for name in bridge_contract['inputs']:
        body=(kit/'inputs/bridge-source'/name).read_bytes()
        if name=='flash.c':
            begin=body.index(b'uint32_t image_valid(');end=body.index(b'static int fail(',begin)
            body=body[:begin]+body[end:]
        if name in ('monitor.c','usb_upload.c'):body=body.replace(b'0x52420001',b'0x52420201')
        if name in ('screen.c','usb_device.c'):body=body.replace(b'USB BRIDGE B1',b'USB BRIDGE B2')
        need(body==(run/'b2/source'/name).read_bytes(), 'B2 original source transformation differs: '+name)
    _,tail=linked_binary(bridge,bridge_sections,[n for n,s in bridge_sections.items() if s['flags']&2 and n!='.hook'])
    _,hook=linked_binary(bridge,bridge_sections,['.hook'])
    need(tail==(run/'b2/tail.bin').read_bytes() and hook==(run/'b2/hook.bin').read_bytes(), 'B2 ELF tail/hook derivation differs')
    need(sha(tail)=='b0b1697152804f8a5770e4931a36b9e44c518f8431474534621cd102fdb94cb2', 'Unreviewed B2 writer bytes')
    image=package.make_image(source,module,tail,hook,package.symbols(run/'b2/usb_bridge_b2.elf'),'SYNTH P6K3!')
    need(image==(run/'candidate.disabled.bin').read_bytes(), 'Complete APP1 source/B2/module replay differs')
    writable=[dict(name=n,address=s['address'],size=s['size']) for n,s in sections.items() if s['flags']&3==3 and s['size']]
    ordered=sorted(writable,key=lambda r:r['address'])
    need(all(a['address']+a['size']<=b['address'] for a,b in zip(ordered,ordered[1:])), 'Writable memory intervals overlap')
    bss=sections['.bss'];need(bss['address']==0x83832310 and bss['address']+bss['size']<=0x8383A30C, 'Owner BSS bounds differ')
    return dict(status='PASS_STANDALONE_FRESH_SELECTED_SOURCE_AND_BYTES',plan_sha256=sha((run/'selected-plan.json').read_bytes()),
        feature_mask=selected['mask'],sources_checked=345,objects_checked=151,
        native_interval_groups_checked=len(plan['native_intervals']),native_recipe_patches=269,
        included_official_extractions_checked=2,source_kit_files_checked=386,
        authenticated_plan_interval_count=241,
        native_interval_count_derived_from_authenticated_archive_plan=True,
        candidate_sha256=sha(image),candidate_bytes=len(image),candidate_crc32=zlib.crc32(image)&0xffffffff,
        module_xip=[start,start+len(module)],config_address=config_address,writable_intervals=writable,
        ordinary_bss=dict(start=bss['address'],end=bss['address']+bss['size'],bytes=bss['size']),
        spare_bytes=0x8383A30C-bss['address']-bss['size'],source_family_verified_locally=True,
        allocation_request_bytes=142399,arena_alignment=8,arena_capacity_bytes=142392,
        artifact_verified_locally=True,website_source_family_verified=False,website_artifact_verified=False,
        legacy_staging_admitted=False,source_redistribution_reviewed=False,public_ready=False,
        native_hardware_qualified=False,device_operations=False,fresh_compile_execution_attested_by_verifier=False,delivery='DO_NOT_DELIVER')


def replay_r3(run,stock,r3):
    r3_elf=(run/'r3/spin.elf').read_bytes();r3_sections=r3.elf_sections(r3_elf);base=bytearray(stock)
    for name,address,offset,size,expected_hash in r3.PATCHES:
        if name=='menu':
            need(stock[offset:offset+size]==b'UTILITY MENU\0', 'Official Utility title preimage differs')
            data=b'ASCII SPIN3!\0'
        else:
            section=r3_sections[name]
            need(section['address']==address and section['type']==1, 'Original R3 section mapping differs')
            data=section['payload']
            if name=='.ram_patch':data=data.ljust(size,b'\0')
            if name=='.flash_patch':need(not any(stock[offset:]), 'Official trailing padding occupied')
        need(len(data)==size and sha(data)==expected_hash, 'Original R3 patch extent/output differs')
        base[offset:offset+size]=data
    base=bytes(base)
    need(base==(run/'r3/baseline-r3.disabled.bin').read_bytes() and sha(base)==r3.R3_SHA,
         'Original source-built R3 ELF-to-baseline replay differs')
    return base

def replay_bridge(kit,run,r3):
    bridge=(run/'b2/usb_bridge_b2.elf').read_bytes();bridge_sections=r3.elf_sections(bridge)
    bridge_contract=read(kit/'inputs/b2-contract.json')
    for name in bridge_contract['inputs']:
        body=(kit/'inputs/bridge-source'/name).read_bytes()
        if name=='flash.c':
            begin=body.index(b'uint32_t image_valid(');end=body.index(b'static int fail(',begin)
            body=body[:begin]+body[end:]
        if name in ('monitor.c','usb_upload.c'):body=body.replace(b'0x52420001',b'0x52420201')
        if name in ('screen.c','usb_device.c'):body=body.replace(b'USB BRIDGE B1',b'USB BRIDGE B2')
        need(body==(run/'b2/source'/name).read_bytes(), 'B2 original source transformation differs: '+name)
    _,tail=linked_binary(bridge,bridge_sections,[n for n,s in bridge_sections.items() if s['flags']&2 and n!='.hook'])
    _,hook=linked_binary(bridge,bridge_sections,['.hook'])
    need(tail==(run/'b2/tail.bin').read_bytes() and hook==(run/'b2/hook.bin').read_bytes(), 'B2 ELF tail/hook derivation differs')
    need(sha(tail)=='b0b1697152804f8a5770e4931a36b9e44c518f8431474534621cd102fdb94cb2', 'Unreviewed B2 writer bytes')
    return tail,hook

def verify_restore(kit,run,official,authority):
    import portable_r3 as r3,portable_package as package
    plan=read(kit/'inputs/module-plan.json');report=read(run/'REPORT.json');boundary=read(run/'READ_BOUNDARY.json')
    stock,_=r3.official_app1(official)
    need(len(plan['native_intervals'])==14,'Restoration extraction count differs')
    for row in plan['native_intervals']:
        fragment=stock[row['official_offset']:row['official_offset']+row['bytes']]
        need(len(fragment)==row['bytes'] and sha(fragment)==row['sha256'],'Restoration official extraction differs')
    for name,digest in plan['inputs'].items():
        need(sha((run/'module/source'/name).read_bytes())==digest,'Restoration compiled source differs')
    elf=(run/'module/module.elf').read_bytes();sections=r3.elf_sections(elf)
    loaded={name:dict(type=s['type'],flags=s['flags'],address=s['address'],size=s['size'],sha256=sha(s['payload']))
            for name,s in sections.items() if s['flags']&2}
    symbols={name:list(value) for name,value in package.symbols(run/'module/module.elf').items() if value[2]!=4}
    need(loaded==plan['expected_loaded_sections'] and symbols==plan['expected_runtime_symbols'],
         'Restoration loaded ELF/symbols differ from source contract')
    start,module=linked_binary(elf,sections,plan['xip_sections'])
    need(module==(run/'module/module.bin').read_bytes() and sha(module)==plan['expected_module_sha256'],
         'Restoration ELF/module placement differs')
    base=replay_r3(run,stock,r3)
    source,writes=package.derive_recipe(base,stock,run/'module/module.elf',read(kit/'inputs/native-contract.json'))
    need(len(writes)==45,'Restoration symbolic recipe count differs')
    tail,hook=replay_bridge(kit,run,r3)
    image=package.make_image(source,module,tail,hook,package.symbols(run/'b2/usb_bridge_b2.elf'),'SYNTH P6S!')
    need(image==(run/'restore-p6s.disabled.bin').read_bytes() and len(image)==2741144 and
         sha(image)=='7f9917ffb0871cca25b1ce5d281ac5c2bf790ae6b8278b04a5ffef8e3c06fd60',
         'Fresh source-built authentic P6S package replay differs')
    need(report['compile_units']==27 and report['known_image_identity_match'] is True and
         boundary['status']=='PASS' and boundary['python_reads_outside_boundary']==0 and
         boundary['historical_artifact_read'] is False and boundary['captured_image_read'] is False,
         'Restoration fresh/read-boundary proof differs')
    return dict(status='PASS_FRESH_AUTHENTIC_P6S_SOURCE_AND_BYTE_REPLAY',source_files_checked=119,
                compile_units=27,official_extraction_intervals=14,symbolic_patches=45,native_recipe_patches=writes,
                module_sha256=sha(module),module_elf_sha256=sha(elf),restoration_sha256=sha(image),
                restoration_bytes=len(image),restoration_crc32=zlib.crc32(image)&0xffffffff,
                authentic_identity_hash_matches=True,new_device_qualification=False,
                historical_artifacts_read=False,public_ready=False,device_operations=False,delivery='DO_NOT_DELIVER')
