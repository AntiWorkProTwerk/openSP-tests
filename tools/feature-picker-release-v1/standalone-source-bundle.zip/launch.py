"""Build and locally verify held selected/P6S APP1s from authenticated sources."""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import types
from pathlib import Path

EXPECTED_AUTHORITY = 'ef933914f014d27ba18632906423546aa2394e281167e231314bd59eccd95ed5'
ROOT = Path(__file__).resolve().parent

def digest(body):return hashlib.sha256(body).hexdigest()
def need(value,why):
    if not value:raise ValueError(why)

def source_module(name,filename,authority):
    path=ROOT/filename;body=path.read_bytes();pin=authority['files'][filename]
    need(digest(body)==pin['sha256'] and len(body)==pin['bytes'],'Owned helper differs')
    module=types.ModuleType(name);module.__file__=str(path)
    exec(compile(body,str(path),'exec'),module.__dict__)
    return module

def checked():
    raw=(ROOT/'AUTHORITY.json').read_bytes()
    need(digest(raw)==EXPECTED_AUTHORITY,'Standalone authority has no reviewed admission')
    data=json.loads(raw)
    authority=source_module('owned_authority','authority.py',data)
    authority.check_bundle(ROOT,EXPECTED_AUTHORITY)
    context=authority.check_python(data)
    return data,authority,context

def environment(tools):
    value={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR','TEMP','TMP')}
    value['PATH']=str(tools/'bin')+os.pathsep+str(Path(os.environ['SYSTEMROOT'])/'System32')
    return value

def compile_role(role,source,tools,selection,official,output):
    data,authority,_=checked();source=Path(source).resolve();tools=Path(tools).resolve()
    official=Path(official).resolve();output=Path(output).resolve()
    authority.check_tools(tools,data,ROOT);authority.check_sources(data,role,source)
    loader=source_module('owned_loader','loader.py',data)
    loader.install(source,data,role,authority.check_sources)
    import audit_run
    prefix=str(tools/'bin/arm-none-eabi-')
    if role=='selected':audit_run.run(source/'inputs',Path(selection),official,prefix,output)
    elif role=='restore':audit_run.run(source/'inputs',official,prefix,output)
    else:raise ValueError('Unknown source role')

def run(official,selection,tools,output):
    data,authority,python_context=checked()
    official=official.resolve();selection=selection.resolve();tools=tools.resolve();output=output.resolve()
    need(not output.exists(),'Use a new standalone output directory')
    need(not ROOT.is_relative_to(output) and not tools.is_relative_to(output) and
         not official.is_relative_to(output) and not selection.is_relative_to(output),
         'Output would contain source/tool/input authority')
    tool_count=authority.check_tools(tools,data,ROOT)
    guard=source_module('owned_read_guard','read_guard.py',data)
    tool_files=json.loads((ROOT/'TOOLCHAIN_AUTHORITY.json').read_bytes())['files']
    accesses,children=guard.install(ROOT,output,official,selection,tools,tool_files)
    # Validate official firmware and canonical input before creating any output.
    selected_members=authority.archive_members(ROOT,data,'selected')
    restore_members=authority.archive_members(ROOT,data,'restore')
    def memory_module(name,filename):
        body=selected_members[filename];module=types.ModuleType(name);module.__file__=str(ROOT/filename)
        exec(compile(body,str(ROOT/filename),'exec'),module.__dict__);sys.modules[name]=module;return module
    r3=memory_module('portable_r3','portable_r3.py')
    config=memory_module('selection_config','selection_config.py')
    raw=selection.read_bytes();official_raw=official.read_bytes();stock,kind=r3.official_app1(official)
    # The archived encoder expects paths. Validate exact canonical semantics
    # after materializing only the authenticated catalog, before any compiler.
    output.mkdir(parents=True,exist_ok=False)
    inputs=output/'sources';inputs.mkdir()
    selected_source=authority.materialize(ROOT,data,'selected',inputs)
    restore_source=authority.materialize(ROOT,data,'restore',inputs)
    generated=config.generate(raw,selected_source/'inputs/catalog')
    (output/'selection.json').write_bytes(raw)
    anchor=dict(schema='opensp-standalone-owned-source-transaction-v1',authority_sha256=EXPECTED_AUTHORITY,
                official_sha256=digest(official_raw),selection_sha256=digest(raw),
                selected_archive_sha256=data['roles']['selected']['archive_sha256'],
                restore_archive_sha256=data['roles']['restore']['archive_sha256'],
                public_ready=False,device_operations=False,delivery='DO_NOT_DELIVER')
    (output/'TRANSACTION.json').write_text(json.dumps(anchor,indent=2)+'\n',encoding='utf-8')
    child_bootstrap='import sys,hashlib;from pathlib import Path;p=Path(sys.argv.pop(1));expected=sys.argv.pop(1);body=p.read_bytes();assert hashlib.sha256(body).hexdigest()==expected;ns={"__file__":str(p),"__name__":"owned_build_entry"};exec(compile(body,str(p),"exec"),ns);ns["compile_role"](*sys.argv[1:])'
    entry=Path(__file__).resolve();entry_sha=digest(entry.read_bytes())
    for role,source in (('selected',selected_source),('restore',restore_source)):
        child=subprocess.run([sys.executable,'-I','-S','-B','-c',child_bootstrap,str(entry),entry_sha,
                              role,str(source),str(tools),str(output/'selection.json'),str(official),str(output/(role+'-build'))],
                             cwd=ROOT,env=environment(tools),capture_output=True,text=True)
        (output/(role+'.stdout.log')).write_text(child.stdout,encoding='utf-8')
        (output/(role+'.stderr.log')).write_text(child.stderr,encoding='utf-8')
        need(child.returncode==0,'Fresh '+role+' source build failed; inspect owned logs')
    authority.check_bundle(ROOT,EXPECTED_AUTHORITY);authority.check_tools(tools,data,ROOT)
    authority.check_sources(data,'selected',selected_source);authority.check_sources(data,'restore',restore_source)
    need(selection.read_bytes()==raw and official.read_bytes()==official_raw,'Supplied inputs changed during build')
    loader=source_module('owned_loader','loader.py',data)
    verifier=source_module('owned_verifier','verify.py',data)
    loader.install(selected_source,data,'selected',authority.check_sources)
    selected_proof=verifier.verify_selected(selected_source,output/'selected-build',official,data)
    loader.install(restore_source,data,'restore',authority.check_sources)
    restore_proof=verifier.verify_restore(restore_source,output/'restore-build',official,data)
    result=dict(schema='opensp-standalone-owned-source-build-proof-v1',
                status='PASS_FRESH_SELECTED_AND_AUTHENTIC_P6S_SOURCE_BUILD_AND_BYTE_REPLAY',
                authority_sha256=EXPECTED_AUTHORITY,selection_sha256=digest(raw),configuration_sha256=generated['config_sha256'],
                toolchain_inputs_checked=tool_count,python_role=python_context,
                selected=selected_proof,restoration=restore_proof,
                source_recompiled=True,selected_observed_compile_units=151,restoration_observed_compile_units=27,
                historical_artifacts_read=False,captured_images_read=False,compiler_binaries_packaged=False,
                standalone_local_source_dependency_closure=True,
                source_promotion_authorized=False,source_redistribution_reviewed=False,public_ready=False,
                native_hardware_qualified=False,browser_build_enabled=False,browser_upload_enabled=False,
                website_source_family_verified=False,website_artifact_verified=False,
                download_ready=False,upload_ready=False,release_ready=False,device_operations=False,
                delivery='DO_NOT_DELIVER')
    boundary=dict(schema='opensp-standalone-parent-python-read-boundary-v1',status='PASS',
                  accessed_files=sorted(accesses),child_roles=children,parent_python_reads_outside_roles=0,
                  source_helpers_loaded_from_authenticated_bodies=True,historical_artifacts_read=False,
                  captured_images_read=False,compiler_internal_reads_traced=False,os_stdlib_reads_attested=False,
                  scope='Parent Python open/write and child launcher roles after authority/tool preflight; child source builds have their own pinned Python guards. Source-only imports and external runtime preflight precede these guards.',
                  public_ready=False,device_operations=False,delivery='DO_NOT_DELIVER')
    (output/'READ_BOUNDARY.json').write_text(json.dumps(boundary,indent=2)+'\n',encoding='utf-8')
    (output/'REPORT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('official','selection','toolchain-root','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    options=parser.parse_args()
    print(json.dumps(run(options.official,options.selection,options.toolchain_root,options.output),indent=2))
