# Standalone local source builder

Run the matching external Python3.12.14 with `-I -S -B` and supply owner official
Roland5.52 input, a canonical OpenSP Synth/recorder export, the matching explicit
ArmGNU14.3.Rel1 toolchain root, and a new output directory:

```text
python -I -S -B launch.py --official OWNER_V552.zip --selection CANONICAL_EXPORT.json --toolchain-root ARM_ROOT --output NEW_LOCAL_OUTPUT
```

The two original licensed archives are authenticated fixed source inputs. This
bundle contains no compiler, firmware, captured RAM, historical ELF/object or
private installation path. Each transaction rebuilds the selected151-unit
module and required authentic27-unit P6S restoration, then verifies the current
source/config/ELF/native recipe/R3/B2/APP1 bytes. No old artifact/report is read.
The exact canonical export is the only variable source configuration. No caller
family, source list, command, authority hash or compiler identity is accepted.

All original LICENSE/NOTICE/provenance/build metadata stays beside each extracted
source role. MIT covers the owner's original contributions, copyright2026
AntiWorkProTwerk; supplied firmware and third-party/compiler rights retain the
original archive exclusions. Archive origins are not independent attestations.

The installed compiler and interpreter remain pinned external dependencies.
OS/Python standard-library and child compiler-internal reads are untraced.
Source promotion/public/hardware/browser/upload/release flags remain false;
delivery is DO_NOT_DELIVER. This is a standalone local source build proof,
with no new shared website source-family admission or browser integration.
