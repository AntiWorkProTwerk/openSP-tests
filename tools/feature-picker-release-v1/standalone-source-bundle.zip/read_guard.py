"""Record the standalone parent's bounded Python reads and child launch roles."""
import os
import re
import sys
from pathlib import Path

def install(bundle,output,official,selection,tools,tool_files):
    accesses=set();children=[];runtime=Path(sys.base_prefix).resolve();launcher=Path(sys.executable).resolve()
    def label(path):
        if path==official:return 'owner-official'
        if path==selection:return 'canonical-selection'
        if path.is_relative_to(bundle):return 'bundle/'+path.relative_to(bundle).as_posix()
        if path.is_relative_to(output):return 'output/'+path.relative_to(output).as_posix()
        if path.is_relative_to(tools):
            name=path.relative_to(tools).as_posix()
            if name in tool_files:return 'pinned-tool/'+name
            raise PermissionError('Parent read of undeclared compiler input')
        if path.is_relative_to(runtime):return 'python-runtime/'+path.relative_to(runtime).as_posix()
        if path==launcher:return 'reviewed-python-launcher'
        raise PermissionError('Parent Python access escaped standalone roles')
    def audit(event,args):
        if event=='open':
            if not isinstance(args[0],(str,bytes,os.PathLike)):return
            path=Path(os.fsdecode(args[0])).resolve();tag=label(path)
            writing=bool(args[2]&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            if writing and not path.is_relative_to(output):raise PermissionError('Parent write escaped owned output')
            accesses.add(tag)
        elif event=='subprocess.Popen':
            executable,argsv,cwd,env=args
            if isinstance(argsv,str):
                match=re.match(r'^(?:"([^"]+)"|(\S+))',argsv)
                if match is None:raise PermissionError('Parent child has no explicit interpreter')
                program=next(value for value in match.groups() if value is not None)
                isolated=argsv[match.end():].lstrip().startswith('-I -S -B -c ')
            else:
                program=argsv[0];isolated=argsv[1:4]==['-I','-S','-B'] and argsv[4]=='-c'
            if executable is None:executable=program
            if Path(executable).resolve()!=launcher:raise PermissionError('Parent child escaped reviewed interpreter role')
            if not isolated:
                raise PermissionError('Parent child lacks isolated source-only bootstrap')
            children.append('isolated-reviewed-python-role')
    sys.addaudithook(audit)
    return accesses,children
