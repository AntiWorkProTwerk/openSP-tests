"""Build the fixed openSynth N1 source transaction from owner official v5.52.

The admitted wrapper/outer archive must authenticate this entry itself. Its
fixed authority digest binds all other source, recipe and tool inputs.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import types
import zlib

EXPECTED_AUTHORITY = '4cb94d4f82ae7975495b3ccff2c07d71db6a5a21c9bda07f78170a70f5bc95a0'
ROOT = Path(__file__).resolve().parent


def sha(raw):return hashlib.sha256(raw).hexdigest()
def need(ok, why):
    if not ok:raise ValueError(why)
def save(path, value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')


def authenticate(inputs):
    need(inputs.resolve()==ROOT/'inputs','Use the fixed admitted source input role')
    raw=(ROOT/'BUILD_AUTHORITY.json').read_bytes()
    need(sha(raw)==EXPECTED_AUTHORITY,'Compact build authority is not admitted')
    authority=json.loads(raw)
    need(authority['schema']=='opensp-priority1-compact-build-authority-v1','Build authority schema differs')
    expected=set(authority['files'])|{'BUILD_AUTHORITY.json','build_candidate.py'}
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    need(actual==expected,'Undeclared source/helper/import alternative in source kit')
    need(not any(p.is_symlink() for p in ROOT.rglob('*')),'Source kit symlink is not admitted')
    for name,pin in authority['files'].items():
        path=ROOT/name;raw=path.read_bytes()
        need(path.resolve().is_relative_to(ROOT) and len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],
             'Pinned compact build input differs: '+name)
    return authority


def owned(name):
    path=ROOT/(name+'.py');body=path.read_bytes()
    module=types.ModuleType(name);module.__file__=str(path);sys.modules[name]=module
    exec(compile(body,str(path),'exec'),module.__dict__)
    return module


def undefined_symbols(elf):
    raw=elf.read_bytes();offset=struct.unpack_from('<I',raw,32)[0]
    stride,count=struct.unpack_from('<HH',raw,46)
    need(stride==40 and offset+stride*count<=len(raw),'ELF section extent differs')
    rows=[struct.unpack_from('<10I',raw,offset+i*stride) for i in range(count)]
    missing=[]
    for row in rows:
        if row[1]!=2:continue
        need(row[9]==16 and row[5]%16==0 and row[4]+row[5]<=len(raw) and row[6]<count,
             'ELF symbol table extent differs')
        strings=rows[row[6]];names=raw[strings[4]:strings[4]+strings[5]]
        need(len(names)==strings[5],'ELF symbol strings extent differs')
        for at in range(row[4],row[4]+row[5],16):
            name,value,size,info,other,section=struct.unpack_from('<IIIBBH',raw,at)
            need(name<len(names),'ELF symbol name extent differs')
            end=names.find(b'\0',name);need(end>=0,'ELF symbol name lacks terminator')
            label=names[name:end].decode('ascii')
            if label and section==0:missing.append(label)
    return sorted(set(missing))


def build(inputs, official, tool_prefix, output):
    inputs,official,output=inputs.resolve(),official.resolve(),output.resolve()
    authority=authenticate(inputs)
    tools=Path(tool_prefix).resolve().parent.parent
    need(Path(tool_prefix).name=='arm-none-eabi-' and Path(tool_prefix).parent.name=='bin','Explicit reviewed Arm prefix differs')
    guard_authority=owned('authority')
    python_role=guard_authority.check_python(authority)
    tool_count=guard_authority.check_tools(tools,authority,ROOT)
    r3=owned('portable_r3');package=owned('portable_package')
    stock,kind=r3.official_app1(official)
    need(not output.exists() and not ROOT.is_relative_to(output) and not official.is_relative_to(output) and
         not output.is_relative_to(ROOT),'Output must be new and separate from source/official roles')
    plan=json.loads((inputs/'module-plan.json').read_bytes())
    need(plan['schema']=='opensp-priority1-p6s-record-source-contract-v1' and plan['identity']=='openSynth N1' and
         plan['policy_id']=='50544E31' and len(plan['compile_commands'])==105,'Fixed compact source contract differs')
    need(plan['features']==dict(synth=True,record_to_pad=True,global_usb=False,expanded128=False), 'Unsupported feature request')
    need(plan.get('direct_flow_contract') is not None and plan.get('capture_contract') is not None,
         'Final chooser and finite capture source contract is not sealed')
    for row in plan['native_intervals']:
        fragment=stock[row['official_offset']:row['official_offset']+row['bytes']]
        need(len(fragment)==row['bytes'] and sha(fragment)==row['sha256'],'Official native extraction interval differs')
    for command in plan['compile_commands']+[plan['link_command']]:
        need(isinstance(command,list) and command.count('-o')==1,'Compile/link output shape differs')
        for arg in command:
            need(isinstance(arg,str) and not arg.startswith('@') and
                 not re.search(r'[A-Za-z]:[\\/]|(?:^|[=,])/|(?:^|[=/,\\])\.\.(?:[/\\]|$)',arg),
                 'Unreviewed command path or response file')
    output.mkdir()
    for name in ('GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','CPATH','C_INCLUDE_PATH',
                 'CPLUS_INCLUDE_PATH','OBJC_INCLUDE_PATH','GCC_SPECS'):
        need(not os.environ.get(name),'Unreviewed compiler environment override: '+name)
    guards=owned('read_guard').install(ROOT,output,official,tools,authority['tool_files'])
    def tool(name):
        path=Path(tool_prefix+name+'.exe').resolve()
        need(path.is_relative_to(tools) and path.is_file(),'Explicit compiler tool is absent')
        return str(path)
    module=output/'module';module.mkdir();(module/'objects').mkdir();(module/'dependencies').mkdir()
    for name,digest in plan['inputs'].items():
        raw=(inputs/'module-source'/name).read_bytes();need(sha(raw)==digest,'Declared source changed during build')
        target=module/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    ledger=[]
    def run(command):
        command=list(command);result=subprocess.run(command,cwd=module,capture_output=True,text=True)
        ledger.append(dict(command=command,returncode=result.returncode))
        with (module/'compiler.private.log').open('a',encoding='utf-8') as stream:stream.write(result.stdout+result.stderr)
        need(result.returncode==0,'Compact source compiler/link step failed')
        return result.stdout
    with tempfile.TemporaryDirectory(prefix='official-',dir=module) as scratch:
        Path(scratch,'official-app1.local.bin').write_bytes(stock)
        for command in plan['compile_commands']:
            run([tool('gcc'),'-Wa,-I,'+scratch,*command])
        run([tool('gcc'),*plan['link_command']])
    r3.elf_sections((module/'module.elf').read_bytes())
    need(not undefined_symbols(module/'module.elf'),'Unresolved compact source symbol')
    syms=package.symbols(module/'module.elf');sections=r3.elf_sections((module/'module.elf').read_bytes())
    save(module/'ELF_MAP.json',dict(symbols=syms,sections={name:{key:value for key,value in row.items() if key!='payload'}
                                                       for name,row in sections.items()}))
    need(syms['__synth_bss_start'][0]==0x83832310 and syms['__synth_bss_end'][0]<=0x8383A30C,
         'Compact ordinary BSS overlaps native constructors')
    need(syms['__synth_image_end'][0]<=0x603FF000 and not sections.get('.forbidden',{}).get('size') and
         not sections.get('.data',{}).get('size'),
         'Unsupported compact placement/startup state')
    for name,size in [('sp_p6_record_files_v552',plan['file_owner_bytes']),('sp_p6_production_capture',1336),
                      ('sp_p6_production_session',3824)]:
        need(syms[name][1]==size,'Compact owner extent differs: '+name)
    need('sp_global_v552_owner' not in syms and 'sp_p6_full_audio_mix' not in syms and
         'sp_synth_factory_bank' not in syms,'Unselected global/full-engine owner retained')
    dependency_inputs={};file_consumers=[]
    for index in range(105):
        path=module/'dependencies'/f'unit-{index:03d}.d'
        text=path.read_text().replace('\\\n',' ');parts=text.split(':',1)
        need(len(parts)==2,'Compiler dependency receipt differs')
        names=[]
        for label in parts[1].split():
            dependency=(module/label).resolve()
            need(dependency.is_relative_to(module/'source') and dependency.is_file(),'Compiler project dependency escaped source role')
            name=dependency.relative_to(module/'source').as_posix();body=dependency.read_bytes()
            need(name in plan['inputs'] and sha(body)==plan['inputs'][name], 'Actual compiler source dependency differs')
            dependency_inputs[name]=sha(body);names.append(name)
            if dependency.name=='sp_p6_record_files_v552.h':
                need(sha(body)==plan['file_header_sha256'],'Actual FILE consumer used a historical ABI')
        if any(name.endswith('/sp_p6_record_files_v552.h') for name in names):file_consumers.append(index)
    need(file_consumers,'No actual FILE ABI consumer recorded')
    run([tool('objcopy'),'-O','binary',*sum((['-j',name] for name in plan['xip_sections']),[]),'module.elf','module.bin'])
    raw_module=(module/'module.bin').read_bytes()
    need(len(raw_module)==syms['__synth_image_end'][0]-0x60310000,'Compact XIP module extent differs')
    save(module/'compiler-ledger.json',dict(compile_units=105,objects={p.name:sha(p.read_bytes()) for p in (module/'objects').glob('*.o')},
        commands=ledger,actual_dependency_inputs=dependency_inputs,file_abi_consumers=file_consumers,
        stack_receipts={p.name:sha(p.read_bytes()) for p in (module/'objects').glob('*.su')},
        assembly_stack_receipts_not_emitted_by_gcc=True,undefined_symbols=[]))
    r3.build(official,inputs/'r3-source',tool_prefix,output/'r3')
    base=(output/'r3/baseline-r3.disabled.bin').read_bytes()
    source,patches=package.derive_recipe(base,stock,module/'module.elf',json.loads((inputs/'native-contract.json').read_bytes()))
    tail,hook,b2syms=package.build_b2(inputs/'bridge-source',json.loads((inputs/'b2-contract.json').read_bytes()),tool_prefix,output/'b2')
    image=package.make_image(source,raw_module,tail,hook,b2syms,plan['identity'])
    need(image[0x160560:0x16056D]==b'openSynth N1\0','Native Utility identity differs')
    (output/'candidate.disabled.bin').write_bytes(image)
    (output/'source_APP1.private.bin').write_bytes(source)
    save(output/'recipe.json',dict(schema='opensp-priority1-derived-native-recipe-v1',patches=patches))
    report=dict(schema='opensp-priority1-compact-candidate-build-v1',status='PASS_SOURCE_PACKAGE_ONLY',
        identity=plan['identity'],policy_id=plan['policy_id'],features=plan['features'],official_kind=kind,
        source_contract_sha256=sha((inputs/'module-plan.json').read_bytes()),authority_sha256=EXPECTED_AUTHORITY,
        module_elf_sha256=sha((module/'module.elf').read_bytes()),module_sha256=sha(raw_module),
        compile_units=105,actual_file_abi_consumers=file_consumers,file_header_sha256=plan['file_header_sha256'],
        xip_bytes=len(raw_module),bss_begin=syms['__synth_bss_start'][0],bss_end=syms['__synth_bss_end'][0],
        bss_spare=0x8383A30C-syms['__synth_bss_end'][0],native_patches=len(patches),
        recipe_sha256=sha((output/'recipe.json').read_bytes()),source_APP1_sha256=sha(source),
        candidate_sha256=sha(image),candidate_bytes=len(image),candidate_crc32=f'{zlib.crc32(image)&0xffffffff:08X}',
        padded_bytes=(len(image)+4095)&~4095,toolchain_pinned_files=tool_count,python_role=python_role,
        restoration_sha256='7f9917ffb0871cca25b1ce5d281ac5c2bf790ae6b8278b04a5ffef8e3c06fd60',
        restoration_bytes=2741144,restoration_crc32='BA6967B2',restoration_freshly_compiled=False,
        actual_native_route_qualified=False,runtime_budget_qualified=False,hardware_qualified=False,
        software_eligible_for_owner_test=False,public_release_eligible=False,
        release_ready=False,delivery_enabled=False,upload_enabled=False,browser_enabled=False,public_ready=False,
        delivery='DO_NOT_DELIVER',historical_binaries_read=False,captured_RAM_read=False,
        audit_scope='Python access after hook and explicit tools; prehook imports, OS/stdlib and compiler-internal reads untraced')
    save(output/'REPORT.json',report)
    save(output/'READ_BOUNDARY.json',dict(input_and_output_labels=sorted(guards[0]),explicit_tool_calls=guards[1],
        compiler_internal_reads_traced=False,os_and_stdlib_reads_attested=False,prehook_imports_traced=False))
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('inputs','official','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--tool-prefix',required=True);args=parser.parse_args()
    try:
        print(json.dumps(build(args.inputs,args.official,args.tool_prefix,args.output),indent=2))
    except Exception as error:
        if args.output.is_dir():save(args.output/'BUILD_FAILURE.json',dict(status='FAILED_COMPACT_BUILD',
            error_type=type(error).__name__,error=str(error),delivery='DO_NOT_DELIVER'))
        raise
