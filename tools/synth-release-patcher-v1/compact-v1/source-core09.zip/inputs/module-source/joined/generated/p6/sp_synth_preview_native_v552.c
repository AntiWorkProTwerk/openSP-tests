#include <stdint.h>
extern int sp_p6_record_audio_v552_native(const void *,const int16_t *,uint32_t,int32_t *);
#include "sp_synth_preview_native_v552.h"
#include "sp_synth_control_v552.h"
#include "sp_p6_menu.h"
#include "sp_demo_v552.h"
#include <stddef.h>
#include "sp_p6_production_join.h"
#include "sp_p6_record_retirement_v552.h"
#include "sp_p6_session_binding_v552.h"
#include "sp_p6_record_controls_v552.h"
extern void sp_p6_record_request_v552_panel(void);
extern void sp_p6_record_rearm_v552_panel(void);
extern int sp_p6_record_rearm_v552_constructor_ready(void);
extern int sp_p6_record_backend_v552_panel(void);

_Static_assert(sizeof(void *)==4 && ATOMIC_INT_LOCK_FREE==2,"Native ARM32 atomics");
_Static_assert(sizeof(SpPreviewNativeV552)<32764,"Permanent32K reservation");
SpPreviewNativeV552 sp_synth_preview_native_v552;
extern unsigned char __synth_bss_start[],__synth_bss_end[];
typedef uint32_t (*Method)(void *,uint32_t,uint32_t,uint32_t);
static uint32_t task(void){return ((uint32_t (*)(void))(uintptr_t)0x800D3163)();}
static uint32_t phase(SpPreviewNativeV552 *m){return atomic_load_explicit(&m->phase,memory_order_acquire);}
static int ready(SpPreviewNativeV552 *m){return atomic_load_explicit(&m->ready,memory_order_acquire)==1;}
static int owned(SpPreviewNativeV552 *m,void *panel) {
    return (uintptr_t)panel==0x8300A3E4 && ready(m) && task()==m->task_id;
}
static void fail(SpPreviewNativeV552 *m,uint32_t reason) {
    atomic_fetch_or_explicit(&m->terminal,reason,memory_order_release);
    if(ready(m))sp_synth_preview_voice_stop(&m->voice);
}
void sp_synth_preview_native_v552_cancel(void){fail(&sp_synth_preview_native_v552,SP_PREVIEW_NATIVE_LIFETIME);}
uint32_t sp_synth_preview_native_v552_shutdown_initialize(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    if(ready(&sp_synth_preview_native_v552))sp_synth_preview_native_v552_cancel();
    return ((uint32_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(uintptr_t)0x80104F31)(a,b,c,d);
}
uint32_t sp_synth_preview_native_v552_shutdown_callback(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(ready(m)) {
        sp_synth_preview_native_v552_cancel();
        if(!sp_synth_preview_voice_stop_ack(&m->voice)) {
            /* The native callback's final indicator action remains live while
             * its counter/reply is deferred. Nothing increments the shutdown
             * counter or sends a power acknowledgment before audio silence. */
            return ((uint32_t (*)(uint32_t,uint32_t))(uintptr_t)0x800C4D29)(1,0);
        }
    }
    return ((uint32_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(uintptr_t)0x80104ED9)(a,b,c,d);
}
__attribute__((weak)) int sp_synth_preview_native_v552_present(void *p,const SpPreviewNativeView *v){(void)p;(void)v;return 0;}
__attribute__((weak)) void sp_synth_preview_native_v552_detach(void *p){(void)p;}
__attribute__((weak)) void sp_synth_preview_native_v552_retire(void *p){(void)p;}
static void entry_stop(void *context){fail(context,SP_PREVIEW_NATIVE_ENTRY);}
static int publish(void *context,const sp_synth_input_batch *batch) {
    SpPreviewNativeV552 *m=context;
    if(task()!=m->task_id || batch->count>SP_SYNTH_INPUT_BATCH_CAPACITY)return 0;
    if(phase(m)!=SP_PREVIEW_NATIVE_ACTIVE || atomic_load_explicit(&m->terminal,memory_order_acquire))return 1;
    for(unsigned i=0;i<batch->count;++i) {
        const sp_ui_event *e=&batch->events[i];
        if(sp_p6_record_controls_v552_pad(e) && e->type==SP_UI_PAD_DOWN)continue;
        if(e->type==SP_UI_PAD_DOWN) {
            if(e->index<1 || e->index>16 || !sp_synth_preview_voice_down(&m->voice,e->index-1))return 0;
            sp_demo_v552_event(e->index,SP_DEMO_DOWN,e->value,m->voice.control_ids[e->index-1]);
        } else if(e->type==SP_UI_PAD_UP) {
            if(e->index<1 || e->index>16)return 0;
            unsigned pad=e->index-1;
            /* Chooser-held pads are captured for release but have no voice ID. */
            uint32_t ticket=m->voice.control_ids[pad];
            if(ticket && !sp_synth_preview_voice_up(&m->voice,pad,ticket))return 0;
        }
    }
    return 1;
}
static int page_owned(void *page) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    return ready(m) && task()==m->task_id && m->active_page==page;
}
int sp_synth_preview_native_v552_snapshot(void *panel,SpPreviewNativeView *out) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(!out || !owned(m,panel))return 0;
    uint32_t fault=atomic_load_explicit(&m->terminal,memory_order_acquire);
    fault|=sp_synth_preview_voice_faults(&m->voice)&~SP_PREVIEW_STOP;
    *out=(SpPreviewNativeView){phase(m),fault,m->choice,m->entry.input.captured,
        m->route_ticket,sp_synth_generator_route_v552_ack(&m->generator),
        m->permission_ticket,sp_synth_preview_voice_permission_ack(&m->voice),
        (m->normal_stop_ticket && sp_synth_preview_voice_idle_ack(&m->voice)==m->normal_stop_ticket) ||
        sp_synth_preview_voice_stop_ack(&m->voice),{0}};
    if(!sp_p4_controls_snapshot(&m->controls,&out->controls))return 0;
    out->controls.command_ticket=sp_synth_preview_voice_command(&m->voice);
    out->controls.command_ack=sp_synth_preview_voice_command_ack(&m->voice);
    return 1;
}
int sp_synth_preview_native_v552_select(void *panel,uint32_t command) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(!owned(m,panel) || m->command)return 0;
    uint32_t state=phase(m);
    if(atomic_load_explicit(&m->terminal,memory_order_acquire)) {
        if(command!=SP_PREVIEW_EXIT || state!=SP_PREVIEW_NATIVE_FAULT)return 0;
        m->command=command;return 1;
    }
    if(command==SP_PREVIEW_SELECT_SYNTH || command==SP_PREVIEW_SELECT_GENERATOR) {
        if(state!=SP_PREVIEW_NATIVE_CHOOSER)return 0;
        if(command==SP_PREVIEW_SELECT_SYNTH && m->voice_used==UINT32_MAX)return 0;
        m->choice=command==SP_PREVIEW_SELECT_GENERATOR;return 1;
    }
    if(command==SP_PREVIEW_CONFIRM) {
        if(state!=SP_PREVIEW_NATIVE_CHOOSER || (!m->choice && m->voice_used==UINT32_MAX))return 0;
    } else if(command==SP_PREVIEW_EXIT || command==SP_PREVIEW_PANIC) {
        if(state<SP_PREVIEW_NATIVE_HOLD || state>SP_PREVIEW_NATIVE_ACTIVE)return 0;
    } else return 0;
    m->command=command;return 1;
}
static uint32_t pad_down(void *page,uint32_t id,uint32_t velocity,uint32_t r3) {
    if(page_owned(page)) {
        uint16_t record[3]={16,(uint16_t)id,(uint16_t)velocity};
        if(sp_synth_entry_owner_v552_page((void *)0x8300A3E4,record))return 1;
    }
    return ((Method)(uintptr_t)0x8015BF91)(page,id,velocity,r3);
}
static void seed_controls(SpPreviewNativeV552 *m) {
    for(unsigned index=1;index<=3;++index) {
        int value=((int (*)(uint32_t))(uintptr_t)0x800D9FF1)(index);
        if(value>=0 && value<=127)(void)sp_p4_controls_seed(&m->controls,(int32_t)index,value);
        else (void)sp_p4_controls_forget(&m->controls,(int32_t)index);
    }
}
static uint32_t button(void *page,uint32_t id,uint32_t r2,uint32_t r3) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(page_owned(page) && id==27 && phase(m)==SP_PREVIEW_NATIVE_ACTIVE &&
       !atomic_load_explicit(&m->terminal,memory_order_acquire) &&
       sp_synth_entry_owner_v552_control_offer((void *)0x8300A3E4,5,27,0)) {
        int shift=((int (*)(uint32_t))(uintptr_t)0x800D9F21)(42);
        if(!shift)seed_controls(m);
        return sp_p6_record_controls_v552_button(page,id,shift);
    }
    if(page_owned(page) && id==49 && phase(m)==SP_PREVIEW_NATIVE_ACTIVE &&
       !atomic_load_explicit(&m->terminal,memory_order_acquire) &&
       sp_synth_entry_owner_v552_control_offer((void *)0x8300A3E4,5,49,0)) {
        int shift=((int (*)(uint32_t))(uintptr_t)0x800D9F21)(42);
        if(!shift)seed_controls(m);
        if(sp_p6_record_controls_v552_button(page,id,shift))return 1;
        if(!sp_p6_menu_press(&m->controls,&m->voice,shift))fail(m,SP_PREVIEW_NATIVE_AUDIO);
        sp_demo_v552_event(SP_DEMO_VALUE_PRESS,SP_DEMO_DOWN,1,sp_synth_preview_voice_command(&m->voice));
        return 1;
    }
    if(page_owned(page) && (id==49 || id==34) &&
       sp_synth_entry_owner_v552_control_offer((void *)0x8300A3E4,5,(int32_t)id,0)) {
        if(id==49)sp_demo_v552_event(SP_DEMO_VALUE_PRESS,SP_DEMO_DOWN,1,0);
        if(id==34) {
            if(phase(m)==SP_PREVIEW_NATIVE_ACTIVE && sp_p6_record_controls_v552_button(page,id,
                ((int (*)(uint32_t))(uintptr_t)0x800D9F21)(42)))return 1;
            if(phase(m)==SP_PREVIEW_NATIVE_ACTIVE && sp_p6_menu_exit())return 1;
            if(((int (*)(void *))(uintptr_t)0x800CE421)(page)) {
                ((void (*)(void *))(uintptr_t)0x800C3EB9)(page);return 1;
            }
            if(((int (*)(void))(uintptr_t)0x800C3F19)()) {
                ((void (*)(void *))(uintptr_t)0x800C3EF9)(page);return 1;
            }
            if(((int (*)(uint32_t))(uintptr_t)0x800D9F21)(42)) {
                uint32_t *vtable=*(uint32_t **)page;
                ((void (*)(void *))(uintptr_t)vtable[0x150/4])(page);
                (void)sp_synth_preview_native_v552_select((void *)0x8300A3E4,SP_PREVIEW_PANIC);return 1;
            }
        }
        (void)sp_synth_preview_native_v552_select((void *)0x8300A3E4,
            id==49?SP_PREVIEW_CONFIRM:SP_PREVIEW_EXIT);return 1;
    }
    (void)m;
    return ((Method)(uintptr_t)0x8015C551)(page,id,r2,r3);
}
static uint32_t encoder(void *page,uint32_t id,uint32_t delta,uint32_t r3) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(page_owned(page) && id==0 && delta && phase(m)==SP_PREVIEW_NATIVE_ACTIVE &&
       !atomic_load_explicit(&m->terminal,memory_order_acquire) &&
       sp_synth_entry_owner_v552_control_offer((void *)0x8300A3E4,7,0,(int32_t)delta)) {
        int shift=((int (*)(uint32_t))(uintptr_t)0x800D9F21)(42);
        if(!shift)seed_controls(m);
        if(sp_p6_record_controls_v552_turn(page,(int32_t)delta,shift))return 1;
        if(!sp_p6_menu_turn(&m->controls,&m->voice,(int32_t)delta,shift))fail(m,SP_PREVIEW_NATIVE_AUDIO);
        sp_demo_v552_event(SP_DEMO_VALUE_TURN,SP_DEMO_RELATIVE,(int32_t)delta,sp_synth_preview_voice_command(&m->voice));
        return 1;
    }
    if(page_owned(page) && id==0 && delta &&
       sp_synth_entry_owner_v552_control_offer((void *)0x8300A3E4,7,0,(int32_t)delta)) {
        sp_demo_v552_event(SP_DEMO_VALUE_TURN,SP_DEMO_RELATIVE,(int32_t)delta,0);
        (void)sp_synth_preview_native_v552_select((void *)0x8300A3E4,
            (int32_t)delta>0?SP_PREVIEW_SELECT_GENERATOR:SP_PREVIEW_SELECT_SYNTH);return 1;
    }
    return ((Method)(uintptr_t)0x8015C531)(page,id,delta,r3);
}
static uint32_t ctrl(void *page,uint32_t id,uint32_t value,uint32_t r3) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(page_owned(page) && id>=1 && id<=3 && value<=127 &&
       sp_synth_entry_owner_v552_control_offer((void *)0x8300A3E4,9,(int32_t)id,(int32_t)value)) {
        sp_demo_v552_event((uint16_t)(SP_DEMO_CTRL1+id-1),SP_DEMO_ABSOLUTE,(int32_t)value,0);
        /* Native CTRL's own child predicate runs once, including its stale
         * child cleanup. Keep the native child sink before any synth edit. */
        if(((int (*)(void *))(uintptr_t)0x800CE421)(page)) {
            (void)((Method)(uintptr_t)0x800CC031)(page,id,value,r3);return 1;
        }
        /* Chooser/startup observations update only the physical baseline.
         * Only an admitted ACTIVE voice receives parameter commands. */
        if(phase(m)==SP_PREVIEW_NATIVE_ACTIVE &&
           !atomic_load_explicit(&m->terminal,memory_order_acquire)) {
            if(!sp_p4_controls_ctrl(&m->controls,&m->voice,(int32_t)id,(int32_t)value))
                fail(m,SP_PREVIEW_NATIVE_AUDIO);
        } else if(!atomic_load_explicit(&m->terminal,memory_order_acquire))
            (void)sp_p4_controls_seed(&m->controls,(int32_t)id,(int32_t)value);
        return 1;
    }
    return ((Method)(uintptr_t)0x8015CE09)(page,id,value,r3);
}
static uint32_t tick(void *page,uint32_t a,uint32_t b,uint32_t c) {
    uint32_t result=((Method)(uintptr_t)0x800735B1)(page,a,b,c);
    if(page_owned(page)) {
        sp_demo_v552_poll();
        SpPreviewNativeView view;
        if(sp_synth_preview_native_v552_snapshot((void *)0x8300A3E4,&view) &&
           !sp_synth_preview_native_v552_present(page,&view))fail(&sp_synth_preview_native_v552,SP_PREVIEW_NATIVE_DISPLAY);
    }
    return result;
}
static uint32_t destroy(void *object,uint32_t a,uint32_t b,uint32_t c,uintptr_t native,unsigned adjustment) {
    void *page=(void *)((uintptr_t)object-adjustment);
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(ready(m) && atomic_load_explicit(&m->active_page,memory_order_acquire)==page) {
        atomic_store_explicit(&m->active_page,0,memory_order_release);
        if(task()==m->task_id) {
            sp_synth_preview_native_v552_detach(page);
            if(!m->exit_requested)fail(m,SP_PREVIEW_NATIVE_LIFETIME);
        } else {
            atomic_store_explicit(&m->retired_page,page,memory_order_release);
            fail(m,SP_PREVIEW_NATIVE_LIFETIME);
        }
    }
    uint32_t result=((Method)native)(object,a,b,c);
    sp_p6_record_retirement_v552_destructor_return();
    return result;
}
static uint32_t complete(void *p,uint32_t a,uint32_t b,uint32_t c){return destroy(p,a,b,c,0x800CC859,0);}
static uint32_t deleting(void *p,uint32_t a,uint32_t b,uint32_t c){return destroy(p,a,b,c,0x8015CEF9,0);}
static uint32_t second_complete(void *p,uint32_t a,uint32_t b,uint32_t c){return destroy(p,a,b,c,0x801991C1,56);}
static uint32_t second_deleting(void *p,uint32_t a,uint32_t b,uint32_t c){return destroy(p,a,b,c,0x801991B1,56);}
static int normal_retired(SpPreviewNativeV552 *m) {
    return m->normal_stop_ticket && !atomic_load_explicit(&m->terminal,memory_order_acquire) &&
        !sp_synth_preview_voice_faults(&m->voice) &&
        !atomic_load_explicit(&m->entry.fault,memory_order_acquire) &&
        !atomic_load_explicit(&m->generator.fault,memory_order_acquire) &&
        sp_synth_preview_voice_idle_ack(&m->voice)==m->normal_stop_ticket &&
        sp_synth_preview_voice_permission_ack(&m->voice)==m->normal_stop_ticket &&
        m->route_ticket && !(m->route_ticket&1u) &&
        sp_synth_generator_route_v552_ack(&m->generator)==m->route_ticket &&
        atomic_load_explicit(&m->generator.requested,memory_order_acquire)==m->route_ticket;
}
static int bind(SpPreviewNativeV552 *m,void *page) {
    if(!page || (uintptr_t)page%4 || m->active_page || *(void *volatile *)(uintptr_t)0x80CFD4FC!=page)return 0;
    uint32_t *object=page;
    if(object[0]!=0x802295A8 || object[14]!=0x80229708 ||
       *(volatile uint16_t *)(uintptr_t)0x8024587A!=30 ||
       *(volatile uint16_t *)(uintptr_t)0x80245880!=30 ||
       *(volatile uint32_t *)(uintptr_t)0x8023B628!=
           ((uintptr_t)sp_synth_preview_native_v552_factory|1u))return 0;
    /* Stock constructs mode30 synchronously inside the copied sampler button
     * frame. Attach lifetime wrappers now, after native children complete.
     * HOLD grants no new input epoch or voice permission. Service cannot enter
     * until both real dispatch/sample frames have closed; no depth is cleared. */
    uint32_t state=phase(m);
    if(state!=SP_PREVIEW_NATIVE_PREPARED &&
       (state!=SP_PREVIEW_NATIVE_LEFT || !normal_retired(m) || m->entry.input.enabled ||
        m->retired_page || m->command))return 0;
    if(state==SP_PREVIEW_NATIVE_LEFT && !sp_p6_record_rearm_v552_constructor_ready())return 0;
    m->choice=0;m->stop_action=0;m->exit_requested=0;m->normal_stop_ticket=0;
    sp_p6_menu_init();seed_controls(m);
    m->active_page=page;object[0]=(uintptr_t)(m->primary+2);object[14]=(uintptr_t)(m->secondary+2);
    atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_HOLD,memory_order_release);return 1;
}
uint64_t sp_synth_preview_native_v552_pool(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    /* Native copy row5 restores both IDs to -1 on each true image startup.
     * The private reservation is outside native zero row10. Never inspect
     * its cold receipt until these independent copied words prove reuse. */
    volatile const int32_t *ids=(const void *)(uintptr_t)0x80245820;
    volatile const uint32_t *patch=(const void *)(uintptr_t)0x80002268;
    if((uintptr_t)__builtin_return_address(0)!=UINT32_C(0x80000B11) ||
       patch[0]!=UINT32_C(0x300CF24A) || patch[1]!=UINT32_C(0x310CF242) || patch[2]!=UINT32_C(0x3053F2C8) || patch[3]!=UINT32_C(0x3183F2C8))return 0;
    int32_t first=ids[0],second=ids[1];
    if(first>=0 && second>=0) {
        return sp_p6_production_cold_started()==1?sp_p6_production_cold_result():0;
    }
    if(first!=-1 || second!=-1 ||
       (uintptr_t)__synth_bss_start!=UINT32_C(0x83832310) ||
       (uintptr_t)__synth_bss_end<=(uintptr_t)__synth_bss_start ||
       (uintptr_t)__synth_bss_end>UINT32_C(0x8383A30C))return 0;

    for(volatile unsigned char *p=__synth_bss_start;p<__synth_bss_end;++p)*p=0;
    __asm__ volatile("dmb":::"memory");
    uint64_t result=((uint64_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(uintptr_t)0x80002261)(a,b,c,d);
    /* The native initializer checks the first pool twice. Independently
     * require the small pool too; failure never publishes synth owners. */
    if(patch[0]!=UINT32_C(0x300CF24A) || patch[1]!=UINT32_C(0x310CF242) || patch[2]!=UINT32_C(0x3053F2C8) || patch[3]!=UINT32_C(0x3183F2C8) || ids[0]<0 || ids[1]<0)return result;
    sp_synth_preview_native_v552.initialized=(uint32_t)sp_synth_generator_route_v552_init(&sp_synth_preview_native_v552.generator);
    sp_p6_production_cold_done(result);
    return result;
}
static int prepare(SpPreviewNativeV552 *m,const SpPreviewNativeConfigV552 *config) {
    if(m->initialized!=1 || m->attempted || atomic_load_explicit(&m->terminal,memory_order_acquire))return 0;
    m->attempted=1;
    uint32_t id=task();
    if(!config || config->trial_policy!=UINT32_C(0x50544E31) || id<1 || id>32 ||
       config->audio_task<1 || config->audio_task>32 || config->audio_task==id ||
       config->pair_index>6 || !config->control_lease_frames)return 0;
    const uint32_t *p=(const void *)(uintptr_t)0x802295A0,*s=(const void *)(uintptr_t)0x80229700;
    if(p[0] || p[1] || p[2]!=0x800CC859 || p[3]!=0x8015CEF9 || s[0]!=0xFFFFFFC8 ||
       s[1] || s[2]!=0x801991C1 || s[3]!=0x801991B1 || p[2+0x5C/4]!=0x800735B1 ||
       p[2+0xD8/4]!=0x8015C551 || p[2+0xE0/4]!=0x8015C531 ||
       p[2+0xE4/4]!=0x8015CE09)return 0;
    m->task_id=id;m->config=*config;
    if(!sp_synth_preview_voice_init(&m->voice,config->sample_rate) ||
       !sp_p4_controls_init(&m->controls) ||
       !sp_synth_preview_voice_lease(&m->voice,config->control_lease_frames) ||
       !sp_synth_entry_owner_v552_install(&m->entry,(void *)0x8300A3E4,publish,entry_stop,m))return 0;
    seed_controls(m);
    for(unsigned i=0;i<88;++i)m->primary[i]=p[i];
    for(unsigned i=0;i<7;++i)m->secondary[i]=s[i];
    m->primary[2]=(uintptr_t)complete;m->primary[3]=(uintptr_t)deleting;
    m->primary[2+0x5C/4]=(uintptr_t)tick;m->primary[2+0xD8/4]=(uintptr_t)button;
    m->primary[2+0xE0/4]=(uintptr_t)encoder;m->primary[2+0xE4/4]=(uintptr_t)ctrl;
    m->primary[2+0xFC/4]=(uintptr_t)pad_down;
    m->secondary[2]=(uintptr_t)second_complete;m->secondary[3]=(uintptr_t)second_deleting;
    atomic_store_explicit(&m->ready,1,memory_order_release);
    sp_demo_v552_init();sp_p6_menu_init();
    if(atomic_load_explicit(&m->terminal,memory_order_acquire)){sp_synth_preview_voice_stop(&m->voice);return 0;}
    return 1;
}
uint32_t sp_synth_preview_native_v552_panel_init(uint32_t a,uint32_t target,uint32_t c,uint32_t d) {
    uint32_t result=((uint32_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(uintptr_t)target)(a,target,c,d);
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(a==0x8300A3E4 && target==0x80072F81 && sp_synth_preview_native_v552_config && !m->attempted &&
       !prepare(m,sp_synth_preview_native_v552_config))fail(m,SP_PREVIEW_NATIVE_CONFIG);
    return result;
}
static void request_sampler(SpPreviewNativeV552 *m,void *page) {
    if(m->exit_requested || !sp_p6_record_retirement_v552_native_exit_allowed())return;
    /* A newly held SHIFT or child must not turn a queued EXIT into a chord or
     * close an unrelated child. A blocked native top request remains pending. */
    if(((int (*)(uint32_t))(uintptr_t)0x800D9F21)(42) ||
       ((int (*)(void *))(uintptr_t)0x800CE421)(page) ||
       ((int (*)(void))(uintptr_t)0x800C3F19)() ||
       ((int (*)(void))(uintptr_t)0x800D4A61)())return;
    uint32_t edit=*(volatile uint8_t *)(uintptr_t)0x80591C48;
    ((Method)(uintptr_t)0x8015C551)(page,34,0,0);
    /* Native EXIT first leaves editing when this byte is zero. Complete the
     * explicit return-to-sampler action through a second native EXIT then. */
    if(!edit && *(volatile uint8_t *)(uintptr_t)0x80591C48==1)
        ((Method)(uintptr_t)0x8015C551)(page,34,0,0);
    uint32_t requested=*(volatile uint16_t *)(uintptr_t)0x8024587C;
    if((requested==1 || requested==14) &&
       (*(volatile uint32_t *)(uintptr_t)0x8059245C & UINT32_C(0x8000)))
        m->exit_requested=1;
    else fail(m,SP_PREVIEW_NATIVE_LIFETIME);
}
uint32_t sp_synth_preview_native_v552_factory(const uint16_t *event) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    uint32_t type=*event;void *before=*(void *volatile *)(uintptr_t)0x80CFD4FC;
    sp_p6_record_retirement_v552_factory_enter(event);
    uint32_t result=((uint32_t (*)(const void *))(uintptr_t)0x80065449)(event);
    if(!ready(m) || task()!=m->task_id)return result;
    void *page=*(void *volatile *)(uintptr_t)0x80CFD4FC;
    if(type==1 && (phase(m)==SP_PREVIEW_NATIVE_PREPARED || phase(m)==SP_PREVIEW_NATIVE_LEFT) && page &&
       !atomic_load_explicit(&m->terminal,memory_order_acquire) && (before || !bind(m,page)))fail(m,SP_PREVIEW_NATIVE_LIFETIME);
    if(type==2 && before && !page) {
        if(!m->active_page && ((m->exit_requested && phase(m)==SP_PREVIEW_NATIVE_WAIT_NATIVE) ||
           (phase(m)==SP_PREVIEW_NATIVE_GENERATOR && normal_retired(m))))
            atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_LEFT,memory_order_release);
        else fail(m,SP_PREVIEW_NATIVE_LIFETIME);
    }
    sp_p6_record_retirement_v552_factory_return(event);
    return result;
}
void sp_synth_preview_native_v552_service(void *panel) {
    sp_p6_session_binding_v552_panel();
    sp_p6_record_rearm_v552_panel();
    sp_p6_record_request_v552_panel();
    (void)sp_p6_record_backend_v552_panel();
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(!owned(m,panel))return;
    if(m->entry.dispatch_depth || m->entry.sample_depth)return;
    sp_p6_record_retirement_v552_panel();
    sp_p6_record_rearm_v552_panel();
    sp_demo_v552_poll();
    void *retired=atomic_exchange_explicit(&m->retired_page,0,memory_order_acq_rel);
    if(retired)sp_synth_preview_native_v552_retire(retired);
    if(sp_synth_preview_voice_faults(&m->voice)&~SP_PREVIEW_STOP)fail(m,SP_PREVIEW_NATIVE_AUDIO);
    if(atomic_load_explicit(&m->generator.fault,memory_order_acquire))fail(m,SP_PREVIEW_NATIVE_ROUTE);
    if(atomic_load_explicit(&m->terminal,memory_order_acquire)) {
        if(m->entry.input.enabled)(void)sp_synth_entry_owner_v552_exit();
        if(phase(m)==SP_PREVIEW_NATIVE_LEFT)return;
        if(m->command==SP_PREVIEW_EXIT){m->command=0;m->stop_action=2;}
        if(m->stop_action==2 && sp_synth_preview_voice_stop_ack(&m->voice) && !m->exit_requested) {
            void *page=atomic_load_explicit(&m->active_page,memory_order_acquire);
            if(!page || *(void *volatile *)(uintptr_t)0x80CFD4FC!=page ||
               *(uint32_t *)page!=(uintptr_t)(m->primary+2))return;
            if(phase(m)!=SP_PREVIEW_NATIVE_WAIT_NATIVE && !atomic_load_explicit(&m->generator.fault,memory_order_acquire)) {
                m->route_ticket=sp_synth_generator_route_v552_request(&m->generator,SP_SYNTH_GENERATOR_NATIVE);
                if(m->route_ticket)atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_WAIT_NATIVE,memory_order_release);
            }
            if(phase(m)==SP_PREVIEW_NATIVE_WAIT_NATIVE && sp_synth_generator_route_v552_ack(&m->generator)==m->route_ticket) {
                request_sampler(m,page);
            }
        }
        if(phase(m)!=SP_PREVIEW_NATIVE_WAIT_NATIVE)atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_FAULT,memory_order_release);
        return;
    }
    uint32_t state=phase(m);
    if(m->active_page && (*(void *volatile *)(uintptr_t)0x80CFD4FC!=m->active_page ||
       *(uint32_t *)m->active_page!=(uintptr_t)(m->primary+2))) {fail(m,SP_PREVIEW_NATIVE_LIFETIME);return;}
    if(state==SP_PREVIEW_NATIVE_HOLD) {
        SpSynthEntryBoundaryV552 boundary;
        if(sp_synth_entry_owner_v552_enter(&boundary))atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_CHOOSER,memory_order_release);
    }
    if(m->command) {
        uint32_t command=m->command;m->command=0;
        if(command==SP_PREVIEW_CONFIRM && !m->choice && state==SP_PREVIEW_NATIVE_CHOOSER && m->voice_used!=UINT32_MAX) {
            m->route_ticket=sp_synth_generator_route_v552_request(&m->generator,SP_SYNTH_GENERATOR_DISCARD);
            if(!m->route_ticket){fail(m,SP_PREVIEW_NATIVE_ROUTE);return;}
            atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_WAIT_ROUTE,memory_order_release);
        } else {
            m->stop_action=command==SP_PREVIEW_CONFIRM?1u:2u;
            if(!sp_synth_entry_owner_v552_exit() ||
               !(m->normal_stop_ticket=sp_synth_preview_voice_quiesce(&m->voice))){
                fail(m,SP_PREVIEW_NATIVE_AUDIO);return;
            }
            atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_STOPPING,memory_order_release);
        }
    }
    state=phase(m);
    if(state==SP_PREVIEW_NATIVE_WAIT_ROUTE && sp_synth_generator_route_v552_ack(&m->generator)==m->route_ticket) {
        if(!sp_synth_preview_voice_pulse(&m->voice) || !sp_synth_preview_voice_admit(&m->voice,1)){fail(m,SP_PREVIEW_NATIVE_AUDIO);return;}
        m->permission_ticket=sp_synth_preview_voice_permission(&m->voice);
        atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_WAIT_AUDIO,memory_order_release);
    }
    if((phase(m)==SP_PREVIEW_NATIVE_WAIT_AUDIO || phase(m)==SP_PREVIEW_NATIVE_ACTIVE) &&
       !sp_synth_preview_voice_pulse(&m->voice)){fail(m,SP_PREVIEW_NATIVE_AUDIO);return;}
    if(phase(m)==SP_PREVIEW_NATIVE_WAIT_AUDIO && sp_synth_preview_voice_permission_ack(&m->voice)==m->permission_ticket) {
        ++m->voice_used;atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_ACTIVE,memory_order_release);
    }
    if(phase(m)==SP_PREVIEW_NATIVE_STOPPING && m->normal_stop_ticket &&
       sp_synth_preview_voice_idle_ack(&m->voice)==m->normal_stop_ticket) {
        m->route_ticket=sp_synth_generator_route_v552_request(&m->generator,SP_SYNTH_GENERATOR_NATIVE);
        if(!m->route_ticket){fail(m,SP_PREVIEW_NATIVE_ROUTE);return;}
        atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_WAIT_NATIVE,memory_order_release);
    }
    if(phase(m)==SP_PREVIEW_NATIVE_WAIT_NATIVE && sp_synth_generator_route_v552_ack(&m->generator)==m->route_ticket) {
        void *page=m->active_page;
        if(!page || *(void *volatile *)(uintptr_t)0x80CFD4FC!=page){fail(m,SP_PREVIEW_NATIVE_LIFETIME);return;}
        if(m->stop_action==2) {
            if(!m->exit_requested)request_sampler(m,page);
            return;
        }
        sp_synth_preview_native_v552_detach(page);
        uint32_t *object=page;object[0]=0x802295A8;object[14]=0x80229708;m->active_page=0;
        atomic_store_explicit(&m->phase,SP_PREVIEW_NATIVE_GENERATOR,memory_order_release);
    }
    if(m->active_page) {
        SpPreviewNativeView view;
        if(sp_synth_preview_native_v552_snapshot(panel,&view) &&
           !sp_synth_preview_native_v552_present(m->active_page,&view))fail(m,SP_PREVIEW_NATIVE_DISPLAY);
    }
}
void sp_synth_preview_native_v552_before_control(void *panel,uint32_t control) {
    if((control&1u) && owned(&sp_synth_preview_native_v552,panel))sp_synth_preview_native_v552_cancel();
}
static bool render(void *context,int16_t *stereo,uint32_t frames) {
    return sp_synth_preview_voice_render(context,stereo,frames*2,frames)==SP_PREVIEW_OK;
}
uint32_t sp_synth_preview_native_v552_audio(void *state,int32_t *work,int32_t frames,int32_t stride) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    int admitted=ready(m);
    if(admitted && ((uintptr_t)state!=0x80249800 || (uintptr_t)work!=0x202AD3A0 || frames!=64 || stride!=14 || task()!=m->config.audio_task)) {
        fail(m,SP_PREVIEW_NATIVE_CONTEXT);
        return ((uint32_t (*)(void *,int32_t *,int32_t,int32_t))(uintptr_t)0x1CB85)(state,work,frames,stride);
    }
    uint32_t result=sp_synth_generator_route_v552_dispatch(m->initialized?&m->generator:0,state,work,frames,stride);
    if(!admitted)return result;
    if(atomic_load_explicit(&m->terminal,memory_order_acquire) || sp_synth_preview_voice_faults(&m->voice)) {
        (void)sp_synth_preview_voice_render(&m->voice,m->scratch.stereo,128,64);return result;
    }
    SpSynthStockBlock block={work,896,64,(uint8_t)m->config.pair_index};
    if(sp_synth_stock_mix_block(&block,&m->scratch,render,&m->voice)!=SP_SYNTH_STOCK_OK)fail(m,SP_PREVIEW_NATIVE_AUDIO);
    else {
        register uintptr_t a0 __asm__("r0")=(uintptr_t)&m->voice;
        register uintptr_t a1 __asm__("r1")=(uintptr_t)m->scratch.stereo;
        register uintptr_t a2 __asm__("r2")=64;
        register uintptr_t a3 __asm__("r3")=(uintptr_t)work;
        __asm__ volatile("bl sp_p6_record_audio_v552_native\n.global sp_p6_record_audio_native_return\nsp_p6_record_audio_native_return:"
            : "+r"(a0),"+r"(a1),"+r"(a2),"+r"(a3) :
            : "r12","lr","cc","memory","s0","s1","s2","s3","s4","s5","s6","s7",
              "s8","s9","s10","s11","s12","s13","s14","s15");
        if(a0)sp_p6_production_pcm(&m->voice,m->scratch.stereo,64);
    }
    return result;
}
