#include "sp_p6_record_start_gate_v552.h"
#include "sp_p6_record_request_v552.h"
#include "sp_p6_record_audio_v552.h"
#include "sp_p6_record_retirement_v552.h"
#include "sp_p6_production_join.h"
#include "sp_p6_session_binding_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_native_service_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_token_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_record_project_gate_v552.h"
#include "sp_p6_record_joint_v552.h"
#include "sp_p6_record_ingress_alias_v552.h"
#include "sp_p6_transaction_ingress_v552.h"
#include "sp_synth_memory_v552.h"
#include <limits.h>
#include <stddef.h>
#include <string.h>

typedef struct {
    atomic_uint cold,bootstrap,fault;
    uint64_t result;
} SpP6StartProductionView;
extern SpP6StartProductionView sp_p6_production_state;
extern const unsigned char sp_tcapture_smpl_entry[],sp_tcapture_record_init_entry[];
/* The complete profile links the actual bounded retirement and private-owner
 * observers. An isolated object never substitutes successful readiness. */
__attribute__((weak)) uint32_t sp_p6_record_retirement_join_v552_bounded_blocks(void) {return UINT32_MAX;}
__attribute__((weak)) uint32_t sp_p6_record_start_capture_idle_v552(void) {return 0;}
__attribute__((weak)) uint32_t sp_p6_record_start_token_idle_v552(void) {return 0;}
__attribute__((weak)) uint32_t sp_p6_record_start_rec_init_v552_current(void) {return 0;}

_Static_assert(sizeof(SpP6StartProductionView)==24,"Actual production state ABI");
_Static_assert(offsetof(SpP6StartProductionView,bootstrap)==4,"Actual bootstrap ABI");
_Static_assert(offsetof(SpP6StartProductionView,fault)==8,"Actual fault ABI");
_Static_assert(sizeof(SpSynthCaptureTimedV552)==1336,"Current capture ABI");
_Static_assert(sizeof(SpSynthSessionV552)==3824,"Current session ABI");
_Static_assert(sizeof(SpSynthRuntimeStorage)==116032,"Current recording runtime ABI");
#define value(a) atomic_load_explicit((a),memory_order_acquire)
#define OUTER UINT32_C(0x82E0E71C)
#define NORMAL UINT32_C(0x82FE4F08)
static uint32_t rd(uintptr_t p) {return *(volatile const uint32_t *)p;}
static uint16_t rh(uintptr_t p) {return *(volatile const uint16_t *)p;}
static uint8_t rb(uintptr_t p) {return *(volatile const uint8_t *)p;}
static uint32_t native(uintptr_t p,uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return ((uint32_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(p|1u))(a,b,c,d);
}
static uint32_t lock(void) {uint32_t p;__asm__ volatile("mrs %0,primask\n cpsid i\n dmb":"=r"(p)::"memory");return p;}
static void unlock(uint32_t p) {__asm__ volatile("dmb\n msr primask,%0"::"r"(p):"memory");}
static uint32_t context(void) {
    uint32_t i,p,b,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));__asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(b));__asm__ volatile("mrs %0,faultmask":"=r"(f));
    if(i || p || b || f || rd(0x202BBBF8) || rd(0x80245764))return 0;
    uint32_t task=native(0x800D3162,0,0,0,0);
    return task && task<=32 && task==sp_p6_record_contexts_v552.smpl_task &&
        rd(0x202ACD00)==0x8022D244 && rd(0x202ACD04)==task &&
        sp_p6_record_context_v552_registered() && sp_p6_record_context_v552_current(1);
}
static int profile(const SpAppRequest *r,const SpP6SessionBindingV552 *b) {
    SpAppCapture expected;
    return b->settings.source==SP_P6_SOURCE_SYNTH_ONLY && b->settings.mode==SP_P6_PHRASE_MANUAL &&
        b->settings.bars==4 && !b->settings.count_in_bars && !b->settings.include_release_tail &&
        sp_p6_phrase_capture_profile(&b->settings,b->pattern.tempo100,&expected) &&
        !memcmp(&expected,&r->capture,sizeof(expected)) &&
        !r->release_start_frames && !r->tail_cut_reason;
}

/* The native getters here only read their objects. The brief mask keeps the
 * current project/storage/tempo/selected-cache observation coherent. No file,
 * allocator, recorder or native pattern setter runs in this section. */
static uint32_t destination(const SpAppRequest *r,const SpP6SessionBindingV552 *b) {
    if(r->bank>=10 || r->index<1 || r->index>16 || r->replace ||
       r->bank!=b->settings.destination_bank || r->index!=b->settings.destination_pad)
        return SP_P6_SG_DESTINATION;
    uint32_t index=(uint32_t)r->bank*16u+r->index-1u,mask=lock();
    uint32_t project=native(0x800E1190,0,0,0,0);
    uint32_t storage=native(0x800D94D8,0x82E01144,132,0,0);
    uint32_t tempo=native(0x800D94D8,0x82E01144,27,0,0);
    uint32_t channels=native(0x800DC6B8,0x82E2CD08,101,index,0),busy=0;
    if(rd(UINT32_C(0x82E2CD08)+172u*index+208u))busy=1;
    for(unsigned i=0;i<38;++i) {
        uintptr_t row=UINT32_C(0x82E111C8)+304u*index+8u*i;
        if(rb(row) || rd(row+4)!=UINT32_MAX)busy=1;
    }
    unlock(mask);
    return project>=128 || project!=b->pattern.project || project!=b->destination.project ||
        storage || tempo!=b->pattern.tempo100 || channels || busy?SP_P6_SG_DESTINATION:0;
}
static int native_idle(void) {
    int32_t handle=(int32_t)rd(NORMAL+432);
    /* The stock cold ctor leaves this member at BSS zero. Native OPEN
     * 800D9CC0 allocates descriptor IDs from 1; zero is usable here only
     * before the first take, with the authenticated cold REC receipt and
     * the reserved descriptor/cache slot still empty. */
    int cold_zero=!handle && !sp_p6_production_capture.last_token &&
        sp_p6_record_start_rec_init_v552_current() &&
        !rd(0x80B5F3B4) && !rb(0x80B5F3B4+4096);
    if(rb(OUTER+57) || rb(OUTER+590) || (int32_t)rd(OUTER+72)>=0 || rd(OUTER+592) ||
       rd(OUTER+596)!=NORMAL || rd(NORMAL)!=0x8021E020 || (handle>=0 && !cold_zero) ||
       rd(NORMAL+420)>=30 || rd(NORMAL+424)>=30 || rd(NORMAL+420)!=rd(NORMAL+424))return 0;
    for(unsigned i=0;i<30;++i)if(rb(NORMAL+60+12u*i) || rd(NORMAL+64+12u*i))return 0;
    /* Ordinary queued stock work is retained; the bounded first test waits for
     * all three command-ring heads and Param envelopes to become empty. */
    const uintptr_t pairs[][2]={{0x805917E0,0x805917E4},{0x805917A4,0x805917A8},
        {0x805917AC,0x805917B0},{0x805917D8,0x805917DC}};
    const uint32_t bound[]={4096,128,128,128};
    for(unsigned i=0;i<4;++i)if(rd(pairs[i][0])>=bound[i] || rd(pairs[i][0])!=rd(pairs[i][1]))return 0;
    return !rh(0x82E0D624+20) && !rh(0x82E0D624+44) &&
        rd(0x82E0E5F8+4)<=8 && rd(0x82E0E5F8+4)==rd(0x82E0E5F8+8);
}
/* The prior LEAVE retains its once-issued exit request after successful
 * deletion/release. A new binding may admit START only against that exact
 * historical release and the source-owned rearm commit. This is read-only;
 * tickets, token history, clocks and faults are never cleared here. */
/* rx_window() is the sole RX window owner. After token/file cleanup it
 * already retires an old sealed/canceled window before arming the next real
 * token. BEGIN may observe that exact pending retirement; it must not mutate
 * the RX object or accept failed/inflight/unacknowledged history. */
static int completed_window(void) {
    const SpSynthCaptureTimedV552 *c=&sp_p6_production_capture;
    const SpSynthCaptureWindow *w=&c->window;
    if(value(&c->cleanup_token)!=c->last_token)return 0;
    if(w->phase==SP_CAPTURE_WINDOW_RETIRED)return 1;
    return (w->phase==SP_CAPTURE_WINDOW_SEALED || w->phase==SP_CAPTURE_WINDOW_CANCELED) &&
        !w->inflight && !w->native_failed && !w->failed_accepted &&
        w->last_token==c->last_token && w->start.take_token==c->last_token &&
        c->plan.take_token==c->last_token && w->start.start_generation==c->plan.start_generation;
}
static int completed_prior_exit(void) {
    const SpSynthCaptureTimedV552 *c=&sp_p6_production_capture;
    const SpP6RecordRetirementV552 *r=&sp_p6_record_retirement_v552;
    const SpP6RecordRequestV552 *q=&sp_p6_record_request_v552;
    const SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
    return c->exit_requested==1 && value(&r->phase)==SP_P6_RR_EMPTY &&
        !value(&r->released) && !value(&r->blocked) && !r->destructor_returned &&
        r->ticket && r->released_ticket==r->ticket && r->released_lifetime==r->lifetime &&
        r->lifetime && r->intent && value(&c->exit_ticket)==r->ticket &&
        value(&c->released_ticket)==r->ticket && c->last_ticket==r->ticket &&
        r->take_token==c->last_token && c->plan.take_token==r->take_token &&
        c->plan.start_generation==r->start_generation &&
        q->visit>r->lifetime && q->intent>r->intent && q->generation>r->start_generation &&
        b->visit==q->visit && b->sequence==q->intent && value(&b->pending)==q->intent &&
        b->page==q->page && b->task==q->task;
}
uint32_t sp_p6_record_start_gate_v552_blocked(void) {
    if(!context())return SP_P6_SG_CONTEXT;
    if(value(&sp_p6_production_state.cold)!=1 || value(&sp_p6_production_state.bootstrap)!=2 ||
       value(&sp_p6_production_state.fault))return SP_P6_SG_BOOTSTRAP;
    SpSynthSessionV552 *s=&sp_p6_production_session;
    SpSynthCaptureTimedV552 *c=&sp_p6_production_capture;
    SpP6RecordRequestV552 *q=&sp_p6_record_request_v552;
    SpP6RecordAudioV552 *audio=&sp_p6_record_audio_v552;
    SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
    SpP6NativeServiceV552 *cadence=&sp_p6_native_service_v552;
    SpP6RecordProducerV552 *producer=&sp_p6_record_producer_v552;
    SpP6RecordFilesV552 *files=&sp_p6_record_files_v552;
    uint32_t blocked=0,revision=value(&audio->revision);
    uintptr_t p=(uintptr_t)s->startup.memory.storage;
    if(!p || (p&7u) || p<SP_SYNTH_V552_POOL_BEGIN || p>SP_SYNTH_V552_POOL_END-sizeof(SpSynthRuntimeStorage) ||
       s->startup.ready!=1 || s->startup.memory.attached!=1 || !s->startup.memory.allocation ||
       value(&s->ready)!=1 || value(&s->control_ready)!=1 || value(&s->terminal) ||
       sp_p6_record_audio_v552_session()!=s)return SP_P6_SG_SESSION;
    SpSynthRuntimeStorage *runtime=(void *)p;
    SpSynthApp *a=&runtime->controller;
    SpSynthBackendLink *link=&s->backend;
    const SpAppRequest *r=&link->request;
    if(value(&c->backend)!=link || value(&link->request_phase)!=2 || value(&link->responses.phase) ||
       value(&link->responses.stopped) || value(&link->capture_cancel_phase) ||
       value(&q->fault) || value(&q->phase)!=SP_P6_RQ_WORKING ||
       r->type!=SP_APP_REQUEST_CAPTURE_START || !r->generation || r->token ||
       q->working_generation!=r->generation || q->generation!=r->generation ||
       q->request_type!=SP_APP_REQUEST_CAPTURE_START || !q->intent || !q->visit ||
       !c->working || c->response_ready || c->closed_request || c->start_admitted || c->start_canceled ||
       memcmp(&c->work,r,sizeof(*r)) || sp_p6_record_request_v552_claim()!=r)
        blocked|=SP_P6_SG_REQUEST;
    if(!profile(r,b) || memcmp(&a->capture,&r->capture,sizeof(r->capture)))blocked|=SP_P6_SG_PROFILE;
    if(a->request_count || a->request_issued_generation!=r->generation || a->audio_pending || a->audio_batch ||
       a->audio_faulted || a->event_count || a->batch_failed || !a->ui.busy ||
       a->ui.pending!=SP_UI_CMD_CAPTURE_START || a->ui.page!=SP_UI_CAPTURE_READY ||
       a->ui.generation!=r->generation || a->ui.take_token || a->ui.revision!=r->revision ||
       a->ui.dest_pad!=r->index || a->ui.dest_bank!=r->bank ||
       a->audio_sequence!=q->audio_sequence || runtime->controls.count || runtime->controls.faulted ||
       runtime->midi.count || runtime->midi.fault || runtime->audio.faulted ||
       !sp_synth_engine_quiescent(&runtime->audio.engine) || value(&runtime->mailbox.phase)!=SP_AUDIO_FREE ||
       value(&runtime->mailbox.stop_requested) || value(&runtime->mailbox.stopped))blocked|=SP_P6_SG_AUDIO;
    SpP6RecordAudioReceiptV552 receipt;
    if((revision&1u) || value(&audio->gate) || value(&audio->audio_active) ||
       !sp_p6_record_audio_v552_acknowledged(q->audio_sequence) ||
       !sp_p6_record_audio_v552_receipt(&receipt) || receipt.visit!=q->visit || receipt.intent!=q->intent ||
       receipt.generation!=r->generation || !receipt.sequence || receipt.sample_end-receipt.sample_start!=64 ||
       receipt.mailbox_sequence<q->audio_sequence ||
       !sp_p6_record_audio_v552_source_current(q->visit,q->intent,r->generation))blocked|=SP_P6_SG_AUDIO;
    /* This PCM producer still uses the legacy joint clock. Observe the same
     * current provider before OPEN; a fresh request/audio receipt alone cannot
     * prove that its next PCM block will be accepted. Callback-relative
     * recording needs no downbeat flag. */
    SpP6ClockReceiptV552 joint_clock;
    int joint_valid=sp_p6_record_joint_v552_read(&joint_clock,0);
    if(joint_valid!=1 || joint_clock.abi!=SP_P6_CLOCK_ABI ||
       !joint_clock.epoch || !joint_clock.sequence ||
       (joint_clock.flags&(SP_P6_CLOCK_NOMINAL|SP_P6_CLOCK_BLOCK_BOUNDARY))!=
           (SP_P6_CLOCK_NOMINAL|SP_P6_CLOCK_BLOCK_BOUNDARY) ||
       joint_clock.project!=b->pattern.project || joint_clock.tempo100!=b->pattern.tempo100 ||
       joint_clock.pcm_rate!=48000 || joint_clock.maximum_block_frames!=64 ||
       joint_clock.pcm_end-joint_clock.pcm_begin!=64)blocked|=SP_P6_SG_AUDIO;
    if(joint_valid==1 && (joint_clock.sequence==UINT32_MAX ||
       joint_clock.pcm_end>UINT32_MAX-64u))blocked|=SP_P6_SG_EXHAUSTED;
    unsigned state=value(&c->state);
    if((state!=SP_TCAP_FREE && state!=SP_TCAP_EXCLUSIVE_IDLE) || value(&c->fault) || value(&c->handoff_fault) ||
       value(&c->handoff_pending) || value(&c->token) || value(&c->rx_active) || value(&c->permit) ||
       c->file_owned || c->window.inflight || c->sample_rate_hz!=48000 || value(&c->record_ready)!=1 ||
       value(&c->notice_ready) || value(&c->fence_phase) ||
       (c->exit_requested && !completed_prior_exit()) ||
       (c->last_token && !completed_window()) || !sp_p6_record_start_capture_idle_v552() ||
       !sp_p6_record_start_token_idle_v552())blocked|=SP_P6_SG_CAPTURE;
    if(producer->capture!=c || producer->held || producer->active || producer->token || producer->fault ||
       producer->pending || producer->drain_requested || files->active || files->fault || files->smpl_operation ||
       files->record_operation || files->cache_depth || sp_p6_record_files_v552_outstanding() ||
       sp_p6_record_token_v552_current() || sp_p6_record_project_gate_v552.active ||
       sp_p6_record_project_gate_v552.count || sp_p6_record_project_gate_v552.fault ||
       !sp_p6_ia_v552_quiescent() || !sp_p6_tx_v552_quiescent())blocked|=SP_P6_SG_PRODUCER;
    if(!value(&cadence->installed) || value(&cadence->fault) || value(&cadence->active) ||
       !(rd(0x202ACD0C)&128u) || rd(0x202ACD4C)!=4 ||
       rd(0x8022D264)!=((uintptr_t)sp_tcapture_smpl_entry|1u) ||
       rd(0x8021F388)!=((uintptr_t)sp_tcapture_record_init_entry|1u) ||
       sp_p6_record_retirement_join_v552_bounded_blocks())blocked|=SP_P6_SG_HOOK;
    if(c->last_token==UINT32_MAX || r->generation==UINT32_MAX || q->control_calls==UINT32_MAX ||
       q->backend_takes==UINT32_MAX || q->backend_finishes==UINT32_MAX ||
       value(&c->barrier_sequence)==UINT32_MAX || c->last_ticket==UINT32_MAX ||
       sp_p6_record_project_gate_v552.generation==UINT32_MAX || files->serial==UINT32_MAX ||
       value(&cadence->blocks)==UINT32_MAX || value(&cadence->visits)==UINT32_MAX ||
       value(&audio->sequence)==UINT32_MAX || value(&audio->sample)>UINT32_MAX-64u ||
       a->audio_sequence==UINT32_MAX)blocked|=SP_P6_SG_EXHAUSTED;
    uint32_t mask=lock();int idle=native_idle();unlock(mask);
    if(!idle)blocked|=SP_P6_SG_NATIVE;
    blocked|=destination(r,b);
    if(value(&audio->revision)!=revision || value(&audio->audio_active))blocked|=SP_P6_SG_AUDIO;
    return blocked;
}
uint32_t sp_p6_record_start_gate_v552_admit(void) {return sp_p6_record_start_gate_v552_blocked()==0;}
