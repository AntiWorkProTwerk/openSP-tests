"""Authenticate relative source/archive/tool identities for a standalone build."""
import hashlib
import io
import json
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath

def sha(body): return hashlib.sha256(body).hexdigest()
def need(value, why):
    if not value: raise ValueError(why)

def check_bundle(root, expected):
    body=(root/'AUTHORITY.json').read_bytes()
    need(sha(body)==expected,'Standalone authority has no reviewed admission')
    authority=json.loads(body)
    need(authority['schema']=='opensp-standalone-owned-source-authority-v1','Authority schema differs')
    expected_files=set(authority['files'])|{'AUTHORITY.json','launch.py'}
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    need(actual==expected_files,'Standalone bundle has undeclared files/import alternatives')
    for name,pin in authority['files'].items():
        path=(root/name).resolve()
        need(path.is_relative_to(root) and not (root/name).is_symlink(),'Source authority path escapes root')
        raw=path.read_bytes()
        need(len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],'Standalone dependency changed: '+name)
    return authority

def archive_members(root, authority, role):
    contract=authority['roles'][role]
    raw=(root/contract['archive']).read_bytes()
    need(sha(raw)==contract['archive_sha256'],'Source archive differs')
    expected=contract['members'];members={};seen=set()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries=archive.infolist()
        need(len(entries)==len(expected),'Source archive member count differs')
        for entry in entries:
            name=entry.filename
            need(entry.orig_filename==name and name and not name.startswith('/') and ':' not in name and
                 '\\' not in name and all(p not in ('','.','..') and p.rstrip(' .')==p for p in name.split('/')) and
                 PurePosixPath(name).as_posix()==name,'Noncanonical source archive path')
            need(name not in members and name.casefold() not in seen,'Duplicate source archive member')
            need(name in expected,'Unexpected source archive member')
            need(not entry.is_dir() and stat.S_IFMT(entry.external_attr>>16) in (0,stat.S_IFREG) and
                 not entry.flag_bits&1 and entry.file_size==expected[name]['bytes'] and entry.file_size<=2*1024*1024,
                 'Source archive member type/extent differs')
            body=archive.read(entry)
            need(sha(body)==expected[name]['sha256'],'Source archive member changed')
            members[name]=body;seen.add(name.casefold())
    need(set(members)==set(expected),'Source archive member set differs')
    return members

def materialize(root, authority, role, output):
    members=archive_members(root,authority,role)
    destination=output/role;destination.mkdir()
    sources=destination/'source';sources.mkdir()
    for name,body in members.items():
        parent=sources if authority['roles'][role]['members'][name]['original'] else destination
        path=parent/name;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(body)
    check_sources(authority,role,sources)
    return sources

def check_sources(authority, role, root):
    expected={name:pin for name,pin in authority['roles'][role]['members'].items() if pin['original']}
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    need(actual==set(expected),'Role source namespace contains undeclared files/import alternatives')
    for name,pin in expected.items():
        path=(root/name).resolve();raw=path.read_bytes()
        need(path.is_relative_to(root) and not (root/name).is_symlink() and
             len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],'Role source differs: '+name)
    return expected

def check_tools(root, authority, bundle):
    raw=(bundle/'TOOLCHAIN_AUTHORITY.json').read_bytes()
    need(sha(raw)==authority['toolchain_authority_sha256'],'Toolchain authority differs')
    manifest=json.loads(raw)
    for name,names in manifest['namespaces'].items():
        actual=sorted(p.relative_to(root/name).as_posix() for p in (root/name).rglob('*') if p.is_file())
        need(actual==names,'Unreviewed compiler namespace input: '+name)
    for name,pin in manifest['files'].items():
        path=(root/name).resolve();raw=path.read_bytes()
        need(path.is_relative_to(root) and len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],
             'Pinned compiler input differs: '+name)
    return len(manifest['files'])

def check_python(authority):
    need(sys.platform=='win32' and tuple(sys.version_info[:3])==(3,12,14),'Reviewed Python release differs')
    need(sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode,
         'Run Python with -I -S -B; site/user paths and bytecode are not admitted')
    contract=authority['python_role']
    need(sha(Path(sys.executable).read_bytes()) in contract['launcher_sha256'],'Interpreter launcher differs')
    need(sha(Path(sys._base_executable).read_bytes())==contract['base_executable_sha256'],'Base interpreter differs')
    for name,digest in contract['base_binary_files'].items():
        need(sha((Path(sys.base_prefix)/name).read_bytes())==digest,'Python role binary differs: '+name)
    # -S avoids sitecustomize, user-site and venv-site initialization. The
    # interpreter/base release and actual base binary identities bind the role;
    # no user-specific installation path or pyvenv.cfg digest grants authority.
    return dict(version='3.12.14',isolated=True,site_disabled=True,bytecode_disabled=True,
                role_bound=True,stdlib_and_os_reads_traced=False)
