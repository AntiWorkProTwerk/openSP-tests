#ifndef SP_SYNTH_FACTORY_UI_H
#define SP_SYNTH_FACTORY_UI_H
#include "sp_synth_ui.h"
/* Optional UI catalog; core preset/codec code has no UI dependency. */
extern const sp_ui_patch sp_synth_factory_ui[128];
#endif
