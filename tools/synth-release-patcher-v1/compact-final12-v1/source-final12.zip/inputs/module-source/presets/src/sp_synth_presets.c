#include "sp_synth_presets.h"

const SpPreset *sp_synth_preset_at(size_t index) {
    return index < SP_PRESET_COUNT ? &sp_synth_factory_presets[index] : 0;
}

const SpPreset *sp_synth_preset_find(uint32_t id) {
    size_t i;
    for (i = 0; i < SP_PRESET_COUNT; ++i)
        if (sp_synth_factory_presets[i].id == id) return &sp_synth_factory_presets[i];
    return 0;
}

int sp_synth_preset_is_factory(uint32_t id) {
    return sp_synth_preset_find(id) != 0;
}

const char *sp_synth_preset_category_name(uint8_t category) {
    static const char *const names[] = {
        "All", "Bass", "Leads", "Pads", "Keys", "Plucks", "Brass",
        "Percussion", "Textures"
    };
    return category <= SP_PRESET_TEXTURE ? names[category] : 0;
}
