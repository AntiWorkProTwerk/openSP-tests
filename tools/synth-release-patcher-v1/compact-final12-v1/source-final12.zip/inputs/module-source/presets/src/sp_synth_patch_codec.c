#include "sp_synth_presets.h"
#include <float.h>
#include <math.h>
#include <string.h>

_Static_assert(sizeof(float) == 4 && FLT_RADIX == 2 && FLT_MANT_DIG == 24 &&
               FLT_MAX_EXP == 128, "patch format requires IEEE binary32");

enum {
    HEADER_SIZE = 16,
    MACRO_OFFSET = HEADER_SIZE + 8 + SP_PRESET_NAME_CAPACITY + SP_PRESET_INTENT_CAPACITY,
    MACRO_SIZE = SP_PRESET_MACRO_LABEL_CAPACITY + 16,
    PARAMETER_OFFSET = MACRO_OFFSET + 3 * MACRO_SIZE,
    PATCH_WORDS = 0
#define SP_FIELD_FLOAT(field, low, high) + 1
#define SP_FIELD_UINT(field, low, high) + 1
#include "sp_synth_patch_fields.inc"
#undef SP_FIELD_FLOAT
#undef SP_FIELD_UINT
    , RECORD_SIZE = PARAMETER_OFFSET + PATCH_WORDS * 4
};

static void put32(uint8_t *p, uint32_t value) {
    p[0] = (uint8_t)value; p[1] = (uint8_t)(value >> 8);
    p[2] = (uint8_t)(value >> 16); p[3] = (uint8_t)(value >> 24);
}

static uint32_t get32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void put_float(uint8_t *p, float value) {
    uint32_t bits;
    memcpy(&bits, &value, sizeof(bits));
    put32(p, bits);
}

static float get_float(const uint8_t *p) {
    uint32_t bits = get32(p);
    float value;
    memcpy(&value, &bits, sizeof(value));
    return value;
}

static uint32_t record_crc(const uint8_t *bytes, size_t length) {
    uint32_t crc = UINT32_C(0xFFFFFFFF);
    size_t i;
    unsigned bit;
    for (i = 0; i < length; ++i) {
        if (i >= 12 && i < 16) continue;
        crc ^= bytes[i];
        for (bit = 0; bit < 8; ++bit)
            crc = (crc >> 1) ^ (UINT32_C(0xEDB88320) & (0u - (crc & 1u)));
    }
    return ~crc;
}

static int string_valid(const char *value, size_t capacity) {
    size_t i;
    int ended = 0;
    if (!value[0]) return 0;
    for (i = 0; i < capacity; ++i) {
        unsigned char c = (unsigned char)value[i];
        if (!c) ended = 1;
        else if (ended || c < 32 || c > 126) return 0;
    }
    return ended;
}

size_t sp_synth_preset_record_size(void) { return RECORD_SIZE; }

int sp_synth_preset_valid(const SpPreset *preset) {
    unsigned i;
    if (!preset || !preset->id || preset->category < SP_PRESET_BASS ||
        preset->category > SP_PRESET_TEXTURE || preset->favorite > 1 ||
        !string_valid(preset->name, sizeof(preset->name)) ||
        !string_valid(preset->intent, sizeof(preset->intent))) return 0;
    for (i = 0; i < 3; ++i) {
        const SpPresetMacro *m = &preset->macro_controls[i];
        SpSynthParamRange range;
        if (!string_valid(m->label, sizeof(m->label)) || m->logarithmic > 1 ||
            m->parameter >= SP_PARAM_COUNT || m->parameter == SP_PARAM_GAIN ||
            (m->parameter >= SP_PARAM_MACRO1 && m->parameter <= SP_PARAM_MACRO3) ||
            !sp_synth_param_range((SpSynthParam)m->parameter, &range) ||
            !isfinite(m->minimum) || !isfinite(m->maximum) ||
            m->minimum < range.minimum || m->maximum > range.maximum ||
            m->minimum >= m->maximum || (m->logarithmic && m->minimum <= 0)) return 0;
    }
#define SP_FIELD_FLOAT(field, low, high) \
    if (!isfinite(preset->patch.field) || preset->patch.field < (low) || \
        preset->patch.field > (high)) return 0;
#define SP_FIELD_UINT(field, low, high) \
    if ((uint32_t)preset->patch.field - (uint32_t)(low) > \
        (uint32_t)(high) - (uint32_t)(low)) return 0;
#include "sp_synth_patch_fields.inc"
#undef SP_FIELD_FLOAT
#undef SP_FIELD_UINT
    return sp_synth_patch_valid(&preset->patch);
}

int sp_synth_preset_macro_value(const SpPreset *preset, uint32_t macro,
                                 float normalized, SpSynthParam *parameter, float *value) {
    const SpPresetMacro *m;
    if (!parameter || !value || macro >= 3 || !isfinite(normalized) ||
        normalized < 0 || normalized > 1 || !sp_synth_preset_valid(preset)) return 0;
    m = &preset->macro_controls[macro];
    *parameter = (SpSynthParam)m->parameter;
    if (normalized == 0) *value = m->minimum;
    else if (normalized == 1) *value = m->maximum;
    else {
        /* Subtract finite logarithms: maximum/minimum can overflow even
         * when both endpoints are valid. Clamp rounding at either endpoint. */
        float low = m->logarithmic ? logf(m->minimum) : m->minimum;
        float high = m->logarithmic ? logf(m->maximum) : m->maximum;
        float result = low + normalized * (high - low);
        if (m->logarithmic) result = expf(result);
        *value = result < m->minimum ? m->minimum :
                 result > m->maximum ? m->maximum : result;
    }
    return 1;
}

SpPresetStatus sp_synth_preset_encode(const SpPreset *preset, uint8_t *bytes,
                                     size_t capacity, size_t *written) {
    size_t cursor = PARAMETER_OFFSET;
    unsigned i;
    if (written) *written = 0;
    if (!preset || !bytes || !written) return SP_PRESET_ARGUMENT;
    if (!sp_synth_preset_valid(preset)) return SP_PRESET_INVALID;
    if (capacity < RECORD_SIZE) return SP_PRESET_CAPACITY;
    memset(bytes, 0, RECORD_SIZE);
    memcpy(bytes, "SPSP", 4);
    bytes[4] = SP_PRESET_VERSION;
    bytes[6] = HEADER_SIZE;
    put32(bytes + 8, RECORD_SIZE);
    put32(bytes + 16, preset->id);
    bytes[20] = preset->category;
    bytes[21] = preset->favorite;
    memcpy(bytes + 24, preset->name, SP_PRESET_NAME_CAPACITY);
    memcpy(bytes + 24 + SP_PRESET_NAME_CAPACITY, preset->intent, SP_PRESET_INTENT_CAPACITY);
    for (i = 0; i < 3; ++i) {
        const SpPresetMacro *m = &preset->macro_controls[i];
        uint8_t *p = bytes + MACRO_OFFSET + i * MACRO_SIZE;
        memcpy(p, m->label, SP_PRESET_MACRO_LABEL_CAPACITY);
        put32(p + 12, m->parameter); put32(p + 16, m->logarithmic);
        put_float(p + 20, m->minimum); put_float(p + 24, m->maximum);
    }
#define SP_FIELD_FLOAT(field, low, high) \
    put_float(bytes + cursor, preset->patch.field); cursor += 4;
#define SP_FIELD_UINT(field, low, high) \
    put32(bytes + cursor, (uint32_t)preset->patch.field); cursor += 4;
#include "sp_synth_patch_fields.inc"
#undef SP_FIELD_FLOAT
#undef SP_FIELD_UINT
    put32(bytes + 12, record_crc(bytes, RECORD_SIZE));
    *written = RECORD_SIZE;
    return SP_PRESET_OK;
}

SpPresetStatus sp_synth_preset_decode(const uint8_t *bytes, size_t length,
                                     SpPreset *preset) {
    SpPreset decoded;
    size_t cursor = PARAMETER_OFFSET;
    unsigned i;
    if (!bytes || !preset) return SP_PRESET_ARGUMENT;
    if (length < HEADER_SIZE) return SP_PRESET_TRUNCATED;
    if (length > RECORD_SIZE) return SP_PRESET_OVERSIZED;
    if (memcmp(bytes, "SPSP", 4)) return SP_PRESET_MAGIC;
    if (bytes[4] != SP_PRESET_VERSION || bytes[5] ||
        bytes[6] != HEADER_SIZE || bytes[7]) return SP_PRESET_UNSUPPORTED;
    if (get32(bytes + 8) > RECORD_SIZE) return SP_PRESET_OVERSIZED;
    if (length < RECORD_SIZE || get32(bytes + 8) != RECORD_SIZE)
        return SP_PRESET_TRUNCATED;
    if (get32(bytes + 12) != record_crc(bytes, length)) return SP_PRESET_CRC;
    if (bytes[22] || bytes[23]) return SP_PRESET_INVALID;
    memset(&decoded, 0, sizeof(decoded));
    decoded.id = get32(bytes + 16);
    decoded.category = bytes[20];
    decoded.favorite = bytes[21];
    memcpy(decoded.name, bytes + 24, SP_PRESET_NAME_CAPACITY);
    memcpy(decoded.intent, bytes + 24 + SP_PRESET_NAME_CAPACITY, SP_PRESET_INTENT_CAPACITY);
    for (i = 0; i < 3; ++i) {
        SpPresetMacro *m = &decoded.macro_controls[i];
        const uint8_t *p = bytes + MACRO_OFFSET + i * MACRO_SIZE;
        memcpy(m->label, p, SP_PRESET_MACRO_LABEL_CAPACITY);
        m->parameter = get32(p + 12); m->logarithmic = get32(p + 16);
        m->minimum = get_float(p + 20); m->maximum = get_float(p + 24);
    }
#define SP_FIELD_FLOAT(field, low, high) \
    decoded.patch.field = get_float(bytes + cursor); cursor += 4;
#define SP_FIELD_UINT(field, low, high) \
    decoded.patch.field = get32(bytes + cursor); cursor += 4;
#include "sp_synth_patch_fields.inc"
#undef SP_FIELD_FLOAT
#undef SP_FIELD_UINT
    if (!sp_synth_preset_valid(&decoded)) return SP_PRESET_INVALID;
    *preset = decoded;
    return SP_PRESET_OK;
}
