#include "sp_synth_capture_window_v552.h"
#define OUTER UINT32_C(0x82E0E71C)
#define NORMAL UINT32_C(0x82FE4F08)
_Static_assert(sizeof(void *)==4,"Roland v5.52 ARM32 ABI");
extern uint32_t sp_hcapture_native_consume(uint32_t,uint32_t,uint32_t,uint32_t);
static uint32_t word(uintptr_t a) {return *(volatile const uint32_t *)a;}
static uint8_t byte(uintptr_t a) {return *(volatile const uint8_t *)a;}
/* Sole qualified RX task owns the 64-bit native frame counter. The enclosing
 * lease/task contract, not these two loads, prevents a competing producer. */
static uint64_t counter(void) {
    return (uint64_t)word(NORMAL+512)|((uint64_t)word(NORMAL+516)<<32);
}
static int normal(void) {
    return word(OUTER+596)==NORMAL && word(NORMAL)==0x8021E020 &&
        word(0x8021E04C)==0x1BD5D && byte(OUTER+57)==2 &&
        byte(OUTER+590)==2 && byte(OUTER+59)==1 && !word(OUTER+592);
}
int sp_synth_capture_window_v552_consume(SpSynthCaptureWindow *w,uint32_t token,
    const int16_t *input,uint32_t frames) {
    uintptr_t p=(uintptr_t)input;
    if(!w || !token || token!=w->start.take_token || !p || (p&1u) || !frames ||
       frames>64 || p>UINTPTR_MAX-4u*frames || !normal())return 0;
    uint64_t before=counter();
    if(before!=w->accepted_frames)return 0;
    SpCaptureWindowSlice slice;
    if(!sp_synth_capture_window_offer(w,frames,&slice))return 0;
    if(slice.take_frames)
        (void)sp_hcapture_native_consume(OUTER,(uint32_t)p+slice.skip_frames*4u,slice.take_frames,0);
    uint64_t after=counter();
    uint32_t accepted=after>=before && after-before<=UINT32_MAX?(uint32_t)(after-before):UINT32_MAX;
    return sp_synth_capture_window_commit(w,&slice,accepted,normal())?1:-1;
}
