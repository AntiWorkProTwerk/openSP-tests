#include "sp_synth_startup_v552.h"
#include "sp_synth_factory_ui.h"
#include "sp_synth_preview.h"
#include <stdint.h>
#include <string.h>

static int object(const void *p,size_t bytes,size_t alignment) {
    uintptr_t address=(uintptr_t)p;
    return address && !(address&(alignment-1u)) && bytes<=UINTPTR_MAX-address;
}
static int valid_owner(const SpSynthStartupV552 *owner) {
    return object(owner,sizeof(*owner),_Alignof(SpSynthStartupV552));
}
static int prepare(SpSynthStartupV552 *owner,const SpSynthStartupConfig *input,int deferred) {
    if(!valid_owner(owner) || !object(input,sizeof(*input),_Alignof(SpSynthStartupConfig)))return -1004;
    uintptr_t a=(uintptr_t)owner,b=(uintptr_t)input;
    if(a<b+sizeof(*input) && b<a+sizeof(*owner))return -1004;
    if(owner->ready || owner->memory.storage || owner->memory.allocation ||
       owner->memory.pool_id || owner->memory.attached)return -1004;
    SpSynthStartupConfig c=*input;
    if(c.preset>=128 || !c.voices || c.voices>16 || c.sample%64 ||
       c.held_pads>65535 || c.shift>1)return -1004;
    SpSynthInputClock clock;
    if(!sp_synth_input_clock_init(&clock,c.tick,c.sample,c.tick_hz,48000,c.latency))return -1004;
    int result=sp_synth_storage_v552_acquire(&owner->memory);
    if(result)return result;
    SpSynthRuntimeStorage *s=owner->memory.storage;
    memset(s,0,sizeof(*s));
    if(!sp_synth_app_init(&s->controller,&sp_synth_factory_presets[c.preset],sp_synth_factory_ui,128,
                          48000,c.voices,c.seed) ||
       !sp_synth_app_audio_transfer(&s->controller,&s->audio) ||
       !sp_synth_audio_mailbox_init_timed(&s->mailbox,c.sample)) {
        sp_synth_storage_v552_abandon(&owner->memory);
        return -1005;
    }
    if(!deferred)s->clock=clock;
    sp_synth_control_queue_init(&s->controls);
    sp_synth_midi_queue_init(&s->midi);
    if(!deferred)sp_synth_input_init(&s->input,(uint16_t)c.held_pads,(int)c.shift);
    sp_synth_app_make_view(&s->controller,&s->view,s->plot);
    owner->ready=1;
    return 0;
}
int sp_synth_startup_v552_prepare(SpSynthStartupV552 *owner,const SpSynthStartupConfig *input) {
    return prepare(owner,input,0);
}
int sp_synth_startup_v552_prepare_deferred(SpSynthStartupV552 *owner,
    const SpSynthDeferredStartupConfig *input) {
    if(!valid_owner(owner) || !object(input,sizeof(*input),_Alignof(SpSynthDeferredStartupConfig)))return -1004;
    uintptr_t a=(uintptr_t)owner,b=(uintptr_t)input;
    if(a<b+sizeof(*input) && b<a+sizeof(*owner))return -1004;
    SpSynthStartupConfig c={input->preset,input->voices,input->seed,0,input->sample,
        input->tick_hz,input->latency,0,0};
    return prepare(owner,&c,1);
}
int sp_synth_startup_v552_pin(SpSynthStartupV552 *owner) {
    if(!valid_owner(owner) || owner->ready!=1)return -1004;
    return sp_synth_storage_v552_attach(&owner->memory);
}
int sp_synth_startup_v552_cancel(SpSynthStartupV552 *owner) {
    if(!valid_owner(owner))return -1004;
    int result=sp_synth_storage_v552_abandon(&owner->memory);
    if(!result)owner->ready=0;
    return result;
}
