#include "sp_synth_view_exchange.h"
#include <string.h>

_Static_assert(ATOMIC_INT_LOCK_FREE==2,"View exchange requires lock-free atomics");
void sp_synth_view_exchange_init(SpSynthViewExchange *e) {
    if(!e)return;
    memset(&e->view,0,sizeof(e->view));memset(e->plot,0,sizeof(e->plot));
    atomic_init(&e->ready,0);atomic_init(&e->stopped,0);
}
int sp_synth_view_exchange_publish(SpSynthViewExchange *e,
    const sp_ui_view *view,const uint8_t plot[120]) {
    if(!e || !view || !plot)return 0;
    if(atomic_load_explicit(&e->stopped,memory_order_acquire))return -1;
    if(atomic_load_explicit(&e->ready,memory_order_acquire))return 0;
    e->view=*view;memcpy(e->plot,plot,sizeof(e->plot));
    atomic_store_explicit(&e->ready,1,memory_order_release);return 1;
}
int sp_synth_view_exchange_take(SpSynthViewExchange *e,
    sp_ui_view *view,uint8_t plot[120]) {
    if(!e || !view || !plot)return 0;
    if(atomic_load_explicit(&e->stopped,memory_order_acquire))return -1;
    if(!atomic_load_explicit(&e->ready,memory_order_acquire))return 0;
    *view=e->view;memcpy(plot,e->plot,sizeof(e->plot));
    atomic_store_explicit(&e->ready,0,memory_order_release);return 1;
}
void sp_synth_view_exchange_stop(SpSynthViewExchange *e) {
    if(e)atomic_store_explicit(&e->stopped,1,memory_order_release);
}
