#include "sp_synth_catalog.h"
#include "sp_synth_factory_ui.h"
#include <string.h>
void sp_synth_catalog_begin(SpSynthCatalog *c) {
    if(!c)return;
    memset(c,0,sizeof(*c));memcpy(c->entries,sp_synth_factory_ui,sizeof(sp_synth_factory_ui));c->count=128;
}
SpCatalogStatus sp_synth_catalog_step(SpSynthCatalog *c,const SpSynthPatchIO *io,SpSynthPatchStoreScratch *scratch) {
    if(!c)return SP_CATALOG_FAILED;
    if(c->error)return SP_CATALOG_FAILED;
    if(c->count<128 || c->count>256 || c->next_slot>128) {c->error=SP_UI_ERR_BACKEND;return SP_CATALOG_FAILED;}
    if(c->next_slot==128)return SP_CATALOG_READY;
    SpAppRequest request={.type=SP_APP_REQUEST_PATCH_QUERY,.generation=1,.index=c->next_slot};
    SpAppCompletion response;
    if(!sp_synth_patch_store_execute(io,scratch,&request,&response)) {c->error=SP_UI_ERR_BACKEND;return SP_CATALOG_FAILED;}
    if(response.error) {c->error=response.error;return SP_CATALOG_FAILED;}
    if(response.occupied) {
        if(!response.preset || c->count==256) {c->error=SP_UI_ERR_BACKEND;return SP_CATALOG_FAILED;}
        const SpPreset *p=response.preset;sp_ui_patch *entry=&c->entries[c->count++];
        entry->token=p->id;memcpy(entry->name,p->name,sizeof(entry->name));
        entry->family=p->category;entry->favorite=p->favorite;entry->factory=0;
    }
    ++c->next_slot;return c->next_slot==128?SP_CATALOG_READY:SP_CATALOG_MORE;
}
