#include "sp_synth_app_mix.h"
#include <math.h>
#include <stdint.h>

typedef struct {SpSynthApp *app;SpSynthAppMixScratch *scratch;} Context;
static int range(const void *p,size_t size,uintptr_t *begin,uintptr_t *end) {
    *begin=(uintptr_t)p;
    if(!p || *begin>UINTPTR_MAX-size)return 0;
    *end=*begin+size;return 1;
}
static bool render(void *context,int16_t *pcm,uint32_t frames) {
    Context *c=context;float *samples=c->scratch->stereo;
    if(!sp_synth_app_render(c->app,samples,frames))return false;
    for(unsigned i=0;i<frames*2;++i)if(!isfinite(samples[i]))return false;
    for(unsigned i=0;i<frames*2;++i) {
        float value=samples[i];
        if(value>1)value=1;else if(value< -1)value=-1;
        pcm[i]=(int16_t)(value>=0?value*32767.0f:value*32768.0f);
    }
    return true;
}
SpSynthStockResult sp_synth_app_mix_stock(SpSynthApp *app,const SpSynthStockBlock *input,
                                         SpSynthAppMixScratch *scratch) {
    if(!app || !input || !scratch)return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    SpSynthStockBlock block=*input;
    if(block.frames>SP_SYNTH_STOCK_MAX_FRAMES || block.pair_index>=SP_SYNTH_STOCK_PAIR_COUNT)return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    if(!block.frames)return SP_SYNTH_STOCK_OK;
    if(block.word_count<(size_t)block.frames*SP_SYNTH_STOCK_STRIDE_WORDS)return SP_SYNTH_STOCK_INSUFFICIENT_BUFFER;
    uintptr_t ab,ae,sb,se,wb,we;
    if(!range(app,sizeof(*app),&ab,&ae) || !range(scratch,sizeof(*scratch),&sb,&se) ||
       !range(block.words,(size_t)block.frames*SP_SYNTH_STOCK_STRIDE_WORDS*sizeof(int32_t),&wb,&we) ||
       (ab<se && sb<ae) || (ab<we && wb<ae) || (sb<we && wb<se))return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    Context context={app,scratch};
    return sp_synth_stock_mix_block(&block,&scratch->pcm,render,&context);
}
