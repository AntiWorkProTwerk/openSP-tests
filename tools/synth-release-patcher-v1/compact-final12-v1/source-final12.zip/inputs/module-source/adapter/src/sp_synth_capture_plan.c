#include "sp_synth_capture_plan.h"
#include <float.h>

_Static_assert(sizeof(float)==4 && FLT_RADIX==2 && FLT_MANT_DIG==24 &&
    FLT_MAX_EXP==128, "capture plan requires IEEE binary32");

static uint32_t bits(float value) {
    union { float value; uint32_t word; } copy;
    copy.value=value;
    return copy.word;
}
static uint32_t significand(uint32_t word) {
    return (word&0x7fffffu)|0x800000u;
}
static int exponent(uint32_t word) {
    return (int)(word>>23)-127;
}
static int multiply(uint64_t a,uint64_t b,uint64_t *out) {
    if(b && a>UINT64_MAX/b)return 0;
    *out=a*b;
    return 1;
}
/* Round n/d * 2^shift exactly. Splitting quotient/remainder before a positive
 * shift avoids overflowing an intermediate numerator for large valid rates. */
static int rounded(uint64_t n,uint64_t d,int shift,uint64_t *out) {
    uint64_t q,r,extra;
    if(!d || shift<=-64 || shift>=64)return 0;
    if(shift<0) {
        unsigned right=(unsigned)-shift;
        if(d>(UINT64_MAX>>right))return 0;
        d<<=right;
    }
    q=n/d;r=n%d;
    if(shift>0) {
        unsigned left=(unsigned)shift;
        if(q>(UINT64_MAX>>left) || r>(UINT64_MAX>>left))return 0;
        q<<=left;r<<=left;
        extra=r/d;r%=d;
        if(q>UINT64_MAX-extra)return 0;
        q+=extra;
    }
    if(r>=d/2+(d&1u)) {
        if(q==UINT64_MAX)return 0;
        ++q;
    }
    *out=q;
    return 1;
}
int sp_synth_capture_plan_build(const SpAppCapture *capture,
    uint32_t sample_rate_hz,SpSynthCapturePlan *out) {
    SpSynthCapturePlan plan;
    uint32_t seconds,bars,tempo;
    uint64_t n;
    if(!capture || !out || !sample_rate_hz)return 0;
    plan.capture=*capture;
    seconds=bits(plan.capture.seconds);
    bars=bits(plan.capture.bars);
    tempo=bits(plan.capture.tempo_bpm);
    /* Positive IEEE encodings sort numerically. These bounds also exclude
     * every NaN, infinity, signed zero, subnormal and negative input. */
    if(plan.capture.mode>1 || seconds<0x3f800000u || seconds>0x42f00000u ||
       bars<0x3f800000u || bars>0x42800000u ||
       tempo<0x41a00000u || tempo>0x43960000u ||
       plan.capture.count_in_bars>4 || plan.capture.include_release_tail>1)return 0;
    if(plan.capture.mode==0) {
        if(!multiply(sample_rate_hz,significand(seconds),&n) ||
           !rounded(n,1,exponent(seconds)-23,&plan.duration_frames))return 0;
    } else {
        if(!multiply(sample_rate_hz,significand(bars),&n) ||
           !multiply(n,240,&n) ||
           !rounded(n,significand(tempo),exponent(bars)-exponent(tempo),
                    &plan.duration_frames))return 0;
    }
    if(!multiply(sample_rate_hz,plan.capture.count_in_bars,&n) ||
       !multiply(n,240,&n) ||
       !rounded(n,significand(tempo),23-exponent(tempo),&plan.count_in_frames))return 0;
    plan.sample_rate_hz=sample_rate_hz;
    plan.reserved=0;
    *out=plan;
    return 1;
}
int sp_synth_capture_plan_start(const SpAppRequest *request,
    uint32_t sample_rate_hz,uint32_t last_token,uint32_t take_token,
    SpSynthCaptureStartPlan *out) {
    SpSynthCaptureStartPlan start;
    if(!request || !out || request->type!=SP_APP_REQUEST_CAPTURE_START ||
       request->token || !request->generation || !take_token ||
       take_token<=last_token)return 0;
    start.start_generation=request->generation;
    start.take_token=take_token;
    if(!sp_synth_capture_plan_build(&request->capture,sample_rate_hz,&start.plan))return 0;
    *out=start;
    return 1;
}
