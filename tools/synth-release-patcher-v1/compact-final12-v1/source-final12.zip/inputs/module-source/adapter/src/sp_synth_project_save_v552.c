#include "sp_synth_project_save_v552.h"
extern SpSynthProjectSaveV552 *sp_p6_save_two_leg_v552_second(void);
#include "sp_synth_memory_v552.h"
#include <stdatomic.h>
#include <stddef.h>
#include <string.h>

_Static_assert(sizeof(void *)==4,"v5.52 ARM32 only");
_Static_assert(ATOMIC_POINTER_LOCK_FREE==2,"Lock-free transaction publication");
#define MAGIC UINT32_C(0x50534731)
#define PARAM UINT32_C(0x82E2CD08)
#define SMPL UINT32_C(0x202ACD00)
#define UNSEEN INT32_MIN
typedef uint32_t (*Native)(uint32_t,uint32_t,uint32_t,uint32_t);
static _Atomic(SpSynthProjectSaveV552 *) active;
static uint32_t rd(uintptr_t p) { return *(volatile const uint32_t *)p; }
static uint32_t native(uintptr_t p,uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return ((Native)(p|1u))(a,b,c,d);
}
static uint32_t worker(void) {
    uint32_t ipsr,basepri,primask,faultmask;
    __asm__ volatile("mrs %0, ipsr":"=r"(ipsr));
    __asm__ volatile("mrs %0, basepri":"=r"(basepri));
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    if(ipsr || basepri || primask || faultmask || (int32_t)rd(0x80245764)>0 || rd(0x202BBBF8))return 0;
    uint32_t id=native(0x800D3162,0,0,0,0);
    return id>=1 && id<=32 && id==rd(SMPL+4)?id:0;
}
/* 0 preserves unrelated stock calls, 1 selects this transaction, -1 refuses
 * an active SMPL call in a context where blocking I/O is not permitted.
 * A rejected exception does not write the thread-owned observation fields. */
static int select_owner(SpSynthProjectSaveV552 **selected) {
    *selected=0;
    SpSynthProjectSaveV552 *o=atomic_load_explicit(&active,memory_order_acquire);
    if(!o)return 0;
    uint32_t ipsr;
    __asm__ volatile("mrs %0, ipsr":"=r"(ipsr));
    if(ipsr)return -1;
    uint32_t id=native(0x800D3162,0,0,0,0);
    if(id<1 || id>32)return -1;
    if(id!=rd(SMPL+4))return 0;
    if(worker()!=id || id!=o->task)return -1;
    *selected=o;return 1;
}
static int span(uintptr_t p,uint32_t n) { return p && !(p&3u) && p<=UINTPTR_MAX-n; }
static int apart(uintptr_t a,uint32_t an,uintptr_t b,uint32_t bn) {
    return a+an<=b || b+bn<=a;
}
static uint32_t setting(void) { return native(0x800D94D8,0x82E01144,132,0,0); }
static int same_project(SpSynthProjectSaveV552 *o) {
    if(native(0x800E1190,0,0,0,0)==o->project && setting()==0)return 1;
    o->fault|=SP_PROJECT_PATH;return 0;
}
static int clear(SpSynthProjectSaveV552 *o,uint32_t reason) {
    if(native(0x800B45DA,0,0,0,0)==0)return 1;
    o->fault|=reason;return 0;
}
static int error(SpSynthProjectSaveV552 *o,uint32_t reason) {
    if(native(0x800B45A8,0,0,0,0)==0)return 0;
    o->fault|=reason;return 1;
}
static int owns(SpSynthProjectSaveV552 *o,uint32_t fd) {
    if(fd<1024 && (int32_t)fd==o->fd && o->file && !(o->file&3u) &&
       rd(0x80B5F3B4+4*fd)==o->file)return 1;
    o->fault|=SP_PROJECT_FILE;o->terminal=1;return 0;
}
static void path(SpSynthProjectSaveV552 *o) {
    static const char prefix[]="B:/ROLAND/SP-404MKII/PROJECT_";
    static const char suffix[]="/PADCONF.BIN";
    memcpy(o->path,prefix,sizeof(prefix)-1);
    unsigned p=sizeof(prefix)-1,n=o->project+1;
    if(n>=100)o->path[p++]=(char)('0'+n/100);
    o->path[p++]=(char)('0'+n/10%10);o->path[p++]=(char)('0'+n%10);
    memcpy(o->path+p,suffix,sizeof(suffix));
}
static int path_matches(const char *a,const char *b) {
    for(unsigned i=0;i<64;++i) {
        if(a[i]!=b[i])return 0;
        if(!a[i])return 1;
    }
    return 0;
}
int sp_synth_project_save_v552_init(SpSynthProjectSaveV552 *o) {
    uintptr_t p=(uintptr_t)o;
    if(!span(p,sizeof(*o)) || !apart(p,sizeof(*o),SP_SYNTH_V552_POOL_BEGIN,
          SP_SYNTH_V552_POOL_END-SP_SYNTH_V552_POOL_BEGIN) ||
       !apart(p,sizeof(*o),PARAM,85000))return 0;
    const unsigned char *b=(const unsigned char *)o;
    for(size_t i=0;i<sizeof(*o);++i)if(b[i])return 0;
    o->magic=MAGIC;o->fd=-1;return 1;
}
uint32_t sp_synth_project_save_v552_alloc(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthProjectSaveV552 *o;int selected=select_owner(&o);
    if(selected<0)return 0;
    if(!selected)return native(0x800E2C68,a,b,c,d);
    unsigned index=o->alloc_count++;
    if(index>=2 || a!=(index?20608u:27692u)) { o->fault|=SP_PROJECT_ALLOC;return 0; }
    uintptr_t p=native(0x800E2C68,a,b,c,d);
    if(!p) { o->fault|=SP_PROJECT_ALLOC;return 0; }
    if(!span(p,a) || !apart(p,a,(uintptr_t)o,sizeof(*o)) || !apart(p,a,PARAM,85000) ||
       (index && o->allocations[0] && !apart(p,a,o->allocations[0],27692))) {
        o->fault|=SP_PROJECT_ALLOC;o->terminal=1;return 0;
    }
    o->allocations[index]=p;return p;
}
uint32_t sp_synth_project_save_v552_free(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthProjectSaveV552 *o;int selected=select_owner(&o);
    if(selected<0)return 0;
    if(!selected)return native(0x800E2CA8,a,b,c,d);
    for(unsigned i=0;i<2;++i)if(a && a==o->allocations[i] && !(o->free_mask&(1u<<i))) {
        o->free_mask|=1u<<i;return native(0x800E2CA8,a,b,c,d);
    }
    o->fault|=SP_PROJECT_ALLOC;o->terminal=1;return 0;
}
uint32_t sp_synth_project_save_v552_open(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthProjectSaveV552 *o;int selected=select_owner(&o);
    if(selected<0)return UINT32_MAX;
    if(!selected)return native(0x800DEC60,a,b,c,d);
    if(o->open_raw!=UNSEEN || o->fault || b!=1537 || !a || !same_project(o) ||
       !path_matches((const char *)(uintptr_t)a,o->path)) {
        o->fault|=SP_PROJECT_PATH;return UINT32_MAX;
    }
    if(!clear(o,SP_PROJECT_FILE))return UINT32_MAX;
    o->open_raw=(int32_t)native(0x800DEC60,a,b,c,d);
    int err=error(o,SP_PROJECT_FILE);
    if(o->open_raw<0) { o->fault|=SP_PROJECT_FILE;return UINT32_MAX; }
    o->fd=o->open_raw;
    o->file=o->fd<1024?rd(0x80B5F3B4+4*(uint32_t)o->fd):0;
    if(!o->file || (o->file&3u) || !owns(o,(uint32_t)o->fd)) {
        o->fault|=SP_PROJECT_FILE;o->terminal=1;return UINT32_MAX;
    }
    return err?UINT32_MAX:(uint32_t)o->fd;
}
static uint32_t length(unsigned i) {
    if(i==0)return 16;
    if(i<29)return 4;
    if(i<61)return 1;
    if(i==61)return 27520;
    if(i==62)return 3840;
    return i==63?20480:0;
}
uint32_t sp_synth_project_save_v552_write(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthProjectSaveV552 *o;int selected=select_owner(&o);
    if(selected<0)return UINT32_MAX;
    if(!selected)return native(0x800DD9B8,a,b,c,d);
    if(o->fault || !b || !c || c!=length(o->write_count) || !owns(o,a)) {
        o->fault|=SP_PROJECT_WRITE;return UINT32_MAX;
    }
    if(!clear(o,SP_PROJECT_WRITE))return UINT32_MAX;
    uint32_t result=native(0x800DD9B8,a,b,c,d);
    ++o->write_count;
    int err=error(o,SP_PROJECT_WRITE);
    if(result!=c || err) { o->fault|=SP_PROJECT_WRITE;return UINT32_MAX; }
    o->bytes+=result;return result;
}
uint32_t sp_synth_project_save_v552_stat(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthProjectSaveV552 *o;int selected=select_owner(&o);
    if(selected<0)return UINT32_MAX;
    if(!selected)return native(0x800D1130,a,b,c,d);
    if(!b || o->stat_seen || !owns(o,a)) { o->fault|=SP_PROJECT_STAT;return UINT32_MAX; }
    o->stat_seen=1;memset((void *)(uintptr_t)b,0,28);
    if(!clear(o,SP_PROJECT_STAT))return UINT32_MAX;
    o->stat_raw=(int32_t)native(0x800D1130,a,b,c,d);
    int err=error(o,SP_PROJECT_STAT);
    memcpy(&o->size_low,(const void *)(uintptr_t)(b+8),4);
    memcpy(&o->size_high,(const void *)(uintptr_t)(b+12),4);
    if(o->stat_raw || err || o->size_low!=52000 || o->size_high)o->fault|=SP_PROJECT_STAT;
    return (uint32_t)o->stat_raw;
}
uint32_t sp_synth_project_save_v552_close(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthProjectSaveV552 *o;int selected=select_owner(&o);
    if(selected<0)return UINT32_MAX;
    if(!selected)return native(0x800DEBD8,a,b,c,d);
    if(o->close_attempted) { o->fault|=SP_PROJECT_CLOSE;return UINT32_MAX; }
    o->close_attempted=1;
    if(!owns(o,a))return UINT32_MAX;
    if(!o->fault && o->write_count==64 && o->bytes==52000 && o->stat_seen &&
       clear(o,SP_PROJECT_SYNC)) {
        o->sync_raw=(int32_t)native(0x8009E3D2,o->file,0,0,0);
        int err=error(o,SP_PROJECT_SYNC);
        if(o->sync_raw || err)o->fault|=SP_PROJECT_SYNC;
    }
    /* Recheck after a sync that may block; never close a replaced descriptor. */
    if(!owns(o,a))return UINT32_MAX;
    if(!clear(o,SP_PROJECT_CLOSE))return UINT32_MAX;
    o->fd=-1;o->file=0; /* Consume obligation before native close can release it. */
    o->close_raw=(int32_t)native(0x800DEBD8,a,b,c,d);
    int err=error(o,SP_PROJECT_CLOSE);
    if(o->close_raw || err)o->fault|=SP_PROJECT_CLOSE;
    return (uint32_t)o->close_raw;
}
int sp_synth_project_save_v552_run(SpSynthProjectSaveV552 *o,uint32_t token,uint32_t project) {
    if(!o || o->magic!=MAGIC || o->terminal || o->fault || !token || token<o->last_token || project>=128)return -1;
    uint32_t id=worker();
    if(!id || native(0x800E1190,0,0,0,0)!=project || setting()!=0)return -1;
    if(token==o->last_token && sp_p6_save_two_leg_v552_second()!=o)return -1;
    SpSynthProjectSaveV552 *empty=0;
    if(!atomic_compare_exchange_strong_explicit(&active,&empty,o,memory_order_acq_rel,memory_order_acquire))return -1;
    o->last_token=token;o->token=token;o->project=project;o->task=id;
    o->allocations[0]=o->allocations[1]=0;o->alloc_count=0;o->free_mask=0;
    o->write_count=o->bytes=o->stat_seen=o->close_attempted=0;o->fd=-1;o->file=0;
    o->open_raw=o->stat_raw=o->sync_raw=o->close_raw=o->native_raw=UNSEEN;
    o->size_low=o->size_high=0;path(o);
    *(volatile uint8_t *)(uintptr_t)(PARAM+28)=1; /* Require actual serialization. */
    o->native_raw=(int32_t)native(0x800CF218,PARAM,project,0,0);
    int qualified=worker()==id;
    if(qualified) {
        if(o->fd>=0 && !o->close_attempted)sp_synth_project_save_v552_close((uint32_t)o->fd,0,0,0);
        for(unsigned i=0;i<2;++i)if(o->allocations[i] && !(o->free_mask&(1u<<i)))
            sp_synth_project_save_v552_free(o->allocations[i],0,0,0);
        (void)same_project(o);
    } else { o->fault|=SP_PROJECT_CONTEXT;o->terminal=1; }
    for(unsigned i=0;i<2;++i)if(o->allocations[i] && !(o->free_mask&(1u<<i)))o->terminal=1;
    if(o->fd>=0)o->terminal=1;
    if(o->native_raw!=1 || o->write_count!=64 || o->bytes!=52000 || !o->stat_seen ||
       o->stat_raw || o->sync_raw || o->close_raw || o->terminal)o->fault|=SP_PROJECT_NATIVE;
    if(o->fault && qualified)*(volatile uint8_t *)(uintptr_t)(PARAM+28)=1;
    atomic_store_explicit(&active,0,memory_order_release);
    return o->fault?0:1;
}
