#include "sp_synth_capture_window.h"
#include <string.h>
_Static_assert(sizeof(SpCaptureWindowSlice)==24,"Slice comparison excludes padding");

static int usable(const SpSynthCaptureWindow *w) {
    return w && w->start.take_token && w->last_token==w->start.take_token &&
        w->phase>=SP_CAPTURE_WINDOW_COUNT_IN && w->phase<=SP_CAPTURE_WINDOW_CANCELED;
}
static void phase(SpSynthCaptureWindow *w) {
    if(w->stop_set && w->observed_frames>=w->stop_frame)
        w->phase=w->accepted_frames?SP_CAPTURE_WINDOW_SEALED:SP_CAPTURE_WINDOW_CANCELED;
    else if(w->observed_frames<w->start.plan.count_in_frames)w->phase=SP_CAPTURE_WINDOW_COUNT_IN;
    else if(w->observed_frames<w->nominal_end)w->phase=SP_CAPTURE_WINDOW_RECORD;
    else w->phase=SP_CAPTURE_WINDOW_TAIL;
}
int sp_synth_capture_window_arm(SpSynthCaptureWindow *w,const SpSynthCaptureStartPlan *p) {
    if(!w || !p || w->inflight ||
       (w->phase!=SP_CAPTURE_WINDOW_EMPTY && w->phase!=SP_CAPTURE_WINDOW_RETIRED) ||
       !p->take_token || p->take_token<=w->last_token ||
       !p->start_generation || !p->plan.sample_rate_hz || p->plan.reserved ||
       p->plan.capture.mode>1 || p->plan.capture.count_in_bars>4 ||
       p->plan.capture.include_release_tail>1 || !p->plan.duration_frames ||
       p->plan.count_in_frames>UINT64_MAX-p->plan.duration_frames)return 0;
    SpSynthCaptureWindow next={0};next.start=*p;next.last_token=p->take_token;
    next.nominal_end=p->plan.count_in_frames+p->plan.duration_frames;
    next.stop_set=!p->plan.capture.include_release_tail;
    next.stop_frame=next.nominal_end;phase(&next);*w=next;return 1;
}
int sp_synth_capture_window_offer(SpSynthCaptureWindow *w,uint32_t frames,SpCaptureWindowSlice *out) {
    if(!usable(w) || !out || w->inflight || !frames || frames>64 ||
       w->sequence==UINT64_MAX || w->observed_frames>UINT64_MAX-frames)return 0;
    uint64_t first=w->observed_frames,end=first+frames;
    uint64_t begin=first>w->start.plan.count_in_frames?first:w->start.plan.count_in_frames;
    if(begin>end)begin=end;
    uint64_t stop=w->stop_set && w->stop_frame<end?w->stop_frame:end;
    uint32_t take=stop>begin?(uint32_t)(stop-begin):0;
    if(w->accepted_frames>UINT64_MAX-take)return 0;
    SpCaptureWindowSlice slice={w->sequence+1u,w->start.take_token,frames,(uint32_t)(begin-first),take};
    w->sequence=slice.sequence;w->pending=slice;w->inflight=1;*out=slice;return 1;
}
int sp_synth_capture_window_commit(SpSynthCaptureWindow *w,const SpCaptureWindowSlice *slice,
    uint32_t accepted,int native_ok) {
    if(!usable(w) || !slice || !w->inflight ||
       memcmp(slice,&w->pending,sizeof(*slice)))return 0;
    if(!native_ok || accepted!=slice->take_frames) {
        w->failed_accepted=accepted;w->native_failed=!native_ok;
        w->phase=SP_CAPTURE_WINDOW_ERROR;return 0;
    }
    w->observed_frames+=slice->block_frames;w->accepted_frames+=accepted;
    w->inflight=0;phase(w);return 1;
}
int sp_synth_capture_window_stop_at(SpSynthCaptureWindow *w,uint32_t token,uint64_t frame) {
    if(!usable(w) || w->inflight || token!=w->start.take_token || frame<w->observed_frames ||
       w->phase==SP_CAPTURE_WINDOW_SEALED || w->phase==SP_CAPTURE_WINDOW_CANCELED ||
       (w->stop_set && frame>w->stop_frame))return 0;
    w->stop_frame=frame;w->stop_set=1;phase(w);return 1;
}
int sp_synth_capture_window_retire(SpSynthCaptureWindow *w,uint32_t token) {
    if(!w || !token || token!=w->start.take_token || token!=w->last_token ||
       (w->phase!=SP_CAPTURE_WINDOW_ERROR &&
        ((w->phase!=SP_CAPTURE_WINDOW_SEALED && w->phase!=SP_CAPTURE_WINDOW_CANCELED) ||
         w->inflight)))return 0;
    w->inflight=0;w->phase=SP_CAPTURE_WINDOW_RETIRED;return 1;
}
