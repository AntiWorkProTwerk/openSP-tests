#include "sp_synth_audio_mix.h"
#include <math.h>
#include <stdint.h>

typedef struct {SpAppAudioState *audio;const SpAppAudioBatch *batch;SpSynthAppMixScratch *scratch;} Context;
static bool render(void *context,int16_t *pcm,uint32_t frames) {
    Context *c=context;float *samples=c->scratch->stereo;
    int ok=c->batch?sp_synth_app_audio_render(c->audio,c->batch,samples):
                    sp_synth_app_audio_continue(c->audio,samples,frames);
    if(!ok)return false;
    for(unsigned i=0;i<frames*2;++i)if(!isfinite(samples[i]))return false;
    for(unsigned i=0;i<frames*2;++i) {
        float value=samples[i];
        if(value>1)value=1;else if(value< -1)value=-1;
        pcm[i]=(int16_t)(value>=0?value*32767.0f:value*32768.0f);
    }
    return true;
}
SpSynthStockResult sp_synth_audio_mix_stock(SpAppAudioState *audio,const SpAppAudioBatch *batch,
    const SpSynthStockBlock *input,SpSynthAppMixScratch *scratch) {
    if(!audio || !input || !scratch)return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    SpSynthStockBlock block=*input;
    if(block.frames>SP_SYNTH_STOCK_MAX_FRAMES || block.pair_index>=SP_SYNTH_STOCK_PAIR_COUNT)return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    if(!block.frames)return SP_SYNTH_STOCK_OK;
    if(batch && batch->frames!=block.frames)return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    if(block.word_count<(size_t)block.frames*SP_SYNTH_STOCK_STRIDE_WORDS)return SP_SYNTH_STOCK_INSUFFICIENT_BUFFER;
    const void *p[]={audio,scratch,block.words,batch};
    size_t sizes[]={sizeof(*audio),sizeof(*scratch),(size_t)block.frames*SP_SYNTH_STOCK_STRIDE_WORDS*sizeof(int32_t),sizeof(*batch)};
    uintptr_t begin[4],end[4];unsigned count=batch?4:3;
    for(unsigned i=0;i<count;++i) {
        begin[i]=(uintptr_t)p[i];
        if(!p[i] || begin[i]>UINTPTR_MAX-sizes[i])return SP_SYNTH_STOCK_INVALID_ARGUMENT;
        end[i]=begin[i]+sizes[i];
        for(unsigned j=0;j<i;++j)if(begin[i]<end[j] && begin[j]<end[i])return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    }
    Context context={audio,batch,scratch};
    SpSynthStockResult result=sp_synth_stock_mix_block(&block,&scratch->pcm,render,&context);
    if(result==SP_SYNTH_STOCK_RENDER_FAILED || result==SP_SYNTH_STOCK_NO_HEADROOM) {
        sp_synth_engine_panic(&audio->engine);audio->faulted=1;
    }
    return result;
}
