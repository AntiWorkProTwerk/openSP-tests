#include "sp_synth_storage_v552.h"
#include "sp_synth_memory_v552.h"
#include <stdint.h>

#define POOL_BEGIN SP_SYNTH_V552_POOL_BEGIN
#define POOL_END SP_SYNTH_V552_POOL_END
#define ALIGNMENT ((uint32_t)_Alignof(SpSynthRuntimeStorage))
#define REQUEST ((uint32_t)sizeof(SpSynthRuntimeStorage) + ALIGNMENT - 1u)
_Static_assert(sizeof(void *) == 4, "v5.52 requires ARM32 pointers");
_Static_assert((ALIGNMENT & (ALIGNMENT - 1u)) == 0, "power-of-two alignment");
_Static_assert(REQUEST < POOL_END - POOL_BEGIN, "storage fits pool extent");

static int valid_owner(const SpSynthStorageV552 *owner) {
    uintptr_t p = (uintptr_t)owner;
    return p && !(p & (_Alignof(SpSynthStorageV552) - 1u)) &&
           p <= UINTPTR_MAX - sizeof(*owner);
}
static int valid_allocation(const SpSynthStorageV552 *owner) {
    uintptr_t raw = (uintptr_t)owner->allocation;
    uintptr_t aligned = (raw + ALIGNMENT - 1u) & ~(uintptr_t)(ALIGNMENT - 1u);
    return owner->pool_id >= 1 && owner->pool_id <= 8 &&
           raw >= POOL_BEGIN && raw <= POOL_END - REQUEST &&
           (uintptr_t)owner->storage == aligned && owner->attached <= 1;
}
int sp_synth_storage_v552_acquire(SpSynthStorageV552 *owner) {
    if (!valid_owner(owner) || owner->storage || owner->allocation ||
        owner->pool_id || owner->attached) return -1001;
    int32_t pool = *(volatile const int32_t *)(uintptr_t)0x80245820;
    if (pool < 1 || pool > 8) return -1002;
    void *raw = 0;
    int result = ((int (*)(int, unsigned, void **, int))(uintptr_t)0x800D2F1F)(pool, REQUEST, &raw, 0);
    if (result) return result;
    uintptr_t p = (uintptr_t)raw;
    /* A broken provider must not cause writes or a release of an untrusted address. */
    if (p < POOL_BEGIN || p > POOL_END - REQUEST) return -1003;
    uintptr_t h = (uintptr_t)owner;
    if (h < p + REQUEST && h + sizeof(*owner) > p) return -1003;
    owner->storage = (SpSynthRuntimeStorage *)((p + ALIGNMENT - 1u) & ~(uintptr_t)(ALIGNMENT - 1u));
    owner->allocation = raw;
    owner->pool_id = pool;
    return 0;
}
int sp_synth_storage_v552_attach(SpSynthStorageV552 *owner) {
    if (!valid_owner(owner) || !valid_allocation(owner)) return -1001;
    owner->attached = 1;
    return 0;
}
int sp_synth_storage_v552_abandon(SpSynthStorageV552 *owner) {
    if (!valid_owner(owner)) return -1001;
    if (!owner->storage && !owner->allocation && !owner->pool_id && !owner->attached) return 0;
    if (!valid_allocation(owner) || owner->attached) return -1001;
    ((void (*)(int, void *))(uintptr_t)0x800D2F29)(owner->pool_id, owner->allocation);
    owner->storage = 0;
    owner->allocation = 0;
    owner->pool_id = 0;
    return 0;
}
