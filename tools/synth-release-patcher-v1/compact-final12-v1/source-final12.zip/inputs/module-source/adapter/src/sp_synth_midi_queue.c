#include "sp_synth_midi_queue.h"
#include <string.h>

static int fail(SpSynthMidiQueue *q,SpSynthAudioMailbox *m,SpMidiQueueFault why) {
    if(q && q->fault==SP_MIDI_QUEUE_OK)q->fault=why;
    sp_synth_audio_mailbox_stop(m);return 0;
}
static int ready(SpSynthMidiQueue *q,SpSynthAudioMailbox *m) {
    if(!q || !m || !m->timed)
        return fail(q,m,SP_MIDI_QUEUE_PROTOCOL);
    if(q->fault)return fail(q,m,q->fault);
    if(atomic_load_explicit(&m->stop_requested,memory_order_acquire))return fail(q,m,SP_MIDI_QUEUE_STOP_REQUESTED);
    /* Once its last closed block is past, an empty queue has no ordering
     * history to retain. Otherwise a long idle session could outlive the
     * modular comparison horizon despite the control owner still running. */
    if(!q->count && q->has_closed &&
       atomic_load_explicit(&m->sample_cursor,memory_order_acquire)-q->closed_until<=UINT32_MAX/2u)
        q->has_last=q->has_closed=0;
    return 1;
}
static int admitted(SpSynthAudioMailbox *m,uint32_t target) {
    uint32_t cursor;
    return !(target%SP_AUDIO_TIMED_FRAMES) && sp_synth_audio_mailbox_cursor(m,&cursor) &&
        target-cursor<=SP_AUDIO_MAX_LOOKAHEAD;
}
static int closed(const SpSynthMidiQueue *q,uint32_t target) {
    return q->has_watermark && q->watermark-(target+SP_AUDIO_TIMED_FRAMES)<=UINT32_MAX/2u;
}
void sp_synth_midi_queue_init(SpSynthMidiQueue *q){if(q)memset(q,0,sizeof(*q));}
int sp_synth_midi_queue_watermark(SpSynthMidiQueue *q,SpSynthAudioMailbox *m,uint32_t sample) {
    if(!ready(q,m))return 0;
    uint32_t cursor;
    if((q->has_watermark && sample-q->watermark>UINT32_MAX/2u) ||
       !sp_synth_audio_mailbox_cursor(m,&cursor) || sample-cursor>SP_AUDIO_MAX_LOOKAHEAD+SP_AUDIO_TIMED_FRAMES)
        return fail(q,m,SP_MIDI_QUEUE_TIME);
    q->watermark=sample;q->has_watermark=1;return 1;
}
int sp_synth_midi_queue_push(SpSynthMidiQueue *q,SpSynthAudioMailbox *m,uint32_t sample,const SpSynthEvent *e) {
    if(!ready(q,m))return 0;
    if(!e || e->offset || !sp_synth_app_event_valid(e))return fail(q,m,SP_MIDI_QUEUE_INPUT);
    if(q->count>=SP_MIDI_QUEUE_CAPACITY)return fail(q,m,SP_MIDI_QUEUE_FULL);
    if(q->has_last && sample-q->last_sample>UINT32_MAX/2u)return fail(q,m,SP_MIDI_QUEUE_ORDER);
    if((q->has_watermark && sample-q->watermark>UINT32_MAX/2u) ||
       (q->has_closed && sample-q->closed_until>UINT32_MAX/2u) ||
       !admitted(m,sample-sample%SP_AUDIO_TIMED_FRAMES))return fail(q,m,SP_MIDI_QUEUE_TIME);
    q->events[(q->head+q->count)%SP_MIDI_QUEUE_CAPACITY]=(SpTimedMidi){sample,*e};
    ++q->count;q->has_last=1;q->last_sample=sample;return 1;
}
SpMidiService sp_synth_midi_queue_publish(SpSynthMidiQueue *q,SpSynthAudioMailbox *m,SpSynthApp *a,uint32_t target) {
    if(!ready(q,m))return SP_MIDI_STOPPED;
    if(!a || atomic_load_explicit(&m->phase,memory_order_acquire)!=SP_AUDIO_WRITING ||
       a->audio_batch!=&m->batch || a->event_count) {
        fail(q,m,SP_MIDI_QUEUE_PROTOCOL);return SP_MIDI_STOPPED;
    }
    if(!closed(q,target) || !admitted(m,target) || (q->has_closed && target-q->closed_until>UINT32_MAX/2u)) {
        fail(q,m,SP_MIDI_QUEUE_TIME);return SP_MIDI_STOPPED;
    }
    unsigned count=0;
    while(count<q->count) {
        const SpTimedMidi *item=&q->events[(q->head+count)%SP_MIDI_QUEUE_CAPACITY];
        uint32_t offset=item->sample-target;
        if(offset>UINT32_MAX/2u) {fail(q,m,SP_MIDI_QUEUE_TIME);return SP_MIDI_STOPPED;}
        if(offset>=SP_AUDIO_TIMED_FRAMES)break;
        SpSynthEvent event=item->event;event.offset=offset;
        if(!sp_synth_app_input(a,&event)) {fail(q,m,SP_MIDI_QUEUE_DELIVERY);return SP_MIDI_STOPPED;}
        ++count;
    }
    if(sp_synth_audio_mailbox_publish_at(m,a,target)!=SP_AUDIO_PUBLISHED) {
        fail(q,m,SP_MIDI_QUEUE_DELIVERY);return SP_MIDI_STOPPED;
    }
    q->head=(uint16_t)((q->head+count)%SP_MIDI_QUEUE_CAPACITY);q->count=(uint16_t)(q->count-count);
    q->closed_until=target+SP_AUDIO_TIMED_FRAMES;q->has_closed=1;
    return SP_MIDI_PUBLISHED;
}
SpMidiService sp_synth_midi_queue_service(SpSynthMidiQueue *q,SpSynthAudioMailbox *m,SpSynthApp *a) {
    if(!q || !m || !m->timed || !a) {fail(q,m,SP_MIDI_QUEUE_PROTOCOL);return SP_MIDI_STOPPED;}
    SpAudioCompletion out;
    if(sp_synth_audio_mailbox_complete(m,a,&out)==SP_AUDIO_COMPLETED_FAILED) {
        fail(q,m,SP_MIDI_QUEUE_DELIVERY);return SP_MIDI_STOPPED;
    }
    if(!ready(q,m))return SP_MIDI_STOPPED;
    if(!q->count || atomic_load_explicit(&m->phase,memory_order_acquire)!=SP_AUDIO_FREE)return SP_MIDI_IDLE;
    uint32_t sample=q->events[q->head].sample,target=sample-sample%SP_AUDIO_TIMED_FRAMES;
    if(!admitted(m,target)) {fail(q,m,SP_MIDI_QUEUE_TIME);return SP_MIDI_STOPPED;}
    if(!closed(q,target))return SP_MIDI_IDLE;
    if(!sp_synth_audio_mailbox_begin(m,a)) {fail(q,m,SP_MIDI_QUEUE_PROTOCOL);return SP_MIDI_STOPPED;}
    return sp_synth_midi_queue_publish(q,m,a,target);
}
