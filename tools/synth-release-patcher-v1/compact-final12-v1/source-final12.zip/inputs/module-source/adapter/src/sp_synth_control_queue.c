#include "sp_synth_control_queue.h"
#include <string.h>

static int fail(SpSynthControlQueue *q,SpSynthAudioMailbox *m) {
    if(q)q->faulted=1;
    sp_synth_audio_mailbox_stop(m);return 0;
}
static int valid(const sp_ui_event *e) {
    switch(e->type) {
    case SP_UI_PAD_DOWN:return e->index>=1 && e->index<=16 && e->value>=0 && e->value<=127;
    case SP_UI_PAD_UP:return e->index>=1 && e->index<=16;
    case SP_UI_CTRL_MOVE:return e->index<3 && e->value>=0 && (uint32_t)e->value<=SP_UI_VALUE_MAX;
    case SP_UI_SHIFT_DOWN:case SP_UI_SHIFT_UP:case SP_UI_VALUE_PRESS:
    case SP_UI_VALUE_TURN:case SP_UI_REC_PRESS:case SP_UI_EXIT_PRESS:return 1;
    default:return 0;
    }
}
void sp_synth_control_queue_init(SpSynthControlQueue *q) {if(q)memset(q,0,sizeof(*q));}
/* In sp_ui_dispatch, unshifted non-destination pad downs and all pad ups
 * emit at most one note command each. They cannot change page/patch or issue
 * backend requests. Keep shortcut/destination controls outside this grouping. */
static unsigned group_count(const SpSynthControlQueue *q,const SpSynthApp *a) {
    sp_ui_event_type type=q->events[q->head].type;
    if(type!=SP_UI_PAD_UP &&
       !(type==SP_UI_PAD_DOWN && !a->ui.shift && a->ui.page!=SP_UI_DESTINATION))return 1;
    unsigned n=1;
    while(n<q->count && n<16 && q->events[(q->head+n)%SP_SYNTH_CONTROL_QUEUE_CAPACITY].type==type)++n;
    return n;
}
int sp_synth_control_queue_push(SpSynthControlQueue *q,SpSynthAudioMailbox *m,const sp_synth_input_batch *b) {
    if(!q || !m || !b)return fail(q,m);
    if(q->faulted || atomic_load_explicit(&m->stop_requested,memory_order_acquire) ||
       b->count>SP_SYNTH_INPUT_BATCH_CAPACITY || b->count>SP_SYNTH_CONTROL_QUEUE_CAPACITY-q->count)
        return fail(q,m);
    for(unsigned i=0;i<b->count;++i)if(!valid(&b->events[i]))return fail(q,m);
    for(unsigned i=0;i<b->count;++i)
        q->events[(q->head+q->count+i)%SP_SYNTH_CONTROL_QUEUE_CAPACITY]=b->events[i];
    q->count=(uint16_t)(q->count+b->count);return 1;
}
SpControlService sp_synth_control_queue_service(SpSynthControlQueue *q,SpSynthAudioMailbox *m,SpSynthApp *a,uint32_t frames) {
    if(!q || !m || !a || !frames || frames>64) {fail(q,m);return SP_CONTROL_STOPPED;}
    if(q->faulted || atomic_load_explicit(&m->stop_requested,memory_order_acquire)) {
        fail(q,m);return SP_CONTROL_STOPPED;
    }
    SpAudioCompletion out;
    if(sp_synth_audio_mailbox_complete(m,a,&out)==SP_AUDIO_COMPLETED_FAILED) {
        fail(q,m);return SP_CONTROL_STOPPED;
    }
    if(!q->count)return SP_CONTROL_IDLE;
    if(atomic_load_explicit(&m->phase,memory_order_acquire)!=SP_AUDIO_FREE)return SP_CONTROL_IDLE;
    unsigned count=group_count(q,a);
    if(!sp_synth_audio_mailbox_begin(m,a)) {fail(q,m);return SP_CONTROL_STOPPED;}
    for(unsigned i=0;i<count;++i) {
        if(!sp_synth_app_dispatch(a,&q->events[(q->head+i)%SP_SYNTH_CONTROL_QUEUE_CAPACITY])) {
            fail(q,m);return SP_CONTROL_STOPPED;
        }
    }
    if(sp_synth_audio_mailbox_publish(m,a,frames)!=SP_AUDIO_PUBLISHED) {
        fail(q,m);return SP_CONTROL_STOPPED;
    }
    q->head=(uint16_t)((q->head+count)%SP_SYNTH_CONTROL_QUEUE_CAPACITY);q->count=(uint16_t)(q->count-count);
    return SP_CONTROL_SENT;
}
SpControlService sp_synth_control_queue_service_timed(SpSynthControlQueue *q,
    SpSynthMidiQueue *midi,SpSynthAudioMailbox *m,SpSynthApp *a,uint32_t target) {
    return sp_synth_control_queue_service_backend(q,midi,m,a,target,0,0);
}
SpControlService sp_synth_control_queue_service_backend(SpSynthControlQueue *q,
    SpSynthMidiQueue *midi,SpSynthAudioMailbox *m,SpSynthApp *a,uint32_t target,
    const SpAppCompletion *completion,SpBackendDelivery *delivery) {
    return sp_synth_control_queue_service_observed(q,midi,m,a,target,completion,delivery,0,0);
}
SpControlService sp_synth_control_queue_service_observed(SpSynthControlQueue *q,
    SpSynthMidiQueue *midi,SpSynthAudioMailbox *m,SpSynthApp *a,uint32_t target,
    const SpAppCompletion *completion,SpBackendDelivery *delivery,
    const SpAppCaptureProgress *progress,SpBackendDelivery *progress_delivery) {
    return sp_synth_control_queue_service_capture(q,midi,m,a,target,completion,delivery,
        progress,progress_delivery,0,0);
}
SpControlService sp_synth_control_queue_service_capture(SpSynthControlQueue *q,
    SpSynthMidiQueue *midi,SpSynthAudioMailbox *m,SpSynthApp *a,uint32_t target,
    const SpAppCompletion *completion,SpBackendDelivery *delivery,
    const SpAppCaptureProgress *progress,SpBackendDelivery *progress_delivery,
    const SpAppCaptureCancelCompletion *cancel,SpBackendDelivery *cancel_delivery) {
    if(delivery)*delivery=SP_BACKEND_WAITING;
    if(progress_delivery)*progress_delivery=SP_BACKEND_WAITING;
    if(cancel_delivery)*cancel_delivery=SP_BACKEND_WAITING;
    if(!q || !midi || !m || !a || !m->timed || target%SP_AUDIO_TIMED_FRAMES ||
       (completion && !delivery) || (progress && !progress_delivery) || (cancel && !cancel_delivery)) {
        fail(q,m);return SP_CONTROL_STOPPED;
    }
    if(q->faulted || midi->fault || atomic_load_explicit(&m->stop_requested,memory_order_acquire)) {
        fail(q,m);return SP_CONTROL_STOPPED;
    }
    SpAudioCompletion out;
    if(sp_synth_audio_mailbox_complete(m,a,&out)==SP_AUDIO_COMPLETED_FAILED) {
        fail(q,m);return SP_CONTROL_STOPPED;
    }
    if(atomic_load_explicit(&m->phase,memory_order_acquire)!=SP_AUDIO_FREE)return SP_CONTROL_IDLE;
    if(completion && (!a->ui.busy || completion->generation!=a->ui.generation ||
                      completion->generation!=a->request_issued_generation)) {
        ++a->stale_completions;*delivery=SP_BACKEND_STALE;return SP_CONTROL_IDLE;
    }
    /* A backend may publish HELD before the ordinary START reply. Keep its
     * receipt borrowed while still allowing panel releases and timed MIDI. */
    if(cancel && a->request_issued_generation && !completion)cancel=0;
    if(!completion && !progress && !cancel && !q->count && !midi->count)return SP_CONTROL_IDLE;
    uint32_t cursor;
    if(!sp_synth_audio_mailbox_cursor(m,&cursor) || target-cursor>SP_AUDIO_MAX_LOOKAHEAD ||
       (midi->has_closed && target-midi->closed_until>UINT32_MAX/2u)) {
        fail(q,m);return SP_CONTROL_STOPPED;
    }
    uint32_t offset=midi->count ? midi->events[midi->head].sample-target : SP_AUDIO_TIMED_FRAMES;
    if(midi->count && offset>UINT32_MAX/2u) {fail(q,m);return SP_CONTROL_STOPPED;}
    if(!completion && !progress && !cancel && !q->count && offset>=SP_AUDIO_TIMED_FRAMES)return SP_CONTROL_IDLE;
    if(!midi->has_watermark || midi->watermark-(target+SP_AUDIO_TIMED_FRAMES)>UINT32_MAX/2u)
        return SP_CONTROL_IDLE;
    if(!sp_synth_audio_mailbox_begin(m,a)) {fail(q,m);return SP_CONTROL_STOPPED;}
    if(completion) {
        /* A reported backend error is a consumed response, not an audio fault.
         * Completion clears the issued generation even when it reports error. */
        (void)sp_synth_app_complete(a,completion);
        *delivery=SP_BACKEND_APPLIED;
        if(a->request_issued_generation || a->audio_faulted || m->batch.failed) {
            fail(q,m);return SP_CONTROL_STOPPED;
        }
    }
    if(progress)*progress_delivery=sp_synth_app_capture_progress(a,progress)?SP_BACKEND_APPLIED:SP_BACKEND_STALE;
    if(cancel) {
        if(!sp_synth_app_cancel_complete(a,cancel->start_generation,cancel->take_token,
            cancel->audio_sequence,cancel->result) || a->audio_faulted || m->batch.failed) {
            fail(q,m);return SP_CONTROL_STOPPED;
        }
        *cancel_delivery=SP_BACKEND_APPLIED;
    }
    unsigned count=q->count ? group_count(q,a) : 0;
    for(unsigned i=0;i<count;++i) {
        if(!sp_synth_app_dispatch(a,&q->events[(q->head+i)%SP_SYNTH_CONTROL_QUEUE_CAPACITY])) {
            fail(q,m);return SP_CONTROL_STOPPED;
        }
    }
    if(sp_synth_midi_queue_publish(midi,m,a,target)!=SP_MIDI_PUBLISHED) {
        fail(q,m);return SP_CONTROL_STOPPED;
    }
    q->head=(uint16_t)((q->head+count)%SP_SYNTH_CONTROL_QUEUE_CAPACITY);
    q->count=(uint16_t)(q->count-count);
    return SP_CONTROL_SENT;
}
