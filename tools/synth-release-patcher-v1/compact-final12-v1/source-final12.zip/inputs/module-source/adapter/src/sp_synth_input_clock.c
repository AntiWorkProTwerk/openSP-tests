#include "sp_synth_input_clock.h"
int sp_synth_input_clock_init(SpSynthInputClock *c,uint32_t tick,uint32_t sample,
    uint32_t tick_hz,uint32_t sample_hz,uint32_t latency) {
    if(!c || !tick_hz || !sample_hz || latency<2*SP_AUDIO_TIMED_FRAMES ||
       latency>SP_AUDIO_MAX_LOOKAHEAD || latency%SP_AUDIO_TIMED_FRAMES)return 0;
    *c=(SpSynthInputClock){tick,sample,0,tick_hz,sample_hz,latency,SP_INPUT_CLOCK_OK};return 1;
}
int sp_synth_input_clock_map(SpSynthInputClock *c,uint32_t tick,uint32_t *sample) {
    if(!c)return 0;
    if(c->fault)return 0;
    if(!sample || !c->tick_hz || !c->sample_hz){c->fault=SP_INPUT_CLOCK_ARGUMENT;return 0;}
    uint32_t delta=tick-c->tick;
    if(delta>UINT32_MAX/2u){c->fault=SP_INPUT_CLOCK_ORDER;return 0;}
    /* delta<2^31 and both rates are32-bit: product plus remainder fits64. */
    uint64_t scaled=(uint64_t)delta*c->sample_hz+c->remainder;
    uint64_t advance=scaled/c->tick_hz;
    if(advance>UINT32_MAX/2u){c->fault=SP_INPUT_CLOCK_SPAN;return 0;}
    c->sample+=(uint32_t)advance;c->remainder=(uint32_t)(scaled%c->tick_hz);c->tick=tick;
    *sample=c->sample+c->latency;return 1;
}
int sp_synth_input_clock_midi(SpSynthInputClock *c,SpSynthMidiQueue *q,
    SpSynthAudioMailbox *m,uint32_t tick,const SpSynthEvent *e) {
    uint32_t sample;
    if(!sp_synth_input_clock_map(c,tick,&sample)){sp_synth_audio_mailbox_stop(m);return 0;}
    return sp_synth_midi_queue_push(q,m,sample,e);
}
int sp_synth_input_clock_watermark(SpSynthInputClock *c,SpSynthMidiQueue *q,
    SpSynthAudioMailbox *m,uint32_t tick) {
    uint32_t sample;
    if(!sp_synth_input_clock_map(c,tick,&sample)){sp_synth_audio_mailbox_stop(m);return 0;}
    return sp_synth_midi_queue_watermark(q,m,sample);
}
