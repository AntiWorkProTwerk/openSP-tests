#ifndef SP_SYNTH_MODULE_V552_H
#define SP_SYNTH_MODULE_V552_H
#include "sp_synth_memory_v552.h"
#include "sp_synth_panel_v552.h"
#include "sp_synth_audio_binding_v552.h"
#include "sp_synth_pad_release_v552.h"
#include "sp_synth_clock_handoff_v552.h"

#if SP_SYNTH_V552_MEMORY_PROFILE != SP_SYNTH_V552_MEMORY_RESERVED4K
#error "The v5.52 synth module requires the reserved4K memory profile"
#endif
#ifndef SP_SYNTH_V552_PAIR_INDEX
#error "Define SP_SYNTH_V552_PAIR_INDEX explicitly for this build"
#elif SP_SYNTH_V552_PAIR_INDEX < 0 || SP_SYNTH_V552_PAIR_INDEX > 6
#error "SP_SYNTH_V552_PAIR_INDEX must be0..6"
#endif

enum {
    SP_SYNTH_MODULE_OK=0,
    SP_SYNTH_MODULE_UNAVAILABLE=-1020,
    SP_SYNTH_MODULE_ALREADY_ATTEMPTED=-1021,
    SP_SYNTH_MODULE_UI_INIT_FAILED=-1022,
    SP_SYNTH_MODULE_PANEL_INIT_FAILED=-1023,
    SP_SYNTH_MODULE_NOT_PREPARED=-1024,
    SP_SYNTH_MODULE_AUDIO_INIT_FAILED=-1025,
    SP_SYNTH_MODULE_RELEASE_INIT_FAILED=-1026,
    SP_SYNTH_MODULE_CLOCK_INIT_FAILED=-1027,
    SP_SYNTH_MODULE_CLOCK_CLAIM_FAILED=-1028
};
typedef struct {
    _Alignas(8) SpSynthSessionV552 session;
    SpSynthPanelV552 panel;
    SpSynthAudioBindingV552 audio;
    SpSynthPadReleaseV552 release;
    SpSynthClockHandoffV552 clock;
    uint32_t initialized,preparation_attempted;
    int32_t preparation_result;
} SpSynthModuleV552;

/* One permanent BSS owner. The linker must place this object and every module
 * BSS byte inside the reserved page, disjoint from code, stack, native objects
 * and dynamic runtime. All components use the same reserved profile. No data
 * relocation, TLS or constructor initialization is provided by this module. */
extern SpSynthModuleV552 sp_synth_module_v552;

/* Cold-boot ONCE, before any callbacks; not restartable or idempotent. Calls
 * original80002261 once with original R0..R3 and preserves native R0/R1 bits.
 * Reads the proposed pool-patch word before/after that call. If either differs,
 * performs no BSS zeroing or owner initialization; native memory effects are
 * outside that guarantee. Otherwise zeroes the complete linker-owned
 * [__synth_bss_start,__synth_bss_end), initializes the unadmitted audio binding
 * with the compiled pair, and marks initialized only on success. Pair selection
 * is a supplied work-buffer index, not physical-route qualification. This call
 * never prepares session, admits audio, grants control or installs a callback.
 * Inspect initialized only after a matching, qualified cold-boot invocation:
 * patch mismatch deliberately provides no initialized owner-page status. */
uint64_t sp_synth_module_v552_pool(uint32_t original_r0,uint32_t original_r1,
    uint32_t original_r2,uint32_t original_r3);

/* Serialized qualified selected-panel owner (native object 0x8300A3E4), after
 * native panel initialization and successful cold initialization, and
 * before other control/UI callbacks use session. Stable config is disjoint from
 * module/runtime storage and supplies the existing startup clock/input budget.
 * Unadmitted audio may run: its wrapper never accesses session in that state.
 * Accepts one attempt, including failed config/startup. Calls session prepare,
 * UI registration, panel initialization, then retained-release registration.
 * The last step captures the native task ID. Passing the selected panel constant
 * does not establish task provenance: the caller must qualify this task as the
 * selected panel/control owner, require task-only dispatch, and retain its ID
 * without reuse while registered. Returns0 on success, propagates
 * startup/session errors, or returns the named registration errors above.
 * Failures request session stop (effective after readiness) and retain storage.
 * Stores the attempt's final result; unavailable/duplicate calls leave it intact.
 * After cold init, result is NOT_PREPARED, or AUDIO_INIT_FAILED if audio binding
 * setup failed; preparation_attempted remains0 in both cases.
 * No audio admission, normal-service gate, target grant, input drain or backend
 * I/O occurs here. Their clock, lifetime and component contracts still apply. */
int sp_synth_module_v552_prepare(const SpSynthStartupConfig *config);
/* Additive path after intact selected-panel initialization. Config explicitly
 * qualifies clock, maximum gaps, route, budget and task lifetime. Prepares once
 * without public readiness, registrations or admission. selected_panel must be
 * 0x8300A3E4 and the caller must be its qualified task, never an ISR. */
int sp_synth_module_v552_prepare_deferred(const SpSynthClockConfigV552 *config,
    void *selected_panel);
int sp_synth_module_v552_arm_deferred(void);
/* Same selected control task, after exact first audio binding/admission.
 * Requires a fresh ordered input snapshot and callback ownership qualification.
 * Registers UI/panel/release only after successful claim. Normal service,
 * Generator/Synth selection and fresh note enable still require explicit APIs. */
int sp_synth_module_v552_claim_deferred(const SpSynthClockClaimV552 *snapshot);
void sp_synth_module_v552_cancel_deferred(void);
#endif
