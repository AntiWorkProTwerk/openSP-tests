#ifndef SP_SYNTH_CAPTURE_PLAN_H
#define SP_SYNTH_CAPTURE_PLAN_H

#include "sp_synth_app.h"

/* Original control-side arithmetic only. The caller supplies a separately
 * qualified integer capture rate; accepting it establishes no route or clock.
 * duration_frames counts nominal recorded PCM, excluding count-in and tail.
 * count_in_frames precedes recording. Tail policy is retained without a length. */
typedef struct {
    uint64_t duration_frames;
    uint64_t count_in_frames;
    SpAppCapture capture;       /* Exact START values, including inactive mode. */
    uint32_t sample_rate_hz;
    uint32_t reserved;          /* Always zero. */
} SpSynthCapturePlan;

/* Serialized control/SMPL owner, never the audio callback. IEEE binary32
 * inputs: modes 0/1, seconds 1..120, bars 1..64, BPM 20..300, count-in 0..4,
 * tail 0/1. Both active and inactive numeric controls must be finite/in range.
 * sample_rate_hz is 1..UINT32_MAX. Exact input values are rounded to nearest
 * whole frame with positive half-frame ties up. No allocation or float math.
 * Returns 1 on success; returns 0 without changing *out on any refusal.
 * Inputs must remain stable for the call. Only complete plans may be shared;
 * this function supplies no cross-task publication or native frame limit. */
int sp_synth_capture_plan_build(const SpAppCapture *capture,
    uint32_t sample_rate_hz, SpSynthCapturePlan *out);

/* Immutable identity for one admitted START, separate from UI generation,
 * native handback tickets and record-barrier sequences. */
typedef struct {
    SpSynthCapturePlan plan;
    uint32_t start_generation;
    uint32_t take_token;
} SpSynthCaptureStartPlan;

/* Pure binding check; DOES NOT allocate/consume a token or acquire work.
 * The sole SMPL worker supplies its authoritative permanent last_token and
 * a candidate take_token > last_token. Real app START requires request.token=0
 * and generation!=0. Native admission must reserve the token and this plan once,
 * before side effects; SMPL retains them through errors and completion
 * backpressure. Do not preincrement the last_token that native BEGIN validates.
 * Discard/global handback must not reset last_token; exhaustion
 * refuses. Repeating this pure function cannot detect duplicate START work.
 * STOP token 0 continues to resolve to the worker's current native take.
 * No native BEGIN or app completion is issued here. Successful planning does
 * not authorize translating modes 0/1 into unlimited manual capture.
 * Returns 0 with unchanged *out on refusal; caller owns serialized lifetime. */
int sp_synth_capture_plan_start(const SpAppRequest *request,
    uint32_t sample_rate_hz, uint32_t last_token, uint32_t take_token,
    SpSynthCaptureStartPlan *out);

#endif
