#ifndef SP_SYNTH_PANEL_SERVICE_V552_H
#define SP_SYNTH_PANEL_SERVICE_V552_H
#include <stdint.h>

/* Permanent diagnostic counters, written only by the acquired selected panel
 * task. They saturate and are not clocks or evidence of an input cutoff. Cold
 * module initialization clears them with the complete linker-owned BSS. */
typedef struct { uint32_t opportunities,suspensions; } SpSynthPanelServiceV552;
extern SpSynthPanelServiceV552 sp_synth_panel_service_v552;

/* Called only by the attached native loop, after matching cold initialization.
 * Its R4 is the native panel object. Task-only loop provenance and the existing
 * coordinator's no-task-ID-reuse contract remain required. Acquire the permanent
 * coordinator identity before reading mutable state. No registration, input
 * claim, grant, watermark or heartbeat update occurs here. */
void sp_synth_panel_service_v552_opportunity(void *panel);
void sp_synth_panel_service_v552_before_control(void *panel,uint32_t control);

/* Assembly callsite entries: wait captures panel from native R4; control uses
 * native R0/R1. Both preserve original R0..R3 and tail-call the intact native
 * helper once. They preserve its raw return, including the native wait helper's
 * undefined pattern on a kernel error. Attach only at80072BB4/80072BCA. */
void sp_synth_panel_service_v552_wait(void);
void sp_synth_panel_service_v552_control(void);
#endif
