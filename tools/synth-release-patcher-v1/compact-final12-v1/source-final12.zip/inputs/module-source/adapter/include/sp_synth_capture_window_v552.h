#ifndef SP_SYNTH_CAPTURE_WINDOW_V552_H
#define SP_SYNTH_CAPTURE_WINDOW_V552_H
#include "sp_synth_capture_window.h"
/* Call only inside the existing qualified native RX lease, after a freshly
 * prepared normal stereo recorder and a published frame plan. The containing
 * owner must exclude native reuse/drain errors and serialize this window.
 * This function acquires no lease, makes no backend request and is not an
 * installed hook. Input is a stable, nonaliasing interleaved signed16 block.
 * Returns1 for committed input (including skipped frames),0 before admission,
 * -1 for an entered native operation whose acceptance/state check failed.
 * Check the window/native error before reporting progress; return is not PCM.
 * A rejected call does not establish retirement, STOP, HELD or a saved take. */
int sp_synth_capture_window_v552_consume(SpSynthCaptureWindow *,uint32_t token,
    const int16_t *input,uint32_t frames);
#endif
