#ifndef SP_SYNTH_LIVE_TIMED_V552_H
#define SP_SYNTH_LIVE_TIMED_V552_H
#include <stdint.h>

/* Separate from the input timestamp clock. Set only before cold initialization,
 * after the integer RX rate and recorded stream have been qualified. Immutable
 * for the entire provider lifetime; NULL keeps Synth admission closed. */
enum { SP_SYNTH_TIMED_RX_RATE=1, SP_SYNTH_TIMED_RX_STREAM=2,
    SP_SYNTH_TIMED_QUALIFIED=3 };
typedef struct {
    uint32_t sample_rate_hz,qualified;
} SpSynthLiveTimedConfigV552;
extern const SpSynthLiveTimedConfigV552 * const sp_synth_live_timed_v552_config;
#if defined(SP_SYNTH_FULL_V552) && defined(SP_SYNTH_NATIVE_BOUND_V552)
/* Actual one-time capture/tail/backend publication. The selected entry owner
 * must wait for this receipt before starting Synth preparation. Native chooser,
 * Generator and cancellation service remain available while it is pending. */
int sp_synth_live_capture_v552_attachment_ready(void);
#endif
#endif
