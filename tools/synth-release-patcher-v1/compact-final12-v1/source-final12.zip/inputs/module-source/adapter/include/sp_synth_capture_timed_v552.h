#ifndef SP_SYNTH_CAPTURE_TIMED_V552_H
#define SP_SYNTH_CAPTURE_TIMED_V552_H
#include "sp_synth_session_v552.h"
#include "sp_synth_capture_window_v552.h"
#include "sp_synth_project_save_v552.h"

/* RX -> sole SMPL worker snapshot. The slot is never overwritten unread.
 * Milestones are sticky within a token; late observation cannot lose START or
 * nominal completion. It is not a control/UI completion or a native HELD proof. */
typedef struct {
    uint64_t observed_frames,accepted_frames;
    uint32_t generation,token,phase,failed_accepted,native_failed,milestones,tail_cut_reason;
} SpSynthCaptureTimedNotice;
enum { SP_TCAP_PCM_STARTED=1, SP_TCAP_NOMINAL_REACHED=2, SP_TCAP_WINDOW_ENDED=4 };

enum { SP_TCAP_FREE, SP_TCAP_RESERVING, SP_TCAP_RESERVED,
    SP_TCAP_RUNNING, SP_TCAP_STOP_PENDING, SP_TCAP_HELD,
    SP_TCAP_SAVING, SP_TCAP_FINALIZED, SP_TCAP_ERROR, SP_TCAP_ACQUIRING,
    SP_TCAP_EXCLUSIVE_IDLE, SP_TCAP_BEGIN, SP_TCAP_DISCARD_BARRIER, SP_TCAP_DISCARDING,
    SP_TCAP_WAIT_DELETE, SP_TCAP_RELEASE_BARRIER };
enum { SP_TCAP_BLOCKED=-1040, SP_TCAP_CONTEXT=-1041,
    SP_TCAP_NATIVE_STATE=-1042, SP_TCAP_UNEXPECTED_SAVE=-1043,
    SP_TCAP_INITIAL_WRITE=-1044, SP_TCAP_CLOSE=-1045, SP_TCAP_UNLINK=-1046,
    SP_TCAP_CUTOFF=-1047, SP_TCAP_EXIT=-1048, SP_TCAP_EXHAUSTED=-1049,
    SP_TCAP_PROJECT=-1050 };
#define SP_TCAP_UNSUPPORTED UINT32_C(0x80000000)
/* App modes0/1 only. The caller separately qualifies the integer RX sample
 * rate. No manual mode, guessed physical route or TX-to-RX tail mapping. */
/* Low byte is phase; tracked native work owns a 0x100 lease until return.
 * Bit31 is permanent unsupported-context provenance and prevents zero-lease
 * acquisition/retirement. An observed unqualified FREE entry retains native
 * fallback; owned unqualified writers/posts are rejected. This is not IRQ
 * writer support, a native scheduler proof or permission for ISR API callers.
 * All storage is permanent. Initialization and hooks must precede native task
 * callbacks. No late installation or owner reset is supported.
 * Placement is external; this component does not reserve firmware RAM. All
 * native hooks must be installed together before callbacks, and every guarded
 * entry must retain its installed arguments/provenance. Task IDs cannot be
 * reused while registered. One serialized SMPL action4 consumer owns work;
 * no other backend consumer, recursive worker, ISR API caller or owner reset.
 * Owner, session and allocated runtime must be disjoint permanent storage.
 * This separate timed revision replaces V3; never link duplicate capture owners.
 * Plan fields are SMPL-owned until RUNNING release publication and immutable
 * until native cleanup plus the next zero-lease admission. Window is RX-only.
 * RX callbacks for the qualified task must be serialized and nonrecursive. */
typedef struct {
    atomic_uint state,token,rx_ack,fault,permit,audio_task;
    _Atomic(SpSynthBackendLink *) backend;
    uint32_t last_token,handle,work_token,working,response_ready,closed_request;
    atomic_uint native_save_count,blocked_save_count;
    atomic_uint record_ready,barrier_token,barrier_ack;
    atomic_uint barrier_sequence,wait_sequence,handoff_pending,handoff_fault;
    atomic_uint exit_ticket,released_ticket;
    uint32_t last_ticket,exit_requested;
    uint32_t override_mask,write_count,discard_attempted,file_owned,descriptor;
    int32_t initial_write_raw,close_raw,unlink_raw,setup_unlink_raw,setup_raw,start_raw;
    int32_t save_raw;
    SpAppRequest work;
    SpAppCompletion completion;
    uint32_t sample_rate_hz,start_admitted,start_canceled;
    SpSynthCaptureStartPlan plan;
    SpSynthCaptureWindow window;
    atomic_uint rx_active,started_token,cleanup_token,notice_ready;
    SpSynthCaptureTimedNotice notice,observed_notice;
    atomic_uint fence_phase;
    uint32_t fence_token;
    uint64_t fence_frame;
    int32_t fence_result;
    /* SMPL-owned, permanent project transaction and one native SAVE witness.
     * Never reset/release after FINALIZED without qualified file/project recovery. */
    SpSynthProjectSaveV552 project_write;
    uint32_t save_project,project_calls;
    int32_t project_raw;
    atomic_uint tail_cut_reason;
#ifdef SP_SYNTH_NATIVE_BOUND_V552
    /* Consumed START identity refused before any native I/O. This is separate
     * from cleanup_token and cannot retire an RX window or retained file. */
    atomic_uint pre_io_abort_token;
#endif
} SpSynthCaptureTimedV552;

/* Cold once: zero owner outside native pool; no callbacks may have entered. */
int sp_synth_capture_timed_v552_init(SpSynthCaptureTimedV552 *owner,uint32_t qualified_rx_rate);
/* Selected native panel task publishes an initialized, pinned session link.
 * Worker never invokes a session/control service. Publication is one-shot. */
int sp_synth_capture_timed_v552_publish(SpSynthSessionV552 *session);
/* Qualified panel owner after request publication or response-slot release.
 * Schedules action4 only. The ordinary control attachment is still external. */
int sp_synth_capture_timed_v552_kick(void);
/* Actual SMPL task only. Validates the real immutable START request (token0,
 * positive generation, modes0/1) and reserves last_token+1 before file effects.
 * Runs native setup/open/initial write/start, then publishes the frame plan.
 * Returns1 for prepared, NOT for first PCM or app START success. The sole worker
 * delays that response until RX publishes started_token. Error retains ownership.
 * Uses one checked, non-nesting native dispatch-inhibit pair for admission and
 * token reset only. Existing leases still exclude suspended callbacks; native
 * recorder/filesystem calls begin after dispatch is restored. No ISR callers.
 * Request must be immutable and disjoint from all owner/session storage. */
int sp_synth_capture_timed_v552_begin(const SpAppRequest *request);
/* Sole SMPL worker after a separately acknowledged control/audio cancellation.
 * Cancels the exact admitted START before or after its response is published,
 * provided no later ordinary request has been queued/acquired and discard/save/
 * handback has not taken ownership. The original START generation and token
 * must still match the immutable plan. Repeated admission is harmless before
 * discard. Returns1 for STOP admitted, not RX settlement or file cleanup.
 * An already published START response remains immutable in the control inbox;
 * the future cancellation consumer must retire it before issuing DISCARD.
 * UI/control cancellation transport is not implemented here. */
int sp_synth_capture_timed_v552_cancel_start(uint32_t generation);
/* Sole SMPL owner:0 unknown/pending,1 exact canceled take HELD after RX return,
 * -1 retained failure. Does not wait, complete START, clear a fault or discard.
 * Result1 still requires the normal tokened DISCARD and its checked RECORD barrier,
 * close/unlink/reset before the UI may report cancellation complete. The
 * result becomes unavailable once another ordinary request owns the worker. */
int sp_synth_capture_timed_v552_cancel_result(uint32_t generation);
/* Sole SMPL owner, qualified recorded-stream fence only. One pending fence;
 * RX consumes it at a block boundary. status returns0 pending/no acknowledgment,
 * 1 applied, -1 refused, then releases the mailbox. A late fence is refused and
 * faults the take; it is never retimed. These calls supply no note gate, release
 * acknowledgment, route delay or effects-tail proof. */
int sp_synth_capture_timed_v552_tail_fence(uint32_t token,uint64_t frame);
int sp_synth_capture_timed_v552_fence_status(uint32_t token);
/* Sole SMPL worker, disjoint output. Latest worker-consumed coherent notice;
 * token/generation must be checked by a future control publication bridge. */
int sp_synth_capture_timed_v552_status(SpSynthCaptureTimedNotice *out);
int sp_synth_capture_timed_v552_stop(uint32_t token);
/* Same task/token, after acknowledged STOP and drain retirement. Starts a
 * record-task barrier, then checked close/unlink/reset on later worker passes.
 * Returns1 accepted/pending,0 rejected. Successful completion retires the token
 * into EXCLUSIVE_IDLE. A later held backend LEAVE drives checked handback. */
int sp_synth_capture_timed_v552_discard(uint32_t token);
/* Low-level native primitive, NOT connected to TAKE_WRITE requests. Requires a
 * separately qualified destination already bound at outer+4C, with overwrite
 * permission and project/file ownership established. Calls native SAVE once,
 * requires internal SMP format and a matching checked project write. Records
 * native raw result separately and returns a latched error when project work
 * fails/is absent. Then pins FINALIZED/error provenance. Sample/rename/file
 * identity still needs qualification: a zero result is NOT a pad-success
 * completion. No retry, reset or token release is provided. */
int32_t sp_synth_capture_timed_v552_save_once(uint32_t token);
/* Exact two native SAVE->project callsites. Ordinary FREE state delegates;
 * an owned SAVE invokes the project guard once for its retained take/project. */
uint32_t sp_synth_capture_timed_v552_project_save(uint32_t,uint32_t,uint32_t,uint32_t);

/* Exact installed-boundary adapters; assembly entries restore the callback's
 * originally resolved R2. Native trampolines replay displaced prologues.
 * Null owner, unrelated objects and qualified unrelated/FREE paths call native
 * once. Native message storage must remain valid and immutable through return.
 * EXCLUSIVE_IDLE deliberately keeps ordinary recorder mutation blocked.
 * Owned rejection intentionally returns SP_TCAP_BLOCKED. */
uint32_t sp_synth_capture_timed_v552_smpl(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_record(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_dispatch(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_save(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_rx(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_consume(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_initial_write(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_stereo_query(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_mode_query(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_setup_unlink(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_record_init(uint32_t,uint32_t,uint32_t,uint32_t);
/* Sole SMPL backend owner only. Exact-ticket readiness keeps recorder mutation
 * closed; deletion is requested through the live provider. RELEASED is published
 * only after that provider's deletion ack and the final record-task batch.
 * Standalone tests model the provider boundary; joint deletion remains a
 * separate composition. RELEASED is historical evidence for that exact ticket.
 * These predicates never infer handback from token0 or EXCLUSIVE_IDLE. */
int sp_synth_capture_timed_v552_exit_ready(uint32_t ticket);
int sp_synth_capture_timed_v552_released(uint32_t ticket);
/* Shared wait recipe: preserve original R0-R4/LR, call this RECORD-only hook,
 * then tail into the unchanged live-session wait shim. That shim alone executes
 * native11978. One72BB4 call/80103394 veneer target replaces the old target. */
void sp_synth_capture_timed_v552_before_wait(void *native_object);
void sp_synth_capture_timed_v552_wait(void);
uint32_t sp_synth_capture_timed_v552_append(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_coalesce(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_deferred(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_post_drain(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_timed_v552_post_save(uint32_t,uint32_t,uint32_t,uint32_t);
#endif
