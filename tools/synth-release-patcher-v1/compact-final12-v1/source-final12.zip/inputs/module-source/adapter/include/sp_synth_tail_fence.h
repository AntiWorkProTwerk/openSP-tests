#ifndef SP_SYNTH_TAIL_FENCE_H
#define SP_SYNTH_TAIL_FENCE_H
#include <stdint.h>

enum { SP_TAIL_RATE=1u, SP_TAIL_ORDER=2u, SP_TAIL_DELAY=4u,
    SP_TAIL_EFFECTS=8u, SP_TAIL_QUALIFIED=15u };
typedef struct {
    uint32_t sample_rate_hz,block_frames,qualified;
    /* At the first RX slice, its source TX position is the completed TX
     * cursor plus this separately qualified signed offset. Both callbacks
     * must be serialized on the same audio owner. */
    int32_t source_offset_frames;
    /* Qualified upper bound after the synth becomes quiet. Zero requires a
     * route without an additional effect tail. */
    uint32_t effect_tail_frames;
} SpSynthTailProfile;
typedef struct {
    uint32_t generation,token,release_sequence,quiet_sequence,quiet_sample;
    uint32_t quiet;
    uint64_t release_start_frames;
} SpSynthTailReceipt;
typedef struct {
    SpSynthTailProfile profile;
    uint32_t initialized,last_token,generation,token,source_tx_start;
    uint32_t release_sequence,quiet_sequence,quiet_sample,has_release,has_quiet;
    uint64_t count_in_frames,duration_frames,release_start_frames;
    uint64_t limit_frame,quiet_frame,last_observed;
} SpSynthTailFence;
typedef struct {
    uint64_t frame;
    uint32_t at_limit,already_crossed;
} SpSynthTailBoundary;

/* Pure RX-owner arithmetic; no hardware qualification or native STOP. Owner
 * is cold-zero, profile immutable. Frame observations and receipts are copied
 * at real callback boundaries by the platform. The sample cursor may wrap;
 * each take and source offset must stay inside its signed half-range. */
int sp_synth_tail_fence_init(SpSynthTailFence *,const SpSynthTailProfile *);
int sp_synth_tail_fence_begin(SpSynthTailFence *,uint32_t generation,uint32_t token,
    uint32_t tx_cursor,uint64_t count_in_frames,uint64_t duration_frames);
/* A release receipt requires an actual acknowledged ALL_NOTES_OFF batch.
 * A quiet receipt additionally requires its end-of-render quiet observation.
 * Wrong identities, changed receipts and decreasing observations refuse. */
int sp_synth_tail_fence_receive(SpSynthTailFence *,const SpSynthTailReceipt *,
    uint64_t observed_frames);
/* Returns the maximum tail boundary, or an earlier quiet-derived boundary.
 * If RX has already crossed the quiet-derived position, returns the CURRENT
 * RX boundary and preserves the original quiet position for evidence. This
 * deliberately retains extra silence; it never drops or retimes tail PCM. */
int sp_synth_tail_fence_boundary(SpSynthTailFence *,uint64_t observed_frames,
    SpSynthTailBoundary *);
#endif
