#ifndef SP_SYNTH_CLOCK_HANDOFF_V552_H
#define SP_SYNTH_CLOCK_HANDOFF_V552_H
#include "sp_synth_session_v552.h"
struct SpSynthAudioBindingV552;

typedef enum {
    SP_CLOCK_EMPTY,SP_CLOCK_PREPARING,SP_CLOCK_PREPARED,SP_CLOCK_ARMED,
    SP_CLOCK_BINDING,SP_CLOCK_BOUND,SP_CLOCK_CLAIMED,SP_CLOCK_TERMINAL
} SpSynthClockPhase;
/* These bits assert independent qualification supplied by the integrator.
 * No value measured by this module can substitute for those facts. */
enum {
    SP_CLOCK_QUAL_COUNTER=1u, /* enabled, fixed measured rate and no reset */
    SP_CLOCK_QUAL_GAP=2u, /* every counter observation gap below max_audio_gap */
    SP_CLOCK_QUAL_ROUTE=4u, /* exact tuple/pair and continuous 48k/64-frame path */
    SP_CLOCK_QUAL_BUDGET=8u, /* supplied voice/render and control budget */
    SP_CLOCK_QUAL_TASK=16u, /* selected task, FPU/stack, no ISR or task-ID reuse */
    SP_CLOCK_QUAL_ALL=31u,
    SP_CLOCK_CLAIM_DRAINED=1u, /* pre-epoch input remains stock-owned */
    SP_CLOCK_CLAIM_SNAPSHOT=2u, /* fresh held controls at ordered boundary */
    SP_CLOCK_CLAIM_CALLBACKS=4u, /* selected task/lifetime callback exclusion */
    SP_CLOCK_CLAIM_ALL=7u
};
typedef struct {
    SpSynthDeferredStartupConfig startup;
    volatile const uint32_t *counter; /* qualified CYCCNT, 0xE0001004 only */
    uint32_t max_audio_gap,first_control_age,control_age,qualified;
} SpSynthClockConfigV552;
typedef struct {uint32_t held_pads,shift,qualified;} SpSynthClockClaimV552;

/* Permanent coordinator outside the native allocation pool. Initialize once
 * before any callback. Immutable request fields publish at ARMED. Audio alone
 * owns last_audio_tick/age/seen_heartbeat/epoch after binding. Control owns the
 * clock object after BOUND publication; audio never accesses it again. */
typedef struct SpSynthClockHandoffV552 {
    SpSynthSessionV552 *session;
    struct SpSynthAudioBindingV552 *audio;
    volatile const uint32_t *counter;
    uint32_t sample,tick_hz,latency,max_audio_gap,first_control_age,control_age;
    atomic_uint task_id,phase,heartbeat;
    uint32_t last_audio_tick,age,seen_heartbeat,epoch;
} SpSynthClockHandoffV552;

int sp_synth_clock_handoff_v552_init(SpSynthClockHandoffV552 *owner,
    SpSynthSessionV552 *session,struct SpSynthAudioBindingV552 *audio);
/* Selected task, after native panel initialization. One attempt. Configuration
 * is stable/disjoint and all qualification flags are mandatory. Allocates and
 * pins prepared storage with public ready0 and an unbound clock/input owner.
 * Returns0 prepared; -1030 invalid, -1031 unavailable, startup errors propagate.
 * A failed first attempt is terminal. Later calls reject without changing an
 * existing lifetime. Cancellation retains pinned storage. */
int sp_synth_clock_handoff_v552_prepare(SpSynthClockHandoffV552 *owner,
    const SpSynthClockConfigV552 *config,void *selected_panel);
/* Same serialized control task. One-shot release publication; no audio enable,
 * clock read or waiting. Requires untouched origin, empty queues and no stop. */
int sp_synth_clock_handoff_v552_arm(SpSynthClockHandoffV552 *owner);
/* Audio binding calls once after intact native mixer and exact tuple check.
 * Binds once, commits admission and permits rendering that same call. Later
 * calls supervise age. No allocation, app preparation, division or waiting. */
void sp_synth_clock_handoff_v552_audio(SpSynthClockHandoffV552 *owner,int exact_tuple);
/* Any owner after init. Terminal latch; before admission it closes its CAS
 * phase permanently. BINDING->BOUND is the admission commit; the audio binding's
 * admitted flag is its publication mirror. After that commit normal mailbox
 * stop acknowledgment applies, including cancellation before mirror publication.
 * Ready is never reset and there is no retry, reanchor or reclamation. */
void sp_synth_clock_handoff_v552_cancel(SpSynthClockHandoffV552 *owner);
/* Qualified control task only. Acquire successful binding/admission, enforce
 * age, initialize input once from the fresh ordered snapshot, and publish one
 * fresh input cutoff. No fresh note admission or UI registration occurs here. */
int sp_synth_clock_handoff_v552_claim(SpSynthClockHandoffV552 *owner,
    const SpSynthClockClaimV552 *snapshot);
int sp_synth_clock_handoff_v552_control_owner(const SpSynthClockHandoffV552 *owner);
/* Guard every resumed control entry, including silence. Expiry is terminal.
 * Retained captured releases may still use the session terminal route. */
int sp_synth_clock_handoff_v552_check(SpSynthClockHandoffV552 *owner);
/* Caller has drained every source before cutoff_tick. The heartbeat is that
 * actual ordered observation, never the time at which old work is serviced.
 * Same/old ticks cannot refresh its age. Must call during silence too. */
int sp_synth_clock_handoff_v552_watermark(SpSynthClockHandoffV552 *owner,uint32_t cutoff_tick);
/* Ordered source observation after claim. Input must be disjoint and stable.
 * Does not refresh the drain heartbeat; watermark closes the merged sources. */
int sp_synth_clock_handoff_v552_midi(SpSynthClockHandoffV552 *owner,uint32_t tick,
    const SpSynthEvent *event);
#endif
