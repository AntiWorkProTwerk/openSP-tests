#ifndef SP_SYNTH_ENTRY_OWNER_V552_LIVE_H
#define SP_SYNTH_ENTRY_OWNER_V552_LIVE_H
#include "sp_synth_entry_owner_v552.h"
/* Separate source variant for the live-session composition. Link it instead
 * of the accepted entry-owner C file, never alongside that file. All existing
 * entry functions and owner layout retain their original implementation.
 *
 * Trusted selected-page callback after native generic routing. Offer only the
 * current copied kind5 REC/EXIT/VALUE, kind7 VALUE or kind9 CTRL record. Button
 * payload beyond kind/index is undefined and is not compared. Other controls
 * compare the signed16 native value too. A fresh matching frame is offered
 * once; old-prefix, duplicate, stale, disabled and foreign offers return0.
 * A successful offer reserves source ownership, not musical admission: the
 * caller must still run its native derived child/modal decisions once. */
int sp_synth_entry_owner_v552_control_offer(void *panel,uint32_t kind,
    int32_t index,int32_t value);
typedef struct { uint32_t ticket,physical_pads,shift; } SpSynthFreshEntryV552;
/* Selected owner outside scanner/drain frames. Establish a new record cutoff
 * and require actual completed samples of all16 pads after this call. SHIFT
 * is the continuously observed native edge state; unknown SHIFT blocks ready.
 * The result is physical state, distinct from captured-release suppression. */
uint32_t sp_synth_entry_owner_v552_fresh_begin(void);
int sp_synth_entry_owner_v552_fresh(uint32_t ticket,SpSynthFreshEntryV552 *out);
/* Selected owner immediately before enter. Track the real fresh-held mask for
 * one app UP when those silent pads release. Completed sampler release does
 * not retire captured stock ups; their copied native record still runs gate. */
int sp_synth_entry_owner_v552_fresh_admit(uint32_t ticket);
/* Fresh copied chooser VALUE/EXIT offer while note admission remains disabled.
 * A chooser pad down is captured silently so its later release remains ours. */
int sp_synth_entry_owner_v552_chooser_offer(void *panel,uint32_t kind,int32_t index,int32_t value);
int sp_synth_entry_owner_v552_chooser_page(void *panel,const void *record);
#endif
