#ifndef SP_SYNTH_CAPTURE_TAIL_V552_H
#define SP_SYNTH_CAPTURE_TAIL_V552_H
#include "sp_synth_tail_fence.h"
#include "sp_synth_audio_mailbox.h"
#include "sp_synth_capture_window.h"

/* Entire platform profile stays NULL until the actual native route's rate,
 * callback order, source offset and any effects tail have been qualified. */
extern const SpSynthTailProfile *const sp_synth_capture_tail_v552_config;
int sp_synth_capture_tail_v552_init(void);
int sp_synth_capture_tail_v552_attach(SpSynthAudioMailbox *);
/* Selected control owner, AFTER completed live service/audio receipt. Copies
 * app observations; no audio/RX/worker reads of the app are permitted. Full
 * receipt slot is retained and retried, never overwritten. */
int sp_synth_capture_tail_v552_publish(const SpSynthApp *);
/* Serialized qualified RX owner only, before consuming this block. */
int sp_synth_capture_tail_v552_step(SpSynthCaptureWindow *,uint32_t *at_limit);
#endif
