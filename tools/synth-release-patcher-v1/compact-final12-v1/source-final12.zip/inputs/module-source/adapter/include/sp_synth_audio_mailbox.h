#ifndef SP_SYNTH_AUDIO_MAILBOX_H
#define SP_SYNTH_AUDIO_MAILBOX_H
#include "sp_synth_audio_mix.h"
#include <stdatomic.h>

typedef enum {SP_AUDIO_FREE,SP_AUDIO_WRITING,SP_AUDIO_READY,SP_AUDIO_DONE} SpAudioPhase;
typedef enum {SP_AUDIO_NOT_PUBLISHED,SP_AUDIO_PUBLISHED,SP_AUDIO_PUBLISHED_FAILED} SpAudioPublication;
typedef enum {SP_AUDIO_NO_COMPLETION,SP_AUDIO_COMPLETED,SP_AUDIO_COMPLETED_FAILED} SpAudioCompletionStatus;
typedef struct {
    uint32_t sequence;SpSynthStockResult result;
    uint32_t quiescent,sample_end; /* Audio-owned end-of-render observation. */
} SpAudioCompletion;
#define SP_AUDIO_TIMED_FRAMES 64u
#define SP_AUDIO_MAX_LOOKAHEAD 4096u
typedef struct {
    SpAppAudioBatch batch;
    SpAudioCompletion completion;
    atomic_uint phase,stop_requested,stopped;
    atomic_uint sample_cursor; /* Audio writer; completed successful frames. */
    uint32_t target_sample; /* Producer writes before READY; then immutable. */
    uint8_t timed; /* Immutable after initialization. */
} SpSynthAudioMailbox;

/* Exactly one serialized control producer and one serialized audio consumer.
 * Initialize with both stopped; keep the entire mailbox disjoint from app,
 * audio state, scratch and work storage. Normal CPU memory only, no DMA/ISR
 * producer. No allocation, waiting, mutex, retry loop or pointer publication. */
void sp_synth_audio_mailbox_init(SpSynthAudioMailbox *mailbox);
/* Optional fixed64-frame software timeline. Both owners must be stopped.
 * Initial sample must be a multiple of64; unsigned wrap is intentional.
 * This counts rendered samples, not hardware/DAC time. No wall-clock mapping.
 * Timed mode rejects the ordinary publish API and nonzero blocks other than64. */
int sp_synth_audio_mailbox_init_timed(SpSynthAudioMailbox *mailbox,uint32_t initial_sample);
/* Snapshot of the next uncompleted block start, possibly already in progress.
 * A snapshot is not a reservation. Caller owns disjoint output storage. */
int sp_synth_audio_mailbox_cursor(const SpSynthAudioMailbox *mailbox,uint32_t *sample);
int sp_synth_audio_mailbox_begin(SpSynthAudioMailbox *mailbox,SpSynthApp *app);
SpAudioPublication sp_synth_audio_mailbox_publish(SpSynthAudioMailbox *mailbox,SpSynthApp *app,uint32_t frames);
/* Timed mode only: target must be0..4096 samples ahead of a cursor snapshot,
 * in multiples of64. Seals exactly64 frames. A publication race can still miss
 * the deadline; audio then fails completion, leaves work unchanged and stops.
 * Current-cursor admission allows consecutive blocks but is not a reservation.
 * Invalid admission leaves WRITING unsealed. Do not silently retime MIDI. */
SpAudioPublication sp_synth_audio_mailbox_publish_at(SpSynthAudioMailbox *mailbox,SpSynthApp *app,uint32_t target_sample);
SpAudioCompletionStatus sp_synth_audio_mailbox_complete(SpSynthAudioMailbox *mailbox,SpSynthApp *app,SpAudioCompletion *out);
/* Consumer mixes at most one batch; FREE/WRITING/DONE ticks continue audio.
 * Zero frames does not consume READY. Every consumed batch gets one completion.
 * Any mixing failure latches stop. An explicit stop is acknowledged on the
 * next consumer call; a call already in progress may finish its current block.
 * Once acknowledged, later calls leave work unchanged and do not touch engine.
 * Stop ack is not DAC-buffer drain, task detachment or permission to free this
 * mailbox. Reinitialization/resume requires both owners quiescent externally. */
SpSynthStockResult sp_synth_audio_mailbox_mix(SpSynthAudioMailbox *mailbox,SpAppAudioState *audio,
    const SpSynthStockBlock *block,SpSynthAppMixScratch *scratch);
void sp_synth_audio_mailbox_stop(SpSynthAudioMailbox *mailbox);
int sp_synth_audio_mailbox_stopped(const SpSynthAudioMailbox *mailbox);
#endif
