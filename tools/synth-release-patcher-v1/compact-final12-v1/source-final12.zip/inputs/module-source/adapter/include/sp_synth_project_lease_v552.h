#ifndef SP_SYNTH_PROJECT_LEASE_V552_H
#define SP_SYNTH_PROJECT_LEASE_V552_H
#include "sp_synth_native_lease.h"

/* Samples original CPU/task/project state before any local interrupt mask.
 * Uses only the pinned v5.52 getters. Zero means context cannot be admitted. */
int sp_synth_lease_context_v552(SpSynthLeaseContext *);
/* Same native getters and normal CPU/task requirements, allowing ordinary
 * startup sentinels and storage transitions for observation before ownership.
 * Never use this weaker identity check for a Synth grant, borrow, or capture. */
int sp_synth_lease_observation_context_v552(SpSynthLeaseContext *);

/* These observers have no installed hooks and attest no native coverage.
 * Publication enables observation only; it cannot grant a production lease. */
int sp_synth_project_lease_v552_publish(SpSynthNativeLease *);
uint32_t sp_synth_project_lease_v552_coverage(void);
int sp_synth_project_lease_v552_grant(SpSynthLeaseGrant *);

/* Scoped replacement only for the checked UI call at 0x8013CFEE (argument42).
 * A nonzero result follows the native busy exit at 0x8013CFF4. */
uint32_t sp_synth_project_lease_v552_ui_busy(uint32_t);
/* Retains a conflicting primary record before native dequeue/consumer store.
 * The native Boolean zero return is the existing no-record result. This
 * sentry requires root-producer admission to prevent queue overflow. */
uint32_t sp_synth_project_lease_v552_dequeue(uint32_t record);
int sp_synth_project_lease_v552_conflict(uint32_t tag,uint32_t command);
/* Future typed pre-entry hooks call these before any side effect. An ignored
 * stock dispatcher return cannot implement this admission decision. */
uint32_t sp_synth_project_lease_v552_enter(uint32_t group);
int sp_synth_project_lease_v552_leave(uint32_t ticket);
int sp_synth_project_lease_v552_load_begin(uint32_t ticket);
int sp_synth_project_lease_v552_metadata(uint32_t ticket,uint32_t success);
int sp_synth_project_lease_v552_load_return(uint32_t ticket,uint32_t sample_ready);
#endif
