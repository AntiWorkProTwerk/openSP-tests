#ifndef SP_SYNTH_PANEL_V552_H
#define SP_SYNTH_PANEL_V552_H
#include "sp_synth_session_v552.h"

/* One serialized control owner, including every API and callback below. Zero
 * once in permanent storage outside the stock pool and disjoint from session.
 * Prepare and claim control readiness first. Register on the qualified native panel task and retain
 * both for this boot, without task ID reuse. Release/acquire publication allows
 * unrelated native callbacks during registration; they keep native behavior.
 * No reset, free, second registration, concurrent control owner or ISR use.
 * Fields are observable status; mutate them only through this API. */
typedef struct {
    SpSynthSessionV552 *session;
    uint32_t normal_service, pending, target;
    uint32_t service_count; /* Wrapping count of attempted session service calls. */
    SpControlService service_result; /* Last attempted service, initially IDLE. */
    uint32_t task_id; /* Immutable after release publication. */
} SpSynthPanelV552;

/* Registers one initialized context in this module's initialized BSS. Writes
 * no stock callback/table. Returns1 once,0 for invalid/occupied registration. */
int sp_synth_panel_v552_init(SpSynthPanelV552 *owner,SpSynthSessionV552 *session);
/* Explicit externally qualified normal-service lifetime admission. Revoking
 * cancels any outstanding grant. This is independent of synth input enable and
 * session stop, and does not claim stock sleep/shutdown has been detected. */
int sp_synth_panel_v552_normal_service(SpSynthPanelV552 *owner,int admitted);
/* One attempt at a caller-chosen 64-frame target. Caller has drained every input
 * source and established the MIDI watermark, clock mapping and safe deadline.
 * Requires admission and no outstanding grant. Checks cutoff/cursor now and
 * again after the native action. Does not advance a cutoff or reserve audio.
 * Skipped callbacks retain the grant; revoke admission to cancel/replace it.
 * The qualifying callback consumes it before service, even when service is
 * IDLE. A retry needs a newly qualified grant. Returns1 accepted,0 rejected. */
int sp_synth_panel_v552_grant(SpSynthPanelV552 *owner,uint32_t target);
/* Stock-compatible action ABI at v5.52 virtual slot+0x20. Always calls original
 * 80072CF1 once with original R0..R3 and returns its raw R0 unchanged. Only after
 * selected panel8300A3E4/action0 returns on the registered task may an admitted
 * grant service session. Wrong tasks do not read mutable owner/session state.
 * Stock pointer/action validity remains the caller's responsibility, including
 * when unregistered. No task entry, callback installation or input drain here. */
uint32_t sp_synth_panel_v552_dispatch(void *panel,uint32_t action,
    uint32_t original_r2,uint32_t original_r3);
#endif
