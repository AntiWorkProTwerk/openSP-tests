#ifndef SP_SYNTH_AUDIO_MIX_H
#define SP_SYNTH_AUDIO_MIX_H
#include "sp_synth_app_mix.h"
#include "sp_synth_audio_batch.h"

/* Audio owner only. An optional immutable batch must match block.frames;
 * null continues rendering without a control update. Uses the measured stock
 * 14-word layout and existing 768-byte scratch, with no app/UI access.
 * Audio, batch, scratch and used work words must be pairwise disjoint.
 * Zero frames consumes nothing, including no sequence/completion.
 * Validation failure leaves audio/work untouched. Render/headroom failure
 * preserves work but panics/latches audio; it may have consumed the batch.
 * Report failed completion and stop/reinitialize both owners; never retry. */
SpSynthStockResult sp_synth_audio_mix_stock(SpAppAudioState *audio,
    const SpAppAudioBatch *batch,const SpSynthStockBlock *block,SpSynthAppMixScratch *scratch);
#endif
