#ifndef SP_SYNTH_ENTRY_OWNER_V552_MIDI_H
#define SP_SYNTH_ENTRY_OWNER_V552_MIDI_H
#include "sp_synth_entry_owner_v552_live.h"
/* Link the matching source variant alone. After ordinary pad-entry checks,
 * invoke this bounded gate with the proposed epoch while PRIMASK is held.
 * Gate0 leaves the pad epoch/ownership/output unchanged; a successful gate is
 * followed immediately by the existing pad claim. No allocation, I/O, blocking
 * work or recursive entry API call is permitted in gate. A second owner may
 * claim its own state here. The later original publish callback runs after
 * mask restoration; its failure remains terminal with no rollback. */
typedef int (*SpSynthEntryGateV552)(void *context,uint32_t epoch);
int sp_synth_entry_owner_v552_enter_gated(SpSynthEntryBoundaryV552 *out,
    SpSynthEntryGateV552 gate,void *context);
#endif
