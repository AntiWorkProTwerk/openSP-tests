#ifndef SP_SYNTH_FILESYSTEM_LEASE_V552_H
#define SP_SYNTH_FILESYSTEM_LEASE_V552_H
#include "sp_synth_native_lease.h"

enum { SP_FS_LEASE_CONTEXT=1u,SP_FS_LEASE_RESOURCE=2u,
       SP_FS_LEASE_UNEXPECTED=4u,SP_FS_LEASE_CHANGED=8u };
enum { SP_FS_OPEN=1,SP_FS_ALT_OPEN,SP_FS_COPY,SP_FS_READ,SP_FS_WRITE,
       SP_FS_CLOSE,SP_FS_SYNC,SP_FS_DIR_OPEN,SP_FS_DIR_READ,SP_FS_DIR_CLOSE,
       SP_FS_MKDIR,SP_FS_BULK_ALL,SP_FS_BULK_FLAGGED,
       SP_FS_SERVICE_POP,SP_FS_SERVICE_DISPATCH };
typedef struct {
    SpSynthNativeLease *shared;
    const SpSynthLeaseGrant *grant;
    uint32_t task,operation;
} SpSynthFilesystemLeaseProfileV552;

/* One permanent cold-zeroed patch borrower. Scope is the exact a:/SP4SYNTH
 * namespace, one fd/FILE and one DIR at a time. The shared owner supplies the
 * actual project/admission generation. No task-only or fallback-context grant.
 * Failed retirement keeps identities and borrow intact; no retry/reset API.
 * Capture/cache borrowers require their own resource adapters, not this patch
 * borrower's namespace. Root installation/coverage is deliberately separate. */
typedef struct {
    SpSynthFilesystemLeaseProfileV552 profile;
    uint32_t magic,active,fault,depth,generation,native_context,held;
    int32_t fd;
    uint32_t file,dir,node,calls,refusals;
} SpSynthFilesystemLeaseV552;
int sp_synth_filesystem_lease_v552_init(SpSynthFilesystemLeaseV552 *,
    const SpSynthFilesystemLeaseProfileV552 *);
/* Profile-compatible callbacks:0 acquired/released; otherwise refusal. They
 * call the actual shared owner and native task/context resolver. */
int sp_synth_filesystem_lease_v552_acquire(void *);
int sp_synth_filesystem_lease_v552_release(void *);
/* Publish once before any source-installed callsite can execute. No unpublish
 * or live reinitialization. NULL before publication preserves native stock.
 * Publication does not set any shared coverage bit or establish installation. */
int sp_synth_filesystem_lease_v552_publish(SpSynthFilesystemLeaseV552 *);
/* Permanent published object for the installed typed entry router. */
SpSynthFilesystemLeaseV552 *sp_synth_filesystem_lease_v552_current(void);

/* Original callsite shims. Original native entry bodies must remain intact:
 * these wrappers call the pinned entries, so patching their entries back to
 * these wrappers would recurse. Whole-operation guards count unowned stock
 * work; owned patch calls also need exact scope and registered context.
 * Refusal never invokes native I/O. Upper producer/refusal/queue hooks remain
 * required before supplying FS coverage; leaf refusal is only a final sentry. */
uint32_t sp_synth_fs_v552_open_table(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_alt_open(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_copy_table(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_read(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_write(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_close(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_sync(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_directory_open(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_directory_read(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_directory_close(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_mkdir(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_bulk_all(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_bulk_flagged(uint32_t,uint32_t,uint32_t,uint32_t);
/* ParamTask's filesystem-service queue is distinct from an established FILE
 * task queue. Its dispatcher checks a NULL pop before command effects. Owned
 * unexpected work is retained before cursor advance and revokes the lease.
 * Install both pop callsites and the whole dispatcher guard. No producer
 * refusal is supplied: the outer transport drain ignores its downstream
 * return, so rejecting enqueue alone would silently consume that request. */
uint32_t sp_synth_fs_v552_service_pop(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_fs_v552_service_dispatch(uint32_t,uint32_t,uint32_t,uint32_t);
/* A bounded observation only. Complete producer admission, whole-dispatch
 * operation retirement and owner barriers remain required for a grant. */
int sp_synth_fs_v552_service_idle(void);
#endif
