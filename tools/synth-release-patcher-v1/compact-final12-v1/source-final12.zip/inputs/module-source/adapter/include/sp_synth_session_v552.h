#ifndef SP_SYNTH_SESSION_V552_H
#define SP_SYNTH_SESSION_V552_H
#include "sp_synth_startup_v552.h"
#include "sp_synth_backend_link.h"
#include "sp_synth_factory_v552.h"
struct SpSynthClockHandoffV552;

/* Permanent caller-owned storage outside the stock allocation pool. Zero once
 * before any owner runs. Control and UI may share a qualified serialized panel
 * task; audio and backend retain their separate component ownership contracts.
 * All members and allocated runtime remain pinned after successful preparation.
 * This is finite coordination, not task creation or firmware attachment. */
typedef struct {
    SpSynthStartupV552 startup;
    SpSynthBackendLink backend;
    SpSynthViewExchange views;
    SpSynthPageBindingV552 page;
    atomic_uint ready, terminal, control_ready;
    struct SpSynthClockHandoffV552 *clock_handoff; /* Immutable before ready. */
    uint32_t ui_registered; /* UI owner only */
} SpSynthSessionV552;

/* Serialized qualified startup owner, before all callbacks. Config must be
 * disjoint and already qualified as required by startup. Initializes runtime,
 * backend/view exchanges, pins storage, then release-publishes ready once.
 * No retry/reset after success; no filesystem or UI registration occurs here.
 * 0=success, -1010=invalid owner/config; other startup errors propagate. */
int sp_synth_session_v552_prepare(SpSynthSessionV552 *session,
    const SpSynthStartupConfig *config);
/* Additive deferred path: prepares and pins storage while ready/control_ready
 * stay0. A registered clock coordinator alone may later publish those fields.
 * This function does not supply a usable clock or expose UI/control callbacks. */
int sp_synth_session_v552_prepare_deferred(SpSynthSessionV552 *session,
    const SpSynthDeferredStartupConfig *config);
/* UI owner: initialize the permanent page and one-argument factory context.
 * Returns1 registered/idempotent,0 unavailable/failure. Failure after readiness
 * requests terminal stop and retains all storage. Writes no stock registration. */
int sp_synth_session_v552_register_ui(SpSynthSessionV552 *session);
/* Control owner: page handoff and normalized panel delivery. Enable queues the
 * owner's synchronization/release batch. Route returns1 to consume stock input,
 * 0 to forward. Queue failure requests terminal stop without replay. After stop
 * these calls disable note admission but keep consuming previously captured pad
 * releases; generated release batches are discarded because audio is stopping.
 * Incoming events must be stable and disjoint from session/runtime storage. */
int sp_synth_session_v552_enable(SpSynthSessionV552 *session,int enabled,int shift);
int sp_synth_session_v552_route(SpSynthSessionV552 *session,const sp_ui_event *event);
/* Control owner: caller first delivers ordered panel/MIDI input and qualifies
 * its cutoff. Target is supplied, never inferred. Services one bounded backend/
 * control transaction and offers the current copied view; full skips that view.
 * Does not advance the watermark, perform I/O, wait, or clear captured releases.
 * Continue route calls even after terminal stop for captured pad releases. */
SpControlService sp_synth_session_v552_control(SpSynthSessionV552 *session,
    uint32_t target);
/* Audio owner only, with disjoint qualified stock work block. Readiness is
 * acquired before accessing immutable storage pointers. On stop, a further
 * audio call acknowledges the existing mailbox stop; no app/UI access occurs. */
SpSynthStockResult sp_synth_session_v552_mix(SpSynthSessionV552 *session,
    const SpSynthStockBlock *block);
/* Any qualified owner after readiness. Atomic terminal latches only; no widget
 * destruction, backend cancellation, DAC drain, reclamation or task shutdown.
 * In-flight component work may finish. UI consumes stop on its next callback. */
void sp_synth_session_v552_stop(SpSynthSessionV552 *session);
#endif
