#ifndef SP_SYNTH_PATCH_READER_V552_H
#define SP_SYNTH_PATCH_READER_V552_H
#include "sp_synth_patch_reader.h"
/* Pinned pristine v5.52 only. Backend-owned storage, zero before init; no live
 * reinitialization. Caller qualifies filesystem/task context and image identity.
 * Private path proposal: a:/SP4SYNTH/P000A.SPS .. P127B.SPS.
 * No mkdir/write/absence classification; no runtime attachment supplied. */
typedef struct {
    SpSynthPatchReader reader;
    char path[sizeof("a:/SP4SYNTH/P000A.SPS")];
} SpSynthPatchReaderV552;
int sp_synth_patch_reader_v552_init(SpSynthPatchReaderV552 *owner);
#endif
