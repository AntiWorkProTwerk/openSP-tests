#ifndef SP_SYNTH_NATIVE_LEASE_H
#define SP_SYNTH_NATIVE_LEASE_H
#include <stdint.h>
#include <stdatomic.h>

enum { SP_LEASE_OBSERVING=1,SP_LEASE_CLOSING,SP_LEASE_DRAINING,
    SP_LEASE_OWNED,SP_LEASE_REVOKING,SP_LEASE_TERMINAL,SP_LEASE_RELEASED };
enum { SP_LEASE_PATCH=1,SP_LEASE_TAKE,SP_LEASE_CACHE,SP_LEASE_RECORD };
/* Coverage is an installation/test attestation, never evidence by itself. */
enum { SP_LEASE_ROOT_GATES=1u,SP_LEASE_PRIMARY_QUEUE=2u,
    SP_LEASE_DEFERRED_QUEUE=4u,SP_LEASE_PROJECT_SET=8u,
    SP_LEASE_STORAGE_SET=16u,SP_LEASE_LOAD_OBSERVER=32u,
    SP_LEASE_ALTERNATE_LOAD=64u,SP_LEASE_FS_TABLE=128u,
    SP_LEASE_FS_NAMESPACE=256u,SP_LEASE_FS_IDENTITIES=512u,
    SP_LEASE_FS_CONTEXT=1024u,SP_LEASE_MEDIA=2048u,
    SP_LEASE_AUDIO_LOADERS=4096u,SP_LEASE_RECORD_BARRIER=8192u,
    SP_LEASE_IMAGE=16384u,SP_LEASE_QUEUE_BARRIER=32768u,
    SP_LEASE_ALL_COVERAGE=65535u };
enum { SP_LEASE_BAD_CONTEXT=1u,SP_LEASE_OVERLAP=2u,
    SP_LEASE_EXHAUSTED=4u,SP_LEASE_BAD_RECEIPT=8u,
    SP_LEASE_CHANGED=16u,SP_LEASE_UNEXPECTED=32u,
    SP_LEASE_RESOURCES=64u };
/* Operation groups are a bitmask. LOAD invalidates the previous load receipt;
 * other mutations still count toward acquisition/retirement barriers. */
enum { SP_LEASE_STOCK_PROJECT=1u,SP_LEASE_STOCK_LOAD=2u,
    SP_LEASE_STOCK_FS=4u,SP_LEASE_STOCK_AUDIO=8u,
    SP_LEASE_STOCK_METADATA=16u,SP_LEASE_STOCK_MEDIA=32u,
    SP_LEASE_STOCK_ALL=63u };
enum { SP_LEASE_BAR_SMPL=1u,SP_LEASE_BAR_DEFERRED=2u,
    SP_LEASE_BAR_FILE=4u,SP_LEASE_BAR_AUDIO=8u,
    SP_LEASE_BAR_RECORD=16u,SP_LEASE_BAR_LOADERS=32u,
    SP_LEASE_ALL_BARRIERS=63u };
typedef struct {
    uint32_t task,ipsr,basepri,primask,faultmask,kernel_depth,dispatch_gate;
    uint32_t project,storage;
} SpSynthLeaseContext;
typedef struct { uint32_t ticket,task,group; } SpSynthLeaseOperation;
typedef struct {
    uint32_t generation,project,task,token;
} SpSynthLeaseGrant;
/* Permanent cold-zeroed owner. All APIs use a bounded try-lock; contention
 * latches a fault instead of spinning. Native shims mask briefly around APIs
 * after sampling the ORIGINAL context. Never hold that mask over native calls.
 * External writes to this structure are invalid after initialization. */
typedef struct {
    atomic_uint lock,fault,state,retained;
    uint32_t magic,control_task,worker_task,record_task,coverage;
    uint32_t generation,next_operation,mutation,request,barriers,barrier_mutation;
    uint32_t project,storage,loaded,loaded_project,load_ticket,load_task;
    uint32_t load_project,metadata_seen,metadata_success,load_returned,load_invalidated;
    uint32_t take_token,last_take,partial,borrow_role,borrow_operation;
    uint32_t borrow_token,borrow_task,borrow_generation;
    SpSynthLeaseOperation operations[8];
} SpSynthNativeLease;

int sp_synth_lease_init(SpSynthNativeLease *,uint32_t control,uint32_t worker,uint32_t record);
int sp_synth_lease_coverage(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t);
int sp_synth_lease_producer_allowed(const SpSynthNativeLease *);
/* Native UI admission only: a fault before any grant disables Synth while
 * allowing ordinary stock. A fault after grant retains native exclusion. */
int sp_synth_lease_stock_excluded(const SpSynthNativeLease *);
/* Ordinary stock observation accepts transitional project/storage values in
 * normal task context. It counts work and invalidates loadedness without
 * treating a cold sentinel or external-storage visit as a permanent fault. */
uint32_t sp_synth_lease_stock_enter(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t group);
int sp_synth_lease_stock_leave(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t ticket);
int sp_synth_lease_load_begin(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t ticket);
/* Successful metadata stamps a stable project/storage0 identity. The outer
 * return must match that stamp on the same whole-operation ticket to publish
 * loadedness; caller-supplied ready1 must come from the actual loader result. */
int sp_synth_lease_metadata_result(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t ticket,uint32_t success);
int sp_synth_lease_load_return(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t ticket,uint32_t sample_ready);
uint32_t sp_synth_lease_request(SpSynthNativeLease *,const SpSynthLeaseContext *);
int sp_synth_lease_drain(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t request);
/* Cancel an ungranted request only after admitted whole operations return. */
int sp_synth_lease_cancel(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t request);
/* Each receipt is after the real domain callback returns. A domain's source
 * observer must cover producers/queues; empty-looking cursors are insufficient.
 * New stock work clears all accumulated receipts. */
int sp_synth_lease_barrier(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t request,uint32_t domains);
int sp_synth_lease_acquire(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t request,SpSynthLeaseGrant *);
int sp_synth_lease_grant(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t generation,SpSynthLeaseGrant *);
int sp_synth_lease_take_retain(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t generation,uint32_t token);
int sp_synth_lease_take_partial(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t generation,uint32_t token);
/* Retirement is supplied only by an actual recorder/file cleanup receipt;
 * partial takes additionally require explicit successful repair/discard. */
int sp_synth_lease_take_retire(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t generation,uint32_t token,uint32_t repaired);
int sp_synth_lease_borrow_begin(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t generation,uint32_t role,uint32_t operation,uint32_t token);
int sp_synth_lease_permit(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t generation,uint32_t role,uint32_t operation,uint32_t token);
int sp_synth_lease_borrow_end(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t generation,uint32_t role,uint32_t operation,uint32_t token);
/* reason0 is orderly revocation; nonzero retains TERMINAL ownership forever. */
void sp_synth_lease_revoke(SpSynthNativeLease *,uint32_t reason);
int sp_synth_lease_release(SpSynthNativeLease *,const SpSynthLeaseContext *,uint32_t generation);
#endif
