#ifndef SP_SYNTH_NATIVE_INPUT_V552_H
#define SP_SYNTH_NATIVE_INPUT_V552_H
#include "sp_synth_app.h"

#ifdef SP_SYNTH_NATIVE_BOUND_V552
/* Each query attests its selected-input subset only. Installation and current
 * closure are separate; neither establishes the other native producer roots. */
int sp_synth_live_session_v552_input_installed(void);
int sp_synth_live_session_v552_input_closed(void);
int sp_synth_live_midi_v552_installed(void);
int sp_synth_live_midi_v552_closed(void);
#endif

/* During orderly revocation, keep the real take's cleanup controls available.
 * Callers consume rejected events; they must never fall back to stock playback. */
static inline int sp_synth_native_input_v552_panel_cleanup(const sp_ui *u,const sp_ui_event *e) {
    if(!u || !e)return 0;
    switch(e->type) {
    case SP_UI_PAD_UP:case SP_UI_SHIFT_DOWN:case SP_UI_SHIFT_UP:
    case SP_UI_EXIT_PRESS:case SP_UI_SYNTH_PANIC:return 1;
    case SP_UI_PAD_DOWN:return u->page==SP_UI_DESTINATION && !u->shift;
    case SP_UI_REC_PRESS:return u->page==SP_UI_RECORDING || u->page==SP_UI_DESTINATION;
    case SP_UI_VALUE_PRESS:return u->page==SP_UI_DESTINATION || u->page==SP_UI_OVERWRITE ||
        u->page==SP_UI_NEW_CONFIRM || u->page==SP_UI_LEAVE_CONFIRM || u->page==SP_UI_SAVE_ERROR ||
        u->page==SP_UI_CAPTURE_ERROR;
    case SP_UI_VALUE_TURN:return u->page==SP_UI_DESTINATION || u->page==SP_UI_OVERWRITE ||
        u->page==SP_UI_NEW_CONFIRM || u->page==SP_UI_LEAVE_CONFIRM;
    default:return 0;
    }
}
static inline int sp_synth_native_input_v552_midi_cleanup(const SpSynthEvent *e) {
    if(!e)return 0;
    return e->type==SP_EVENT_NOTE_OFF || e->type==SP_EVENT_NOTE_CANCEL ||
        e->type==SP_EVENT_ALL_NOTES_OFF || e->type==SP_EVENT_ALL_SOUND_OFF ||
        (e->type==SP_EVENT_NOTE_ON && e->value==0) ||
        (e->type==SP_EVENT_SUSTAIN && e->value<.5f);
}
#endif
