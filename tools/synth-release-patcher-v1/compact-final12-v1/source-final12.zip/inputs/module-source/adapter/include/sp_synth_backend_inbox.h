#ifndef SP_SYNTH_BACKEND_INBOX_H
#define SP_SYNTH_BACKEND_INBOX_H
#include "sp_synth_control_queue.h"

/* One serialized backend producer, one serialized control consumer. Normal
 * coherent CPU memory only; no DMA/ISR, reset, copy or destruction while live.
 * Separate permanently owned storage; not included in RuntimeStorage yet. */
typedef struct {
    SpAppCompletion completion;
    SpPreset preset;
    atomic_uint phase; /* 0 empty, 1 ready/borrowed by control */
    atomic_uint stopped; /* Independent latch: stop may race with publication. */
} SpSynthBackendInbox;
void sp_synth_backend_inbox_init(SpSynthBackendInbox *inbox);
/* Producer copies the response AND optional preset. Caller input must remain
 * immutable during this call, disjoint from inbox. Returns1 copied,0 unavailable
 * or null argument. On0 keep the response externally; never drop or overwrite.
 * Once1 returns the producer may release/reuse its original storage. */
int sp_synth_backend_inbox_publish(SpSynthBackendInbox *inbox,const SpAppCompletion *completion);
/* Control consumer retains the copied payload across busy/cutoff waits. APPLIED
 * or STALE frees the slot after the timed service returns; STOPPED latches a
 * terminal hold, even after partial application. An in-flight producer may
 * finish copying into that hold. No automatic reset/retry/free.
 * With an empty slot this still services panel/MIDI and audio acknowledgments.
 * Does not dequeue requests, perform I/O, schedule tasks or wake either owner. */
SpControlService sp_synth_backend_inbox_service(SpSynthBackendInbox *inbox,
    SpSynthControlQueue *queue,SpSynthMidiQueue *midi,SpSynthAudioMailbox *mailbox,
    SpSynthApp *app,uint32_t target);
/* Same consumer with optional immutable capture progress borrowed for this
 * call. See the observed control service for ordering and delivery lifetime. */
SpControlService sp_synth_backend_inbox_service_observed(SpSynthBackendInbox *inbox,
    SpSynthControlQueue *queue,SpSynthMidiQueue *midi,SpSynthAudioMailbox *mailbox,
    SpSynthApp *app,uint32_t target,const SpAppCaptureProgress *progress,
    SpBackendDelivery *progress_delivery);
SpControlService sp_synth_backend_inbox_service_capture(SpSynthBackendInbox *inbox,
    SpSynthControlQueue *queue,SpSynthMidiQueue *midi,SpSynthAudioMailbox *mailbox,
    SpSynthApp *app,uint32_t target,const SpAppCaptureProgress *progress,
    SpBackendDelivery *progress_delivery,const SpAppCaptureCancelCompletion *cancel,
    SpBackendDelivery *cancel_delivery);
#endif
