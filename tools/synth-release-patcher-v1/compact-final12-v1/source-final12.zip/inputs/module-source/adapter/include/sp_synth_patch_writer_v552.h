#ifndef SP_SYNTH_PATCH_WRITER_V552_H
#define SP_SYNTH_PATCH_WRITER_V552_H
#include "sp_synth_patch_writer.h"
/* Offline binding for pinned pristine v5.52, ARM32 only. Zero before init;
 * never reinitialize a live owner. One serialized backend owns each fd and its
 * private path from open through close. No other task may close/reuse the fd.
 * Table identity checks detect observed changes; they do not provide exclusion.
 * Caller must qualify image, task/error context, mount/path ownership, native
 * cache policy and completed media flush before any device use. This binding
 * does not change cache policy or establish persistence. No mkdir or absence
 * classification. Namespace matches the reader: a:/SP4SYNTH/P000A.SPS .. P127B.SPS.
 */
typedef struct {
    SpSynthPatchWriter writer;
    char path[sizeof("a:/SP4SYNTH/P000A.SPS")];
    int32_t owned_fd;
    uintptr_t owned_file;
    /* Unexpected native handles or changed table identity stop future opens.
     * Discard only after platform quiescence/recovery; no automatic reset. */
    uint32_t faulted;
} SpSynthPatchWriterV552;
int sp_synth_patch_writer_v552_init(SpSynthPatchWriterV552 *owner);
#endif
