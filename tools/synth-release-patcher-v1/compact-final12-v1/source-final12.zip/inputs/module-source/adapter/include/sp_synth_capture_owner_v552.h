#ifndef SP_SYNTH_CAPTURE_OWNER_V552_H
#define SP_SYNTH_CAPTURE_OWNER_V552_H
#include "sp_synth_session_v552.h"

enum { SP_CAPTURE_FREE, SP_CAPTURE_RESERVING, SP_CAPTURE_RESERVED,
    SP_CAPTURE_RUNNING, SP_CAPTURE_STOP_PENDING, SP_CAPTURE_HELD,
    SP_CAPTURE_SAVING, SP_CAPTURE_FINALIZED, SP_CAPTURE_ERROR, SP_CAPTURE_ACQUIRING };
enum { SP_CAPTURE_BLOCKED=-1040, SP_CAPTURE_CONTEXT=-1041,
    SP_CAPTURE_NATIVE_STATE=-1042, SP_CAPTURE_UNEXPECTED_SAVE=-1043 };
/* Low byte is phase; each native entry owns one 0x100 lease until return.
 * All storage is permanent. Initialization and hooks must precede native task
 * callbacks. No late installation, reset, discard or lifetime release exists.
 * Placement is external; this component does not reserve firmware RAM. All
 * native hooks must be installed together before callbacks, and every guarded
 * entry must retain its installed arguments/provenance. Task IDs cannot be
 * reused while registered. One serialized SMPL action4 consumer owns work;
 * no other backend consumer, recursive worker, ISR API caller or owner reset.
 * Owner, session and allocated runtime must be disjoint permanent storage. */
typedef struct {
    atomic_uint state,token,rx_ack,fault,permit,audio_task;
    _Atomic(SpSynthBackendLink *) backend;
    uint32_t last_token,handle,work_token,working,response_ready,closed_request;
    atomic_uint native_save_count,blocked_save_count;
    int32_t save_raw;
    SpAppRequest work;
    SpAppCompletion completion;
} SpSynthCaptureOwnerV552;

/* Cold once: zero owner outside native pool; no callbacks may have entered. */
int sp_synth_capture_owner_v552_init(SpSynthCaptureOwnerV552 *owner);
/* Selected native panel task publishes an initialized, pinned session link.
 * Worker never invokes a session/control service. Publication is one-shot. */
int sp_synth_capture_owner_v552_publish(SpSynthSessionV552 *session);
/* Qualified panel owner after request publication or response-slot release.
 * Schedules action4 only. The ordinary control attachment is still external. */
int sp_synth_capture_owner_v552_kick(void);
/* Native SMPL task only, after backend publication. Reserve while idle and all
 * guarded calls are retired. A stopped link cannot acquire a new reservation.
 * Future BEGIN must run under this reservation. accept_started checks actual
 * native post-BEGIN state; it does not perform BEGIN or publish START success.
 * The current composition supplies that native transition explicitly. */
int sp_synth_capture_owner_v552_reserve(uint32_t token);
int sp_synth_capture_owner_v552_accept_started(uint32_t token);
int sp_synth_capture_owner_v552_stop(uint32_t token);
/* Low-level native primitive, NOT connected to TAKE_WRITE requests. Requires a
 * separately qualified destination already bound at outer+4C, with overwrite
 * permission and project/file ownership established. Calls native SAVE once,
 * records raw result, then pins FINALIZED/error provenance. No pad-success
 * completion, retry, reset or token release is provided. */
int32_t sp_synth_capture_owner_v552_save_once(uint32_t token);

/* Exact installed-boundary adapters; assembly entries restore the callback's
 * originally resolved R2. Native trampolines replay displaced prologues.
 * Null owner, unrelated objects/commands and unreserved paths call native once.
 * Owned rejection intentionally returns SP_CAPTURE_BLOCKED. */
uint32_t sp_synth_capture_owner_v552_smpl(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_owner_v552_record(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_owner_v552_dispatch(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_owner_v552_save(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_owner_v552_rx(uint32_t,uint32_t,uint32_t,uint32_t);
#endif
