#ifndef SP_SYNTH_NATIVE_RUNTIME_V552_H
#define SP_SYNTH_NATIVE_RUNTIME_V552_H
#include "sp_synth_native_provider_v552.h"

/* Strong native binding accessor. NULL until cold preparation and publication
 * complete. A published object supplies no grant by itself; callers still
 * authenticate readiness, lifetime and exact retained cleanup tokens. */
SpSynthNativeProviderV552 *sp_synth_native_runtime_v552_provider(void);

/* Sole SMPL owner after its complete native callback and all scoped borrows
 * return. Consume checked take/LEAVE receipts without manufacturing success. */
void sp_synth_native_runtime_v552_cleanup_service(void);
/* Published shared exclusion, including acquisition drain and retained cleanup.
 * Native UI/MIDI fallback must remain closed until the owner reopens stock. */
int sp_synth_native_runtime_v552_controls_closed(void);

#endif
