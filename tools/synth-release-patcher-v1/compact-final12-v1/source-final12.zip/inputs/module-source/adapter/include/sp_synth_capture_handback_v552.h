#ifndef SP_SYNTH_CAPTURE_HANDBACK_V552_H
#define SP_SYNTH_CAPTURE_HANDBACK_V552_H
#include "sp_synth_session_v552.h"

enum { SP_HCAP_FREE, SP_HCAP_RESERVING, SP_HCAP_RESERVED,
    SP_HCAP_RUNNING, SP_HCAP_STOP_PENDING, SP_HCAP_HELD,
    SP_HCAP_SAVING, SP_HCAP_FINALIZED, SP_HCAP_ERROR, SP_HCAP_ACQUIRING,
    SP_HCAP_EXCLUSIVE_IDLE, SP_HCAP_BEGIN, SP_HCAP_DISCARD_BARRIER, SP_HCAP_DISCARDING,
    SP_HCAP_WAIT_DELETE, SP_HCAP_RELEASE_BARRIER };
enum { SP_HCAP_BLOCKED=-1040, SP_HCAP_CONTEXT=-1041,
    SP_HCAP_NATIVE_STATE=-1042, SP_HCAP_UNEXPECTED_SAVE=-1043,
    SP_HCAP_INITIAL_WRITE=-1044, SP_HCAP_CLOSE=-1045, SP_HCAP_UNLINK=-1046,
    SP_HCAP_CUTOFF=-1047, SP_HCAP_EXIT=-1048, SP_HCAP_EXHAUSTED=-1049 };
#define SP_HCAP_UNSUPPORTED UINT32_C(0x80000000)
/* Separate component-only manual profile. Existing app modes0/1 are rejected;
 * mode2 requires seconds/bars/tempo/count-in/tail all zero. No timed recording,
 * count-in or release-tail claim follows from successful native BEGIN. */
enum { SP_HCAP_MANUAL_UNTIMED=2 };
/* Low byte is phase; tracked native work owns a 0x100 lease until return.
 * Bit31 is permanent unsupported-context provenance and prevents zero-lease
 * acquisition/retirement. An observed unqualified FREE entry retains native
 * fallback; owned unqualified writers/posts are rejected. This is not IRQ
 * writer support, a native scheduler proof or permission for ISR API callers.
 * All storage is permanent. Initialization and hooks must precede native task
 * callbacks. No late installation or owner reset is supported.
 * Placement is external; this component does not reserve firmware RAM. All
 * native hooks must be installed together before callbacks, and every guarded
 * entry must retain its installed arguments/provenance. Task IDs cannot be
 * reused while registered. One serialized SMPL action4 consumer owns work;
 * no other backend consumer, recursive worker, ISR API caller or owner reset.
 * Owner, session and allocated runtime must be disjoint permanent storage.
 * V3 replaces V1/V2; never link duplicate permanent capture owners. */
typedef struct {
    atomic_uint state,token,rx_ack,fault,permit,audio_task;
    _Atomic(SpSynthBackendLink *) backend;
    uint32_t last_token,handle,work_token,working,response_ready,closed_request;
    atomic_uint native_save_count,blocked_save_count;
    atomic_uint record_ready,barrier_token,barrier_ack;
    atomic_uint barrier_sequence,wait_sequence,handoff_pending,handoff_fault;
    atomic_uint exit_ticket,released_ticket;
    uint32_t last_ticket,exit_requested;
    uint32_t override_mask,write_count,discard_attempted,file_owned,descriptor;
    int32_t initial_write_raw,close_raw,unlink_raw,setup_unlink_raw,setup_raw,start_raw;
    int32_t save_raw;
    SpAppRequest work;
    SpAppCompletion completion;
} SpSynthCaptureHandbackV552;

/* Cold once: zero owner outside native pool; no callbacks may have entered. */
int sp_synth_capture_handback_v552_init(SpSynthCaptureHandbackV552 *owner);
/* Selected native panel task publishes an initialized, pinned session link.
 * Worker never invokes a session/control service. Publication is one-shot. */
int sp_synth_capture_handback_v552_publish(SpSynthSessionV552 *session);
/* Qualified panel owner after request publication or response-slot release.
 * Schedules action4 only. The ordinary control attachment is still external. */
int sp_synth_capture_handback_v552_kick(void);
/* Actual SMPL task only. Validates the explicit manual profile before mutation.
 * Runs native setup/open/initial write/start. Returns1 only after validating
 * actual native state and clearing destination. Error retains the owner/token.
 * Uses one checked, non-nesting native dispatch-inhibit pair for admission and
 * token reset only. Existing leases still exclude suspended callbacks; native
 * recorder/filesystem calls begin after dispatch is restored. No ISR callers.
 * The profile must be immutable and disjoint from all owner/session storage. */
int sp_synth_capture_handback_v552_begin(uint32_t token,const SpAppCapture *profile);
int sp_synth_capture_handback_v552_stop(uint32_t token);
/* Same task/token, after acknowledged STOP and drain retirement. Starts a
 * record-task barrier, then checked close/unlink/reset on later worker passes.
 * Returns1 accepted/pending,0 rejected. Successful completion retires the token
 * into EXCLUSIVE_IDLE. A later held backend LEAVE drives checked handback. */
int sp_synth_capture_handback_v552_discard(uint32_t token);
/* Low-level native primitive, NOT connected to TAKE_WRITE requests. Requires a
 * separately qualified destination already bound at outer+4C, with overwrite
 * permission and project/file ownership established. Calls native SAVE once,
 * records raw result, then pins FINALIZED/error provenance. No pad-success
 * completion, retry, reset or token release is provided. */
int32_t sp_synth_capture_handback_v552_save_once(uint32_t token);

/* Exact installed-boundary adapters; assembly entries restore the callback's
 * originally resolved R2. Native trampolines replay displaced prologues.
 * Null owner, unrelated objects and qualified unrelated/FREE paths call native
 * once. Native message storage must remain valid and immutable through return.
 * EXCLUSIVE_IDLE deliberately keeps ordinary recorder mutation blocked.
 * Owned rejection intentionally returns SP_HCAP_BLOCKED. */
uint32_t sp_synth_capture_handback_v552_smpl(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_record(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_dispatch(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_save(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_rx(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_consume(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_initial_write(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_stereo_query(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_mode_query(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_setup_unlink(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_record_init(uint32_t,uint32_t,uint32_t,uint32_t);
/* Sole SMPL backend owner only. Exact-ticket readiness keeps recorder mutation
 * closed; deletion is requested through the live provider. RELEASED is published
 * only after that provider's deletion ack and the final record-task batch.
 * Standalone tests model the provider boundary; joint deletion remains a
 * separate composition. RELEASED is historical evidence for that exact ticket.
 * These predicates never infer handback from token0 or EXCLUSIVE_IDLE. */
int sp_synth_capture_handback_v552_exit_ready(uint32_t ticket);
int sp_synth_capture_handback_v552_released(uint32_t ticket);
/* Shared wait recipe: preserve original R0-R4/LR, call this RECORD-only hook,
 * then tail into the unchanged live-session wait shim. That shim alone executes
 * native11978. One72BB4 call/80103394 veneer target replaces the old target. */
void sp_synth_capture_handback_v552_before_wait(void *native_object);
void sp_synth_capture_handback_v552_wait(void);
uint32_t sp_synth_capture_handback_v552_append(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_coalesce(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_deferred(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_post_drain(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_handback_v552_post_save(uint32_t,uint32_t,uint32_t,uint32_t);
#endif
