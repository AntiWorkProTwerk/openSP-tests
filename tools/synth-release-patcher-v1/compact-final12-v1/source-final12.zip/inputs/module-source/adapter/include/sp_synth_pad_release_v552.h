#ifndef SP_SYNTH_PAD_RELEASE_V552_H
#define SP_SYNTH_PAD_RELEASE_V552_H
#include "sp_synth_session_v552.h"

/* Permanent, zeroed caller-owned storage outside the selected stock pool.
 * Registration captures the native task ID, not a task handle/generation. */
typedef struct {
    SpSynthSessionV552 *session;
    uint32_t task_id;
} SpSynthPadReleaseV552;

/* Qualified selected-panel task after native initialization. Registration has
 * one serialized caller. Other tasks may take native fallback while it runs;
 * a release-store publishes the fully initialized immutable owner. panel must
 * be 0x8300A3E4; that value alone is
 * not proof of task provenance. Session must be prepared and pinned. Returns
 * 1 once on success, otherwise 0 without changing owner or registration.
 * Owner/session remain disjoint and pinned for this boot; no replacement/reset.
 * Caller must establish task context (never ISR), exact firmware, serialized
 * control ownership, and no reuse of the captured native task ID. */
int sp_synth_pad_release_v552_init(SpSynthPadReleaseV552 *owner,
    SpSynthSessionV552 *session,void *panel);

/* Candidate for router tail 0x8003B560. Incoming record must be the stable,
 * readable internal stock record (at least 6 bytes), disjoint from synth state;
 * this is not a packet parser or an arbitrary-pointer-safe native wrapper.
 * Native fallback preserves all four incoming argument registers and raw R0.
 * On the registered task, captured main-pad up is routed once even after
 * disable/terminal/full queue, then native D4960(80591B24) runs once. Its raw
 * R0 is returned; no other page receives that release. Unknown/malformed fields,
 * other tasks and absent/unready sessions use intact native AED0.
 * Native task getter cannot distinguish an ISR from the interrupted task.
 * All invocations therefore require task context. No fresh input admission. */
uint32_t sp_synth_pad_release_v552_dispatch(const void *record,
    uint32_t r1,uint32_t r2,uint32_t r3);
#endif
