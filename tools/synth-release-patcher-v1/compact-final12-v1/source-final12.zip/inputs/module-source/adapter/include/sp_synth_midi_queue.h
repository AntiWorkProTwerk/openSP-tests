#ifndef SP_SYNTH_MIDI_QUEUE_H
#define SP_SYNTH_MIDI_QUEUE_H
#include "sp_synth_audio_mailbox.h"

#define SP_MIDI_QUEUE_CAPACITY SP_SYNTH_MAX_EVENTS
typedef enum {
    SP_MIDI_QUEUE_OK,SP_MIDI_QUEUE_INPUT,SP_MIDI_QUEUE_FULL,SP_MIDI_QUEUE_ORDER,
    SP_MIDI_QUEUE_TIME,SP_MIDI_QUEUE_PROTOCOL,SP_MIDI_QUEUE_DELIVERY,SP_MIDI_QUEUE_STOP_REQUESTED
} SpMidiQueueFault;
typedef struct {uint32_t sample;SpSynthEvent event;} SpTimedMidi;
typedef struct {
    SpTimedMidi events[SP_MIDI_QUEUE_CAPACITY];
    uint32_t last_sample,closed_until,watermark;
    uint16_t head,count;
    uint8_t has_last,has_closed,has_watermark;
    SpMidiQueueFault fault;
} SpSynthMidiQueue;
typedef enum {SP_MIDI_IDLE,SP_MIDI_PUBLISHED,SP_MIDI_STOPPED} SpMidiService;

/* Serialized control owner only, paired with one timed mailbox/app lifetime.
 * All input and object storage must be disjoint. No concurrent producer/ISR.
 * Initialize only while both mailbox owners are stopped. */
void sp_synth_midi_queue_init(SpSynthMidiQueue *queue);
/* Copies one native musical event with an absolute presentation-sample time.
 * Input offset must be0; publication derives its block offset from sample.
 * Times must be nondecreasing within the bounded modular timeline. Rejects
 * already-published blocks, stale/far targets, invalid events and overflow.
 * Every rejection latches the first fault and requests audio stop. No retiming.
 * This is not a MIDI byte parser or physical-arrival-clock conversion. */
int sp_synth_midi_queue_push(SpSynthMidiQueue *queue,SpSynthAudioMailbox *mailbox,
    uint32_t sample,const SpSynthEvent *event);
/* Producer's exclusive input cutoff: all events with sample<watermark have
 * been drained and no such event may arrive later. Advance only after draining
 * every input source; this function cannot verify the external assertion.
 * A block cannot publish until its end is at/before this cutoff. Monotonic,
 * bounded and wrap-aware. A later event behind the cutoff requests stop. */
int sp_synth_midi_queue_watermark(SpSynthMidiQueue *queue,SpSynthAudioMailbox *mailbox,uint32_t sample);
/* For a shared coordinator: begin mailbox, dispatch due UI controls, then call
 * this function. App must have no timestamped events yet. Appends all queued
 * events in the target block, seals/publishes it and removes them only on
 * success. Future events remain. Caller must not skip an older queued block
 * or begin the batch before the input cutoff closes it.
 * UI changes occur before MIDI, including MIDI at offset0. */
SpMidiService sp_synth_midi_queue_publish(SpSynthMidiQueue *queue,
    SpSynthAudioMailbox *mailbox,SpSynthApp *app,uint32_t target_sample);
/* MIDI-only convenience: takes completion, waits while mailbox is busy, then
 * begins/publishes the earliest queued block. No empty blocks are published.
 * Delivery failures request stop, with no automatic reset/replay. */
SpMidiService sp_synth_midi_queue_service(SpSynthMidiQueue *queue,
    SpSynthAudioMailbox *mailbox,SpSynthApp *app);
#endif
