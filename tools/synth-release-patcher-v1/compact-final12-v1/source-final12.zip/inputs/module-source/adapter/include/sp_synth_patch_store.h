#ifndef SP_SYNTH_PATCH_STORE_H
#define SP_SYNTH_PATCH_STORE_H
#include "sp_synth_app.h"
#define SP_PATCH_USER_BASE UINT32_C(0x53550000)
#define SP_PATCH_USER_SLOTS 128u
#define SP_PATCH_SLOT_BYTES 577u
typedef enum {SP_PATCH_IO_OK,SP_PATCH_IO_ABSENT,SP_PATCH_IO_CARD,
    SP_PATCH_IO_FULL,SP_PATCH_IO_READ_ONLY,SP_PATCH_IO_FAILED} SpPatchIOResult;
typedef struct {
    void *context;
    /* Read exactly one private slot/copy. Report actual length; no truncation
     * disguised as success. ABSENT means no file, not an unreadable file. */
    SpPatchIOResult (*read)(void *,unsigned,unsigned,uint8_t *,size_t,size_t *);
    /* Replace ONLY this copy, write all bytes and flush/close before OK.
     * Never touch the other copy. A failure can leave this copy partially or
     * fully written. Provider enforces bounded private paths and ownership. */
    SpPatchIOResult (*write)(void *,unsigned,unsigned,const uint8_t *,size_t);
} SpSynthPatchIO;
typedef struct {
    uint8_t records[2][SP_PATCH_SLOT_BYTES],verify[SP_PATCH_SLOT_BYTES];
    SpPreset decoded[2],candidate;
} SpSynthPatchStoreScratch;
/* Serialized backend task, outside audio. All objects disjoint. No heap or
 * native filesystem assumptions. Handles user PATCH_QUERY/WRITE/LOAD only;
 * returns1 with a typed completion even on storage error,0 unsupported/bad args.
 * Successful load and occupied query return Completion.preset borrowed from
 * scratch until copied into the backend response link or catalog metadata.
 * Successful save requires provider flush plus exact reread; not physical
 * power-loss proof. A failed save may nevertheless leave a valid newer copy.
 * Neither sequence wrap nor ambiguous equal-generation copies are accepted. */
int sp_synth_patch_store_execute(const SpSynthPatchIO *io,SpSynthPatchStoreScratch *scratch,
    const SpAppRequest *request,SpAppCompletion *completion);
#endif
