#ifndef SP_SYNTH_PARAM_LEASE_V552_H
#define SP_SYNTH_PARAM_LEASE_V552_H
#include "sp_synth_native_lease.h"

/* Uninstalled ParamTask event8 callback gate. Publish once before callbacks.
 * Native loop 80072BA8 invokes its method as void. Event argument0 drains
 * queue82E0D624; other arguments retain the original callback behavior.
 * The gate retains all ParamTask records while ownership is retained and
 * requests orderly revocation before native D3086 can consume a record.
 * It does not establish transport rejection or complete producer coverage. */
int sp_synth_param_lease_v552_publish(SpSynthNativeLease *);
void sp_synth_param_lease_v552_callback(uint32_t,uint32_t,uint32_t,uint32_t);
int sp_synth_param_lease_v552_pending(void);
/* One bounded native wake attempt, only after confirmed shared-owner release
 * and on its worker task. Return1 means the real wake entry was called; its
 * unmodified result is written to out. No status convention is invented.
 * Pending stays set until the native callback actually resumes, so an unknown
 * or failed wake can be retried without consuming the queued records. */
int sp_synth_param_lease_v552_resume(uint32_t *out);
#endif
