#ifndef SP_SYNTH_GENERATOR_ROUTE_V552_H
#define SP_SYNTH_GENERATOR_ROUTE_V552_H
#include <stdatomic.h>
#include <stdint.h>

typedef enum {
    SP_SYNTH_GENERATOR_NATIVE = 0,
    SP_SYNTH_GENERATOR_DISCARD = 1
} SpSynthGeneratorRouteModeV552;

enum {
    SP_SYNTH_GENERATOR_ROUTE_WORDS = 64u * 14u,
    SP_SYNTH_GENERATOR_ROUTE_BAD_TUPLE = 1u
};

/* Permanent, exclusive audio scratch plus one control->audio request slot.
 * Cold initialization must precede publication to either owner. This object
 * reserves no memory: its full aligned extent must be separately reserved,
 * outside the native allocation pool and disjoint from all other owners.
 * Only the serialized control owner calls request(). Only the qualified TX
 * callback calls dispatch(). Neither callback may recurse. No reset/reclaim. */
typedef struct {
    _Alignas(8) int32_t discard[SP_SYNTH_GENERATOR_ROUTE_WORDS];
    atomic_uint requested, acknowledged, fault;
    uint32_t initialized;
} SpSynthGeneratorRouteV552;

/* Requires a valid, zeroed object. Rejects the known native pool and non-SDRAM,
 * misaligned or overflowing extents; these checks do not prove RAM ownership.
 * Returns1 once,0 on rejection. Does not publish the pointer to any callback. */
int sp_synth_generator_route_v552_init(SpSynthGeneratorRouteV552 *owner);

/* Returns a nonzero monotonically numbered ticket, or0 for invalid mode,
 * uninitialized/faulted owner, pending prior request or sequence exhaustion.
 * Equal modes still receive distinct tickets. No cancellation/retiming: the
 * caller retains a pending transition until acknowledged. A concurrent first
 * tuple fault may race a request that already passed its fault read; that
 * request remains accepted. The fault prevents later requests, not execution
 * of the already published route. No UI or native
 * Generator entry is performed. Store/ownership validity is a caller contract. */
uint32_t sp_synth_generator_route_v552_request(SpSynthGeneratorRouteV552 *owner,
    SpSynthGeneratorRouteModeV552 mode);

/* Acquire the last completed native-render ticket; zero means initial NATIVE.
 * The low bit is the completed route. Acknowledgment means that one exact TX
 * invocation has returned in that route, not a complete DAC/capture boundary.
 * The control owner may inspect fault with an acquire load. */
uint32_t sp_synth_generator_route_v552_ack(const SpSynthGeneratorRouteV552 *owner);

/* For the recovered v5.52 TX call1C766 only. Calls native1CB85 exactly once.
 * Exact tuple: state80249800,work202AD3A0,64frames,14-word stride. DISCARD copies
 * all896 live words to permanent scratch and gives native that copy, preserving
 * its raw R0 and state progression while leaving live work untouched. NATIVE
 * forwards the original tuple. A pending ticket publishes acknowledgment only
 * after that native call returns. No allocation, waits, control or synth mix.
 * NULL/uninitialized owner falls back unchanged. An unsupported tuple also
 * falls back, latches BAD_TUPLE and leaves its pending ticket unacknowledged.
 * Existing native validity requirements still apply to every fallback.
 * This is separate from the existing audio binding; it installs no hook. */
uint32_t sp_synth_generator_route_v552_dispatch(SpSynthGeneratorRouteV552 *owner,
    void *state, int32_t *work, int32_t frames, int32_t stride);
#endif
