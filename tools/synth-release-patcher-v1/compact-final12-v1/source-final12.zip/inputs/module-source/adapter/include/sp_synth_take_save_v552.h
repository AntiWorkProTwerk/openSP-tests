#ifndef SP_SYNTH_TAKE_SAVE_V552_H
#define SP_SYNTH_TAKE_SAVE_V552_H
#include "sp_synth_capture_timed_v552.h"

enum { SP_TAKE_SAVE_IDLE,SP_TAKE_SAVE_QUERIED,SP_TAKE_SAVE_WRITING,
       SP_TAKE_SAVE_BARRIER,SP_TAKE_SAVE_SAVED,SP_TAKE_SAVE_RECOVERY };
enum { SP_TAKE_SAVE_CONTEXT=1u,SP_TAKE_SAVE_LEASE=2u,SP_TAKE_SAVE_DEST=4u,
       SP_TAKE_SAVE_CHANGED=8u,SP_TAKE_SAVE_SAMPLE=16u,SP_TAKE_SAVE_SYNC=32u,
       SP_TAKE_SAVE_CLOSE=64u,SP_TAKE_SAVE_UNLINK=128u,SP_TAKE_SAVE_RENAME=256u,
       SP_TAKE_SAVE_READY=512u,SP_TAKE_SAVE_PROJECT=1024u,SP_TAKE_SAVE_RETIRE=2048u };
enum { SP_TAKE_SAVE_INTACT=1u,SP_TAKE_SAVE_CLOSED=2u,
       SP_TAKE_SAVE_DEST_REMOVED=4u,SP_TAKE_SAVE_RENAMED=8u,
       SP_TAKE_SAVE_PROJECT_DONE=16u,SP_TAKE_SAVE_RETIRED=32u,
       SP_TAKE_SAVE_RECOVERY_REQUIRED=64u,SP_TAKE_SAVE_REPAIR_ALLOWED=128u };

/* Immutable platform lease, held from query through poll completion. The
 * platform supplies these facts: fully loaded project, exclusive project and
 * all selected pad files/metadata and existing parent directories, no native
 * FILE/directory identity reuse or recursive SAVE,
 * serialized SMPL/RECORD callbacks, stable task IDs and owner lifetime. An
 * equality check does not acquire those resources. Missing lease refuses work.
 * generation is positive and changes whenever that external lease is renewed.
 * bounded poll count is a supplied scheduling bound, not a physical timeout.
 */
typedef struct {
    uint32_t generation,project,project_ready,exclusive,max_barrier_polls;
} SpSynthTakeSaveLeaseV552;

typedef struct {
    uint32_t token,project,pad,occupied,flags,fault,state;
    int32_t native_raw;
    char name[25];
} SpSynthTakeSaveResultV552;

/* Permanent, zeroed before any callback; disjoint from native data/capture.
 * One owner may be published once. All scoped hooks must be installed together.
 * One serialized SMPL caller owns query/write/poll/results. A result never
 * licenses an automatic retry after file effects or recovery-required failure.
 * Successful completion is published only after a fresh RECORD barrier and
 * native recorder retirement. Modeled file checks do not prove durability.
 */
typedef struct {
    uint32_t magic;
    atomic_uint state;
    uint32_t task,token,project,pad,occupied,lease_generation;
    uint32_t fault,flags,last_attempt,close_seen,rename_seen,ready_seen;
    uint32_t unlink_call,unlink_seen,unlink_leaf_seen,barrier_polls,max_polls;
    int32_t native_raw,close_raw,rename_raw,unlink_raw,unlink_leaf_raw;
    uint32_t fd,file,expected_bytes,sample_rate;
    SpSynthCaptureTimedV552 *capture;
    atomic_uint active,terminal,barrier,wait_barrier,barrier_ack;
    uint32_t next_barrier;
    uint8_t pad_record[172],pad_cache[36],pad_name[24];
    char path[3][64],source[64];
    uint8_t header[512];
    uint32_t initial_fault,repair_attempt,repairing,saved_snapshot;
    int32_t repair_raw;
    uint32_t read_fd,read_file,read_location,read_close_attempted;
    int32_t read_close_raw;
    SpSynthProjectSaveV552 repair_project;
    uint32_t prepare_seen;
    int32_t prepare_raw;
    uint32_t prepare_active,dir_handle,dir_context,dir_opens,dir_closes,dir_close_attempted;
    int32_t dir_close_raw;
} SpSynthTakeSaveV552;

int sp_synth_take_save_v552_init(SpSynthTakeSaveV552 *,SpSynthCaptureTimedV552 *);
/* Queries are read-only native getters/path formatters; they copy one pad and
 * its native 24-byte name. pad is UI1..16 and bank0..9. Return1 queried,0
 * refusal. A refusal before write keeps the stopped native take intact. */
int sp_synth_take_save_v552_query(SpSynthTakeSaveV552 *,uint32_t token,
    uint32_t bank,uint32_t pad,const SpSynthTakeSaveLeaseV552 *,SpSynthTakeSaveResultV552 *);
/* Return1 means accepted/pending. Return0 is a prewrite refusal with intact
 * take. Once accepted, poll must run; the same token is never attempted again.
 * replace must exactly equal the previously queried occupancy. */
int sp_synth_take_save_v552_write(SpSynthTakeSaveV552 *,uint32_t token,
    uint32_t bank,uint32_t pad,uint32_t replace,const SpSynthTakeSaveLeaseV552 *);
/* 0 pending,1 checked saved+retired,-1 retained recovery-required failure.
 * Results are copied once by the worker; callers retain them under inbox
 * backpressure without repeating write/poll effects. */
int sp_synth_take_save_v552_poll(SpSynthTakeSaveV552 *,const SpSynthTakeSaveLeaseV552 *,SpSynthTakeSaveResultV552 *);
/* Explicit, once-per-token project repair. Refuses uncertain sample/reader
 * ownership or unresolved project resources. Never repeats SAVE or rename. */
int sp_synth_take_save_v552_recover(SpSynthTakeSaveV552 *,uint32_t token,const SpSynthTakeSaveLeaseV552 *);
void sp_synth_take_save_v552_record_before_wait(void *);
void sp_synth_take_save_v552_record_return(uint32_t object,uint32_t action);

/* Exact native callsite adapters. Unrelated calls retain native behavior.
 * During an owned call, invalid execution context refuses further I/O and
 * atomically latches terminal; it never falls back through a stock write. */
uint32_t sp_synth_take_save_v552_sample_close(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_take_save_v552_cache(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_take_save_v552_clear(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_take_save_v552_prepare(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_take_save_v552_directory(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_take_save_v552_unlink(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_take_save_v552_unlink_leaf(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_take_save_v552_rename(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_take_save_v552_ready(uint32_t,uint32_t,uint32_t,uint32_t);
#endif
