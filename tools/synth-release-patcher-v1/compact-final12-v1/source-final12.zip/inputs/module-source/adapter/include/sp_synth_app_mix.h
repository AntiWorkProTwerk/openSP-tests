#ifndef SP_SYNTH_APP_MIX_H
#define SP_SYNTH_APP_MIX_H
#include "sp_synth_app.h"
#include "sp_synth_stock_adapter.h"
typedef struct {
    SpSynthStockScratch pcm;
    float stereo[SP_SYNTH_STOCK_MAX_FRAMES*2];
} SpSynthAppMixScratch;
/* Full app render into the measured stock work-buffer layout. One serialized
 * app/audio owner only. Caller reserves scratch; no UI, allocation or stock
 * note helpers occur. App, scratch and used work words must be disjoint.
 * Finite samples clip to [-1,1], then truncate with asymmetric S16 scaling.
 * Render/headroom failure preserves work words but may advance app state;
 * never retry that block. Zero frames returns OK without rendering. */
SpSynthStockResult sp_synth_app_mix_stock(SpSynthApp *app,const SpSynthStockBlock *block,
                                         SpSynthAppMixScratch *scratch);
#endif
