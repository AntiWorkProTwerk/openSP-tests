#ifndef SP_SYNTH_PATCH_READER_H
#define SP_SYNTH_PATCH_READER_H
#include "sp_synth_patch_store.h"
/* All calls run serially in one qualified filesystem context, outside audio.
 * open_read owns bounded private slot/copy paths; returns -1 or a live handle.
 * Every nonnegative handle is closed exactly once, including rejected handles.
 * Native binding and open-error classification are not supplied by this module. */
typedef struct {
    void *context;
    int (*clear_error)(void *);
    uint32_t (*get_error)(void *);
    int32_t (*open_read)(void *,unsigned,unsigned);
    int32_t (*read)(void *,int32_t,uint8_t *,size_t);
    int (*close)(void *,int32_t);
    /* Optional. Only qualified missing-file errors may return ABSENT.
     * Unknown codes must return FAILED. OK/FULL/READ_ONLY are rejected. */
    SpPatchIOResult (*classify_open_error)(void *,uint32_t);
} SpSynthPatchReadOps;
typedef struct {
    SpSynthPatchReadOps ops;
    uint8_t bytes[SP_PATCH_SLOT_BYTES+1];
} SpSynthPatchReader;
/* SpSynthPatchIO.read-compatible. Context points to SpSynthPatchReader.
 * All objects disjoint, callbacks non-reentrant. Capacity must be577.
 * Outputs untouched on failure except *length=0. On OK, length is a bounded
 * observed count (578 means oversized), at most577 bytes copied. Empty EOF
 * is an existing malformed record, never ABSENT. Close failure rejects data. */
SpPatchIOResult sp_synth_patch_reader_read(void *context,unsigned slot,unsigned copy,
    uint8_t *out,size_t capacity,size_t *length);
#endif
