#ifndef SP_SYNTH_INPUT_OBSERVER_V552_H
#define SP_SYNTH_INPUT_OBSERVER_V552_H
#include "sp_synth_session_v552.h"

/* Source-initialized once by stock scatter copy record 4. Never reset by pool,
 * preparation, entry or exit. The fixed placement is part of the offline
 * recipe, not storage supplied or initialized by an arbitrary caller. */
typedef struct {
    uint32_t held_pads,shift,loss,depth,records;
    SpSynthSessionV552 *session;
    uint32_t task_id;
} SpSynthInputObserverV552;
extern SpSynthInputObserverV552 sp_synth_input_observer_v552;
enum {
    SP_INPUT_OBSERVER_DROP=1u, SP_INPUT_OBSERVER_CURSOR=2u,
    SP_INPUT_OBSERVER_FOREIGN=4u, SP_INPUT_OBSERVER_EXHAUSTED=8u
};
typedef struct {
    uint32_t held_pads,shift,counter,records;
    /* Always zero in this revision: events for controls held before the first
     * native scan have not been qualified. Source zeros are an origin only. */
    uint32_t physical_qualified;
} SpSynthPanelRingCutoffV552;

/* Common native drain replacement. Copies/advances/observes each head under
 * saved PRIMASK, then dispatches outside that added exclusion. Nested drains
 * retain native cursor-first ordering. R0/R1 are native read/write cursor bits.
 * No initial-occupancy cap: callbacks may append as with the stock drain.
 * All producers and drains must participate; no NMI/HardFault/DMA access. */
uint64_t sp_synth_input_observer_v552_drain(void);

/* Read an empty panel-ring boundary and actual CYCCNT under one exclusion.
 * Refuses loss, an in-flight dispatcher, malformed cursors or record counter
 * exhaustion. Output is unchanged on refusal. Does not close MIDI queues,
 * provide a silent heartbeat, claim a clock or qualify physical state. */
int sp_synth_input_observer_v552_panel_cutoff(SpSynthPanelRingCutoffV552 *out);

/* Optional later integration on an already qualified, serialized selected
 * panel task. Session must already be prepared/pinned/control-ready with
 * disabled input matching observed bits. One permanent binding, no reset.
 * This API neither supplies the missing physical-origin qualification nor
 * performs the clock claim. Foreign drainers never mutate the input owner.
 * There is no fresh-note enable API. */
int sp_synth_input_observer_v552_bind(SpSynthSessionV552 *session,void *panel);
#endif
