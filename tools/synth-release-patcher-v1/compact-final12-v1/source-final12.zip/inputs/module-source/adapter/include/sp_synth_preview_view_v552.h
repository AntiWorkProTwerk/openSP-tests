#ifndef SP_SYNTH_PREVIEW_VIEW_V552_H
#define SP_SYNTH_PREVIEW_VIEW_V552_H
#include "sp_synth_ui_render.h"
#include <stdint.h>
/* Builds a copied semantic frame. Zero means the native page owns the display. */
int sp_synth_preview_view_v552_build(uint32_t state, uint32_t choice,
                                    uint32_t fault, sp_ui_view *out);
#endif
