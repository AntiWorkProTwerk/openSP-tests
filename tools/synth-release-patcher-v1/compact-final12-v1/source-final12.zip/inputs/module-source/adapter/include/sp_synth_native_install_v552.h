#ifndef SP_SYNTH_NATIVE_INSTALL_V552_H
#define SP_SYNTH_NATIVE_INSTALL_V552_H
#include <stdint.h>
#include <stddef.h>

enum { SP_NATIVE_HOOK_POINTER=1,SP_NATIVE_HOOK_ENTRY8,SP_NATIVE_HOOK_ENTRY10,
    SP_NATIVE_HOOK_BL,SP_NATIVE_HOOK_BYTES };
/* Immutable source/linker-owned expectation. target is a Thumb function for
 * POINTER/ENTRY/BL, or a stable byte array for BYTES. Records are strictly
 * sorted by site and disjoint. No coverage bits or grant permission occur in
 * this format. A component separately owns its complete semantic inventory. */
typedef struct {
    uintptr_t site,target;
    uint32_t kind,size;
} SpSynthNativeHookV552;
/* Read-only checks of actual mapped code/pointer words. No patch operation.
 * count1..256 and byte spans2..32; malformed/unmapped-range descriptions fail.
 * This helper cannot establish that an inventory contains every required hook,
 * that its wrappers have correct semantics, or that live work has retired. */
int sp_synth_native_install_v552_verify(const SpSynthNativeHookV552 *,size_t count);
#endif
