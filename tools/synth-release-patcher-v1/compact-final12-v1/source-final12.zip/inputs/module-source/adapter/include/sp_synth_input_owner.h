#ifndef SP_SYNTH_INPUT_OWNER_H
#define SP_SYNTH_INPUT_OWNER_H
#include "sp_synth_ui.h"

#define SP_SYNTH_INPUT_BATCH_CAPACITY 17u
typedef struct {
    uint16_t physical, captured, delivered;
    uint8_t enabled, shift;
} sp_synth_input_owner;
typedef struct {
    sp_ui_event events[SP_SYNTH_INPUT_BATCH_CAPACITY];
    uint8_t count;
} sp_synth_input_batch;

/* Single serialized caller. Initialize once from a real held-pad/SHIFT snapshot,
 * not on every page transition. Retain and feed this owner until captured pads
 * are released, even after leaving the synth page. No callbacks or allocation. */
void sp_synth_input_init(sp_synth_input_owner *owner,uint16_t held_pads,int shift);
/* 0/1 enabled and current SHIFT required. Copies at most16 releases plus SHIFT
 * synchronization. Consume the complete batch in order before another call.
 * Returns0 for invalid input,1 otherwise. Output/state must be disjoint.
 * The platform must deliver releases reliably; this is not a concurrent queue. */
int sp_synth_input_enable(sp_synth_input_owner *owner,int enabled,int shift,sp_synth_input_batch *out);
/* Takes normalized events from the control translator. Returns1 to consume the
 * stock event,0 to forward it. SHIFT always forwards and also updates synth
 * state while enabled. Captured pad-up is consumed even after disabling.
 * Invalid/unsupported events forward without changing state. Output is empty
 * unless a copied synth event is produced. Input/output/state must be disjoint. */
int sp_synth_input_route(sp_synth_input_owner *owner,const sp_ui_event *event,sp_synth_input_batch *out);
#endif
