#ifndef SP_SYNTH_CONTROL_V552_H
#define SP_SYNTH_CONTROL_V552_H
#include "sp_synth_ui.h"
#include <stddef.h>

/* Pure event translation for the verified v5.52 synth-page callback ABI.
 * Return 1 for an event, 0 for ignored/invalid input. Failure leaves output
 * unchanged. Caller gates page/modal ownership and copies events to the app's
 * serialized owner. These helpers install no hooks and dispatch nothing. */
int sp_synth_control_v552_ctrl(int32_t index,int32_t value,sp_ui_event *out);
/* Stock index0 is VALUE. Preserve stock's one-step-per-callback sign behavior;
 * ignore zero. Magnitude is not a verified detent count or acceleration. */
int sp_synth_control_v552_encoder(int32_t index,int32_t delta,sp_ui_event *out);
/* Main pads only: stock0..15 -> UI1..16. Down velocity must already be 0..127;
 * this is not raw ADC/pressure calibration. Release ignores its velocity value.
 * Special stock pad19 and other indices are left to the owning page. */
int sp_synth_control_v552_pad(int32_t index,int32_t velocity,int down,sp_ui_event *out);
/* Verified IDs: SHIFT42 both edges, VALUE49/REC27/EXIT34 press only.
 * down must be 0 or 1. Other buttons and non-SHIFT releases are ignored.
 * Caller must also synchronize already-held SHIFT on page entry/resumption. */
int sp_synth_control_v552_button(int32_t id,int down,sp_ui_event *out);
/* Decode a copied stock UI event record, not a USB/UART packet. Requires at
 * least six bytes: LE type16, signed index16, signed value16. Only types
 * 5/6(button),7(encoder),9(CTRL),16/17(main pads) are translated. Input/output
 * must be disjoint. Caller still decides whether this synth owns the event. */
int sp_synth_control_v552_event(const void *record,size_t bytes,sp_ui_event *out);
#endif
