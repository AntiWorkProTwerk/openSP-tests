#ifndef SP_SYNTH_PATCH_WRITER_H
#define SP_SYNTH_PATCH_WRITER_H
#include "sp_synth_patch_store.h"
/* Serialized backend task, private slot/copy paths, all objects disjoint.
 * Native flush/media/task qualification is required before binding these ops.
 * open_write returns -1 or an owned handle; every nonnegative handle must be
 * safely closeable by the provider, including handles rejected for writing. */
typedef struct {
    void *context;
    int (*clear_error)(void *);
    uint32_t (*get_error)(void *);
    int32_t (*open_write)(void *,unsigned,unsigned);
    int32_t (*write)(void *,int32_t,const uint8_t *,size_t);
    /* Must finish the qualified file/cache/media flush, returning0 on success.
     * A placeholder, queued request or successful close is insufficient. */
    int (*flush)(void *,int32_t);
    int (*close)(void *,int32_t);
    /* Optional qualified error mapping; only CARD/FULL/READ_ONLY accepted. */
    SpPatchIOResult (*classify_error)(void *,uint32_t);
} SpSynthPatchWriteOps;
typedef struct {SpSynthPatchWriteOps ops;} SpSynthPatchWriter;
/* SpSynthPatchIO.write-compatible; context is SpSynthPatchWriter.
 * Writes exactly577 bytes to only the requested copy. No retries/rollback.
 * A reported failure may leave a complete newer copy; store reread still follows
 * successful return. Input bytes remain borrowed until this function returns. */
SpPatchIOResult sp_synth_patch_writer_write(void *context,unsigned slot,unsigned copy,
    const uint8_t *bytes,size_t length);
#endif
