#ifndef SP_SYNTH_BACKEND_LINK_H
#define SP_SYNTH_BACKEND_LINK_H
#include "sp_synth_backend_inbox.h"
#include "sp_synth_capture_feedback.h"
#include "sp_synth_capture_cancel.h"

/* One control owner and one backend owner, coherent CPU memory. Initialize
 * both stopped; keep separately allocated storage pinned while either is live.
 * Backend owns its copied work request; no app/engine access from that owner. */
typedef struct {
    SpSynthBackendInbox responses;
    SpAppRequest request;
    atomic_uint request_phase; /* 0 empty, 1 available, 2 backend working */
    SpSynthCaptureFeedback capture_feedback;
    atomic_uint capture_feedback_ready; /* separate single-producer/consumer slot */
    uint32_t capture_feedback_released; /* control owner only; pending backend wake */
    SpSynthCaptureCancelRequest capture_cancel_request;
    SpSynthCaptureCancelResult capture_cancel_result;
    atomic_uint capture_cancel_phase;
} SpSynthBackendLink;
void sp_synth_backend_link_init(SpSynthBackendLink *link);
/* Control owner: acknowledge audio first, then move at most one queued request
 * only while the app has no pending/open audio transaction. Never dequeue into
 * an occupied link or while a response awaits delivery. Then service responses,
 * capture observations, panel and MIDI. A request generated in this call waits
 * for a later audio ack. Releasing feedback sets capture_feedback_released;
 * the platform must wake its backend then clear that control-owned flag. This
 * lets a held/faulted recorder retry after its last RX callback. No I/O or task
 * wake here. Ack is rendered audio, not DAC drain/capture alignment. */
SpControlService sp_synth_backend_link_service(SpSynthBackendLink *link,
    SpSynthControlQueue *queue,SpSynthMidiQueue *midi,SpSynthAudioMailbox *mailbox,
    SpSynthApp *app,uint32_t target);
/* Backend owner: copy one available request into disjoint caller storage. 1
 * means acquired; 0 leaves output untouched. Keep work until finish succeeds.
 * Stop racing acquisition may leave one acquired request; quiescing actual I/O
 * is the platform's responsibility, not an atomic cancellation guarantee. */
int sp_synth_backend_link_take(SpSynthBackendLink *link,SpAppRequest *out);
/* Finish only after the operation has a real result. Nonzero-generation requests
 * require a matching response (copied with optional preset); generation0 commands
 * require NULL and produce no UI completion. Wrong generation/full response or
 * terminal stop returns0 and preserves the working request. Never repeat I/O
 * merely because its response could not be delivered. */
int sp_synth_backend_link_finish(SpSynthBackendLink *link,const SpAppCompletion *completion);
/* Sole backend owner: copied feedback uses a slot independent of START's
 * request and completion. Full/stopped returns0 without overwriting the slot;
 * retain authoritative observations and retry on a later worker pass. Sticky
 * milestones/faults must survive retries; intermediate progress may coalesce.
 * Returns1 also when the identical payload was already consumed; it remains
 * empty then. This prevents the release wake from republishing unchanged data.
 * Caller input is immutable and disjoint from the whole link. No task wake. */
int sp_synth_backend_link_capture_publish(SpSynthBackendLink *link,
    const SpSynthCaptureFeedback *feedback);
/* Sole control owner, between app operations. Match the original START
 * generation and known take token; token0 allows initial identity binding for
 * that generation only. Caller must retire this expectation after discard or
 * save; UI's current STOP/query generation is not the START generation.
 * WAITING preserves slot/output, STALE frees a mismatched slot without changing
 * output, READY copies then frees it. Output is disjoint from the whole link.
 * This API does not change the app, acknowledge audio, issue STOP/cancel, or
 * establish successful recording/saving. Do not use it as COMPLETE. */
SpCaptureFeedbackDelivery sp_synth_backend_link_capture_take(SpSynthBackendLink *link,
    uint32_t start_generation,uint32_t take_token,SpSynthCaptureFeedback *out);
/* Sole control owner, after the exact successful note-release audio ack.
 * Copies a positive START generation/sequence into a separate empty slot. That
 * exact START must already be the link's pending or most recently completed
 * ordinary request; an app-queued but unissued START cannot be canceled here.
 * Native SMPL owns REQUEST -> STOPPING -> RESULT; control owns publication and
 * result retirement. No ordinary request is dequeued while this slot is live.
 * A nonzero sequence is a caller attestation, not an independently verified ack.
 * The app/gesture publisher is not connected yet. Input is stable/disjoint. */
int sp_synth_backend_link_cancel_publish(SpSynthBackendLink *link,
    const SpSynthCaptureCancelRequest *request);
/* Sole control owner. Matching generation AND audio sequence copies a ready
 * result then frees its slot. Wrong identity, stopped link or pending leaves
 * slot/output untouched. Returns1 copied,0 retained. Output is disjoint.
 * Result1 proves native HELD only. Retire ordinary START response and issue
 * tokened DISCARD; its checked cleanup must finish before returning to setup. */
int sp_synth_backend_link_cancel_take(SpSynthBackendLink *link,
    uint32_t start_generation,uint32_t audio_sequence,SpSynthCaptureCancelResult *out);
#endif
