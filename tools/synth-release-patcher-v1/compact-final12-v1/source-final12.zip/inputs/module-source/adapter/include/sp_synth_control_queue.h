#ifndef SP_SYNTH_CONTROL_QUEUE_H
#define SP_SYNTH_CONTROL_QUEUE_H
#include "sp_synth_audio_mailbox.h"
#include "sp_synth_midi_queue.h"
#include "sp_synth_input_owner.h"

#define SP_SYNTH_CONTROL_QUEUE_CAPACITY 128u
typedef struct {
    sp_ui_event events[SP_SYNTH_CONTROL_QUEUE_CAPACITY];
    uint16_t head, count;
    uint8_t faulted;
} SpSynthControlQueue;
typedef enum {SP_CONTROL_IDLE,SP_CONTROL_SENT,SP_CONTROL_STOPPED} SpControlService;

/* One serialized control owner, the same owner as app/mailbox publication.
 * Not an ISR or inter-task queue. All objects and incoming batches are disjoint.
 * Initialize only with both mailbox owners stopped. No concurrent reset. */
void sp_synth_control_queue_init(SpSynthControlQueue *queue);
/* Copies a whole normalized physical-control batch or none. No coalescing.
 * Invalid input, capacity exhaustion or a stopped mailbox latches queue failure
 * and requests audio stop. The existing queue is retained for diagnosis.
 * Typed backend completions and timestamped MIDI use separate contracts. */
int sp_synth_control_queue_push(SpSynthControlQueue *queue,SpSynthAudioMailbox *mailbox,
    const sp_synth_input_batch *batch);
/* Takes any matching completion, then dispatches a bounded group into a new
 * batch: up to16 consecutive pad ups, or unshifted non-destination pad downs;
 * other controls remain single events. Down/up transitions are block boundaries.
 * No timestamps are inferred; a pending attack group starts at block offset0.
 * Busy mailbox leaves all queued events untouched. Valid frame count is
 * 1..64. Failure is terminal: wait for audio stop acknowledgment, then externally
 * quiesce both owners before recovery. No retry of a partly dispatched event.
 * Caller must also service app backend requests on this same control owner. */
SpControlService sp_synth_control_queue_service(SpSynthControlQueue *queue,
    SpSynthAudioMailbox *mailbox,SpSynthApp *app,uint32_t frames);
/* Shared timed coordinator for panel and MIDI. Caller supplies the next chosen
 * 64-aligned target; no clock or latency is inferred. Every input source must
 * have been drained before advancing MIDI's exclusive watermark. Waits for a
 * complete input cutoff and a free mailbox; never skips an older MIDI event.
 * Dispatches one bounded panel group before the target block's MIDI events.
 * Removes the panel group only after successful publication. Failures stop
 * audio without retry; backend requests still require the same control owner.
 * This is a bounded service call, not an inter-task queue or scheduler loop. */
SpControlService sp_synth_control_queue_service_timed(SpSynthControlQueue *queue,
    SpSynthMidiQueue *midi,SpSynthAudioMailbox *mailbox,SpSynthApp *app,uint32_t target);
typedef enum {SP_BACKEND_WAITING,SP_BACKEND_APPLIED,SP_BACKEND_STALE} SpBackendDelivery;
/* Same timed service with at most one backend completion, applied before panel
 * controls and MIDI. Caller retains immutable completion/preset storage until
 * delivery is APPLIED or STALE; neither pointer is retained. APPLIED means the
 * response was consumed, including reported backend errors, not storage success
 * or audio acknowledgment. On STOPPED never retry a partially applied response.
 * A stale generation is discarded without publishing or dispatching inputs.
 * WAITING preserves the response when busy or missing the input cutoff.
 * Delivery is required when completion is nonnull and must be disjoint from
 * all inputs. All other ownership/timeline preconditions above still apply. */
SpControlService sp_synth_control_queue_service_backend(SpSynthControlQueue *queue,
    SpSynthMidiQueue *midi,SpSynthAudioMailbox *mailbox,SpSynthApp *app,uint32_t target,
    const SpAppCompletion *completion,SpBackendDelivery *delivery);
/* Extended service: apply completion, then one copied capture observation,
 * then panel/MIDI. Observation delivery uses the same cutoff/audio boundary.
 * WAITING retains caller storage; APPLIED/STALE consume it. A completed save
 * or discard retires identity before progress is considered. STOPPED retains
 * all borrowed payloads; never retry partially applied input. */
SpControlService sp_synth_control_queue_service_observed(SpSynthControlQueue *queue,
    SpSynthMidiQueue *midi,SpSynthAudioMailbox *mailbox,SpSynthApp *app,uint32_t target,
    const SpAppCompletion *completion,SpBackendDelivery *delivery,
    const SpAppCaptureProgress *progress,SpBackendDelivery *progress_delivery);
/* Same boundary, with cancellation after START completion/progress and before
 * panel/MIDI. A receipt waits until START has been consumed. Invalid matching
 * receipt data stops the service and retains the borrowed payload. */
SpControlService sp_synth_control_queue_service_capture(SpSynthControlQueue *queue,
    SpSynthMidiQueue *midi,SpSynthAudioMailbox *mailbox,SpSynthApp *app,uint32_t target,
    const SpAppCompletion *completion,SpBackendDelivery *delivery,
    const SpAppCaptureProgress *progress,SpBackendDelivery *progress_delivery,
    const SpAppCaptureCancelCompletion *cancel,SpBackendDelivery *cancel_delivery);
#endif
