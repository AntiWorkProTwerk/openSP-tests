#ifndef SP_SYNTH_FULL_BACKEND_V552_H
#define SP_SYNTH_FULL_BACKEND_V552_H
#include "sp_synth_take_save_v552.h"
#include "sp_synth_patch_backend_v552.h"
enum {SP_FULL_SAVE_LEASE=1u,SP_FULL_PATCH_IO=2u,SP_FULL_LIFETIME=4u,SP_FULL_QUALIFIED=7u};
typedef struct {
    uint32_t qualified;
    /* Caller owns this immutable native project/file exclusion for the entire
     * selected Synth lifetime, including held/partially saved recordings. */
    const SpSynthTakeSaveLeaseV552 *take_lease;
    SpSynthPatchBackendProfileV552 patch_profile;
} SpSynthFullBackendConfigV552;
extern const SpSynthFullBackendConfigV552 *const sp_synth_full_backend_v552_config;
int sp_synth_full_backend_v552_init(SpSynthCaptureTimedV552 *,SpSynthRuntimeStorage *);
/* Selected panel wrapper only, after admission failed before any backend IO.
 * Retain permanent published hooks and wait for actual recorder cleanup. */
void sp_synth_full_backend_v552_admission_refused(SpSynthCaptureTimedV552 *);
/* Sole SMPL owner. -1 unsupported,0 pending,1 copied terminal response. A
 * completion stays retained until the actual backend response handoff. */
int sp_synth_full_backend_v552_begin(const SpAppRequest *,SpAppCompletion *);
int sp_synth_full_backend_v552_poll(SpAppCompletion *);
void sp_synth_full_backend_v552_finished(uint32_t generation);
void sp_synth_full_backend_v552_worker_idle(void);
/* Settle a previously started catalog scan before acquiring any app request.
 * Zero retains the queued request; -1 retains unsafe storage ownership. */
int sp_synth_full_backend_v552_before_request(void);
void sp_synth_full_backend_v552_control(SpSynthApp *);
int sp_synth_full_backend_v552_catalog_pending(void);
int sp_synth_full_backend_v552_needs_service(void);
/* Sole SMPL reader after native callbacks return. +1 is the checked SAVED
 * owner, -1 is retained RECOVERY_REQUIRED,0 is unavailable or incomplete.
 * This does not retire a capture token or consume an app response. */
int sp_synth_full_backend_v552_take_outcome(uint32_t token);
void sp_synth_full_backend_v552_shutdown(void);
int sp_synth_capture_timed_v552_shutdown_ready(void);
int sp_synth_capture_timed_v552_kick_shutdown(void);
#endif
