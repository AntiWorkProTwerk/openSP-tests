#ifndef SP_SYNTH_STOCK_ADAPTER_H
#define SP_SYNTH_STOCK_ADAPTER_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Original offline interface model for the measured v5.52 mixer layout.
 * It contains no stock entry address, hook, memory reservation or loader. */
enum {
    SP_SYNTH_STOCK_MAX_FRAMES = 64,
    SP_SYNTH_STOCK_STRIDE_WORDS = 14,
    SP_SYNTH_STOCK_PAIR_COUNT = 7
};

typedef enum {
    SP_SYNTH_STOCK_OK = 0,
    SP_SYNTH_STOCK_INVALID_ARGUMENT,
    SP_SYNTH_STOCK_INSUFFICIENT_BUFFER,
    SP_SYNTH_STOCK_RENDER_FAILED,
    SP_SYNTH_STOCK_NO_HEADROOM,
    SP_SYNTH_STOCK_DEADLINE_MISSED
} SpSynthStockResult;

typedef struct {
    int32_t *words;
    size_t word_count;
    uint32_t frames;
    uint8_t pair_index;
} SpSynthStockBlock;

/* The eventual integration must reserve this storage and one audio owner.
 * These 256 bytes are scratch only, excluding the synth engine and events. */
typedef struct {
    int16_t stereo[SP_SYNTH_STOCK_MAX_FRAMES * 2];
} SpSynthStockScratch;

/* The renderer overwrites frames*2 interleaved signed16 samples. It must be
 * bounded, allocation-free, nonblocking, and owned by the calling audio task.
 * Control events must already be queued; never call stock note setters here. */
typedef bool (*SpSynthStockRender)(void *context, int16_t *stereo, uint32_t frames);

/* Adds one rendered stereo block to the selected pair. Other positions stay
 * unchanged. All validation happens before rendering. On render failure or
 * insufficient signed32 headroom, the destination remains unchanged; the
 * renderer may have advanced, so the caller must not retry the same block.
 * A zero-frame call returns OK without rendering. Scratch must not overlap
 * any part of the work-buffer interval used by this block. */
SpSynthStockResult sp_synth_stock_mix_block(
    const SpSynthStockBlock *block, SpSynthStockScratch *scratch,
    SpSynthStockRender render, void *context);

#ifdef __cplusplus
}
#endif
#endif
