#ifndef SP_SYNTH_CATALOG_H
#define SP_SYNTH_CATALOG_H
#include "sp_synth_patch_store.h"
typedef struct {
    sp_ui_patch entries[256];
    uint16_t count,next_slot;
    sp_ui_error error;
} SpSynthCatalog;
typedef enum {SP_CATALOG_MORE,SP_CATALOG_READY,SP_CATALOG_FAILED} SpCatalogStatus;
/* Unpublished backend-owned output only. Never reset or advance an object
 * referenced by a live UI. Scan into separate storage, transfer ownership to
 * control only at READY, then use sp_synth_app_set_catalog in its valid phase.
 * No atomic publication, allocation or native task transport is provided. */
void sp_synth_catalog_begin(SpSynthCatalog *catalog);
/* Scan one user slot per call (two copy reads); preserves factory order then
 * user slot order, category and favorite. Any unreadable/corrupt slot aborts
 * the candidate catalog; caller keeps the previously published one. A scan
 * is not an atomic filesystem snapshot. Serialize backend writes/reads. */
SpCatalogStatus sp_synth_catalog_step(SpSynthCatalog *catalog,const SpSynthPatchIO *io,
    SpSynthPatchStoreScratch *scratch);
#endif
