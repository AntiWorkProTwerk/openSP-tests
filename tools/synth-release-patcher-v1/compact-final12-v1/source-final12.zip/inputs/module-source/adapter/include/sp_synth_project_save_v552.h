#ifndef SP_SYNTH_PROJECT_SAVE_V552_H
#define SP_SYNTH_PROJECT_SAVE_V552_H
#include <stdint.h>

enum {
    SP_PROJECT_CONTEXT=1u, SP_PROJECT_PATH=2u, SP_PROJECT_ALLOC=4u,
    SP_PROJECT_FILE=8u, SP_PROJECT_WRITE=16u, SP_PROJECT_STAT=32u,
    SP_PROJECT_SYNC=64u, SP_PROJECT_CLOSE=128u, SP_PROJECT_NATIVE=256u
};
/* Permanent, initially zero, disjoint from native project/file/allocator data.
 * Cold init once. Sole SMPL worker; caller excludes concurrent project changes,
 * other opens of PADCONF.BIN, descriptor reuse and recursive native project
 * serialization until run returns. On terminal failure, retain the owner AND
 * project/file exclusion until platform quiescence and recovery resolve the
 * outstanding resources. A return does not release those external obligations.
 * Native task identity must remain stable.
 * Table comparisons detect changes, not locks.
 * Install ALL scoped callsite wrappers before use. Ordinary calls outside the
 * active worker transaction retain native behavior. During an active transaction,
 * exceptions and masked/locked SMPL calls are refused without I/O or writes to
 * the worker's observations. No global recorder or
 * project ownership is established here. No UI/backend success is published.
 * A token is attempted once; unresolved resources latch terminal. No reset.
 */
typedef struct {
    uint32_t magic,last_token,token,project,task,fault,terminal;
    uintptr_t allocations[2];
    uint32_t alloc_count,free_mask,write_count,bytes,stat_seen,close_attempted;
    int32_t fd,open_raw,stat_raw,sync_raw,close_raw,native_raw;
    uintptr_t file;
    uint32_t size_low,size_high;
    char path[64];
} SpSynthProjectSaveV552;

int sp_synth_project_save_v552_init(SpSynthProjectSaveV552 *owner);
/* Returns 1 only for checked 52,000-byte project serialization, FILE sync and
 * close; 0 for an attempted failure; -1 for refusal before this attempt.
 * Uses current internal project 0..127 only; never changes setting132.
 * Successful sync is a native API result, not physical persistence proof.
 */
int sp_synth_project_save_v552_run(SpSynthProjectSaveV552 *owner,
                                  uint32_t take_token,uint32_t project);

/* Exact v5.52 project/metadata callsites only. ARM R0..R3/raw-return ABI.
 * Never replace global filesystem or allocator entries with these wrappers.
 */
#define SP_PROJECT_HOOK(name) uint32_t sp_synth_project_save_v552_##name(uint32_t,uint32_t,uint32_t,uint32_t)
SP_PROJECT_HOOK(alloc);
SP_PROJECT_HOOK(free);
SP_PROJECT_HOOK(open);
SP_PROJECT_HOOK(write);
SP_PROJECT_HOOK(stat);
SP_PROJECT_HOOK(close);
#undef SP_PROJECT_HOOK
#endif
