#ifndef SP_SYNTH_CANVAS_V552_H
#define SP_SYNTH_CANVAS_V552_H
#include "sp_synth_oled.h"

/* Pinned Roland v5.52 canvas ABI only. Call on the UI owner during a valid draw.
 * The caller guarantees a live canvas/backend and an immutable disjoint frame.
 * Draws local 0..127/0..63 through existing canvas translation/clipping.
 * Restores foreground/background; does not change font or clipping state.
 * No allocation, retained canvas, panel transport or firmware hook.
 * Returns 0 for null canvas/backend/vtable/frame, otherwise 1. Framework
 * pointers are trusted, not a general-purpose pointer-validation boundary. */
int sp_synth_canvas_v552_present(void *canvas,const sp_oled_frame *frame);
#endif
