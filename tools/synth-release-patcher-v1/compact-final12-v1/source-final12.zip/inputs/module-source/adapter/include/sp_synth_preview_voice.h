#ifndef SP_SYNTH_PREVIEW_VOICE_H
#define SP_SYNTH_PREVIEW_VOICE_H
#include "sp_synth_dsp.h"
#include <stdatomic.h>
#include <stddef.h>
#include <stdint.h>

enum { SP_PREVIEW_PADS=16, SP_PREVIEW_QUEUE=32, SP_PREVIEW_FRAMES=64 };
enum { SP_PREVIEW_STOP=1u, SP_PREVIEW_OVERFLOW=2u, SP_PREVIEW_QUEUE_FAULT=4u,
       SP_PREVIEW_IDENTITY_FAULT=8u, SP_PREVIEW_RENDER_FAULT=16u,
       SP_PREVIEW_EXHAUSTED=32u, SP_PREVIEW_CONTROL_STALL=64u };
typedef enum { SP_PREVIEW_INVALID=0, SP_PREVIEW_OK=1,
               SP_PREVIEW_TERMINAL=2 } SpPreviewRenderResult;
typedef struct { uint32_t ticket; uint8_t kind,pad; uint16_t reserved; } SpPreviewEvent;

/* Caller-owned permanent storage. Fields are private except in quiescent tests.
 * Cold init requires zeroed storage, before either owner is published. One
 * serialized control producer and one nonrecursive audio consumer only.
 * No task identity, rate measurement, native hook or RAM reservation is supplied.
 * stop() is the only API usable by an additional supervisor context. */
typedef struct {
    uint32_t initialized;
    _Atomic uint32_t write_index,read_index,terminal;
    SpPreviewEvent queue[SP_PREVIEW_QUEUE];
    uint32_t control_ids[SP_PREVIEW_PADS],next_ticket,control_admitted;
    uint32_t audio_ids[SP_PREVIEW_PADS],audio_admitted,active_pad;
    float increments[SP_PREVIEW_PADS];
    SpOsc oscillator;
    SpEnvelope envelope;
    uint32_t permission_ticket,audio_permission_ticket;
    _Atomic uint32_t permission_ack,stop_ack,heartbeat;
    uint32_t lease_frames,lease_remaining,audio_heartbeat;
} SpSynthPreviewVoice;

/* Numeric rates 8000..192000 are accepted; acceptance is not qualification.
 * Reinitialization is rejected, including after terminal stop. */
int sp_synth_preview_voice_init(SpSynthPreviewVoice *,uint32_t sample_rate);
/* Coordinator permission, queued in note order. Default closed. Disabling
 * retires all note identities and silences at its ordered audio boundary.
 * Success means queued; compare the exact permission ticket with its audio
 * acknowledgment before exposing input. A configured frame lease revokes
 * stalled control independently; callers must qualify its physical meaning.
 * Use terminal stop for revocation that must bypass queued work. */
int sp_synth_preview_voice_admit(SpSynthPreviewVoice *,int admitted);
/* Serialized control reads its latest permission ticket. Audio publishes the
 * same ticket only after consuming that exact ordered permission event. */
uint32_t sp_synth_preview_voice_permission(const SpSynthPreviewVoice *);
uint32_t sp_synth_preview_voice_permission_ack(const SpSynthPreviewVoice *);
/* Configure once before publishing permission or notes. Numeric rendered-frame
 * lease1..INT32_MAX; the caller must qualify its physical meaning separately.
 * Pulse belongs to the control producer. Audio expires the lease independently
 * of further service and latches terminal silence. No DWT/rate claim. */
int sp_synth_preview_voice_lease(SpSynthPreviewVoice *,uint32_t frames);
int sp_synth_preview_voice_pulse(SpSynthPreviewVoice *);
/* Acquire1 only after an audio render with positive frames has observed the
 * terminal latch, cleared DSP and produced a completely silent output block. */
uint32_t sp_synth_preview_voice_stop_ack(const SpSynthPreviewVoice *);
/* Pads 0..15 map to chromatic MIDI pitches 48..63. Fixed gain, no velocity.
 * DOWN returns a nonzero monotonic identity, or0 without accepting the note.
 * Duplicate DOWN is rejected. UP must carry that exact identity; an old UP
 * cannot release a later strike. Both calls belong to the control producer.
 * Notes while closed are rejected, not retained for later replay. */
uint32_t sp_synth_preview_voice_down(SpSynthPreviewVoice *,unsigned pad);
int sp_synth_preview_voice_up(SpSynthPreviewVoice *,unsigned pad,uint32_t ticket);
/* Any qualified context may latch terminal stop. Never frees/resets storage or
 * mutates DSP. A call racing publication may still let the producer report an
 * accepted event; terminal state prevents that event from restoring sound. */
void sp_synth_preview_voice_stop(SpSynthPreviewVoice *);
uint32_t sp_synth_preview_voice_faults(const SpSynthPreviewVoice *);
/* Audio owner only. Overwrite interleaved signed16 stereo, at most64 frames.
 * Output capacity is measured in samples and must not overlap the owner.
 * Invalid output leaves it untouched and latches terminal on a valid owner.
 * Consume at most one queued event per sample, from the entry-time queue
 * snapshot. This preserves short DOWN/UP order without timestamp claims.
 * Latest held note wins; releasing it falls back to the latest remaining
 * identity without retriggering. Last UP starts the fixed 40ms release.
 * Stop observed during rendering zeros this whole block. A stop after the
 * final check takes effect on the next call; already delivered audio cannot
 * be recalled. Zero-frame calls do not consume events. */
SpPreviewRenderResult sp_synth_preview_voice_render(SpSynthPreviewVoice *,
    int16_t *stereo,size_t sample_capacity,uint32_t frames);
#endif
