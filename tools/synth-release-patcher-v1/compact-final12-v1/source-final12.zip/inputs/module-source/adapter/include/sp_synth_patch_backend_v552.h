#ifndef SP_SYNTH_PATCH_BACKEND_V552_H
#define SP_SYNTH_PATCH_BACKEND_V552_H
#include "sp_synth_catalog.h"
#include "sp_synth_patch_reader_v552.h"
#include "sp_synth_patch_writer_v552.h"
#include <stdatomic.h>

enum {
    SP_PATCH_BACKEND_IMAGE=1u, SP_PATCH_BACKEND_CONTEXT=2u,
    SP_PATCH_BACKEND_NAMESPACE=4u, SP_PATCH_BACKEND_PROJECT=8u,
    SP_PATCH_BACKEND_MEDIA=16u, SP_PATCH_BACKEND_QUALIFIED=31u
};
enum {
    SP_PATCH_BACKEND_OPEN=1, SP_PATCH_BACKEND_READ,
    SP_PATCH_BACKEND_WRITE, SP_PATCH_BACKEND_DIRECTORY,
    SP_PATCH_BACKEND_MKDIR, SP_PATCH_BACKEND_CLOSE, SP_PATCH_BACKEND_SYNC
};
enum {
    SP_PATCH_BACKEND_CONTEXT_FAULT=1u, SP_PATCH_BACKEND_OWNERSHIP_FAULT=2u,
    SP_PATCH_BACKEND_RELEASE_FAULT=4u, SP_PATCH_BACKEND_EXHAUSTED=8u
};
typedef struct {
    uint32_t qualified,backend_task,control_task,directory_limit,allow_create;
    void *context;
    /* Supply actual filesystem/error-context, private namespace and project
     * exclusion. Zero means acquired/released. A success attests exclusion
     * until release; it must not be a placeholder or audio/IRQ operation. */
    int (*acquire)(void *);
    int (*release)(void *);
    /* Optional independently qualified error mapping. Unknown codes return
     * FAILED; only CARD/FULL/READ_ONLY are admitted. No ABSENT mapping exists. */
    SpPatchIOResult (*classify)(void *,uint32_t operation,uint32_t native_error);
} SpSynthPatchBackendProfileV552;

typedef struct {
    SpAppCompletion completion;
    SpPreset preset;
} SpSynthPatchBackendCompletion;

/* All fields are private. Permanent, cold-zeroed ARM32 storage. One backend
 * owns requests, native handles, IO and unpublished catalogs; one control owner
 * owns accepted catalog reads. Audio must never read this object or call it.
 * No live reset/reinitialization or concurrent native handle close/reuse. */
typedef struct {
    SpSynthPatchBackendProfileV552 profile;
    SpSynthPatchReaderV552 reader;
    SpSynthPatchWriterV552 writer;
    SpSynthPatchReadOps reader_native;
    SpSynthPatchWriteOps writer_native;
    uint32_t io_operation,native_error;
    SpPatchIOResult io_result;
    int32_t reader_fd;
    uintptr_t reader_file;
    uint32_t reader_faulted;
    SpSynthPatchStoreScratch scratch;
    SpSynthPatchIO io;
    SpAppRequest request;
    SpSynthPatchBackendCompletion response;
    SpSynthCatalog catalogs[2];
    atomic_uint catalog_state[2],catalog_pending,catalog_error,terminal,active;
    uint32_t catalog_sequence[2],next_sequence,control_catalog;
    uint32_t initialized,phase,leased,snapshot,namespace_exists,scan_catalog,servicing;
    uint8_t present[32],directory_record[532];
} SpSynthPatchBackendV552;

typedef enum {
    SP_PATCH_BACKEND_IDLE, SP_PATCH_BACKEND_MORE,
    SP_PATCH_BACKEND_COMPLETE, SP_PATCH_BACKEND_CATALOG_READY,
    SP_PATCH_BACKEND_CATALOG_FAILED, SP_PATCH_BACKEND_STOPPED
} SpPatchBackendService;

int sp_synth_patch_backend_v552_init(SpSynthPatchBackendV552 *,
    const SpSynthPatchBackendProfileV552 *);
/* Copy one supported, nonzero-generation request. Returns0 when busy or for an
 * unsupported request; no filesystem work occurs here. No borrowed app/preset
 * pointer is retained. A completed response stays pinned until finish. */
int sp_synth_patch_backend_v552_request(SpSynthPatchBackendV552 *,const SpAppRequest *);
/* Backend only. Execute a request once, or scan one user catalog slot. Repeated
 * COMPLETE calls do not repeat IO. First service snapshots actual directory
 * entries under exclusion. A read/catalog operation never creates a directory;
 * the first write can create only positively absent a:/SP4SYNTH. */
SpPatchBackendService sp_synth_patch_backend_v552_service(SpSynthPatchBackendV552 *);
/* Copy response AND preset into disjoint output; rebase completion.preset there.
 * Keep output alive through its response-inbox copy. finish is allowed only
 * after the caller's actual completion handoff succeeds, never merely on IO. */
int sp_synth_patch_backend_v552_completion(SpSynthPatchBackendV552 *,SpSynthPatchBackendCompletion *);
int sp_synth_patch_backend_v552_finish(SpSynthPatchBackendV552 *,uint32_t generation);
/* Backend scan uses only a FREE buffer. Error retains the previous control
 * catalog. Pending publication is never overwritten. No FS lease is retained
 * while waiting for control. No atomic filesystem snapshot without exclusion. */
int sp_synth_patch_backend_v552_catalog_begin(SpSynthPatchBackendV552 *);
/* Control only. peek borrows READY immutable metadata. Call accept only after
 * sp_synth_app_set_catalog succeeds in its valid control phase; this releases
 * the previous catalog for reuse. peek failure leaves outputs untouched. */
int sp_synth_patch_backend_v552_catalog_peek(SpSynthPatchBackendV552 *,
    const sp_ui_patch **entries,uint16_t *count,uint32_t *sequence);
int sp_synth_patch_backend_v552_catalog_accept(SpSynthPatchBackendV552 *,uint32_t sequence);
uint32_t sp_synth_patch_backend_v552_faults(const SpSynthPatchBackendV552 *);
sp_ui_error sp_synth_patch_backend_v552_catalog_error(const SpSynthPatchBackendV552 *);
/* May post terminal stop from another task. Does not interrupt an acquired
 * native operation, close a handle or free storage. Backend service retires an
 * outstanding catalog lease. Wait for quiescent before stopping that worker. */
void sp_synth_patch_backend_v552_stop(SpSynthPatchBackendV552 *);
int sp_synth_patch_backend_v552_quiescent(const SpSynthPatchBackendV552 *);
#endif
