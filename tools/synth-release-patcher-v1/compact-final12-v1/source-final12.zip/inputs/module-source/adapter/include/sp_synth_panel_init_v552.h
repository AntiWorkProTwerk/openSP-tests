#ifndef SP_SYNTH_PANEL_INIT_V552_H
#define SP_SYNTH_PANEL_INIT_V552_H
#include "sp_synth_clock_handoff_v552.h"

/* Link exactly one read-only definition. The default provider is NULL and
 * preserves native-only initialization. A supplied non-NULL configuration and
 * this pointer must be immutable before the selected task can start, remain
 * readable through initialization, and be disjoint from module/runtime/native
 * pool storage. Its qualification bits assert externally established facts;
 * this adapter does not establish clock, route, budget or task qualification.
 * No runtime registration, pointer replacement or reset is supported. */
extern const SpSynthClockConfigV552 *const sp_synth_panel_init_v552_config;

/* The call-site veneer replays LDR R1,[R1,#8] before entering this adapter.
 * Arguments therefore match the original BLX R1 at80072CB2, including R1's
 * resolved native target. The target is called once with all four arguments.
 * Only selected object8300A3E4 with target80072F81 can prepare after its intact
 * native initializer returns. A supplied configuration then permits one
 * deferred prepare and immediate same-control-task arm; arm failure cancels
 * without retry. Missing config and every other object/target retain native
 * behavior. The return is always the native initializer's raw R0.
 *
 * Requires the qualified selected task (never ISR), completed early module
 * initialization and intact native panel initialization/lifetime. Native UI
 * callbacks before the initializer returns must retain their ordinary native
 * behavior. Claim, fresh input, callback registration and normal panel service
 * remain separate qualified operations. The whole panel infinite-loop entry
 * is not wrapped. No writable owner, callback publication or clock read is
 * introduced here. */
uint32_t sp_synth_panel_init_v552_dispatch(uint32_t panel,uint32_t native_target,
    uint32_t original_r2,uint32_t original_r3);
#endif
