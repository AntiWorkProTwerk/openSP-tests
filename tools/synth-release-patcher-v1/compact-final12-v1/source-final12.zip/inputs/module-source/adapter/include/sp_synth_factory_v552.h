#ifndef SP_SYNTH_FACTORY_V552_H
#define SP_SYNTH_FACTORY_V552_H
#include "sp_synth_page_binding_v552.h"

/* Serialized qualified native panel task only; task IDs must not be reused and
 * no ISR may call this API. The supplied binding must already have completed
 * sp_synth_page_binding_v552_init successfully. Keep binding, exchange, callback
 * code and this module's initialized BSS pinned for the boot. Returns1 once;
 * null, misaligned, overflowing or subsequent registration returns0.
 * Release-publishes only this module's context; it changes no stock callback
 * pointer. Registration rejects another task or an unregistered page binding. */
int sp_synth_factory_v552_init(SpSynthPageBindingV552 *binding);

/* Stock-compatible one-argument callback. Event is a valid native event record
 * whose first aligned16-bit word is readable. Calls native80065449 exactly once
 * with the original pointer, including when no context has been registered.
 * Captures type before that call; after type1 returns, attempts binding using
 * the current singleton only on the registered task after acquire publication.
 * Other task callbacks do not touch mutable synth state. Binding failure never
 * changes the native R0 result. All bound-page lifecycle calls still require
 * the registered task; fallback cannot repair stock destruction on another task.
 * Initial event1 requires the normal stock absent-page lifetime. Native code
 * has no null-allocation fallback and creates a new page on every event1.
 * No code runs against the former page after event2 returns.
 * Pinned registration evidence only: screen30 descriptor801F9154 refers to
 * callback slot8023B628, originally80065449. This API does not patch that slot. */
uint32_t sp_synth_factory_v552_dispatch(const uint16_t *event);
#endif
