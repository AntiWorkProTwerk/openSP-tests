#ifndef SP_SYNTH_PAGE_BINDING_V552_H
#define SP_SYNTH_PAGE_BINDING_V552_H
#include "sp_synth_frontend_lifecycle_v552.h"

/* One UI-owner binding for the boot. Zero-initialize once and keep this owner,
 * exchange and code pinned, with disjoint owner, exchange and live-page storage.
 * Never copy/reset/free after init succeeds. Registration and all synth page
 * work belong to one qualified native panel task, with no ID reuse or ISR use.
 * Publication is atomic; mutable page/frontend work remains serialized on that
 * task. The exchange has its own SPSC ownership rules. */
typedef struct {
    SpSynthFrontendV552 frontend;
    SpSynthViewExchange *exchange;
    void *active_page;
    uint32_t primary[88];   /* two ABI prefix words, 86 methods */
    uint32_t secondary[7]; /* two prefix words, five methods for page+56 */
    uint32_t task_id; /* Immutable after release publication. */
} SpSynthPageBindingV552;
/* Initializes cloned tables and registers the sole permanent callback owner.
 * Returns1 on success,0 for invalid/nonzero/already-registered owner. The caller
 * must already have identified pinned v5.52 and the selected panel task; table
 * checks and a task ID are not evidence of either. Registration is serialized;
 * unrelated task callbacks may occur before or after publication and use stock.
 * Native bound-page creation/destruction must remain on the selected task. */
int sp_synth_page_binding_v552_init(SpSynthPageBindingV552 *owner,
    SpSynthViewExchange *exchange);
/* Acquires publication and checks the immutable native task ID. Reads no
 * mutable frontend/page state. Does not establish task or image provenance. */
int sp_synth_page_binding_v552_is_control_owner(const SpSynthPageBindingV552 *owner);
/* UI owner only, AFTER initial stock entry has completed all child creation.
 * Requires live stock singleton and original primary/secondary vtables. Installs
 * RAM object pointers, then attaches the copied view without repeating stock
 * entry. Returns1 when bound (even if widget allocation must retry),0 rejected.
 * Same-page calls are idempotent. Rebind after wrapped destruction is permitted.
 * All nonvirtual rebuild/destruction paths must still be covered by integration;
 * cloning tables does not intercept direct calls into native code. */
int sp_synth_page_binding_v552_bind_after_entry(SpSynthPageBindingV552 *owner,
    void *page);
#endif
