#ifndef SP_SYNTH_MIDI_OWNER_V552_H
#define SP_SYNTH_MIDI_OWNER_V552_H
#include "sp_synth_engine.h"
#include <stdatomic.h>
#include <stdint.h>
#define SP_MIDI_OWNER_CAPACITY 64u
#define SP_MIDI_OWNER_PREFIX 16u
#define SP_MIDI_OWNER_KEYS 4096u

typedef struct {
    SpSynthEvent event;
    uint32_t epoch,order,header;
} SpSynthMidiRecordV552;
typedef int (*SpSynthMidiPublishV552)(void *,uint32_t,const SpSynthMidiRecordV552 *,uint32_t);
typedef void (*SpSynthMidiStopV552)(void *,uint32_t);
typedef struct { uint32_t identity,epoch;uint16_t key;uint8_t next,reserved; } SpSynthMidiKeyV552;
typedef struct {
    uint8_t stock[SP_MIDI_OWNER_KEYS],heads[SP_MIDI_OWNER_KEYS],tails[SP_MIDI_OWNER_KEYS];
    uint16_t stock_total[32];
    uint16_t captured_total[16];
    uint32_t stock_sustain,captured_sustain,quarantine;
    SpSynthMidiKeyV552 keys[SP_MIDI_OWNER_CAPACITY];
    SpSynthMidiRecordV552 records[SP_MIDI_OWNER_CAPACITY];
    uint32_t head,count,order,next_identity,free_key;
    uint32_t epoch,active,task_id,rx_task,pop_depth,service_depth;
    uint32_t published,removed;
    _Atomic uint32_t fault;
    SpSynthMidiPublishV552 publish;
    SpSynthMidiStopV552 stop;
    void *context;
} SpSynthMidiOwnerV552;
extern SpSynthMidiOwnerV552 sp_synth_midi_owner_v552;
enum { SP_MIDI_SOURCE_LOSS=1u,SP_MIDI_METADATA=2u,SP_MIDI_FOREIGN=4u,
       SP_MIDI_FULL=8u,SP_MIDI_EXHAUSTED=16u,SP_MIDI_SESSION=32u,
       SP_MIDI_PUBLISH=64u,SP_MIDI_EXTERNAL=128u,SP_MIDI_PROTOCOL=256u };
/* Permanent separate storage. cold() runs once after cold BSS setup, before
 * IRQ22 is enabled. The source hooks record an early miss and forbid late cold
 * publication. Never reset, relocate or reclaim this owner during native RX.
 * Final placement/clear integration is separate from this component. */
int sp_synth_midi_owner_v552_cold(void);
/* Selected panel task, once. Callbacks/context remain permanent; publish copies
 * <=16 records on that task, stop performs only idempotent atomic cancellation
 * and may run on RX/IRQ. Neither callback may reenter this owner. */
int sp_synth_midi_owner_v552_install(void *panel,SpSynthMidiPublishV552,
    SpSynthMidiStopV552,void *context);
/* No supplied physical snapshot or qualification flags. Actual ingress must be
 * empty, with no in-flight callback or partial native frame. The accepted remote
 * snapshot must also report healthy/empty action4/5 queues with no callback in
 * flight. Its guards and fixed source-owned state are required dependencies.
 * Call outside native action/panel dispatch frames. Epoch is the joined
 * owner's nonzero monotonic lifetime. Observed old notes/sustain quarantine their
 * logical channel across both native routes until released. */
int sp_synth_midi_owner_v552_enter(uint32_t epoch);
/* Closes input and retires queued records; stop is independent of FIFO capacity.
 * Captured per-source note-offs stay owned until release. Reentry needs a newer
 * epoch and healthy source. Faults are permanent and have no reset API. */
int sp_synth_midi_owner_v552_exit(void);
void sp_synth_midi_owner_v552_cancel(void);
/* Selected task, after an app-side Panic/destructive key reset and before MIDI
 * service resumes. channel0..15 or16=all. Retires queued records and captured
 * tickets for those channels while preserving monotonic identities. Rejects an
 * inactive/faulted lifetime. A pop/service in flight cancels through stop and
 * returns0. Caller must keep the joined lifetime closed on any failed reset.
 * Ordinary edits that replay held keys do not call this.
 * As with CC120/123, later same-route/note OFFs belong to the post-reset sequence;
 * untagged MIDI cannot identify a delayed pre-reset OFF after a fresh ON. */
int sp_synth_midi_owner_v552_notes_reset(uint32_t channel);
/* At most16 records, selected owner only. MIDI channel controllers merge across
 * routes; unique note identities preserve per-route/channel/note FIFO releases.
 * Full header byte is metadata; only class8/9 distinguish proven native routes. */
int sp_synth_midi_owner_v552_service(void);
/* Native attachment internals. Guard called with PRIMASK set after framing,
 * before completed-record stores; result1 skips only malformed metadata stores.
 * finish runs after restoring PRIMASK. Native valid/full stores remain intact. */
uint32_t sp_synth_midi_owner_v552_before_publish(void);
void sp_synth_midi_owner_v552_after_publish(void);
/* Exact native pop/callback replacement: packet points at original caller local,
 * table/mask are native R10/R6, original_r3 is forwarded. Low word is native raw
 * result, high word says whether the native drain may continue. */
uint64_t sp_synth_midi_owner_v552_dispatch(uint32_t *packet,uintptr_t table,
    uint32_t native_mask,uint32_t original_r3);
#endif
