#ifndef SP_SYNTH_CAPTURE_LIFECYCLE_V552_H
#define SP_SYNTH_CAPTURE_LIFECYCLE_V552_H
#include "sp_synth_session_v552.h"

enum { SP_LCAP_FREE, SP_LCAP_RESERVING, SP_LCAP_RESERVED,
    SP_LCAP_RUNNING, SP_LCAP_STOP_PENDING, SP_LCAP_HELD,
    SP_LCAP_SAVING, SP_LCAP_FINALIZED, SP_LCAP_ERROR, SP_LCAP_ACQUIRING,
    SP_LCAP_EXCLUSIVE_IDLE, SP_LCAP_BEGIN, SP_LCAP_DISCARD_BARRIER, SP_LCAP_DISCARDING };
enum { SP_LCAP_BLOCKED=-1040, SP_LCAP_CONTEXT=-1041,
    SP_LCAP_NATIVE_STATE=-1042, SP_LCAP_UNEXPECTED_SAVE=-1043,
    SP_LCAP_INITIAL_WRITE=-1044, SP_LCAP_CLOSE=-1045, SP_LCAP_UNLINK=-1046 };
/* Separate component-only manual profile. Existing app modes0/1 are rejected;
 * mode2 requires seconds/bars/tempo/count-in/tail all zero. No timed recording,
 * count-in or release-tail claim follows from successful native BEGIN. */
enum { SP_LCAP_MANUAL_UNTIMED=2 };
/* Low byte is phase; each native entry owns one 0x100 lease until return.
 * All storage is permanent. Initialization and hooks must precede native task
 * callbacks. No late installation or global recorder handback exists.
 * Placement is external; this component does not reserve firmware RAM. All
 * native hooks must be installed together before callbacks, and every guarded
 * entry must retain its installed arguments/provenance. Task IDs cannot be
 * reused while registered. One serialized SMPL action4 consumer owns work;
 * no other backend consumer, recursive worker, ISR API caller or owner reset.
 * Owner, session and allocated runtime must be disjoint permanent storage. */
typedef struct {
    atomic_uint state,token,rx_ack,fault,permit,audio_task;
    _Atomic(SpSynthBackendLink *) backend;
    uint32_t last_token,handle,work_token,working,response_ready,closed_request;
    atomic_uint native_save_count,blocked_save_count;
    atomic_uint record_ready,barrier_token,barrier_ack;
    uint32_t override_mask,write_count,discard_attempted,file_owned,descriptor;
    int32_t initial_write_raw,close_raw,unlink_raw,setup_unlink_raw,setup_raw,start_raw;
    int32_t save_raw;
    SpAppRequest work;
    SpAppCompletion completion;
} SpSynthCaptureLifecycleV552;

/* Cold once: zero owner outside native pool; no callbacks may have entered. */
int sp_synth_capture_lifecycle_v552_init(SpSynthCaptureLifecycleV552 *owner);
/* Selected native panel task publishes an initialized, pinned session link.
 * Worker never invokes a session/control service. Publication is one-shot. */
int sp_synth_capture_lifecycle_v552_publish(SpSynthSessionV552 *session);
/* Qualified panel owner after request publication or response-slot release.
 * Schedules action4 only. The ordinary control attachment is still external. */
int sp_synth_capture_lifecycle_v552_kick(void);
/* Actual SMPL task only. Validates the explicit manual profile before mutation.
 * Runs native setup/open/initial write/start. Returns1 only after validating
 * actual native state and clearing destination. Error retains the owner/token.
 * Uses one checked, non-nesting native dispatch-inhibit pair for admission and
 * token reset only. Existing leases still exclude suspended callbacks; native
 * recorder/filesystem calls begin after dispatch is restored. No ISR callers.
 * The profile must be immutable and disjoint from all owner/session storage. */
int sp_synth_capture_lifecycle_v552_begin(uint32_t token,const SpAppCapture *profile);
int sp_synth_capture_lifecycle_v552_stop(uint32_t token);
/* Same task/token, after acknowledged STOP and drain retirement. Starts a
 * record-task barrier, then checked close/unlink/reset on later worker passes.
 * Returns1 accepted/pending,0 rejected. Successful completion retires the token
 * into EXCLUSIVE_IDLE; ordinary native recorder handback remains closed. */
int sp_synth_capture_lifecycle_v552_discard(uint32_t token);
/* Low-level native primitive, NOT connected to TAKE_WRITE requests. Requires a
 * separately qualified destination already bound at outer+4C, with overwrite
 * permission and project/file ownership established. Calls native SAVE once,
 * records raw result, then pins FINALIZED/error provenance. No pad-success
 * completion, retry, reset or token release is provided. */
int32_t sp_synth_capture_lifecycle_v552_save_once(uint32_t token);

/* Exact installed-boundary adapters; assembly entries restore the callback's
 * originally resolved R2. Native trampolines replay displaced prologues.
 * Null owner, unrelated objects/commands and FREE paths call native once.
 * EXCLUSIVE_IDLE deliberately keeps ordinary recorder mutation blocked.
 * Owned rejection intentionally returns SP_LCAP_BLOCKED. */
uint32_t sp_synth_capture_lifecycle_v552_smpl(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_lifecycle_v552_record(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_lifecycle_v552_dispatch(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_lifecycle_v552_save(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_lifecycle_v552_rx(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_lifecycle_v552_consume(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_lifecycle_v552_initial_write(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_lifecycle_v552_stereo_query(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_lifecycle_v552_mode_query(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_lifecycle_v552_setup_unlink(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_capture_lifecycle_v552_record_init(uint32_t,uint32_t,uint32_t,uint32_t);
#endif
