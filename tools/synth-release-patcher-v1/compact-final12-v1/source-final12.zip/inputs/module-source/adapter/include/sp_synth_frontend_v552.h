#ifndef SP_SYNTH_FRONTEND_V552_H
#define SP_SYNTH_FRONTEND_V552_H
#include "sp_synth_page_v552.h"
#include "sp_synth_view_exchange.h"

/* Zero-initialize once, then UI-owner calls only. Stable storage for stock's
 * registered widget handle. No control/audio/app object is shared with this
 * owner. Exchange and frontend must be disjoint. Pinned v5.52 page contract. */
typedef struct {
    sp_synth_page_v552 page;
    sp_ui_view view;
    uint8_t plot[120];
    uint8_t has_view;
    void *entered_page;
} SpSynthFrontendV552;
/* Invoke only after stock finishes creating synth-page children. Consumes one
 * available snapshot; no widget attaches until a view has arrived. Returns the
 * page API's0/1/2 result. A stopped exchange detaches on this UI-owner call. */
int sp_synth_frontend_v552_after_entry(SpSynthFrontendV552 *frontend,
    SpSynthViewExchange *exchange,void *page);
/* Ordinary UI-owner tick: consumes a snapshot even with page==NULL (hidden).
 * May retry attachment only to the same live page previously marked after_entry.
 * Caller must detach before that page leaves its completed-children lifetime.
 * Retains snapshots across attachment failure; no stale page is dereferenced
 * unless the caller passes that same identity as a currently live page. */
int sp_synth_frontend_v552_tick(SpSynthFrontendV552 *frontend,
    SpSynthViewExchange *exchange,void *page);
/* UI exit only; clears page binding but retains latest snapshot for reentry.
 * Does not stop the synth or release exchange/runtime storage. */
void sp_synth_frontend_v552_detach(SpSynthFrontendV552 *frontend);
#endif
