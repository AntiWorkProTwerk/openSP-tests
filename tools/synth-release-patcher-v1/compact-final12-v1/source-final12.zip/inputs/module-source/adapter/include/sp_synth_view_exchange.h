#ifndef SP_SYNTH_VIEW_EXCHANGE_H
#define SP_SYNTH_VIEW_EXCHANGE_H
#include <stdatomic.h>
#include "sp_synth_ui_render.h"

/* One control producer, one UI consumer, coherent CPU memory. Initialize with
 * both stopped. Keep storage pinned until both owners are externally quiesced.
 * Sources/destinations must be disjoint from the exchange and each other.
 * Full means skip this publication and offer the current view on a later tick;
 * never spin or overwrite an unread snapshot. This is not a control-event queue. */
typedef struct {
    sp_ui_view view;
    uint8_t plot[120];
    atomic_uint ready, stopped;
} SpSynthViewExchange;
void sp_synth_view_exchange_init(SpSynthViewExchange *exchange);
/* Copies both inputs; plot is required. Returns1 copied,0 full/invalid,-1 stopped.
 * Inputs must remain stable during the call. No pointer is retained. */
int sp_synth_view_exchange_publish(SpSynthViewExchange *exchange,
    const sp_ui_view *view,const uint8_t plot[120]);
/* Returns1 copied,0 empty/invalid,-1 stopped. Failure preserves outputs. */
int sp_synth_view_exchange_take(SpSynthViewExchange *exchange,
    sp_ui_view *view,uint8_t plot[120]);
/* Terminal; does not clear ready or wait for in-flight calls. A racing call may
 * finish one copy after stop. Stop is not a lifetime/reclamation barrier. */
void sp_synth_view_exchange_stop(SpSynthViewExchange *exchange);
#endif
