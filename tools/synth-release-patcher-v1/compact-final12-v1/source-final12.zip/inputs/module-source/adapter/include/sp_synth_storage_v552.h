#ifndef SP_SYNTH_STORAGE_V552_H
#define SP_SYNTH_STORAGE_V552_H
#include "sp_synth_runtime_storage.h"

typedef struct {
    SpSynthRuntimeStorage *storage;
    void *allocation;
    int32_t pool_id;
    uint32_t attached;
} SpSynthStorageV552;

/* v5.52 only; serialized, qualified task context, before any callbacks attach.
 * Zero-initialize the handle once in independent stable storage. Never copy it.
 * Returns0 on success, a native negative error, or -1001 invalid handle/state,
 * -1002 invalid pool ID, -1003 unexpected allocation range. Failure leaves the
 * handle unchanged. Storage contents are uninitialized; run component initializers.
 * This call neither verifies the running firmware hash nor establishes capacity. */
int sp_synth_storage_v552_acquire(SpSynthStorageV552 *owner);
/* Call after initialization and BEFORE publishing any reference. Idempotent.
 * Pins storage for the rest of this boot; this API cannot reclaim attached data.
 * It does not install callbacks or validate component initialization. */
int sp_synth_storage_v552_attach(SpSynthStorageV552 *owner);
/* Abort setup only while no reference has escaped. Refuses attached storage.
 * Uses the captured pool ID and original pointer, then clears the handle.
 * A successful return means release was issued, not independent reclamation
 * proof. The native void release requires valid task context. No audio/IRQ calls. */
int sp_synth_storage_v552_abandon(SpSynthStorageV552 *owner);
#endif
