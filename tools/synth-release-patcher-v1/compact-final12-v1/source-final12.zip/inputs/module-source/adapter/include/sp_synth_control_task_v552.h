#ifndef SP_SYNTH_CONTROL_TASK_V552_H
#define SP_SYNTH_CONTROL_TASK_V552_H
#include <stdint.h>

/* Call only in task context. The native getter identifies the current TCB; it
 * does not detect an ISR or prove panel provenance. The registered task must
 * remain alive without ID reuse for this boot. */
static inline uint32_t sp_synth_control_task_v552_current(void) {
    return ((uint32_t (*)(void))(uintptr_t)UINT32_C(0x800D3163))();
}
static inline int sp_synth_control_task_v552_valid(uint32_t id) {
    return id>=1 && id<=32;
}
#endif
