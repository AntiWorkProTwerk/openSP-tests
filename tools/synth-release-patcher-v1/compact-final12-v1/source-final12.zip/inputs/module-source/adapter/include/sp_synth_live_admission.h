#ifndef SP_SYNTH_LIVE_ADMISSION_H
#define SP_SYNTH_LIVE_ADMISSION_H
#include "sp_synth_backend_link.h"

#define SP_LIVE_CAPACITY 64u
#define SP_LIVE_PREFIX 16u
typedef enum {SP_LIVE_PANEL,SP_LIVE_MIDI} SpLiveSource;
typedef struct {uint32_t type,index;int32_t value;} SpLivePanel;
typedef struct {
    uint32_t source;
    union {SpLivePanel panel;SpSynthEvent midi;} value;
} SpLiveInput;
typedef struct {SpLiveInput input;uint32_t accepted_tick,order;} SpLiveRecord;
typedef enum {
    SP_LIVE_HEALTHY,SP_LIVE_PROTOCOL,SP_LIVE_INPUT,SP_LIVE_FULL,
    SP_LIVE_RESIDENCE,SP_LIVE_EXHAUSTED,SP_LIVE_DELIVERY,
    SP_LIVE_CONTROL_AGE,SP_LIVE_AUDIO_GAP,SP_LIVE_CANCELED
} SpLiveFault;
typedef enum {SP_LIVE_WAITING,SP_LIVE_IDLE,SP_LIVE_OPEN,SP_LIVE_SENT,SP_LIVE_STOPPED} SpLiveService;
typedef struct {uint32_t lifetime,target,sequence,first_order,count;} SpLiveTicket;
typedef struct {
    volatile const uint32_t *counter;
    uint32_t lead_blocks,max_residence,max_audio_gap,first_service_age,service_age;
} SpLiveConfig;
typedef struct {
    SpSynthApp *app;
    SpSynthAudioMailbox *mailbox;
    SpSynthBackendLink *backend;
    SpLiveConfig config;
    uint32_t lifetime;
    atomic_uint fault,started,progress_tick,progress_count;
    /* Audio owner; epoch is immutable after started release-publication. */
    uint32_t epoch,last_audio_tick,audio_age,seen_progress;
    /* Serialized control owner only. No audio reads of staging/app/backend. */
    SpLiveRecord records[SP_LIVE_CAPACITY];
    uint32_t head,count,accepted,assigned,last_target,last_count,last_first_order;
    uint32_t service_serial,acknowledged_service,service_tick;
    uint8_t has_target,input_closed,admission_open,pending_deliveries;
} SpSynthLiveAdmission;

/* Separate live policy over an existing timed mailbox. All owners stopped;
 * owner starts zeroed and cannot be reset/rebound during this lifetime. The
 * already-prepared app/mailbox/backend and counter storage remain disjoint,
 * pinned and live. This does not transfer/reset an engine or anchor input time.
 * One control producer serializes every acceptance, service and progress call.
 * One audio owner calls mix; stop alone may be called by another owner.
 * Counter must have qualified fixed-rate DWT continuity and observation gaps
 * below half its range. No qualification flag or native attachment is supplied.
 * Nonzero lifetime is the outer owner's unique entry ticket. Its source/entry,
 * held-control and task-lifetime facts remain external requirements. */
int sp_synth_live_init(SpSynthLiveAdmission *owner,SpSynthApp *app,
    SpSynthAudioMailbox *mailbox,SpSynthBackendLink *backend,
    const SpLiveConfig *config,uint32_t lifetime);
/* Control owner after an orderly leave. Observable app/mailbox/backend work
 * must be empty; accepted input after LEAVE is retained but never replayed.
 * This check does not establish native RELEASED or exclusion of audio. */
int sp_synth_live_quiescent(const SpSynthLiveAdmission *owner);
/* Both owners externally parked, after successful app_reenter. Requires the
 * next lifetime exactly once and the same immutable bindings. Preserves all
 * engine/mailbox sequences, sample cursor and accepted input identities; only
 * this coordinator's supervision and admission state start a new lifetime.
 * Caller must acquire a real audio park acknowledgment before calling. */
int sp_synth_live_reenter(SpSynthLiveAdmission *owner,uint32_t next_lifetime);
/* Copy the entire bounded normalized input array or none. Call order is merged
 * acceptance order, not physical arrival order. MIDI offset must be zero;
 * channel/note/parameter identity are retained. Native/ISR delivery must copy
 * to the serialized owner first. All input/output storage must be disjoint.
 * Returns0 without admission before first audio or after orderly UI leave.
 * Invalid input/ticket, overflow, expiry and counter exhaustion stop terminally.
 * Accepted records have no assigned sample timestamp until service. */
int sp_synth_live_accept(SpSynthLiveAdmission *owner,uint32_t lifetime,
    const SpLiveInput *inputs,uint32_t count);
/* Takes audio ack, publishes at most one backend request and any acknowledged
 * capture cancellation. Applies ordinary response, copied capture progress and
 * cancellation receipt, then <=16 ordered input records to one future block.
 * A cancellation receipt waits for its ordinary START response. Borrowed slots
 * stay owned across open/close and release only after successful publication
 * and health checks. Terminal failure retains them without replay.
 * Response priority is the existing backend-before-input policy. MIDI->UI,
 * short-note/retrigger and non-note UI boundaries split prefixes. Assignment
 * occurs once; lost publication deadlines stop without replay or retiming.
 * Successful WAITING/IDLE/SENT passes can be acknowledged through progress.
 * Leave closes new input and retains the accepted tail for diagnosis; service
 * still acknowledges panic audio and delivers the backend LEAVE request. */
SpLiveService sp_synth_live_service(SpSynthLiveAdmission *owner);
/* Explicit form of service's one open/close transition. OPEN copies a ticket
 * to disjoint caller storage and retains the assigned prefix/response/target.
 * Audio may advance while it is open. Close requires that exact immutable
 * ticket once. Inputs cannot be accepted and no new admission can open until
 * it closes; later publication still requires the previous audio ack.
 * A duplicate/changed ticket or missed deadline is terminal, never retimed.
 * No completed-service progress is available for an unfinished OPEN. */
SpLiveService sp_synth_live_open(SpSynthLiveAdmission *owner,SpLiveTicket *ticket);
SpLiveService sp_synth_live_close(SpSynthLiveAdmission *owner,const SpLiveTicket *ticket);
/* Optional serialized-control integration. Weak pending returns0 and opened
 * does nothing. Pending only observes copied/immutable work after the previous
 * real audio receipt; returning nonzero requests the ordinary timed batch even
 * without source input. Opened runs after borrowed deliveries and before input,
 * while app.audio_batch is the real unsealed mailbox batch. It may use ordinary
 * app control APIs, but must not seal/publish, reset/rebind any owner, consume
 * borrowed deliveries, alter admission staging or retain stack/ticket storage.
 * Implementations must verify their selected native owner/task independently.
 * No hook runs after orderly input closure; audio never invokes these hooks. */
int sp_synth_live_control_pending(const SpSynthLiveAdmission *owner);
void sp_synth_live_control_opened(SpSynthLiveAdmission *owner);
/* Explicit completed-service acknowledgment. Checks current health and reads
 * real counter time itself; one new successful service is required per ack.
 * Accepting input or merely waking cannot refresh supervision. No input-source
 * closure/watermark is asserted. Repeated calls without new service return0. */
int sp_synth_live_progress(SpSynthLiveAdmission *owner);
/* Audio owner: DWT supervision, then unchanged exact-deadline mailbox consumer.
 * Only fixed64-frame blocks qualify service startup. Stop panics on this owner;
 * an already-running call can finish. Ack does not imply DAC drain or freeing. */
SpSynthStockResult sp_synth_live_mix(SpSynthLiveAdmission *owner,SpAppAudioState *audio,
    const SpSynthStockBlock *block,SpSynthAppMixScratch *scratch);
/* Independent of queue capacity. Use before suspension; terminal, no retry,
 * automatic resume, reset, reanchor or reclamation. Both owners and actual
 * backend work must be quiescent before any external lifetime replacement. */
void sp_synth_live_stop(SpSynthLiveAdmission *owner);
#endif
