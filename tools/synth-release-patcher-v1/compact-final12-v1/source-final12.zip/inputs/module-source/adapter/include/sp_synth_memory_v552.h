#ifndef SP_SYNTH_MEMORY_V552_H
#define SP_SYNTH_MEMORY_V552_H
#include <stdint.h>

/* Fixed v5.52 build profiles, not runtime discovery or arbitrary placement.
 * Every linked component must use the same selector. Profile1 also requires
 * the corresponding native pool-constructor patch and qualified owner/BSS
 * initialization before callback publication. The flag alone reserves nothing.
 * Code placement, linker intervals and startup ordering remain external. */
#define SP_SYNTH_V552_MEMORY_STOCK 0
#define SP_SYNTH_V552_MEMORY_RESERVED4K 1
#define SP_SYNTH_V552_MEMORY_RESERVED32K 2
#ifndef SP_SYNTH_V552_MEMORY_PROFILE
#define SP_SYNTH_V552_MEMORY_PROFILE SP_SYNTH_V552_MEMORY_STOCK
#endif

#define SP_SYNTH_V552_POOL_BEGIN UINT32_C(0x8353A30C)
#define SP_SYNTH_V552_STOCK_POOL_END UINT32_C(0x8383A30C)
#if SP_SYNTH_V552_MEMORY_PROFILE == SP_SYNTH_V552_MEMORY_STOCK
#define SP_SYNTH_V552_POOL_END SP_SYNTH_V552_STOCK_POOL_END
#define SP_SYNTH_V552_OWNER_PAGE_BEGIN UINT32_C(0)
#define SP_SYNTH_V552_OWNER_PAGE_END UINT32_C(0)
#elif SP_SYNTH_V552_MEMORY_PROFILE == SP_SYNTH_V552_MEMORY_RESERVED4K
#define SP_SYNTH_V552_POOL_END UINT32_C(0x8383930C)
#define SP_SYNTH_V552_OWNER_PAGE_BEGIN SP_SYNTH_V552_POOL_END
#define SP_SYNTH_V552_OWNER_PAGE_END SP_SYNTH_V552_STOCK_POOL_END
#elif SP_SYNTH_V552_MEMORY_PROFILE == SP_SYNTH_V552_MEMORY_RESERVED32K
#define SP_SYNTH_V552_POOL_END UINT32_C(0x8383230C)
#define SP_SYNTH_V552_OWNER_PAGE_BEGIN SP_SYNTH_V552_POOL_END
#define SP_SYNTH_V552_OWNER_PAGE_END SP_SYNTH_V552_STOCK_POOL_END
#else
#error "Unsupported v5.52 synth memory profile (expected0,1 or2)"
#endif
#endif
