#ifndef SP_SYNTH_AUDIO_BINDING_V552_H
#define SP_SYNTH_AUDIO_BINDING_V552_H
#include "sp_synth_session_v552.h"

/* Permanent owner, initialized before audio callbacks. Keep owner/session/code
 * in reserved, disjoint storage outside the stock application pool. The session
 * has its own preparation/publication requirements. No firmware hook is written.
 * Pair is an immutable work-buffer index, not a qualified physical destination. */
struct SpSynthClockHandoffV552;
typedef struct SpSynthAudioBindingV552 {
    SpSynthSessionV552 *session;
    uint32_t pair_index;
    atomic_uint admitted;
    atomic_uint fault; /* Last non-OK synth result; successful stop ack retains it. */
    struct SpSynthClockHandoffV552 *handoff; /* Set only before callbacks. */
} SpSynthAudioBindingV552;

/* Registers one zeroed owner for the boot; session may still be unprepared.
 * Both must be stable, valid objects, with no callback running during init.
 * Returns1 once,0 for invalid/overlapping/nonzero/subsequent registration. */
int sp_synth_audio_binding_v552_init(SpSynthAudioBindingV552 *owner,
    SpSynthSessionV552 *session,uint32_t pair_index);
/* Qualified control/startup owner: one-way admission after session readiness,
 * before its first clocked audio callback. The supplied sample anchor must match
 * that callback; this function neither measures nor repairs a stale anchor.
 * Returns1 admitted/idempotent,0 unready/terminal/wrong owner. No pause/resume.
 * Disable by requesting session stop; keep calling audio to acknowledge it. */
int sp_synth_audio_binding_v552_admit(SpSynthAudioBindingV552 *owner);

/* Native-compatible call wrapper for v5.52 TX instruction1C766 only. Calls
 * original1CB85 exactly once first, forwarding all4 args, and preserves raw R0.
 * An admitted, ready session then adds stereo synth output only for the exact
 * tuple (80249800,202AD3A0,64,14). Unsupported tuples retain native behavior but
 * latch synth failure/stop; they never pass an unqualified buffer to the synth.
 * Native callers must still satisfy native memory/state validity requirements.
 * Native gain/pan remain intact; synth gain/pan belong to its own audio state.
 * A registered deferred coordinator may perform bounded first-clock binding
 * after native and before the same call's mix. No allocation, DSP preparation,
 * control dispatch or waits. Terminal calls still
 * reach the mailbox for stop acknowledgment; storage remains pinned afterward. */
uint32_t sp_synth_audio_binding_v552_dispatch(void *native_state,int32_t *work,
    int32_t frames,int32_t stride);
#endif
