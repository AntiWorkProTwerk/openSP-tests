#ifndef SP_SYNTH_WIDGET_V552_H
#define SP_SYNTH_WIDGET_V552_H
#include "sp_synth_oled.h"
typedef struct sp_synth_widget_v552 sp_synth_widget_v552;
/* UI-owner calls only, pinned v5.52. Parent is the live child container.
 * Uses stock allocation: capacity and allocation failure return NULL, but the
 * stock allocator's installed new-handler may retry. No audio-thread calls.
 * A returned handle is valid until removal, screen rebuild or page destruction. */
sp_synth_widget_v552 *sp_synth_widget_v552_add(void *parent);
/* Preferred owner binding. Requires a zero-initialized handle whose storage
 * remains valid through removal or stock cleanup. On success registers that
 * storage and sets *owner. The destructor clears it if it still points here.
 * NULL owner or nonempty handle returns NULL without changing it or allocating.
 * Failed creation leaves an empty handle. UI-owner calls remain serialized. */
sp_synth_widget_v552 *sp_synth_widget_v552_add_owned(void *parent,sp_synth_widget_v552 **owner);
/* Requires a live handle. Copies the frame; returns 0 if removal is pending or
 * the widget is no longer last, 1 unchanged, 2 changed and marked dirty. */
int sp_synth_widget_v552_update(sp_synth_widget_v552 *widget,const sp_oled_frame *frame);
/* Clears caller's and registered owner's handles immediately; stock container
 * reclaims it later. Registered owner storage may be released after this call.
 * Repeated remove of the same cleared handle is harmless. No stale aliases.
 * Unregistered aliases still require explicit invalidation before rebuild or
 * destruction; a surviving page does not imply a live widget. */
void sp_synth_widget_v552_remove(sp_synth_widget_v552 **handle);
#endif
