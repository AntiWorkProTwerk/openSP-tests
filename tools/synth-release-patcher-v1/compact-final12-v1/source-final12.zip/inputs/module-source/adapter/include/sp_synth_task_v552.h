#ifndef SP_SYNTH_TASK_V552_H
#define SP_SYNTH_TASK_V552_H
#include <stdint.h>

enum { SP_SYNTH_TASK_EMPTY, SP_SYNTH_TASK_DORMANT, SP_SYNTH_TASK_STARTED,
       SP_SYNTH_TASK_FAULT };
typedef struct {
    void *allocation, *stack;
    int32_t pool_id, task_id;
    uint32_t phase, stack_bytes;
} SpSynthTaskV552;
typedef struct {
    uintptr_t entry; /* Thumb address; entry must never return. */
    void *context;
    uint32_t priority, stack_bytes;
} SpSynthTaskConfigV552;

/* Pinned v5.52 only, serialized qualified task context. Zero owner once in
 * independent permanent storage; never copy or reset it after creation.
 * Config must be a disjoint valid object. Entry/context must remain valid for
 * the boot. Caller qualifies task entry ABI, FPU ownership, priority and stack
 * budget separately. Accepts 8..64 KiB stacks, multiple of 8; this is an API
 * bound, not a measured runtime requirement. No callbacks are installed.
 * Creates a dormant task with a pool-owned aligned stack and FPU attribute.
 * Native create failure releases its unused stack. Success pins the allocation
 * until reboot, including if a later start fails; there is no deletion API.
 * 0=success; native negatives propagate; -1002=pool ID, -1003=allocation range,
 * -1006=owner/config/state, -1007=unexpected native task ID (pinned FAULT).
 * Unexpected allocator addresses are not released. These require diagnosis. */
int sp_synth_task_v552_create(SpSynthTaskV552 *owner, const SpSynthTaskConfigV552 *config);
/* Marks STARTED before invoking native start, which may schedule immediately.
 * A native negative return restores DORMANT. Success does not prove the entry
 * ran. The context, owner and stack remain pinned; page exit cannot free them. */
int sp_synth_task_v552_start(SpSynthTaskV552 *owner, int32_t argument);
/* Qualified running task only, with dispatch enabled. A positive kernel-tick
 * count enters native delay; expiry is current tick + ticks + 1. Tick frequency
 * and scheduling latency are not inferred. Rejects zero and >=2^31 with -1006
 * so a caller cannot accidentally turn its wait into a no-op. Native errors
 * propagate; callers must stop servicing work on error, not busy-retry it.
 * No stack/storage ownership is released, and this does not drain audio. */
int sp_synth_task_v552_delay(uint32_t ticks);
#endif
