#ifndef SP_SYNTH_LIVE_SESSION_V552_H
#define SP_SYNTH_LIVE_SESSION_V552_H
#include "sp_synth_session_v552.h"
#include "sp_synth_live_admission.h"
#include "sp_synth_entry_owner_v552_live.h"
#include "sp_synth_generator_route_v552.h"
#include "sp_synth_memory_v552.h"
#if SP_SYNTH_V552_MEMORY_PROFILE != SP_SYNTH_V552_MEMORY_RESERVED32K
#error "The separate live provider requires its reserved32K profile and recipe"
#endif

enum { SP_LSESSION_COLD,SP_LSESSION_PREPARED,SP_LSESSION_ENTERING,
    SP_LSESSION_PLAYING,SP_LSESSION_LEAVING,SP_LSESSION_LEFT,
    SP_LSESSION_GENERATOR_PENDING,SP_LSESSION_GENERATOR,SP_LSESSION_FAILED,
    SP_LSESSION_CHOOSER,SP_LSESSION_WAIT_NATIVE,SP_LSESSION_WAIT_FRESH,
    SP_LSESSION_WAIT_PARK,SP_LSESSION_WAIT_RESUME,SP_LSESSION_WAIT_RELEASE,
    SP_LSESSION_WAIT_LEASE,SP_LSESSION_CANCEL_LEASE };
enum { SP_LSESSION_SELECT_SYNTH=1,SP_LSESSION_SELECT_GENERATOR,
    SP_LSESSION_CONFIRM,SP_LSESSION_EXIT };
enum { SP_LSESSION_FAULT_LIFETIME=1u,SP_LSESSION_FAULT_CONTEXT=2u,
    SP_LSESSION_FAULT_ROUTE=4u,SP_LSESSION_FAULT_DISPLAY=8u,
    SP_LSESSION_FAULT_REENTRY=16u,SP_LSESSION_FAULT_SHUTDOWN=32u };
/* These are externally established operating prerequisites, not measurements
 * or physical input facts produced by the module. Default config is NULL. */
enum { SP_LSESSION_COUNTER=1u,SP_LSESSION_TASK=2u,SP_LSESSION_ROUTE=4u,
    SP_LSESSION_BUDGET=8u,SP_LSESSION_QUALIFIED=15u };
typedef struct {
    SpSynthDeferredStartupConfig startup;
    SpLiveConfig live;
    uint32_t pair_index,backend_task,qualified;
    /* Optional nonblocking schedule-only hook on the selected control task.
     * SMPL remains the sole inner backend take/finish owner. */
    void (*backend_kick)(void *);
    void *backend_context;
    uint32_t audio_task; /* Exact qualified serialized native TX owner. */
} SpSynthLiveSessionConfigV552;
typedef struct {
    _Alignas(8) SpSynthSessionV552 session;
    SpSynthLiveAdmission live;
    SpSynthEntryOwnerV552 entry;
    SpSynthGeneratorRouteV552 generator;
    SpLiveInput input_copy[SP_SYNTH_INPUT_BATCH_CAPACITY];
    SpSynthLiveSessionConfigV552 config;
    atomic_uint ready,terminal,phase,exit_phase;
    uint32_t initialized,attempted,task_id,route_ticket,entry_epoch;
    uint32_t input_disabled,exit_ticket,exit_generation,exit_token;
    void *exit_page;
    int32_t preparation_result;
    /* RELEASED is published only by the configured backend owner after actual
     * native retirement and inner LEAVE finish. It is consumed once on reentry. */
    atomic_uint released;
    uint32_t released_ticket,released_lifetime;
    /* Park publication is control->audio; acknowledgment follows the preceding
     * audio invocation. While parked the callback touches no live/app/mailbox.
     * Resume is published only after the selected owner finishes app_reenter. */
    atomic_uint park_request,park_ack,resume_request,resume_ack;
    _Atomic(void *) active_page,retired_page;
    uint32_t fresh_ticket,choice,command,return_action,visit,exit_requested;
} SpSynthLiveSessionV552;
/* This separate provider is the sole publisher of the prepared session's
 * ready/control_ready fields. It initializes aggregate owners before its
 * release-ready store and rechecks terminal cancellation afterward. Legacy
 * clock/timed session enable/control/mix owners are absent from this link. */
extern SpSynthLiveSessionV552 sp_synth_live_session_v552;
extern const SpSynthLiveSessionConfigV552 *const sp_synth_live_session_v552_config;

/* Cold once, before tasks. Native pool constructor runs once; raw R0/R1 remain
 * intact. Clear only linker BSS after matching32K patch before and after call. */
uint64_t sp_synth_live_session_v552_pool(uint32_t,uint32_t,uint32_t,uint32_t);
/* Exact selected-panel initializer boundary; original resolved R1 runs first.
 * Default NULL configuration never prepares or grants Synth entry. */
uint32_t sp_synth_live_session_v552_panel_init(uint32_t,uint32_t,uint32_t,uint32_t);
/* Selected task outside native dispatch frames. Native chooser confirmation
 * requests this transition. First entry and reentry both require a completed
 * fresh all-pad scan; repeated entry additionally waits exact RELEASED/page
 * deletion, local work retirement and a positively acknowledged audio park.
 * Edited app state and every audio/input/lifetime sequence remain monotonic. */
int sp_synth_live_session_v552_request_synth(void *selected_panel);
/* Visible chooser only. Restore Original Generator tables after its exact
 * NATIVE audio ticket. Ordinary Synth EXIT also restores NATIVE before leave. */
int sp_synth_live_session_v552_request_generator(void *selected_panel);
/* Fresh native chooser controls only. Value chooses; press confirms. Invalid
 * transitions retain state. Play and wait screens consume their own controls. */
int sp_synth_live_session_v552_select(void *selected_panel,uint32_t command);
uint32_t sp_synth_live_session_v552_factory(const uint16_t *event);
/* One bounded control pass and one completed-service progress acknowledgment.
 * Called by the actual wait shim; no waiting or backend I/O inside this call. */
void sp_synth_live_session_v552_service(void *selected_panel);
void sp_synth_live_session_v552_before_control(void *,uint32_t control);
void sp_synth_live_session_v552_wait(void);
void sp_synth_live_session_v552_control(void);
uint32_t sp_synth_live_session_v552_audio(void *,int32_t *,int32_t,int32_t);
void sp_synth_live_session_v552_audio_thunk(void);
/* Any task: terminal atomics and existing stop latches only. Storage stays
 * pinned; retained releases still belong to the selected control task. */
void sp_synth_live_session_v552_cancel(void);

/* Separate SMPL worker attachment, after exact-ticket recorder EXIT_READY:
 * no owned file/token, prior recorder/writer leases retired, and protected
 * native mutation admission still closed. This exit-safe state is a caller
 * prerequisite, never inferred from token0, discard or EXCLUSIVE_IDLE.
 * Worker must already own an audio-ack-gated backend LEAVE (phase2). Nonzero
 * ticket is one-shot. Control requests native exit once; ACK requires actual
 * factory deletion of the associated page. SMPL must then complete its native
 * queue/record-task cutoff and publish RELEASED(ticket) before it alone finishes
 * the inner backend link. Page/ticket evidence is retained for this lifetime.
 * Capture lifecycle and backend consumer remain separate composition owners. */
int sp_synth_live_session_v552_exit_request(uint32_t ticket,uint32_t generation,uint32_t token);
int sp_synth_live_session_v552_exit_ack(uint32_t ticket);
/* Configured backend owner only, after actual recorder RELEASED(ticket) and
 * successful inner LEAVE finish. Exact prior lifetime, ticket, generation and
 * token must match retained deletion evidence. Returns1 once; a stale/duplicate
 * call does not overwrite the receipt. This is an explicit trusted attestation
 * from the real worker, never proof inferred from an empty link or token0. */
int sp_synth_live_session_v552_backend_released(uint32_t ticket,uint32_t lifetime,
    uint32_t generation,uint32_t token);
/* Native shutdown slots802204E0/80220528. The callback retains its indicator
 * but defers native power counter/reply until audio has observed stop and the
 * platform has positively retired every native/backend/file/token lease. */
uint32_t sp_synth_live_session_v552_shutdown_initialize(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_live_session_v552_shutdown_callback(uint32_t,uint32_t,uint32_t,uint32_t);
/* Strong full-runtime implementation required; weak enabled default returns0. */
int sp_synth_live_session_v552_shutdown_backend_ready(void);
/* Stable published session for the separately qualified worker attachment. */
SpSynthSessionV552 *sp_synth_live_session_v552_session(void);
#endif
