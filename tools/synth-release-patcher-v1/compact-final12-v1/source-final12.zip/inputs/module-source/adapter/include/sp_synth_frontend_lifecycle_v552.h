#ifndef SP_SYNTH_FRONTEND_LIFECYCLE_V552_H
#define SP_SYNTH_FRONTEND_LIFECYCLE_V552_H
#include "sp_synth_frontend_v552.h"
#include <stdint.h>

/* Explicit-owner lifecycle bodies for pinned stock v5.52. The caller supplies
 * a valid live synth page and a stable, serialized UI owner. These functions
 * install no hooks. A binding must cover EVERY rebuild/destruction, including
 * nested calls, and route after-entry before using periodic publication.
 * All preserve the original native R0, not the frontend's update status.
 * Null frontend/exchange disables added presentation, never native behavior. */
uint32_t sp_synth_frontend_lifecycle_v552_rebuild(SpSynthFrontendV552 *frontend,
    void *page);
uint32_t sp_synth_frontend_lifecycle_v552_after_entry(SpSynthFrontendV552 *frontend,
    SpSynthViewExchange *exchange,void *page);
uint32_t sp_synth_frontend_lifecycle_v552_tick(SpSynthFrontendV552 *frontend,
    SpSynthViewExchange *exchange,void *page);
/* Preserve opaque original R1/R2/R3: native destruction can forward them to
 * listener cleanup. Page is invalid after the native call and is not inspected.
 * Owner/exchange storage survives deletion; no control/audio stop is implied. */
uint32_t sp_synth_frontend_lifecycle_v552_delete(SpSynthFrontendV552 *frontend,
    void *page,uint32_t original_r1,uint32_t original_r2,uint32_t original_r3);
#endif
