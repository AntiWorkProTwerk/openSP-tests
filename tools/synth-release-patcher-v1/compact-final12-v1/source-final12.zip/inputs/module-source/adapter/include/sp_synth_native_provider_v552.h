#ifndef SP_SYNTH_NATIVE_PROVIDER_V552_H
#define SP_SYNTH_NATIVE_PROVIDER_V552_H
#include "sp_synth_native_lease.h"
#include "sp_synth_filesystem_lease_v552.h"
#include "sp_synth_full_backend_v552.h"

/* This concrete lifecycle owner is separate from the native hook binding.
 * The binding must be linked from the audited recipe and actual observers.
 * No profile supplies an arbitrary coverage/barrier bitmask. */
typedef struct SpSynthNativeBindingV552 SpSynthNativeBindingV552;
enum { SP_NATIVE_UNAVAILABLE=-1,SP_NATIVE_FAULT=-2,SP_NATIVE_WAIT_DRAIN=0,
    SP_NATIVE_READY=1,SP_NATIVE_STOP_PLAYBACK=2,SP_NATIVE_CANCELING=3 };
typedef struct {
    SpSynthNativeLease shared;
    SpSynthFilesystemLeaseV552 filesystem;
    SpSynthLeaseGrant grant;
    SpSynthTakeSaveLeaseV552 take;
    SpSynthFullBackendConfigV552 full;
    SpSynthCaptureTimedV552 *capture;
    SpSynthNativeBindingV552 *binding;
    uint32_t magic,request,operation;
    atomic_uint ready,armed_request,pending_take,scope_role,scope_operation,cancel_requested,entry_lifetime;
    atomic_int status;
    uint32_t control_task,worker_task,record_task,acquired_lifetime,acquired_visit,prior_release,attached_visit;
} SpSynthNativeProviderV552;

/* Source-owned binding imports. They must inspect installed native pointer/
 * instruction words and actual observer state. A positive check returns the
 * exact implemented coverage mask; a receipt is for this request/project only.
 * There is intentionally no weak success/default coverage implementation. */
uint32_t sp_synth_native_binding_v552_check(SpSynthNativeBindingV552 *);
int sp_synth_native_binding_v552_arm(SpSynthNativeBindingV552 *,uint32_t request,
    uint32_t next_generation,uint32_t project);
uint32_t sp_synth_native_binding_v552_retired(SpSynthNativeBindingV552 *,
    uint32_t request,uint32_t project);
void sp_synth_native_binding_v552_released(SpSynthNativeBindingV552 *,uint32_t request);

/* Cold before8018CD48 activates managed tasks. Reads existing object+4 IDs
 * PANEL8300A3E8, SMPL202ACD04, RECORD202ACFA4; never forges a control context.
 * Preparation opens no file. Limits are bounded software policies. */
int sp_synth_native_provider_v552_init(SpSynthNativeProviderV552 *,
    SpSynthNativeBindingV552 *,SpSynthCaptureTimedV552 *,uint32_t directory_limit,
    uint32_t max_barrier_polls,uint32_t allow_create);
const SpSynthFullBackendConfigV552 *sp_synth_native_provider_v552_config(SpSynthNativeProviderV552 *);
/* Control requests once, then polls ready. Worker runs service before taking
 * backend requests or starting catalog work.0 means pending, -1 unavailable. */
uint32_t sp_synth_native_provider_v552_request(SpSynthNativeProviderV552 *);
int sp_synth_native_provider_v552_service(SpSynthNativeProviderV552 *);
int sp_synth_native_provider_v552_ready(SpSynthNativeProviderV552 *);
/* Existing exact-token cleanup remains available during orderly revocation.
 * This does not admit START, a new catalog scan or a new patch operation.
 * token0 is lifetime cleanup only when no take remains retained. */
int sp_synth_native_provider_v552_cleanup_ready(SpSynthNativeProviderV552 *,uint32_t token);
/* Admit the entire selected local preparation before fresh scan/park/reentry.
 * An orderly revoke may finish this already-admitted preparation and attach
 * solely to perform real LEAVE cleanup. No app/catalog/capture work is admitted.
 * Terminal ownership refuses continuation. The sentinel is private state. */
int sp_synth_native_provider_v552_prepare_begin(SpSynthNativeProviderV552 *);
int sp_synth_native_provider_v552_prepare_permit(SpSynthNativeProviderV552 *);
/* Control task immediately after actual selected entry reaches PLAYING, before
 * accepting app work. Matches that native visit and live lifetime once. */
int sp_synth_native_provider_v552_entered(SpSynthNativeProviderV552 *,uint32_t lifetime);
/* Worker after an accepted pre-entry cancel and actual return to CHOOSER with
 * unchanged visit/lifetime, native route acknowledged, no backend/file work.
 * This cannot substitute for a visited Synth page's real LEAVE receipt. */
int sp_synth_native_provider_v552_abort_before_entry(SpSynthNativeProviderV552 *);
int sp_synth_native_provider_v552_status(const SpSynthNativeProviderV552 *);
int sp_synth_native_provider_v552_cancel(SpSynthNativeProviderV552 *);

/* SMPL calls admitted immediately after capture publishes its token and
 * restores its dispatch gate, before feedback/setup/open. Record callbacks
 * require RECORD scopes and their actual capture fd/FILE identities. */
int sp_synth_native_provider_v552_take_admitted(SpSynthNativeProviderV552 *,uint32_t token);
int sp_synth_native_provider_v552_scope_begin(SpSynthNativeProviderV552 *,uint32_t role,uint32_t operation);
int sp_synth_native_provider_v552_scope_permit(SpSynthNativeProviderV552 *,uint32_t role,uint32_t operation);
int sp_synth_native_provider_v552_scope_end(SpSynthNativeProviderV552 *,uint32_t role,uint32_t operation);
int sp_synth_native_provider_v552_partial(SpSynthNativeProviderV552 *,uint32_t token);
/* Requires the real capture cleanup_token and retired native token/file state.
 * Partial takes additionally need the caller's checked successful repair or
 * discard result. It never infers completion from an app response alone. */
int sp_synth_native_provider_v552_take_retired(SpSynthNativeProviderV552 *,uint32_t token,uint32_t repaired);
void sp_synth_native_provider_v552_revoke(SpSynthNativeProviderV552 *,uint32_t fault);
/* SMPL after native recorder RELEASED(ticket), quiesced/gated backend,
 * and exact page deletion/LEAVE handoff. The binding reopens pending stock. */
int sp_synth_native_provider_v552_release(SpSynthNativeProviderV552 *,uint32_t exit_ticket);
#endif
