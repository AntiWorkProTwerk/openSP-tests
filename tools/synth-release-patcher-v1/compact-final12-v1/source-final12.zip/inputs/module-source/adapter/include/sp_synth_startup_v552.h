#ifndef SP_SYNTH_STARTUP_V552_H
#define SP_SYNTH_STARTUP_V552_H
#include "sp_synth_storage_v552.h"

typedef struct {
    uint32_t preset, voices, seed;
    uint32_t tick, sample, tick_hz, latency;
    uint32_t held_pads, shift;
} SpSynthStartupConfig;
/* Separate software-origin configuration. No hardware tick or held-input
 * snapshot is implied; the deferred lifetime binds those after preparation. */
typedef struct {
    uint32_t preset, voices, seed, sample, tick_hz, latency;
} SpSynthDeferredStartupConfig;
typedef struct {
    SpSynthStorageV552 memory;
    uint32_t ready;
} SpSynthStartupV552;

/* Serialized qualified startup task; zero-initialize owner once. Config and
 * owner must be disjoint valid objects. Supplies a VERIFIED simultaneous
 * tick/sample anchor, tick rate, voice budget and held-control snapshot.
 * None is probed here. Sample rate is48k and sample must be64-aligned.
 * No callbacks may run during preparation. Input remains disabled initially.
 * 0=ready; native/storage errors propagate; -1004=invalid config/owner;
 * -1005=component initialization failed (unattached allocation abandoned).
 * Readiness does not admit physical audio routing or prove a render deadline. */
int sp_synth_startup_v552_prepare(SpSynthStartupV552 *owner,const SpSynthStartupConfig *config);
/* Same qualified allocation/task contract. Leaves runtime.clock all-zero and
 * input disabled with no captured/physical controls. Private startup.ready=1
 * means DSP storage prepared; it does not publish public session readiness. */
int sp_synth_startup_v552_prepare_deferred(SpSynthStartupV552 *owner,
    const SpSynthDeferredStartupConfig *config);
/* Marks prepared storage pinned BEFORE any pointer is published. No hooks are
 * installed. Once pinned, prepare/cancel cannot reset or free this lifetime. */
int sp_synth_startup_v552_pin(SpSynthStartupV552 *owner);
/* Before pin/publication only. Uses the storage adapter's qualified-task release
 * precondition. Empty owner is harmless; attached owner remains unchanged. */
int sp_synth_startup_v552_cancel(SpSynthStartupV552 *owner);
#endif
