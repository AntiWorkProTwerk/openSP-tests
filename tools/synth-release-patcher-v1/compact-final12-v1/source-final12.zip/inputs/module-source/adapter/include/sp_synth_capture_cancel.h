#ifndef SP_SYNTH_CAPTURE_CANCEL_H
#define SP_SYNTH_CAPTURE_CANCEL_H
#include <stdint.h>

/* Acknowledged synth-audio sequence, not DAC drain or a captured tail fence.
 * The control owner must gate fresh notes, send cancellation's note release,
 * and observe that exact successful audio acknowledgment before publication.
 * token0 allows binding by the original START generation during preparation. */
typedef struct {
    uint32_t start_generation,take_token,audio_sequence;
} SpSynthCaptureCancelRequest;
typedef struct {
    uint32_t start_generation,take_token,audio_sequence;
    int32_t result; /* 1 exact take HELD; -1 refused/failed, possibly still owned */
} SpSynthCaptureCancelResult;
enum { SP_CAPTURE_CANCEL_EMPTY,SP_CAPTURE_CANCEL_REQUEST,
       SP_CAPTURE_CANCEL_STOPPING,SP_CAPTURE_CANCEL_RESULT };
#endif
