#ifndef SP_SYNTH_PAGE_V552_H
#define SP_SYNTH_PAGE_V552_H
#include "sp_synth_widget_v552.h"

/* Zero-initialize once. Storage must remain stable until detach returns or
 * stock has destroyed the widget. All calls belong to the serialized UI owner.
 * Supply a copied semantic view from sp_ui_make_view; never share live app state
 * concurrently with its audio owner. Scratch and input view/plot must be disjoint. */
typedef struct {
    sp_synth_widget_v552 *widget;
    void *page;
    sp_oled_frame scratch;
} sp_synth_page_v552;

/* Call only after stock has finished creating this synth page's children.
 * Repeated calls reuse the widget. A live binding to another page is rejected.
 * Returns 0 on failure, 1 unchanged, 2 changed. No controls/audio are hooked. */
int sp_synth_page_v552_after_entry(sp_synth_page_v552 *owner,void *page,
                                  const sp_ui_view *view,const uint8_t plot[120]);
/* Publish only to an existing binding on this page. Does not allocate or attach;
 * returns 0 if destroyed, displaced by a later child or mismatched. */
int sp_synth_page_v552_publish(sp_synth_page_v552 *owner,void *page,
                              const sp_ui_view *view,const uint8_t plot[120]);
/* Clears registered handle and page identity before deferred stock reclamation.
 * Safe to call repeatedly; owner storage may be released after return. */
void sp_synth_page_v552_detach(sp_synth_page_v552 *owner);
#endif
