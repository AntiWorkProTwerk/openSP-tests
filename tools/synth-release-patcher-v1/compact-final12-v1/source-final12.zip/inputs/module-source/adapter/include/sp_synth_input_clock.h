#ifndef SP_SYNTH_INPUT_CLOCK_H
#define SP_SYNTH_INPUT_CLOCK_H
#include "sp_synth_midi_queue.h"
typedef enum {SP_INPUT_CLOCK_OK,SP_INPUT_CLOCK_ARGUMENT,SP_INPUT_CLOCK_ORDER,SP_INPUT_CLOCK_SPAN} SpInputClockFault;
typedef struct {
    uint32_t tick,sample,remainder,tick_hz,sample_hz,latency;
    SpInputClockFault fault;
} SpSynthInputClock;
/* One serialized producer, paired with one stopped/reinitialized audio lifetime.
 * Caller supplies a verified simultaneous tick/sample anchor and rates. No
 * stock timer, clock calibration, task transport or DAC anchor is inferred.
 * Latency is128..4096 samples, in multiples of64. Invalid init changes nothing. */
int sp_synth_input_clock_init(SpSynthInputClock *clock,uint32_t tick,uint32_t sample,
    uint32_t tick_hz,uint32_t sample_hz,uint32_t latency);
/* Ordered observations, less than half a tick wrap apart. Fractional samples
 * carry across calls. Output includes fixed latency and wraps unsigned32.
 * A >=half-sample-range advance rejects. Failure latches, leaves output and
 * position unchanged. Clock/output must be disjoint. No automatic reanchor. */
int sp_synth_input_clock_map(SpSynthInputClock *clock,uint32_t tick,uint32_t *sample);
/* Map and forward to the timestamped queue. Mapping failure requests audio
 * stop. Input must already be merged in tick order. The cutoff wrapper may
 * run only after all sources before that exclusive tick have been drained. */
int sp_synth_input_clock_midi(SpSynthInputClock *clock,SpSynthMidiQueue *queue,
    SpSynthAudioMailbox *mailbox,uint32_t tick,const SpSynthEvent *event);
int sp_synth_input_clock_watermark(SpSynthInputClock *clock,SpSynthMidiQueue *queue,
    SpSynthAudioMailbox *mailbox,uint32_t tick);
#endif
