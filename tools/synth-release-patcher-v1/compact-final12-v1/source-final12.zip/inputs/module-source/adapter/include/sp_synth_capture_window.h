#ifndef SP_SYNTH_CAPTURE_WINDOW_H
#define SP_SYNTH_CAPTURE_WINDOW_H
#include "sp_synth_capture_plan.h"

/* One serialized RX-side owner. Arm only after native file preparation, from a
 * successfully validated/published immutable START plan. No control/SMPL task
 * may read or mutate this object concurrently; publish snapshots elsewhere.
 * These helpers perform no I/O, allocation, floating-point math or locking.
 * They do not authorize recording or qualify a physical route/sample clock. */
typedef enum {
    SP_CAPTURE_WINDOW_EMPTY=0,
    SP_CAPTURE_WINDOW_COUNT_IN,
    SP_CAPTURE_WINDOW_RECORD,
    SP_CAPTURE_WINDOW_TAIL,
    SP_CAPTURE_WINDOW_SEALED,
    SP_CAPTURE_WINDOW_CANCELED,
    SP_CAPTURE_WINDOW_ERROR,
    SP_CAPTURE_WINDOW_RETIRED
} SpCaptureWindowPhase;

typedef struct {
    uint64_t sequence;
    uint32_t token,block_frames,skip_frames,take_frames;
} SpCaptureWindowSlice;

typedef struct {
    SpSynthCaptureStartPlan start;
    uint64_t observed_frames,accepted_frames,nominal_end,stop_frame;
    SpCaptureWindowSlice pending;
    uint64_t sequence;
    uint32_t phase,last_token,inflight,stop_set,failed_accepted,native_failed;
} SpSynthCaptureWindow;

/* Zero-initialized permanent object, or an explicitly RETIRED object.
 * A new positive token must exceed this object's retained last_token.
 * A structurally invalid plan is refused without changing the object. The
 * exact arithmetic relation between capture fields and frame counts must
 * already have been established by sp_synth_capture_plan_start. */
int sp_synth_capture_window_arm(SpSynthCaptureWindow *,const SpSynthCaptureStartPlan *);

/* Offer a slice of one qualified RX block (1..64 stereo frames). No second
 * offer, control change or reuse while inflight. skip_frames is a source
 * offset; take_frames is the exact maximum forwarded to the native consumer.
 * Zero-length slices must not call that consumer. Every accepted offer,
 * including a zero-length one, requires exactly one commit. The complete
 * ticket must be returned unchanged. The input block stays valid until then.
 * SEALED/CANCELED windows continue to offer zero PCM; ERROR refuses offers. */
int sp_synth_capture_window_offer(SpSynthCaptureWindow *,uint32_t,SpCaptureWindowSlice *);

/* Called after the native consumer has returned. The containing adapter must
 * measure actual accepted frames from the owned native counter and check
 * its error state; raw function return is not a frame count. Exact acceptance
 * and native_ok are required. Failure enters ERROR, retaining the
 * outstanding ticket, reported partial count and prior committed counters;
 * no retry/replay allowed.
 * Ticket mismatch/busy/null refusal leaves the window unchanged. */
int sp_synth_capture_window_commit(SpSynthCaptureWindow *,const SpCaptureWindowSlice *,
    uint32_t accepted_frames,int native_ok);

/* Install an absolute RX-stream stop frame, measured from arm's first block.
 * It may be the current observed boundary or a future boundary. Never accept
 * a fence in the past or extend an existing earlier stop. For a release tail,
 * the caller must first qualify its route/buffering and release acknowledgment;
 * voice quiescence alone is not such a fence. An early stop before any recorded
 * frame produces CANCELED, not a successful empty take. No native STOP/HELD,
 * backend completion, note gate or tail-timeout policy is supplied here. */
int sp_synth_capture_window_stop_at(SpSynthCaptureWindow *,uint32_t token,uint64_t frame);

/* The RX owner consumes an exact-token cleanup acknowledgment only AFTER the
 * containing recorder has proved that native operations/storage are retired.
 * SEALED, CANCELED or ERROR may then become RETIRED; active work cannot retire.
 * ERROR is possible only after the entered native call has returned to commit.
 * Keep counters, failure details and last_token until a later arm. This API
 * does not itself supply that native proof, close a file or publish FREE. */
int sp_synth_capture_window_retire(SpSynthCaptureWindow *,uint32_t token);
#endif
