#ifndef SP_SYNTH_ENTRY_OWNER_V552_H
#define SP_SYNTH_ENTRY_OWNER_V552_H
#include "sp_synth_input_owner.h"
#include <stdatomic.h>

/* Separate live-mode candidate. Zeroed, writable, disjoint permanent storage
 * and callbacks, installed
 * once on the selected panel task before the entry gesture. No clock claim.
 * publish copies the complete ordered batch before returning; failure is
 * terminal. stop may run on any task: it may only latch a thread-safe terminal
 * stop/panic while retaining permanent storage. It must be idempotent, with no
 * mutable UI/control dispatch, synchronous backend work or recursive cancel.
 * Neither callback may reenter this component. */
typedef int (*SpSynthEntryPublishV552)(void *,const sp_synth_input_batch *);
typedef void (*SpSynthEntryStopV552)(void *);
typedef struct {
    sp_synth_input_owner input;
    uint32_t task_id,seen,active,sample_depth,dispatch_depth;
    uint32_t shift_seen,shift,old_remaining,expected_read,epoch,quarantine;
    _Atomic uint32_t fault;
    SpSynthEntryPublishV552 publish;
    SpSynthEntryStopV552 stop;
    void *context;
    void *dispatch;
} SpSynthEntryOwnerV552;
enum { SP_ENTRY_LOSS=1u,SP_ENTRY_FOREIGN=2u,SP_ENTRY_SEQUENCE=4u,
       SP_ENTRY_PUBLISH=8u,SP_ENTRY_EXHAUSTED=16u,SP_ENTRY_EXTERNAL=32u };
typedef struct { uint32_t blocked_pads,shift,epoch,old_records; } SpSynthEntryBoundaryV552;

int sp_synth_entry_owner_v552_install(SpSynthEntryOwnerV552 *,void *panel,
    SpSynthEntryPublishV552,SpSynthEntryStopV552,void *context);
/* Selected task, outside sample/drain frames. Requires an observed SHIFT edge;
 * unknown pads remain blocked until an actual completed released sample.
 * Output describes admission suppression, never physical qualification. Caller
 * has completed chooser/modal/backend transfer before requesting entry. */
int sp_synth_entry_owner_v552_enter(SpSynthEntryBoundaryV552 *);
/* Emits delivered releases and SHIFT-up; retains captured release ownership.
 * May run from the selected callback (e.g. explicit approved EXIT action). */
int sp_synth_entry_owner_v552_exit(void);
/* Any task may revoke this lifetime. No reset; captured ups remain owned. */
void sp_synth_entry_owner_v552_cancel(void);

/* Replace only the 13 inspected scanner BL sites to 8008E680. Original runs
 * once, R0-R3 forwarded, raw R0 returned. Completion reads native state, not
 * caller-supplied held flags. ID19 remains native and is not a Synth pad. */
uint32_t sp_synth_entry_owner_v552_sample(uint32_t,uint32_t,uint32_t,uint32_t);
/* Alternative common drain, composed with the existing 14 guarded producers
 * and their source-initialized observer loss field. Do not bind the previous
 * observer session or install both drain replacements. Copy/cursor/observation
 * exclusion is short; native routing and publication occur outside it. */
uint64_t sp_synth_entry_owner_v552_drain(void);
/* Call only from the real selected page callback after native gate/modal/global
 * routing. It admits a current copied type16 main-pad down, not other controls.
 * The active dispatch context rejects stale/mismatched records and duplicate
 * calls. This is a trusted native boundary, not an untrusted-call authenticator.
 * Return1 suppresses that page's stock pad action. */
int sp_synth_entry_owner_v552_page(void *panel,const void *record);
#endif
