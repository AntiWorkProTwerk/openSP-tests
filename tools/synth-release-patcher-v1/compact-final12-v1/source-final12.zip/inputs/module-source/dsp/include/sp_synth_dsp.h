#ifndef SP_SYNTH_DSP_H
#define SP_SYNTH_DSP_H

#include <stdint.h>

/* Original DSP building blocks for a Roland-hosted synth. No hardware I/O,
 * allocation or global mutable state. Callers own state and serialize access.
 * This is a component API, not an established stock firmware ABI.
 * Initialize SpOsc/SpNoise/SpDrive with {0}; use env_init/filter_init before
 * processing their states. Reinitialization resets history. Null state pointers
 * return silence or do nothing. State memory must stay valid and serialized;
 * arbitrary byte-corrupted state is outside the contract. Config changes made
 * directly by callers must retain the sanitized bounds documented below.
 * Compile without fast-math and with FP contraction off for tested semantics. */
typedef enum { SP_WAVE_SINE, SP_WAVE_TRIANGLE, SP_WAVE_SAW, SP_WAVE_PULSE } SpWave;
typedef enum { SP_FILTER_LP12, SP_FILTER_LP24, SP_FILTER_HP12,
               SP_FILTER_BP12, SP_FILTER_NOTCH } SpFilterMode;
typedef enum { SP_ENV_IDLE, SP_ENV_ATTACK, SP_ENV_DECAY,
               SP_ENV_SUSTAIN, SP_ENV_RELEASE } SpEnvStage;

typedef struct { float phase; } SpOsc;
typedef struct { uint32_t state; } SpNoise;
/* Seconds: [0,60], sustain [0,1], curve [-.95,.95]. Curve shapes progress
 * within each stage while preserving endpoints. Zero seconds takes one sample.
 * sample_rate is constrained to [8000,192000]. Initialized stages capture
 * their duration; edit config before retrigger to apply a new duration. */
typedef struct { float attack, decay, sustain, release, curve; } SpEnvConfig;
typedef struct {
    SpEnvConfig config;
    float sample_rate, value, step, start;
    uint32_t stage, loop, gate, remaining;
} SpEnvelope;
typedef struct { float ic1, ic2; } SpSvf;
typedef struct {
    SpSvf stage[2];
    float g, k, target_g, target_k;
    uint32_t mode, faults;
} SpFilter;
typedef struct { float previous; uint32_t primed; } SpDrive;

/* Octaves clamp to [-24,24]; nonfinite octaves return 1. Nonfinite sine
 * phases return 0. Phases use cycles and finite inputs wrap into [0,1). */
float sp_synth_exp2(float octaves);
float sp_synth_sine(float phase);
/* increment is cycles/sample, constrained to [0, 0.45]. Zero is silent.
 * Pulse width is constrained to [0.01, 0.99]. Audio-rate PWM and hard sync
 * require further antialiasing work and are not certified by this component. */
float sp_synth_osc(SpOsc *osc, SpWave wave, float increment, float pulse_width);
void sp_synth_noise_seed(SpNoise *noise, uint32_t seed);
float sp_synth_noise(SpNoise *noise);

void sp_synth_env_init(SpEnvelope *env, float sample_rate, const SpEnvConfig *config);
void sp_synth_env_on(SpEnvelope *env, int reset_phase);
void sp_synth_env_off(SpEnvelope *env);
float sp_synth_env_tick(SpEnvelope *env);

void sp_synth_filter_init(SpFilter *filter, SpFilterMode mode,
                          float sample_rate, float cutoff, float resonance);
void sp_synth_filter_set(SpFilter *filter, float sample_rate,
                         float cutoff, float resonance);
/* Input clamps to +/-16. Resonance clamps to [0,1], cutoff to
 * [5, .45*sample_rate]. Targets smooth by .005 per sample (rate-dependent).
 * LP24 cascades the selected resonance stage with a fixed sqrt(2) stage.
 * Mode stays fixed after init. A nonfinite state resets both integrators and
 * increments faults. The output is resonant and is not amplitude-limited. */
float sp_synth_filter_tick(SpFilter *filter, float input);
/* First-order ADAA of an original clipped cubic, crossfaded with dry input.
 * amount=0 is exact bypass for finite bounded input. The wet path has the
 * expected half-sample averaging delay; this does not belong inside feedback. */
float sp_synth_drive_tick(SpDrive *drive, float input, float amount);

#endif
