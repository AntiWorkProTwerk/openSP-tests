#ifndef SP_SYNTH_ENGINE_H
#define SP_SYNTH_ENGINE_H

#include "sp_synth_dsp.h"
#include <stddef.h>
#include <stdint.h>

/* Original, caller-owned component. This is not a Roland firmware ABI.
 * Serialize all calls on one audio owner; prepare/copy patches before callback.
 * No heap, locks, file I/O, hardware access or mutable global state. */
#define SP_SYNTH_MAX_VOICES 16u
#define SP_SYNTH_MAX_NOTES 64u
#define SP_SYNTH_MAX_EVENTS 128u
#define SP_SYNTH_MAX_FRAMES 1024u
#define SP_SYNTH_MOD_SLOTS 8u
#define SP_SYNTH_ENGINE_BYTES 32768u
#define SP_SYNTH_PATCH_VERSION 1u

typedef enum { SP_SYNTH_POLY, SP_SYNTH_MONO } SpSynthMode;
typedef enum { SP_LFO_SINE, SP_LFO_TRIANGLE, SP_LFO_SAW,
               SP_LFO_SQUARE, SP_LFO_SAMPLE_HOLD } SpSynthLfoWave;
typedef enum {
    SP_MOD_NONE, SP_MOD_LFO1, SP_MOD_LFO2, SP_MOD_ENV2, SP_MOD_AMP_ENV,
    SP_MOD_VELOCITY, SP_MOD_KEY, SP_MOD_PRESSURE, SP_MOD_WHEEL, SP_MOD_RANDOM,
    SP_MOD_MACRO1, SP_MOD_MACRO2, SP_MOD_MACRO3, SP_MOD_SOURCE_COUNT
} SpSynthModSource;
typedef enum {
    SP_DEST_NONE, SP_DEST_PITCH, SP_DEST_OSC1_PITCH, SP_DEST_OSC2_PITCH,
    SP_DEST_CUTOFF, SP_DEST_PW1, SP_DEST_PW2, SP_DEST_AMP, SP_DEST_PAN,
    SP_DEST_OSC1_LEVEL, SP_DEST_OSC2_LEVEL, SP_DEST_SUB_LEVEL,
    SP_DEST_NOISE_LEVEL, SP_DEST_RESONANCE, SP_DEST_DRIVE, SP_DEST_COUNT
} SpSynthModDestination;

typedef struct {
    uint32_t wave;                /* SpWave */
    float semitones, cents;       /* -48..48, -100..100 */
    float level, pulse_width;     /* 0..1, .01...99 */
} SpSynthOscConfig;
typedef struct {
    uint32_t wave, tempo_sync, retrigger; /* SpSynthLfoWave, bool, bool */
    float rate_hz, beats, phase;  /* .01..40 Hz; 1/16..64 beats/cycle; 0..1 */
} SpSynthLfoConfig;
typedef struct {
    uint32_t source, destination;
    float amount;                /* -1..1; full scales documented below */
} SpSynthModSlot;
typedef struct {
    uint32_t version, mode, unison, legato; /* unison=1,2,4; legato bool */
    SpSynthOscConfig osc[2];
    uint32_t sub_wave, filter_mode; /* sub=sine/triangle/saw/pulse; SpFilterMode */
    float sub_level, noise_level, noise_color; /* 0..1; color blends white to lowpass */
    float cutoff_hz, resonance, filter_env, key_track, drive;
    /* cutoff=5..21600 Hz (further limited by sample rate); resonance/drive=0..1;
     * filter_env=-8..8 octaves; key_track=0..2 octaves/octave about MIDI60. */
    SpEnvConfig amp, mod;         /* seconds0..60; sustain0..1; curve -.95...95 */
    uint32_t amp_cycle, mod_cycle;
    SpSynthLfoConfig lfo[2];
    SpSynthModSlot route[SP_SYNTH_MOD_SLOTS];
    float glide, unison_detune, unison_spread, variation;
    /* glide0..10 seconds/octave; detune0..100 cents; spread0..1;
     * variation0..20 cents static + bounded slow per-voice pitch drift. */
    float gain, pan, velocity_amount, bend_range;
    /* gain0..1, pan-1..1, velocity0..1, bend0..24 semitones. */
    float macro[3];               /* 0..1; routes explicitly assign destinations */
} SpSynthPatch;

/* Full amount destination scales: pitch=24 semitones, cutoff=6 octaves,
 * pulse width=.48, all level/gain/resonance/drive/pan destinations=1.
 * Sources: LFO/random/key bipolar, other sources unipolar. Key=(note-60)/60,
 * clamped -1..1. Macro default .5 is not an implicit volume control. */
typedef enum {
    SP_PARAM_OSC1_SEMITONES, SP_PARAM_OSC1_CENTS, SP_PARAM_OSC1_LEVEL, SP_PARAM_OSC1_PW,
    SP_PARAM_OSC2_SEMITONES, SP_PARAM_OSC2_CENTS, SP_PARAM_OSC2_LEVEL, SP_PARAM_OSC2_PW,
    SP_PARAM_SUB_LEVEL, SP_PARAM_NOISE_LEVEL, SP_PARAM_NOISE_COLOR,
    SP_PARAM_CUTOFF, SP_PARAM_RESONANCE, SP_PARAM_FILTER_ENV, SP_PARAM_KEY_TRACK,
    SP_PARAM_DRIVE, SP_PARAM_AMP_ATTACK, SP_PARAM_AMP_DECAY, SP_PARAM_AMP_SUSTAIN,
    SP_PARAM_AMP_RELEASE, SP_PARAM_AMP_CURVE, SP_PARAM_MOD_ATTACK, SP_PARAM_MOD_DECAY,
    SP_PARAM_MOD_SUSTAIN, SP_PARAM_MOD_RELEASE, SP_PARAM_MOD_CURVE,
    SP_PARAM_LFO1_RATE, SP_PARAM_LFO1_BEATS, SP_PARAM_LFO1_PHASE,
    SP_PARAM_LFO2_RATE, SP_PARAM_LFO2_BEATS, SP_PARAM_LFO2_PHASE,
    SP_PARAM_GLIDE, SP_PARAM_UNISON_DETUNE, SP_PARAM_UNISON_SPREAD, SP_PARAM_VARIATION,
    SP_PARAM_GAIN, SP_PARAM_PAN, SP_PARAM_VELOCITY, SP_PARAM_BEND_RANGE,
    SP_PARAM_MACRO1, SP_PARAM_MACRO2, SP_PARAM_MACRO3,
    SP_PARAM_ROUTE1_AMOUNT, SP_PARAM_ROUTE2_AMOUNT, SP_PARAM_ROUTE3_AMOUNT,
    SP_PARAM_ROUTE4_AMOUNT, SP_PARAM_ROUTE5_AMOUNT, SP_PARAM_ROUTE6_AMOUNT,
    SP_PARAM_ROUTE7_AMOUNT, SP_PARAM_ROUTE8_AMOUNT, SP_PARAM_COUNT
} SpSynthParam;
typedef struct { float minimum, maximum; const char *unit; } SpSynthParamRange;

typedef enum {
    SP_EVENT_NOTE_ON, SP_EVENT_NOTE_OFF, SP_EVENT_SUSTAIN, SP_EVENT_PITCH_BEND,
    SP_EVENT_PRESSURE, SP_EVENT_POLY_PRESSURE, SP_EVENT_MOD_WHEEL,
    SP_EVENT_ALL_NOTES_OFF, SP_EVENT_ALL_SOUND_OFF, SP_EVENT_TEMPO,
    SP_EVENT_PARAMETER, SP_EVENT_NOTE_CANCEL
} SpSynthEventType;
typedef struct {
    uint32_t offset, type, channel, note;
    float value;
    uint32_t parameter;
} SpSynthEvent;
/* NOTE_ON velocity0..1; zero is NOTE_OFF. OFF consumes oldest unmatched ON
 * for channel/note (FIFO), including stolen notes. For note events, nonzero
 * parameter is a caller identity tag: ON replaces the matching channel/tag;
 * OFF matches channel/note/tag. Zero uses ordinary FIFO matching.
 * SUSTAIN value>=.5; bend
 * -1..1; pressure/wheel0..1; tempo20..300 BPM. PARAMETER uses native units.
 * Pressure is channel-wide; POLY_PRESSURE targets matching current notes.
 * ALL_NOTES_OFF clears sustain/keys and releases channel (channel16=all).
 * ALL_SOUND_OFF fades channel voices over64 samples (16=all).
 * Invalid/unsorted/oversized batches are discarded and release ALL keys,
 * so an overflow cannot leave a stuck note. Events at offset0 affect sample0.
 * A caller that loses events before this API must call panic explicitly. */
/* NOTE_CANCEL consumes a matching active identity, even if already sustained,
 * and releases it regardless of pedal state. Reserved for owner actions such
 * as remapping pads; ordinary MIDI note-off uses NOTE_OFF. */

typedef union {
    uint64_t alignment;
    unsigned char opaque[SP_SYNTH_ENGINE_BYTES];
} SpSynthEngine;
typedef struct {
    uint32_t active_voices, gated_voices, held_notes, peak_voices;
    uint32_t steals, rejected_notes, event_overflows, invalid_batches;
    uint32_t invalid_patches, output_clips, nonfinite_faults;
    uint32_t voice_limit, patch_generation;
    uint64_t rendered_frames;
} SpSynthStats;

void sp_synth_patch_default(SpSynthPatch *patch);
int sp_synth_patch_valid(const SpSynthPatch *patch);
/* Structural comparison only; callers still validate each patch. */
int sp_synth_patch_same_structure(const SpSynthPatch *a, const SpSynthPatch *b);
int sp_synth_patch_set_param(SpSynthPatch *patch, SpSynthParam parameter, float value);
int sp_synth_patch_get_param(const SpSynthPatch *patch, SpSynthParam parameter, float *value);
int sp_synth_param_range(SpSynthParam parameter, SpSynthParamRange *range);
/* init rejects invalid arguments without touching storage. seed gives repeatable
 * oscillator phase, noise, sample-and-hold and drift. Voice limit1..16 is a
 * component limit, not measured SP polyphony. */
int sp_synth_engine_init(SpSynthEngine *engine, float sample_rate,
                         uint32_t voice_limit, uint32_t seed, const SpSynthPatch *patch);
/* load releases held notes/sustain; active release voices keep old patch data.
 * edit requires identical structural fields; all continuous values smooth over
 * about5 ms. Envelope segment time edits affect the next segment, not its clock.
 * LFO phase sets the next retrigger's start, matching the UI's START PHASE.
 * Editing it does not reposition a running LFO; free-running mode ignores it.
 * Call load/edit between renders on the same owner; neither is atomic IPC. */
int sp_synth_engine_load_patch(SpSynthEngine *engine, const SpSynthPatch *patch);
int sp_synth_engine_edit_patch(SpSynthEngine *engine, const SpSynthPatch *patch);
void sp_synth_engine_panic(SpSynthEngine *engine);
/* Apply an immediate control batch on the same owner, between audio blocks.
 * All offsets must be zero. No samples or clocks advance. Invalid batches
 * are discarded and panic; count is bounded by SP_SYNTH_MAX_EVENTS. */
int sp_synth_engine_control(SpSynthEngine *engine,const SpSynthEvent *events,uint32_t count);
int sp_synth_engine_render(SpSynthEngine *engine, float *interleaved_stereo,
                           uint32_t frames, const SpSynthEvent *events, uint32_t count);
int sp_synth_engine_render_s16(SpSynthEngine *engine, int16_t *interleaved_stereo,
                               uint32_t frames, const SpSynthEvent *events, uint32_t count);
void sp_synth_engine_stats(const SpSynthEngine *engine, SpSynthStats *stats);
/* Audio owner only, between renders. True only for a valid engine with no
 * active notes, voices or remaining voice-steal/panic fades. Describes the end
 * of the preceding render, not delivery through a hardware audio route. */
int sp_synth_engine_quiescent(const SpSynthEngine *engine);
/* Diagnostic introspection; no stock pointers. Slot<voice_limit. Returns0 idle. */
int sp_synth_engine_voice(const SpSynthEngine *engine, uint32_t slot,
                          uint32_t *note, uint32_t *channel, float *pitch, float *amplitude);
size_t sp_synth_engine_used_bytes(void);

#endif
