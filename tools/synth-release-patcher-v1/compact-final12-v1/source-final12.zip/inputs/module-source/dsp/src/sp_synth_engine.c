#include "sp_synth_engine.h"
#include <math.h>
#include <string.h>

#define ENGINE_MAGIC UINT32_C(0x53594531)
#define TAIL_FRAMES 64u
#define PI2 6.2831853071795864769f

typedef struct { size_t offset; float lo, hi; const char *unit; } Param;
#define P(field,lo,hi,unit) { offsetof(SpSynthPatch,field), lo, hi, unit }
static const Param params[SP_PARAM_COUNT] = {
    P(osc[0].semitones,-48,48,"semitones"), P(osc[0].cents,-100,100,"cents"),
    P(osc[0].level,0,1,"level"), P(osc[0].pulse_width,.01f,.99f,"duty"),
    P(osc[1].semitones,-48,48,"semitones"), P(osc[1].cents,-100,100,"cents"),
    P(osc[1].level,0,1,"level"), P(osc[1].pulse_width,.01f,.99f,"duty"),
    P(sub_level,0,1,"level"), P(noise_level,0,1,"level"), P(noise_color,0,1,"blend"),
    P(cutoff_hz,5,21600,"Hz"), P(resonance,0,1,"resonance"),
    P(filter_env,-8,8,"octaves"), P(key_track,0,2,"octaves/octave"), P(drive,0,1,"drive"),
    P(amp.attack,0,60,"seconds"), P(amp.decay,0,60,"seconds"), P(amp.sustain,0,1,"level"),
    P(amp.release,0,60,"seconds"), P(amp.curve,-.95f,.95f,"curve"),
    P(mod.attack,0,60,"seconds"), P(mod.decay,0,60,"seconds"), P(mod.sustain,0,1,"level"),
    P(mod.release,0,60,"seconds"), P(mod.curve,-.95f,.95f,"curve"),
    P(lfo[0].rate_hz,.01f,40,"Hz"), P(lfo[0].beats,.0625f,64,"beats/cycle"),
    P(lfo[0].phase,0,1,"cycle"), P(lfo[1].rate_hz,.01f,40,"Hz"),
    P(lfo[1].beats,.0625f,64,"beats/cycle"), P(lfo[1].phase,0,1,"cycle"),
    P(glide,0,10,"seconds/octave"), P(unison_detune,0,100,"cents"),
    P(unison_spread,0,1,"pan"), P(variation,0,20,"cents"),
    P(gain,0,1,"gain"), P(pan,-1,1,"pan"), P(velocity_amount,0,1,"amount"),
    P(bend_range,0,24,"semitones"), P(macro[0],0,1,"normalized"),
    P(macro[1],0,1,"normalized"), P(macro[2],0,1,"normalized"),
    P(route[0].amount,-1,1,"signed amount"), P(route[1].amount,-1,1,"signed amount"),
    P(route[2].amount,-1,1,"signed amount"), P(route[3].amount,-1,1,"signed amount"),
    P(route[4].amount,-1,1,"signed amount"), P(route[5].amount,-1,1,"signed amount"),
    P(route[6].amount,-1,1,"signed amount"), P(route[7].amount,-1,1,"signed amount")
};
#undef P

static float clamp(float x,float lo,float hi) { return x<lo?lo:(x>hi?hi:x); }
static void copy_float(void *out,const void *in) {
    /* Preserve the byte-copy aliasing contract, but allow a fixed four-byte
     * copy to inline even when the enclosing firmware uses -fno-builtin. */
#if defined(__GNUC__) || defined(__clang__)
    __builtin_memcpy(out,in,sizeof(float));
#else
    memcpy(out,in,sizeof(float));
#endif
}
static float get(const SpSynthPatch *p,unsigned i) {
    float v; copy_float(&v,(const unsigned char *)p+params[i].offset); return v;
}
static void put(SpSynthPatch *p,unsigned i,float v) {
    copy_float((unsigned char *)p+params[i].offset,&v);
}
int sp_synth_param_range(SpSynthParam parameter,SpSynthParamRange *range) {
    if ((unsigned)parameter>=SP_PARAM_COUNT || !range) return 0;
    *range=(SpSynthParamRange){params[parameter].lo,params[parameter].hi,params[parameter].unit};
    return 1;
}
int sp_synth_patch_set_param(SpSynthPatch *patch,SpSynthParam parameter,float value) {
    if (!patch || (unsigned)parameter>=SP_PARAM_COUNT || !isfinite(value) ||
        value<params[parameter].lo || value>params[parameter].hi) return 0;
    put(patch,(unsigned)parameter,value); return 1;
}
int sp_synth_patch_get_param(const SpSynthPatch *patch,SpSynthParam parameter,float *value) {
    if (!patch || !value || (unsigned)parameter>=SP_PARAM_COUNT) return 0;
    *value=get(patch,(unsigned)parameter); return 1;
}
void sp_synth_patch_default(SpSynthPatch *p) {
    if (!p) return;
    memset(p,0,sizeof(*p));
    p->version=SP_SYNTH_PATCH_VERSION; p->mode=SP_SYNTH_POLY; p->unison=1;
    p->osc[0]=(SpSynthOscConfig){SP_WAVE_SAW,0,0,.65f,.5f};
    p->osc[1]=(SpSynthOscConfig){SP_WAVE_PULSE,0,7,.3f,.5f};
    p->sub_wave=SP_WAVE_SINE; p->cutoff_hz=3000; p->resonance=.2f;
    p->filter_env=2; p->key_track=.5f;
    p->amp=(SpEnvConfig){.008f,.25f,.7f,.25f,0};
    p->mod=(SpEnvConfig){.01f,.35f,0,.25f,0};
    p->lfo[0]=(SpSynthLfoConfig){SP_LFO_SINE,0,1,2,1,0};
    p->lfo[1]=(SpSynthLfoConfig){SP_LFO_TRIANGLE,0,0,.3f,4,0};
    p->gain=.5f; p->velocity_amount=.7f; p->bend_range=2;
    p->unison_detune=12; p->unison_spread=.6f; p->variation=2;
    p->macro[0]=p->macro[1]=p->macro[2]=.5f;
}
int sp_synth_patch_valid(const SpSynthPatch *p) {
    if (!p || p->version!=SP_SYNTH_PATCH_VERSION || p->mode>SP_SYNTH_MONO ||
        (p->unison!=1 && p->unison!=2 && p->unison!=4) || p->legato>1 ||
        p->sub_wave>SP_WAVE_PULSE || p->filter_mode>SP_FILTER_NOTCH ||
        p->amp_cycle>1 || p->mod_cycle>1) return 0;
    for (unsigned i=0;i<SP_PARAM_COUNT;++i) {
        float v=get(p,i);
        if (!isfinite(v) || v<params[i].lo || v>params[i].hi) return 0;
    }
    for (unsigned i=0;i<2;++i)
        if (p->osc[i].wave>SP_WAVE_PULSE || p->lfo[i].wave>SP_LFO_SAMPLE_HOLD ||
            p->lfo[i].tempo_sync>1 || p->lfo[i].retrigger>1) return 0;
    for (unsigned i=0;i<SP_SYNTH_MOD_SLOTS;++i)
        if (p->route[i].source>=SP_MOD_SOURCE_COUNT || p->route[i].destination>=SP_DEST_COUNT)
            return 0;
    return 1;
}
int sp_synth_patch_same_structure(const SpSynthPatch *a,const SpSynthPatch *b) {
    if (!a || !b) return 0;
    if (a->mode!=b->mode || a->unison!=b->unison || a->legato!=b->legato ||
        a->sub_wave!=b->sub_wave || a->filter_mode!=b->filter_mode ||
        a->amp_cycle!=b->amp_cycle || a->mod_cycle!=b->mod_cycle) return 0;
    for (unsigned i=0;i<2;++i)
        if (a->osc[i].wave!=b->osc[i].wave || a->lfo[i].wave!=b->lfo[i].wave ||
            a->lfo[i].tempo_sync!=b->lfo[i].tempo_sync || a->lfo[i].retrigger!=b->lfo[i].retrigger)
            return 0;
    for (unsigned i=0;i<SP_SYNTH_MOD_SLOTS;++i)
        if (a->route[i].source!=b->route[i].source ||
            a->route[i].destination!=b->route[i].destination) return 0;
    return 1;
}

typedef struct {
    uint32_t active,key_down,channel,note,tag;
    uint64_t token;
    float velocity,pressure;
} Note;
typedef struct { float bend,target_bend,pressure,wheel; uint32_t sustain; } Channel;
typedef struct {
    uint32_t active,generation,note,channel;
    uint64_t token;
    SpSynthPatch patch;
    float smooth[SP_PARAM_COUNT];
    SpOsc osc[3]; SpNoise noise,lfo_noise,drift_noise;
    SpEnvelope amp,mod; SpFilter filter; SpDrive drive;
    float lfo_phase[2],lfo_hold[2],variation,drift,drift_target;
    float pitch,target_pitch,velocity,pressure,layer;
    float colored,dc_x,dc_y,last_l,last_r;
    uint32_t drift_count,smoothing;
} Voice;
typedef struct { float l,r; uint32_t remaining; } Tail;
typedef struct {
    uint32_t magic,seed,limit,generation;
    uint64_t sequence,mono_token;
    float rate,inv_rate,smooth_rate,dc_pole,bpm,target_bpm,last_pitch;
    uint32_t have_last_pitch;
    float free_phase[2];
    SpSynthPatch patch;
    Channel channel[16]; Note note[SP_SYNTH_MAX_NOTES];
    Voice voice[SP_SYNTH_MAX_VOICES]; Tail tail[SP_SYNTH_MAX_VOICES];
    SpSynthStats stats;
} Engine;
_Static_assert(sizeof(Engine)<=SP_SYNTH_ENGINE_BYTES,"Engine storage too small");
static Engine *state(SpSynthEngine *e) { return (Engine *)(void *)e; }
static const Engine *cstate(const SpSynthEngine *e) { return (const Engine *)(const void *)e; }
static int ready(const Engine *e) { return e && e->magic==ENGINE_MAGIC; }
size_t sp_synth_engine_used_bytes(void) { return sizeof(Engine); }
static Note *latest_note(Engine *e);
static void mono_select(Engine *e,Note *n,int trigger);

/* 1-exp(-x), evaluated without cancellation or a libc errno dependency.
 * Init admits x in [0, .025]; omitted sixth term <=3.4e-13. */
static float decay_amount(float x) {
    return x*(1.0f-x*(.5f-x*(1.0f/6.0f-x*(1.0f/24.0f-x/120.0f))));
}

static void release_token(Engine *e,uint64_t token) {
    for (unsigned i=0;i<e->limit;++i) if (e->voice[i].active && e->voice[i].token==token) {
        sp_synth_env_off(&e->voice[i].amp); sp_synth_env_off(&e->voice[i].mod);
    }
}
static void fade_voice(Engine *e,unsigned i) {
    Voice *v=&e->voice[i]; Tail *t=&e->tail[i];
    float fraction=(float)t->remaining/(float)TAIL_FRAMES;
    t->l=clamp(t->l*fraction+v->last_l,-4,4);
    t->r=clamp(t->r*fraction+v->last_r,-4,4);
    t->remaining=TAIL_FRAMES;
    v->active=0;
}
static void all_off(Engine *e,unsigned channel,int immediate) {
    for (unsigned c=0;c<16;++c) if (channel==16 || channel==c) e->channel[c].sustain=0;
    for (unsigned n=0;n<SP_SYNTH_MAX_NOTES;++n)
        if (e->note[n].active && (channel==16 || channel==e->note[n].channel)) e->note[n].active=0;
    for (unsigned i=0;i<e->limit;++i) {
        Voice *v=&e->voice[i];
        if (v->active && (channel==16 || channel==v->channel)) {
            if (immediate) fade_voice(e,i);
            else { sp_synth_env_off(&v->amp); sp_synth_env_off(&v->mod); }
        }
    }
    if (channel==16) e->mono_token=0;
    else if (e->patch.mode==SP_SYNTH_MONO) {
        int retained=0;
        for (unsigned n=0;n<SP_SYNTH_MAX_NOTES;++n)
            retained|=e->note[n].active && e->note[n].token==e->mono_token;
        if (!retained) e->mono_token=0;
        mono_select(e,latest_note(e),1);
    }
}
void sp_synth_engine_panic(SpSynthEngine *engine) {
    Engine *e=state(engine); if (ready(e)) all_off(e,16,1);
}
int sp_synth_engine_init(SpSynthEngine *engine,float rate,uint32_t limit,
                         uint32_t seed,const SpSynthPatch *patch) {
    if (!engine || !isfinite(rate) || rate<8000 || rate>192000 ||
        limit<1 || limit>SP_SYNTH_MAX_VOICES || !sp_synth_patch_valid(patch) ||
        patch->unison>limit) return 0;
    /* Allow a patch copy inside caller storage without erasing its input first. */
    SpSynthPatch copy=*patch;
    memset(engine,0,sizeof(*engine)); Engine *e=state(engine);
    e->magic=ENGINE_MAGIC; e->seed=seed?seed:UINT32_C(0x1f123bb5); e->limit=limit;
    e->generation=1; e->rate=rate; e->inv_rate=1/rate;
    e->smooth_rate=decay_amount(1.0f/(.005f*rate));
    e->dc_pole=1.0f-decay_amount(PI2*12.0f/rate); e->bpm=e->target_bpm=120;
    e->patch=copy; e->stats.voice_limit=limit; return 1;
}
int sp_synth_engine_load_patch(SpSynthEngine *engine,const SpSynthPatch *patch) {
    Engine *e=state(engine); if (!ready(e)) return 0;
    if (!sp_synth_patch_valid(patch) || patch->unison>e->limit) { ++e->stats.invalid_patches; return 0; }
    SpSynthPatch copy=*patch;
    all_off(e,16,0); e->patch=copy;
    ++e->generation;
    if (!e->generation) { /* Keep old release voices separate after wrap. */
        e->generation=1;
        for (unsigned i=0;i<e->limit;++i) e->voice[i].generation=0;
    }
    e->have_last_pitch=0;
    return 1;
}
int sp_synth_engine_edit_patch(SpSynthEngine *engine,const SpSynthPatch *patch) {
    Engine *e=state(engine); if (!ready(e)) return 0;
    if (!sp_synth_patch_valid(patch) || !sp_synth_patch_same_structure(&e->patch,patch)) {
        ++e->stats.invalid_patches; return 0;
    }
    e->patch=*patch;
    for (unsigned i=0;i<e->limit;++i)
        if (e->voice[i].active && e->voice[i].generation==e->generation) {
            e->voice[i].patch=*patch;
            e->voice[i].smoothing=1;
        }
    return 1;
}
static uint32_t hash(uint32_t x) {
    x^=x>>16; x*=UINT32_C(0x7feb352d); x^=x>>15;
    x*=UINT32_C(0x846ca68b); return x^(x>>16);
}
static unsigned free_slots(Engine *e) {
    unsigned n=0; for (unsigned i=0;i<e->limit;++i) n+=!e->voice[i].active; return n;
}
static void make_room(Engine *e,unsigned layers) {
    while (free_slots(e)<layers) { /* <=16 complete groups; fixed bounded work */
        unsigned chosen=SP_SYNTH_MAX_VOICES; float score=1000;
        uint64_t oldest=UINT64_MAX;
        for (unsigned i=0;i<e->limit;++i) {
            Voice *v=&e->voice[i]; if (!v->active) continue;
            float s=v->amp.gate?2.0f:v->amp.value;
            if (s<score || (s==score && v->token<oldest)) {
                score=s; oldest=v->token; chosen=i;
            }
        }
        if (chosen==SP_SYNTH_MAX_VOICES) break;
        uint64_t token=e->voice[chosen].token;
        for (unsigned i=0;i<e->limit;++i)
            if (e->voice[i].active && e->voice[i].token==token) { fade_voice(e,i); ++e->stats.steals; }
    }
}
static float phase_wrap(float x) {
    if (x>=0.0f && x<1.0f) return x==0.0f?0.0f:x;
    x-=floorf(x); return x>=1?0:x;
}
static void start_voice(Engine *e,unsigned slot,const Note *n,unsigned layer) {
    Voice *v=&e->voice[slot]; memset(v,0,sizeof(*v));
    v->active=1; v->generation=e->generation; v->token=n->token;
    v->note=n->note; v->channel=n->channel; v->patch=e->patch;
    for (unsigned i=0;i<SP_PARAM_COUNT;++i) v->smooth[i]=get(&v->patch,i);
    v->velocity=n->velocity; v->pressure=n->pressure;
    v->target_pitch=(float)n->note;
    v->pitch=e->have_last_pitch && e->patch.glide>0?e->last_pitch:v->target_pitch;
    v->layer=e->patch.unison==1?0:(2.0f*(float)layer/(float)(e->patch.unison-1)-1);
    uint32_t seed=hash(e->seed^(uint32_t)n->token^(uint32_t)(n->token>>32)^(slot*7919u));
    sp_synth_noise_seed(&v->noise,seed); sp_synth_noise_seed(&v->lfo_noise,seed^0x10203u);
    sp_synth_noise_seed(&v->drift_noise,seed^0x987654u);
    v->variation=sp_synth_noise(&v->drift_noise);
    v->drift_target=sp_synth_noise(&v->drift_noise);
    for (unsigned i=0;i<3;++i) v->osc[i].phase=.5f+.5f*sp_synth_noise(&v->noise);
    for (unsigned i=0;i<2;++i) {
        v->lfo_phase[i]=e->patch.lfo[i].retrigger?phase_wrap(e->patch.lfo[i].phase):e->free_phase[i];
        v->lfo_hold[i]=sp_synth_noise(&v->lfo_noise);
    }
    sp_synth_env_init(&v->amp,e->rate,&v->patch.amp);
    sp_synth_env_init(&v->mod,e->rate,&v->patch.mod);
    v->amp.loop=v->patch.amp_cycle; v->mod.loop=v->patch.mod_cycle;
    sp_synth_env_on(&v->amp,1); sp_synth_env_on(&v->mod,1);
    sp_synth_filter_init(&v->filter,(SpFilterMode)v->patch.filter_mode,e->rate,
                        v->patch.cutoff_hz,v->patch.resonance);
}
static Note *latest_note(Engine *e) {
    Note *chosen=0;
    for (unsigned i=0;i<SP_SYNTH_MAX_NOTES;++i) {
        Note *n=&e->note[i]; if (!n->active) continue;
        if (!chosen || n->key_down>chosen->key_down ||
            (n->key_down==chosen->key_down && n->token>chosen->token)) chosen=n;
    }
    return chosen;
}
static void mono_select(Engine *e,Note *n,int trigger) {
    if (!n) {
        if (e->mono_token) release_token(e,e->mono_token);
        e->mono_token=0; return;
    }
    if (n->token==e->mono_token) return;
    unsigned found=0;
    for (unsigned i=0;i<e->limit;++i) {
        Voice *v=&e->voice[i];
        if (!v->active || v->token!=e->mono_token || v->generation!=e->generation) continue;
        ++found;
        v->token=n->token; v->note=n->note; v->channel=n->channel;
        v->target_pitch=(float)n->note; v->velocity=n->velocity; v->pressure=n->pressure;
        if (trigger && !e->patch.legato) {
            sp_synth_env_on(&v->amp,0); sp_synth_env_on(&v->mod,0);
            for (unsigned l=0;l<2;++l) if (v->patch.lfo[l].retrigger)
                v->lfo_phase[l]=phase_wrap(v->patch.lfo[l].phase);
        }
    }
    if (!found) {
        make_room(e,e->patch.unison);
        unsigned layer=0;
        for (unsigned i=0;i<e->limit && layer<e->patch.unison;++i)
            if (!e->voice[i].active) start_voice(e,i,n,layer++);
    }
    e->mono_token=n->token; e->last_pitch=(float)n->note; e->have_last_pitch=1;
}
static void note_on(Engine *e,const SpSynthEvent *event) {
    if (event->parameter) {
        for (unsigned i=0;i<SP_SYNTH_MAX_NOTES;++i) {
            Note *n=&e->note[i];
            if (n->active && n->channel==event->channel && n->tag==event->parameter) {
                release_token(e,n->token); n->active=0;
            }
        }
    }
    Note *n=0;
    for (unsigned i=0;i<SP_SYNTH_MAX_NOTES;++i) if (!e->note[i].active) { n=&e->note[i]; break; }
    if (!n) { ++e->stats.rejected_notes; all_off(e,16,1); return; }
    ++e->sequence;
    if (!e->sequence) { all_off(e,16,1); e->sequence=1; }
    *n=(Note){1,1,event->channel,event->note,event->parameter,e->sequence,event->value,-1};
    if (e->patch.mode==SP_SYNTH_MONO) mono_select(e,n,1);
    else {
        make_room(e,e->patch.unison); unsigned layer=0;
        for (unsigned i=0;i<e->limit && layer<e->patch.unison;++i)
            if (!e->voice[i].active) start_voice(e,i,n,layer++);
        e->last_pitch=(float)n->note; e->have_last_pitch=1;
    }
}
static void note_off(Engine *e,const SpSynthEvent *event,int cancel) {
    Note *chosen=0;
    for (unsigned i=0;i<SP_SYNTH_MAX_NOTES;++i) {
        Note *n=&e->note[i];
        if (!n->active || (!cancel && !n->key_down) || n->channel!=event->channel || n->note!=event->note ||
            (event->parameter && n->tag!=event->parameter)) continue;
        if (!chosen || n->token<chosen->token) chosen=n;
    }
    if (!chosen) return;
    chosen->key_down=0;
    if (cancel || !e->channel[chosen->channel].sustain) {
        if (e->patch.mode==SP_SYNTH_POLY) release_token(e,chosen->token);
        chosen->active=0;
    }
    if (e->patch.mode==SP_SYNTH_MONO) mono_select(e,latest_note(e),1);
}
static void sustain(Engine *e,unsigned channel,int down) {
    e->channel[channel].sustain=(uint32_t)down;
    if (!down) {
        for (unsigned i=0;i<SP_SYNTH_MAX_NOTES;++i) {
            Note *n=&e->note[i];
            if (n->active && n->channel==channel && !n->key_down) {
                if (e->patch.mode==SP_SYNTH_POLY) release_token(e,n->token);
                n->active=0;
            }
        }
        if (e->patch.mode==SP_SYNTH_MONO) mono_select(e,latest_note(e),1);
    }
}
static int valid_event(const SpSynthEvent *v,uint32_t frames) {
    if (v->offset>=frames || v->type>SP_EVENT_NOTE_CANCEL || !isfinite(v->value)) return 0;
    if (v->type==SP_EVENT_ALL_NOTES_OFF || v->type==SP_EVENT_ALL_SOUND_OFF) return v->channel<=16;
    if (v->type==SP_EVENT_TEMPO) return v->value>=20 && v->value<=300;
    if (v->type==SP_EVENT_PARAMETER)
        return v->parameter<SP_PARAM_COUNT && v->value>=params[v->parameter].lo &&
            v->value<=params[v->parameter].hi;
    if (v->channel>=16) return 0;
    if (v->type==SP_EVENT_NOTE_ON || v->type==SP_EVENT_NOTE_OFF || v->type==SP_EVENT_POLY_PRESSURE || v->type==SP_EVENT_NOTE_CANCEL)
        if (v->note>127) return 0;
    return v->value>=(v->type==SP_EVENT_PITCH_BEND?-1.0f:0.0f) && v->value<=1;
}
static void apply_event(Engine *e,const SpSynthEvent *v) {
    switch (v->type) {
        case SP_EVENT_NOTE_ON: if (v->value>0) note_on(e,v); else note_off(e,v,0); break;
        case SP_EVENT_NOTE_OFF: note_off(e,v,0); break;
        case SP_EVENT_NOTE_CANCEL: note_off(e,v,1); break;
        case SP_EVENT_SUSTAIN: sustain(e,v->channel,v->value>=.5f); break;
        case SP_EVENT_PITCH_BEND: e->channel[v->channel].target_bend=v->value; break;
        case SP_EVENT_PRESSURE: e->channel[v->channel].pressure=v->value; break;
        case SP_EVENT_MOD_WHEEL: e->channel[v->channel].wheel=v->value; break;
        case SP_EVENT_POLY_PRESSURE:
            for (unsigned i=0;i<SP_SYNTH_MAX_NOTES;++i) if (e->note[i].active &&
                e->note[i].channel==v->channel && e->note[i].note==v->note) e->note[i].pressure=v->value;
            for (unsigned i=0;i<e->limit;++i) if (e->voice[i].active &&
                e->voice[i].channel==v->channel && e->voice[i].note==v->note) e->voice[i].pressure=v->value;
            break;
        case SP_EVENT_ALL_NOTES_OFF: all_off(e,v->channel,0); break;
        case SP_EVENT_ALL_SOUND_OFF: all_off(e,v->channel,1); break;
        case SP_EVENT_TEMPO: e->target_bpm=v->value; break;
        case SP_EVENT_PARAMETER:
            put(&e->patch,v->parameter,v->value);
            for (unsigned i=0;i<e->limit;++i) if (e->voice[i].active &&
                e->voice[i].generation==e->generation) {
                put(&e->voice[i].patch,v->parameter,v->value);
                e->voice[i].smoothing=1;
            }
            break;
        default: break;
    }
}
static float lfo_frequency(const SpSynthLfoConfig *c,float rate,float beats,float bpm) {
    return c->tempo_sync?bpm/(60.0f*beats):rate;
}
int sp_synth_engine_control(SpSynthEngine *engine,const SpSynthEvent *events,uint32_t count) {
    Engine *e=state(engine);if(!ready(e))return 0;
    if(count>SP_SYNTH_MAX_EVENTS || (count && !events)) {
        if(count>SP_SYNTH_MAX_EVENTS)++e->stats.event_overflows;else ++e->stats.invalid_batches;
        all_off(e,16,1);return 0;
    }
    for(unsigned i=0;i<count;++i)if(!valid_event(&events[i],1)) {
        ++e->stats.invalid_batches;all_off(e,16,1);return 0;
    }
    for(unsigned i=0;i<count;++i)apply_event(e,&events[i]);
    return 1;
}
static float lfo_tick(Engine *e,Voice *v,unsigned i) {
    unsigned p=i?SP_PARAM_LFO2_RATE:SP_PARAM_LFO1_RATE;
    float phase=v->lfo_phase[i],out;
    switch (v->patch.lfo[i].wave) {
        case SP_LFO_TRIANGLE: out=1-4*fabsf(phase-.5f); break;
        case SP_LFO_SAW: out=2*phase-1; break;
        case SP_LFO_SQUARE: out=phase<.5f?1:-1; break;
        case SP_LFO_SAMPLE_HOLD: out=v->lfo_hold[i]; break;
        default: out=sp_synth_sine(phase); break;
    }
    phase+=lfo_frequency(&v->patch.lfo[i],v->smooth[p],v->smooth[p+1],e->bpm)*e->inv_rate;
    if (phase>=1) { phase-=1; v->lfo_hold[i]=sp_synth_noise(&v->lfo_noise); }
    v->lfo_phase[i]=phase; return out;
}
static void envelope_config(SpEnvelope *env,const float *s,unsigned first) {
    env->config=(SpEnvConfig){s[first],s[first+1],s[first+2],s[first+3],s[first+4]};
}
static void render_voice(Engine *e,Voice *v,float *left,float *right) {
    float *s=v->smooth;
    if (v->smoothing) {
        unsigned pending=0;
        for (unsigned p=0;p<SP_PARAM_COUNT;++p) {
            float target=get(&v->patch,p);
            /* Settled parameters need no ramp arithmetic. Assign the target
             * so equal signed zeros retain the old loop's exact result. */
            if (s[p]==target) { s[p]=target; continue; }
            float next=s[p]+e->smooth_rate*(target-s[p]);
            /* Complete when float rounding would otherwise stall the ramp. */
            s[p]=next==s[p]?target:next;
            pending|=s[p]!=target;
        }
        v->smoothing=pending;
        /* Initialization supplies these configs; only parameter smoothing
         * changes their values during a voice's lifetime. */
        envelope_config(&v->amp,s,SP_PARAM_AMP_ATTACK);
        envelope_config(&v->mod,s,SP_PARAM_MOD_ATTACK);
    }
    float amp=sp_synth_env_tick(&v->amp),mod=sp_synth_env_tick(&v->mod);
    if (v->amp.stage==SP_ENV_IDLE) { v->active=0; v->last_l=v->last_r=0; return; }
    float step=s[SP_PARAM_GLIDE]>0?12.0f*e->inv_rate/s[SP_PARAM_GLIDE]:256;
    v->pitch+=clamp(v->target_pitch-v->pitch,-step,step);
    if (!v->drift_count) {
        v->drift_target=sp_synth_noise(&v->drift_noise);
        v->drift_count=(uint32_t)(e->rate*.2f);
    }
    --v->drift_count; v->drift+=(.5f*e->inv_rate)*(v->drift_target-v->drift);
    Channel *channel=&e->channel[v->channel];
    float source[SP_MOD_SOURCE_COUNT]={0};
    source[SP_MOD_LFO1]=lfo_tick(e,v,0); source[SP_MOD_LFO2]=lfo_tick(e,v,1);
    source[SP_MOD_ENV2]=mod; source[SP_MOD_AMP_ENV]=amp;
    source[SP_MOD_VELOCITY]=v->velocity;
    source[SP_MOD_KEY]=clamp(((float)v->note-60)/60,-1,1);
    source[SP_MOD_PRESSURE]=v->pressure>=0?v->pressure:channel->pressure;
    source[SP_MOD_WHEEL]=channel->wheel; source[SP_MOD_RANDOM]=v->variation;
    source[SP_MOD_MACRO1]=s[SP_PARAM_MACRO1]; source[SP_MOD_MACRO2]=s[SP_PARAM_MACRO2];
    source[SP_MOD_MACRO3]=s[SP_PARAM_MACRO3];
    float dest[SP_DEST_COUNT]={0};
    /* Fixed routing order; avoid loop/index overhead without reassociation. */
#if defined(__GNUC__) || defined(__clang__)
#pragma GCC unroll 8
#endif
    for (unsigned i=0;i<SP_SYNTH_MOD_SLOTS;++i) {
        const SpSynthModSlot *r=&v->patch.route[i];
        dest[r->destination]+=source[r->source]*s[SP_PARAM_ROUTE1_AMOUNT+i];
    }
    float cents=v->layer*s[SP_PARAM_UNISON_DETUNE]+
        s[SP_PARAM_VARIATION]*(v->variation+.25f*v->drift);
    float base=v->pitch+channel->bend*s[SP_PARAM_BEND_RANGE]+cents*.01f+24*dest[SP_DEST_PITCH];
    float pw1=clamp(s[SP_PARAM_OSC1_PW]+.48f*dest[SP_DEST_PW1],.01f,.99f);
    float pw2=clamp(s[SP_PARAM_OSC2_PW]+.48f*dest[SP_DEST_PW2],.01f,.99f);
    float f1=440*sp_synth_exp2((base-69+s[SP_PARAM_OSC1_SEMITONES]+
        s[SP_PARAM_OSC1_CENTS]*.01f+24*dest[SP_DEST_OSC1_PITCH])/12);
    float f2=440*sp_synth_exp2((base-69+s[SP_PARAM_OSC2_SEMITONES]+
        s[SP_PARAM_OSC2_CENTS]*.01f+24*dest[SP_DEST_OSC2_PITCH])/12);
    float sub=440*sp_synth_exp2((base-81)/12);
    float a=sp_synth_osc(&v->osc[0],(SpWave)v->patch.osc[0].wave,f1*e->inv_rate,pw1);
    float b=sp_synth_osc(&v->osc[1],(SpWave)v->patch.osc[1].wave,f2*e->inv_rate,pw2);
    float c=sp_synth_osc(&v->osc[2],(SpWave)v->patch.sub_wave,sub*e->inv_rate,.5f);
    float noise=sp_synth_noise(&v->noise);
    v->colored+=clamp(PI2*900*e->inv_rate,0,.9f)*(noise-v->colored);
    noise+=s[SP_PARAM_NOISE_COLOR]*(v->colored*2-noise);
    float x=a*clamp(s[SP_PARAM_OSC1_LEVEL]+dest[SP_DEST_OSC1_LEVEL],0,1)+
        b*clamp(s[SP_PARAM_OSC2_LEVEL]+dest[SP_DEST_OSC2_LEVEL],0,1)+
        c*clamp(s[SP_PARAM_SUB_LEVEL]+dest[SP_DEST_SUB_LEVEL],0,1)+
        noise*clamp(s[SP_PARAM_NOISE_LEVEL]+dest[SP_DEST_NOISE_LEVEL],0,1);
    x=sp_synth_drive_tick(&v->drive,x,clamp(s[SP_PARAM_DRIVE]+dest[SP_DEST_DRIVE],0,1));
    float oct=s[SP_PARAM_FILTER_ENV]*mod+s[SP_PARAM_KEY_TRACK]*((float)v->note-60)/12+
        6*dest[SP_DEST_CUTOFF];
    float cutoff=clamp(s[SP_PARAM_CUTOFF]*sp_synth_exp2(oct),5,e->rate*.45f);
    sp_synth_filter_set(&v->filter,e->rate,cutoff,clamp(s[SP_PARAM_RESONANCE]+dest[SP_DEST_RESONANCE],0,1));
    float y=sp_synth_filter_tick(&v->filter,x);
    float dc=y-v->dc_x+e->dc_pole*v->dc_y;
    v->dc_x=y; v->dc_y=fabsf(dc)<1e-20f?0:dc;
    float velocity=1-s[SP_PARAM_VELOCITY]+s[SP_PARAM_VELOCITY]*v->velocity;
    float level=amp*velocity*s[SP_PARAM_GAIN]*clamp(1+dest[SP_DEST_AMP],0,2);
    /* Fixed headroom: adding/removing notes never rescales existing voices. */
    y=dc*level*(.25f/(float)v->patch.unison);
    float pan=clamp(s[SP_PARAM_PAN]+v->layer*s[SP_PARAM_UNISON_SPREAD]+dest[SP_DEST_PAN],-1,1);
    float l=sp_synth_sine((1-pan)*.125f),r=sp_synth_sine((1+pan)*.125f);
    v->last_l=y*l; v->last_r=y*r;
    if (!isfinite(v->last_l) || !isfinite(v->last_r)) {
        v->active=0; v->last_l=v->last_r=0; ++e->stats.nonfinite_faults;
    }
    *left+=v->last_l; *right+=v->last_r;
}
static float output(Engine *e,float value) {
    if (!isfinite(value)) { ++e->stats.nonfinite_faults; return 0; }
    if (value>1 || value< -1) ++e->stats.output_clips;
    return clamp(value,-1,1);
}
static int render(SpSynthEngine *engine,void *audio,uint32_t frames,
                  const SpSynthEvent *events,uint32_t count,int integer) {
    Engine *e=state(engine);
    if (!ready(e) || !audio || !frames || frames>SP_SYNTH_MAX_FRAMES) return 0;
    int accepted=1;
    if (count>SP_SYNTH_MAX_EVENTS) { ++e->stats.event_overflows; accepted=0; }
    else if (count && !events) { ++e->stats.invalid_batches; accepted=0; }
    else for (unsigned i=0;i<count;++i)
        if (!valid_event(&events[i],frames) || (i && events[i].offset<events[i-1].offset)) {
            ++e->stats.invalid_batches; accepted=0; break;
        }
    if (!accepted) { all_off(e,16,1); count=0; }
    unsigned next=0;
    for (unsigned frame=0;frame<frames;++frame) {
        while (next<count && events[next].offset==frame) apply_event(e,&events[next++]);
        e->bpm+=e->smooth_rate*(e->target_bpm-e->bpm);
        for (unsigned c=0;c<16;++c) {
            Channel *channel=&e->channel[c];
            /* A return to zero otherwise stalls in subnormal values and keeps
             * multiplying them even while idle. This threshold is far below
             * pitch precision; preserve the existing nonzero-target ramp. */
            if (channel->target_bend==0.0f && fabsf(channel->bend)<1e-20f)
                channel->bend=0.0f;
            else channel->bend+=e->smooth_rate*(channel->target_bend-channel->bend);
        }
        for (unsigned i=0;i<2;++i) {
            const SpSynthLfoConfig *l=&e->patch.lfo[i];
            e->free_phase[i]=phase_wrap(e->free_phase[i]+
                lfo_frequency(l,l->rate_hz,l->beats,e->bpm)*e->inv_rate);
        }
        float left=0,right=0; unsigned active=0;
        for (unsigned i=0;i<e->limit;++i) {
            if (e->voice[i].active) render_voice(e,&e->voice[i],&left,&right);
            active+=e->voice[i].active;
            Tail *t=&e->tail[i];
            if (t->remaining) {
                float f=(float)t->remaining/(float)TAIL_FRAMES;
                left+=t->l*f; right+=t->r*f; --t->remaining;
            }
        }
        if (active>e->stats.peak_voices) e->stats.peak_voices=active;
        left=output(e,left); right=output(e,right);
        if (integer) {
            int16_t *out=(int16_t *)audio;
            out[2*frame]=(int16_t)(left>=0?left*32767.0f:left*32768.0f);
            out[2*frame+1]=(int16_t)(right>=0?right*32767.0f:right*32768.0f);
        } else {
            float *out=(float *)audio; out[2*frame]=left; out[2*frame+1]=right;
        }
    }
    e->stats.rendered_frames+=frames;
    return accepted;
}
int sp_synth_engine_render(SpSynthEngine *e,float *out,uint32_t frames,
                           const SpSynthEvent *events,uint32_t count) {
    return render(e,out,frames,events,count,0);
}
int sp_synth_engine_render_s16(SpSynthEngine *e,int16_t *out,uint32_t frames,
                               const SpSynthEvent *events,uint32_t count) {
    return render(e,out,frames,events,count,1);
}
int sp_synth_engine_quiescent(const SpSynthEngine *engine) {
    const Engine *e=cstate(engine);if(!ready(e))return 0;
    for(unsigned i=0;i<e->limit;++i)
        if(e->voice[i].active || e->tail[i].remaining)return 0;
    for(unsigned i=0;i<SP_SYNTH_MAX_NOTES;++i)if(e->note[i].active)return 0;
    return 1;
}
void sp_synth_engine_stats(const SpSynthEngine *engine,SpSynthStats *stats) {
    if (!stats) return;
    memset(stats,0,sizeof(*stats));
    const Engine *e=cstate(engine); if (!ready(e)) return;
    *stats=e->stats; stats->patch_generation=e->generation;
    for (unsigned i=0;i<e->limit;++i) {
        stats->active_voices+=e->voice[i].active;
        stats->gated_voices+=e->voice[i].active && e->voice[i].amp.gate;
    }
    for (unsigned i=0;i<SP_SYNTH_MAX_NOTES;++i) stats->held_notes+=e->note[i].active;
}
int sp_synth_engine_voice(const SpSynthEngine *engine,uint32_t slot,
                          uint32_t *note,uint32_t *channel,float *pitch,float *amplitude) {
    const Engine *e=cstate(engine); if (!ready(e) || slot>=e->limit) return 0;
    const Voice *v=&e->voice[slot]; if (!v->active) return 0;
    if (note) *note=v->note;
    if (channel) *channel=v->channel;
    if (pitch) *pitch=v->pitch;
    if (amplitude) *amplitude=v->amp.value;
    return 1;
}
