#include "sp_p6_pattern_transport_v552.h"
#include "sp_p6_pattern_choice.h"
#include "sp_synth_preview_native_v552.h"
#include "sp_p6_record_controls_v552.h"
#include "sp_synth_app.h"
#include <stddef.h>
#define value(a) atomic_load_explicit((a),memory_order_acquire)
typedef struct {uint32_t record[3],old,offered;void *previous;} NativeFrame;
_Static_assert(sizeof(NativeFrame)==24,"Source07 copied frame ARM32 ABI");
_Static_assert(sizeof(SpP6PatternChoice)==28,"PANEL-only chooser intent");
static SpP6PatternChoice choice;
extern int sp_p6_record_direct_view(uint32_t [4]);
extern const SpSynthApp *sp_p6_record_controls_v552_app(void);
static uint32_t rd(uintptr_t a){return *(volatile const uint32_t *)a;}
static uint16_t rh(uintptr_t a){return *(volatile const uint16_t *)a;}
static uint8_t rb(uintptr_t a){return *(volatile const uint8_t *)a;}
static uint32_t native(uintptr_t f,uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return ((uint32_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(f|1u))(a,b,c,d);
}
static uint32_t get(uint32_t key,uint32_t slot){return native(0x800E26D0,0x82DFFC88,key,slot,0);}
static int panel(void *page) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    uint32_t i,p,z,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));__asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(z));__asm__ volatile("mrs %0,faultmask":"=r"(f));
    if(i || p || z || f || rd(0x202BBBF8) || rd(0x80245764))return 0;
    uint32_t task=native(0x800D3162,0,0,0,0);
    return task && task<=32 && task==m->task_id && task==rd(0x8300A3E8) &&
        value(&m->ready)==1 && !value(&m->terminal) && !value(&m->entry.fault) &&
        value(&m->phase)==SP_PREVIEW_NATIVE_ACTIVE && page &&
        page==atomic_load_explicit(&m->active_page,memory_order_acquire) &&
        (uintptr_t)page==rd(0x80CFD4FC) && rd((uintptr_t)page)==(uintptr_t)(m->primary+2);
}
static int offered(void *page,uint32_t kind,int32_t id,int32_t data,int up) {
    SpSynthEntryOwnerV552 *e=&sp_synth_preview_native_v552.entry;
    if(!panel(page) || e->dispatch_depth!=1 || e->sample_depth || !e->input.enabled)return 0;
    const NativeFrame *f=e->dispatch;
    return f && !f->old && f->offered==(uint32_t)!up &&
        (f->record[0]&65535u)==kind && (int16_t)(f->record[0]>>16)==id &&
        (kind==5 || kind==17 || (int16_t)f->record[1]==data);
}
static void *page(void){return atomic_load_explicit(&sp_synth_preview_native_v552.active_page,memory_order_acquire);}
static int current(void *p) {
    return panel(p) && choice.page==(uintptr_t)p && choice.visit==sp_synth_preview_native_v552.voice_used &&
        choice.project==native(0x800E1190,0,0,0,0);
}
static int blocked(void) {
    uint32_t d[4];
    if(sp_p6_record_direct_view(d) && d[0])return 1;
    const SpSynthApp *a=sp_p6_record_controls_v552_app();
    return a && (a->ui.busy || a->ui.take_held);
}
/* Refuse chain/edit/record modes, modifiers and external pattern control. The
 * original normal pattern callback remains responsible for every request. */
static int normal(void) {
    if(get(119,0) || get(124,0)>1 || get(47,0)==2 || get(137,0) ||
       rb(0x82E0D660+128) || rd(0x82E0D660+132) || rd(0x82E0D660+136))return 0;
    if(native(0x800D9F20,17,0,0,0) || native(0x800D9F20,19,0,0,0) ||
       native(0x800D9F20,42,0,0,0) || native(0x800D9F20,49,0,0,0))return 0;
    return !native(0x800DDA38,0x82E009D0,194,UINT32_MAX,0);
}
static int rings(void) {
    uint32_t w=rd(0x80591ED8),r=rd(0x80591EDC);
    uint32_t ew=rh(0x80591EC4),er=rh(0x80591EC6);
    /* Stock producer clears a full command ring. Require the native worker
     * to drain before a selection, retaining every queued stock packet. */
    return w<360 && w==r && ew<320 && ew==er;
}
int sp_p6_pattern_transport_v552_button(void *p,uint32_t id,int shift) {
    if((id!=20 && id!=27 && id!=34) || !offered(p,5,(int32_t)id,0,0))return 0;
    uint32_t project=native(0x800E1190,0,0,0,0),bank=get(122,0);
    if(project>=128 || bank>=10)return id==20;
    sp_p6_pattern_choice_bind(&choice,(uintptr_t)p,sp_synth_preview_native_v552.voice_used,project,bank);
    if(id==27){sp_p6_pattern_choice_close(&choice);return 0;}
    if(id==34){if(!choice.opened)return 0;sp_p6_pattern_choice_close(&choice);return 1;}
    return sp_p6_pattern_choice_toggle(&choice,shift || blocked() || !normal());
}
int sp_p6_pattern_transport_v552_turn(void *p,int32_t delta,int shift) {
    if(!current(p) || !offered(p,7,0,delta,0) || shift)return 0;
    return sp_p6_pattern_choice_turn(&choice,delta);
}
int sp_p6_pattern_transport_v552_pad(const sp_ui_event *e) {
    if(!e || e->index<1 || e->index>16 || (e->type!=SP_UI_PAD_DOWN && e->type!=SP_UI_PAD_UP))return 0;
    void *p=page();int up=e->type==SP_UI_PAD_UP;
    if(!current(p) || !offered(p,up?17:16,(int32_t)e->index-1,up?0:e->value,up))return 0;
    if(up)return sp_p6_pattern_choice_pad(&choice,e->index,0,0);
    if(!choice.opened)return 0;
    uint32_t index=choice.bank*16u+e->index-1u,configured=get(120,index);
    int valid=e->value>=4 && e->value<=127 && configured>=1 && configured<=5 &&
        !blocked() && normal() && rings() && rb(0x80592244)<=2;
    int intent=sp_p6_pattern_choice_pad(&choice,e->index,1,valid);
    if(intent==2) {
        /* Original property122 only changes bank and publishes native property
         * notifications. Normal801350B8 never reads its page argument or opens
         * a page: stopped starts; same playing stops; another queues next. */
        native(0x800E11D0,0x82DFFC88,122,choice.bank,0);
        native(0x801350B8,(uintptr_t)p,1,e->index-1u,(uint32_t)e->value);
    }
    return intent!=0;
}
void sp_p6_pattern_transport_v552_edge(void) {
    void *p=page();SpSynthEntryOwnerV552 *e=&sp_synth_preview_native_v552.entry;
    const NativeFrame *f=e->dispatch;
    if(!current(p) || e->dispatch_depth!=1 || e->sample_depth || !f || f->old || f->offered ||
       (f->record[0]&65535u)!=6 || (int16_t)(f->record[0]>>16)!=20)return;
    choice.pressed=0;
}
int sp_p6_pattern_transport_v552_view(SpP6PatternTransportView *out) {
    if(!out || !current(page()) || !choice.opened || blocked())return 0;
    SpP6PatternTransportView v={choice.bank,0,get(49,0),get(49,1),rb(0x80592244)};
    for(uint32_t pad=0;pad<16;pad++)if(get(120,choice.bank*16u+pad))v.available|=1u<<pad;
    *out=v;return 1;
}
