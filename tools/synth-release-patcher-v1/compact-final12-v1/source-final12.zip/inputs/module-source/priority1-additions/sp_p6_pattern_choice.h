#ifndef SP_P6_PATTERN_CHOICE_H
#define SP_P6_PATTERN_CHOICE_H
#include <stdint.h>
typedef struct {
    uint32_t page,visit,project,bank,opened,captured,pressed;
} SpP6PatternChoice;
void sp_p6_pattern_choice_bind(SpP6PatternChoice *,uint32_t,uint32_t,uint32_t,uint32_t);
int sp_p6_pattern_choice_toggle(SpP6PatternChoice *,int);
void sp_p6_pattern_choice_close(SpP6PatternChoice *);
int sp_p6_pattern_choice_turn(SpP6PatternChoice *,int32_t);
/* 0: pass through; 1: swallow; 2: native selection intent. */
int sp_p6_pattern_choice_pad(SpP6PatternChoice *,uint32_t,int,int);
#endif
