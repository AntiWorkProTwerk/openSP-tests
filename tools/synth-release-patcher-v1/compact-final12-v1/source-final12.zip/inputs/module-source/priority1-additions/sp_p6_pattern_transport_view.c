#include "sp_p6_pattern_transport_v552.h"
#include "sp_synth_oled_font.h"
#include <string.h>
static void pixel(uint8_t *f,int x,int y) {
    if((unsigned)x<128 && (unsigned)y<64)f[(unsigned)y*16+(unsigned)x/8]|=(uint8_t)(128u>>(x&7));
}
static void line(uint8_t *f,int x,int y,int n){for(int i=0;i<n;i++)pixel(f,x+i,y);}
static void box(uint8_t *f,int x,int y,int w,int h) {
    line(f,x,y,w);line(f,x,y+h-1,w);
    for(int i=0;i<h;i++){pixel(f,x,y+i);pixel(f,x+w-1,y+i);}
}
static void text(uint8_t *f,int x,int y,const char *s) {
    while(*s && x+3<=125) {
        unsigned ch=(unsigned char)*s++;if(ch<32 || ch>90)ch='?';
        const uint8_t *r=sp_oled_font_small[ch-32];
        for(int a=0;a<5;a++)for(int b=0;b<3;b++)if(r[a]&(1u<<(2-b)))pixel(f,x+b,y+a);
        x+=4;
    }
}
int sp_p6_pattern_transport_v552_draw(uint8_t frame[1024]) {
    SpP6PatternTransportView v;
    if(!frame || !sp_p6_pattern_transport_v552_view(&v))return 0;
    memset(frame,0,1024);
    char title[]="PATTERN A";title[8]=(char)('A'+v.bank);text(frame,3,1,title);line(frame,3,9,122);
    for(unsigned pad=1;pad<=16;pad++) {
        int x=3+(int)((pad-1)%4)*30,y=13+(int)((pad-1)/4)*10;
        char id[4]={(char)('A'+v.bank),(char)('0'+pad/10),(char)('0'+pad%10),0};
        box(frame,x,y,28,8);text(frame,x+2,y+2,id);
        if(!(v.available&(1u<<(pad-1))))text(frame,x+21,y+2,"X");
    }
    line(frame,3,55,122);text(frame,3,58,"PAD:SELECT EXIT:BACK");return 1;
}
