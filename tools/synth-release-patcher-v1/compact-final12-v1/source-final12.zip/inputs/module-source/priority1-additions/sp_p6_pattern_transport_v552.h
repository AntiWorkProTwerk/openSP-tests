#ifndef SP_P6_PATTERN_TRANSPORT_V552_H
#define SP_P6_PATTERN_TRANSPORT_V552_H
#include "sp_synth_ui.h"
#include <stdint.h>
typedef struct {uint32_t bank,available,current,next,transport;} SpP6PatternTransportView;
int sp_p6_pattern_transport_v552_button(void *,uint32_t,int);
int sp_p6_pattern_transport_v552_turn(void *,int32_t,int);
int sp_p6_pattern_transport_v552_pad(const sp_ui_event *);
void sp_p6_pattern_transport_v552_edge(void);
int sp_p6_pattern_transport_v552_view(SpP6PatternTransportView *);
int sp_p6_pattern_transport_v552_draw(uint8_t [1024]);
#endif
