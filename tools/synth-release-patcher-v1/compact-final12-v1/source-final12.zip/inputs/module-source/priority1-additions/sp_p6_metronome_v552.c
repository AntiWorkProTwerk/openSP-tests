#include <stdint.h>

/* These are the two stock beat-dispatch callsites, not a second clock. The
 * original callback retains its native bookkeeping and configured PTN click.
 * Eligibility is read from the existing compact capture owner, never supplied
 * by a control event or a writable native recording-mode flag. */
extern int sp_p6_capture_v552_metronome_active(void);
typedef uint32_t (*Native)(uint32_t,uint32_t,uint32_t,uint32_t);
static uint32_t native(uint32_t address,uint32_t a,uint32_t b,uint32_t c) {
    return ((Native)(uintptr_t)(address|1u))(a,b,c,0);
}
uint32_t sp_p6_metronome_v552_beat(const void *event) {
    uint32_t original=native(0x80011788,(uint32_t)(uintptr_t)event,0,0);
    if(!sp_p6_capture_v552_metronome_active())return original;
    uint32_t mode=native(0x800D61F0,0x80591ADC,9,0);
    if(mode>3 || mode==2)return original;
    uint32_t level=native(0x800D61F0,0x80591ADC,10,0);
    if(level<1 || level>5)return original;
    /* Native accent and ordinary click restart their same waveform cursor.
     * If the original callback already emitted this beat, the second reset
     * still leaves exactly one waveform in the native mixer. */
    uint16_t flags=*(const uint16_t *)((uintptr_t)event+6);
    (void)native(flags&4u?0x80011BA8:0x80011BD0,level,0,0);
    return original;
}
