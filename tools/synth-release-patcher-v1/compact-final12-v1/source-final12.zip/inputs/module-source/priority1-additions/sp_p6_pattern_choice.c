#include "sp_p6_pattern_choice.h"
void sp_p6_pattern_choice_bind(SpP6PatternChoice *s,uint32_t page,uint32_t visit,uint32_t project,uint32_t bank) {
    if(!s || bank>9)return;
    if(s->page!=page || s->visit!=visit || s->project!=project)
        *s=(SpP6PatternChoice){page,visit,project,bank,0,0,0};
}
int sp_p6_pattern_choice_toggle(SpP6PatternChoice *s,int blocked) {
    if(!s)return 0;
    if(s->pressed)return 1;
    s->pressed=1;
    if(blocked){s->opened=0;return 1;}
    s->opened=!s->opened;return 1;
}
void sp_p6_pattern_choice_close(SpP6PatternChoice *s) {if(s)s->opened=0;}
int sp_p6_pattern_choice_turn(SpP6PatternChoice *s,int32_t delta) {
    if(!s || !s->opened || !delta)return 0;
    if(delta<0){if(s->bank)--s->bank;}else if(s->bank<9)++s->bank;
    return 1;
}
int sp_p6_pattern_choice_pad(SpP6PatternChoice *s,uint32_t pad,int down,int available) {
    if(!s || pad<1 || pad>16)return 0;
    uint32_t bit=1u<<(pad-1);
    if(!down){if(!(s->captured&bit))return 0;s->captured&=~bit;return 1;}
    if(s->captured&bit)return 1;
    if(!s->opened)return 0;
    s->captured|=bit;
    if(!available)return 1;
    s->opened=0;return 2;
}
