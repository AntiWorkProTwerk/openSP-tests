#include "sp_synth_audio_internal.h"
#include <math.h>
#include <string.h>

static int overlap(const void *a,size_t an,const void *b,size_t bn) {
    uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
    if(an>UINTPTR_MAX-x || bn>UINTPTR_MAX-y)return 1;
    return x<y+bn && y<x+an;
}
int sp_app_audio_can_control(const SpSynthApp *a) {
    return a && (!a->audio_deferred || (a->audio_batch && !a->audio_pending &&
           !a->audio_faulted && !a->audio_batch->sealed && !a->audio_batch->failed));
}
static SpAppAudioOp *op(SpSynthApp *a,unsigned type,unsigned index,unsigned expected) {
    SpAppAudioBatch *b=a->audio_batch;
    if(!b || b->sealed || a->audio_pending || a->audio_faulted){a->audio_faulted=1;return 0;}
    if(b->failed || b->op_count>=SP_APP_AUDIO_OPS){b->failed=1;return 0;}
    SpAppAudioOp *out=&b->ops[b->op_count++];
    *out=(SpAppAudioOp){(uint16_t)type,(uint16_t)index,expected};return out;
}
int sp_app_audio_control(SpSynthApp *a,const SpSynthEvent *e) {
    if(!a->audio_deferred)return sp_synth_engine_control(&a->engine,e,1);
    SpAppAudioBatch *b=a->audio_batch;
    if(!b || b->control_count>=SP_APP_AUDIO_EVENTS){if(b)b->failed=1;else a->audio_faulted=1;return 0;}
    if(!op(a,SP_APP_AUDIO_CONTROL,b->control_count,1))return 0;
    b->controls[b->control_count++]=*e;return 1;
}
static int patch(SpSynthApp *a,const SpSynthPatch *p,int edit) {
    if(!a->audio_deferred)return edit?sp_synth_engine_edit_patch(&a->engine,p):sp_synth_engine_load_patch(&a->engine,p);
    SpAppAudioBatch *b=a->audio_batch;
    if(!b || b->patch_count>=SP_APP_AUDIO_PATCHES){if(b)b->failed=1;else a->audio_faulted=1;return 0;}
    int expected=sp_synth_patch_valid(p) && (edit?sp_synth_patch_same_structure(&a->edited.patch,p):p->unison<=a->voice_limit);
    if(!op(a,edit?SP_APP_AUDIO_EDIT:SP_APP_AUDIO_LOAD,b->patch_count,(unsigned)expected))return 0;
    b->patches[b->patch_count++]=*p;return expected;
}
int sp_app_audio_load(SpSynthApp *a,const SpSynthPatch *p){return patch(a,p,0);}
int sp_app_audio_edit(SpSynthApp *a,const SpSynthPatch *p){return patch(a,p,1);}
void sp_app_audio_panic(SpSynthApp *a) {
    if(!a->audio_deferred)sp_synth_engine_panic(&a->engine);
    else (void)op(a,SP_APP_AUDIO_PANIC,0,1);
}
int sp_synth_app_audio_transfer(SpSynthApp *a,SpAppAudioState *s) {
    if(!a || !s || a->audio_deferred || a->event_count || a->batch_failed ||
       !a->voice_limit || overlap(a,sizeof(*a),s,sizeof(*s)))return 0;
    SpSynthStats stats;sp_synth_engine_stats(&a->engine,&stats);
    if(stats.voice_limit!=a->voice_limit)return 0;
    float gain=a->ui.page==SP_UI_BROWSER?a->preview_level:1;
    if(!isfinite(gain) || gain<0 || gain>1)return 0;
    s->engine=a->engine;s->sequence=0;s->faulted=0;s->gain=gain;
    a->audio_deferred=1;a->audio_sequence=0;return 1;
}
int sp_synth_app_audio_begin(SpSynthApp *a,SpAppAudioBatch *b) {
    if(!a || !b || !a->audio_deferred || a->audio_pending || a->audio_batch ||
       a->audio_faulted || a->audio_sequence==UINT32_MAX || overlap(a,sizeof(*a),b,sizeof(*b)))return 0;
    memset(b,0,sizeof(*b));b->sequence=++a->audio_sequence;a->audio_batch=b;return 1;
}
int sp_synth_app_audio_seal(SpSynthApp *a,uint32_t frames) {
    if(!a || !a->audio_deferred || !a->audio_batch || a->audio_pending ||
       !frames || frames>SP_SYNTH_MAX_FRAMES)return 0;
    SpAppAudioBatch *b=a->audio_batch;
    if(b->sealed)return 0;
    if(!sp_app_audio_prepare(a,frames))b->failed=1;
    b->event_count=a->event_count;
    memcpy(b->events,a->events,a->event_count*sizeof(*a->events));
    b->frames=frames;b->gain=a->ui.page==SP_UI_BROWSER?a->preview_level:1;
    b->sealed=1;a->audio_batch=0;a->audio_pending=1;
    a->event_count=0;a->batch_failed=0;
    if(b->failed)a->audio_faulted=1;
    return !b->failed;
}
int sp_synth_app_audio_complete(SpSynthApp *a,uint32_t sequence,int success) {
    if(!a || !a->audio_deferred || !a->audio_pending || sequence!=a->audio_sequence)return 0;
    a->audio_pending=0;if(!success)a->audio_faulted=1;
    if(!a->audio_faulted && a->capture_cancel_state==SP_APP_CANCEL_AUDIO &&
       sequence==a->capture_cancel_sequence)a->capture_cancel_state=SP_APP_CANCEL_READY;
    if(!a->audio_faulted && a->capture_tail_state==SP_APP_TAIL_AUDIO &&
       sequence==a->capture_tail_sequence)a->capture_tail_state=SP_APP_TAIL_RELEASING;
    return !a->audio_faulted;
}
static int failed(SpAppAudioState *s,float *out,uint32_t frames) {
    sp_synth_engine_panic(&s->engine);s->faulted=1;
    memset(out,0,2u*frames*sizeof(float));return 0;
}
int sp_synth_app_audio_render(SpAppAudioState *s,const SpAppAudioBatch *b,float *out) {
    if(!s || !b || !out || !b->frames || b->frames>SP_SYNTH_MAX_FRAMES)return 0;
    size_t bytes=2u*b->frames*sizeof(float);
    if(overlap(s,sizeof(*s),b,sizeof(*b)) || overlap(s,sizeof(*s),out,bytes) ||
       overlap(b,sizeof(*b),out,bytes))return 0;
    if(s->faulted || !b->sealed || b->failed || s->sequence==UINT32_MAX ||
       b->sequence!=s->sequence+1 || b->op_count>SP_APP_AUDIO_OPS ||
       b->patch_count>SP_APP_AUDIO_PATCHES || b->control_count>SP_APP_AUDIO_EVENTS ||
       b->event_count>SP_SYNTH_MAX_EVENTS || !isfinite(b->gain) || b->gain<0 || b->gain>1)
        return failed(s,out,b->frames);
    /* Validate all indices before applying any operation. Engine rejection
     * still panics: there is no rollback or automatic replay. */
    for(unsigned i=0;i<b->op_count;++i) {
        const SpAppAudioOp *o=&b->ops[i];
        if(o->type>SP_APP_AUDIO_PANIC || o->expected>1 ||
           (o->type==SP_APP_AUDIO_CONTROL && (o->index>=b->control_count || !o->expected)) ||
           ((o->type==SP_APP_AUDIO_LOAD || o->type==SP_APP_AUDIO_EDIT) && o->index>=b->patch_count) ||
           (o->type==SP_APP_AUDIO_PANIC && (o->index || !o->expected)))return failed(s,out,b->frames);
    }
    for(unsigned i=0;i<b->op_count;++i) {
        const SpAppAudioOp *o=&b->ops[i];int result=1;
        switch(o->type) {
        case SP_APP_AUDIO_CONTROL:result=sp_synth_engine_control(&s->engine,&b->controls[o->index],1);break;
        case SP_APP_AUDIO_LOAD:result=sp_synth_engine_load_patch(&s->engine,&b->patches[o->index]);break;
        case SP_APP_AUDIO_EDIT:result=sp_synth_engine_edit_patch(&s->engine,&b->patches[o->index]);break;
        case SP_APP_AUDIO_PANIC:sp_synth_engine_panic(&s->engine);break;
        }
        if((unsigned)result!=o->expected)return failed(s,out,b->frames);
    }
    if(!sp_synth_engine_render(&s->engine,out,b->frames,b->events,b->event_count))return failed(s,out,b->frames);
    for(unsigned i=0;i<2*b->frames;++i)out[i]*=b->gain;
    s->sequence=b->sequence;s->gain=b->gain;return 1;
}
int sp_synth_app_audio_continue(SpAppAudioState *s,float *out,uint32_t frames) {
    if(!s || !out || !frames || frames>SP_SYNTH_MAX_FRAMES ||
       overlap(s,sizeof(*s),out,2u*frames*sizeof(float)))return 0;
    if(s->faulted || !isfinite(s->gain) || s->gain<0 || s->gain>1)return failed(s,out,frames);
    if(!sp_synth_engine_render(&s->engine,out,frames,0,0))return failed(s,out,frames);
    for(unsigned i=0;i<2*frames;++i)out[i]*=s->gain;
    return 1;
}
