#include "sp_synth_bindings.h"
#include "sp_synth_audio_internal.h"
#include <math.h>
#include <string.h>
int sp_app_apply_patch(SpSynthApp *a,const SpPreset *p,int preserve_keys);
void sp_app_release_pads(SpSynthApp *a);
#if defined(__GNUC__)
#define SP_UI_NOINLINE __attribute__((noinline))
#else
#define SP_UI_NOINLINE
#endif
static unsigned norm(float value,float lo,float hi) {
    float x=(value-lo)/(hi-lo);return x<=0?0:x>=1?16383:(unsigned)(x*16383+.5f);
}
static unsigned choice(unsigned value,unsigned last) {return last?(value*16383u+last/2u)/last:0;}
static unsigned discrete(unsigned value,unsigned last) {return (value*last+8191u)/16383u;}
static void label(char *out,size_t capacity,const char *value) {
    size_t n=0;while(n+1<capacity && value[n]){out[n]=value[n];++n;}out[n]=0;
}
static void format(char *out,size_t capacity,float value,unsigned decimals,const char *suffix) {
    /* All bound values have magnitude <=21600; no libc floating formatter. */
    if(!capacity)return;
    if(!isfinite(value) || fabsf(value)>1000000 || decimals>2){label(out,capacity,"?");return;}
    unsigned scale=decimals==2?100:decimals==1?10:1;
    unsigned fixed=(unsigned)(fabsf(value)*(float)scale+.5f);
    char reversed[16];unsigned n=0,whole=fixed/scale;
    do {reversed[n++]=(char)('0'+whole%10);whole/=10;}while(whole);
    size_t used=0;if(value<0 && used+1<capacity)out[used++]='-';
    while(n && used+1<capacity)out[used++]=reversed[--n];
    if(decimals && used+1<capacity)out[used++]='.';
    for(unsigned divisor=scale/10;divisor;divisor/=10)if(used+1<capacity)out[used++]=(char)('0'+(fixed/divisor)%10);
    unsigned i=0;while(suffix[i] && used+1<capacity)out[used++]=suffix[i++];out[used]=0;
}
static int logarithmic(unsigned id) {
    return id==SP_PARAM_CUTOFF || id==SP_PARAM_LFO1_RATE || id==SP_PARAM_LFO2_RATE;
}
static int time_parameter(unsigned id) {
    return id==SP_PARAM_AMP_ATTACK || id==SP_PARAM_AMP_DECAY || id==SP_PARAM_AMP_RELEASE ||
        id==SP_PARAM_MOD_ATTACK || id==SP_PARAM_MOD_DECAY || id==SP_PARAM_MOD_RELEASE || id==SP_PARAM_GLIDE;
}
static int macro_target(unsigned id) {return id<SP_PARAM_COUNT && id!=SP_PARAM_GAIN && (id<SP_PARAM_MACRO1 || id>SP_PARAM_MACRO3);}
static unsigned target_at(unsigned index) {
    for(unsigned id=0;id<SP_PARAM_COUNT;++id)if(macro_target(id)){if(!index)return id;--index;}
    return 0;
}
static unsigned target_index(unsigned id) {
    unsigned index=0;for(unsigned i=0;i<id;++i)index+=(unsigned)macro_target(i);return index;
}
static float denorm(unsigned id,unsigned value) {
    SpSynthParamRange r;sp_synth_param_range((SpSynthParam)id,&r);
    if(!value)return r.minimum;
    if(value==16383)return r.maximum;
    float x=value/16383.0f;
    if(time_parameter(id))return .001f*(expf(x*logf(1+r.maximum/.001f))-1);
    return logarithmic(id)?expf(logf(r.minimum)+x*logf(r.maximum/r.minimum)):r.minimum+x*(r.maximum-r.minimum);
}
static unsigned normalized(unsigned id,float value) {
    SpSynthParamRange r;sp_synth_param_range((SpSynthParam)id,&r);
    if(time_parameter(id))return norm(logf(1+value/.001f),0,logf(1+r.maximum/.001f));
    return logarithmic(id)?norm(logf(value),logf(r.minimum),logf(r.maximum)):norm(value,r.minimum,r.maximum);
}
static SP_UI_NOINLINE sp_ui_binding continuous(const SpSynthApp *a,unsigned id,const char *name) {
    sp_ui_binding b={0};float value;SpSynthParamRange r;
    sp_synth_patch_get_param(&a->edited.patch,(SpSynthParam)id,&value);sp_synth_param_range((SpSynthParam)id,&r);
    b.parameter_id=(uint16_t)id;b.value=(uint16_t)normalized(id,value);label(b.label,16,name);
    if(id==SP_PARAM_CUTOFF)format(b.display,16,value>=1000?value/1000:value,value>=1000?2:0,value>=1000?"kHz":"Hz");
    else if(!strcmp(r.unit,"seconds"))format(b.display,16,value<1?value*1000:value,value<1?0:2,value<1?"ms":"s");
    else format(b.display,16,value,2,"");
    b.step=64;return b;
}
static SP_UI_NOINLINE sp_ui_binding enumerated(unsigned id,unsigned value,unsigned last,const char *name,const char *display) {
    sp_ui_binding b={0};b.parameter_id=(uint16_t)id;b.value=(uint16_t)choice(value,last);
    b.step=(uint16_t)(last?(16383u+last-1u)/last:1);label(b.label,16,name);
    if(display)label(b.display,16,display);else format(b.display,16,(float)value,0,"");return b;
}
static SP_UI_NOINLINE sp_ui_binding app_value(unsigned id,float value,float lo,float hi,const char *name) {
    sp_ui_binding b={0};b.parameter_id=(uint16_t)id;b.value=(uint16_t)norm(value,lo,hi);b.step=128;
    label(b.label,16,name);format(b.display,16,value,2,"");return b;
}
static SP_UI_NOINLINE void bank(SpSynthApp *a,sp_ui_page page,unsigned index,unsigned count,sp_ui_binding x,sp_ui_binding y,sp_ui_binding z) {
    sp_ui_binding b[3]={x,y,z};sp_ui_set_bank(&a->ui,page,(uint8_t)index,(uint8_t)count,b);
}
#define C(id,name) continuous(a,id,name)
#define E(id,value,last,name,display) enumerated(id,value,last,name,display)
    static const char *const waves[]={"SINE","TRIANGLE","SAW","PULSE"};
    static const char *const modes[]={"LP12","LP24","HP","BP","NOTCH"};
    static const char *const scales[]={"CHROMATIC","MAJOR","MINOR","DORIAN","MIXOLYDIAN","PENTATONIC","MINOR PENTA"};
    static const char *const roots[]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
    static const char *const lfos[]={"SINE","TRIANGLE","SAW","SQUARE","SAMPLE HOLD"};
    static const char *const sources[]={"OFF","LFO 1","LFO 2","ENV 2","AMP ENV","VELOCITY","KEY","PRESSURE","MOD WHEEL","RANDOM","MACRO 1","MACRO 2","MACRO 3"};
    static const char *const destinations[]={"OFF","PITCH","OSC 1 PITCH","OSC 2 PITCH","CUTOFF","WIDTH 1","WIDTH 2","AMP","PAN","OSC 1 LEVEL","OSC 2 LEVEL","SUB LEVEL","NOISE LEVEL","RESONANCE","DRIVE"};
    static const char *const parameters[]={"OSC1 TUNE","OSC1 CENTS","OSC1 LEVEL","WIDTH 1","OSC2 TUNE","OSC2 CENTS","OSC2 LEVEL","WIDTH 2",
        "SUB LEVEL","NOISE LEVEL","NOISE COLOR","CUTOFF","RESONANCE","FILTER ENV","KEY TRACK","DRIVE","AMP ATTACK","AMP DECAY","AMP SUSTAIN","AMP RELEASE","AMP CURVE",
        "ENV2 ATTACK","ENV2 DECAY","ENV2 SUSTAIN","ENV2 RELEASE","ENV2 CURVE","LFO1 RATE","LFO1 BEATS","LFO1 PHASE","LFO2 RATE","LFO2 BEATS","LFO2 PHASE",
        "GLIDE","DETUNE","SPREAD","VARIATION","GAIN","PAN","VELOCITY","BEND RANGE","MACRO 1","MACRO 2","MACRO 3","ROUTE 1","ROUTE 2","ROUTE 3","ROUTE 4","ROUTE 5","ROUTE 6","ROUTE 7","ROUTE 8"};

static SP_UI_NOINLINE void refresh_play(SpSynthApp *a) {
    const SpSynthPatch *p=&a->edited.patch;
    sp_ui_binding macro[3];
    for(unsigned i=0;i<3;++i) {
        macro[i]=app_value(SP_BIND_MACRO1+i,p->macro[i],0,1,a->edited.macro_controls[i].label);
        format(macro[i].display,16,p->macro[i]*100,0,"%");
    }
    bank(a,SP_UI_PLAY,0,1,macro[0],macro[1],macro[2]);
}

static SP_UI_NOINLINE void refresh_osc(SpSynthApp *a) {
    const SpSynthPatch *p=&a->edited.patch;
    bank(a,SP_UI_OSC,0,6,E(SP_BIND_OSC1_WAVE,p->osc[0].wave,3,"WAVE 1",waves[p->osc[0].wave]),C(SP_PARAM_OSC1_PW,"WIDTH"),C(SP_PARAM_OSC1_LEVEL,"LEVEL"));
    bank(a,SP_UI_OSC,1,6,C(SP_PARAM_OSC1_SEMITONES,"SEMITONES"),C(SP_PARAM_OSC1_CENTS,"CENTS"),C(SP_PARAM_VARIATION,"VARIATION"));
    bank(a,SP_UI_OSC,2,6,E(SP_BIND_OSC2_WAVE,p->osc[1].wave,3,"WAVE 2",waves[p->osc[1].wave]),C(SP_PARAM_OSC2_PW,"WIDTH"),C(SP_PARAM_OSC2_LEVEL,"LEVEL"));
    bank(a,SP_UI_OSC,3,6,C(SP_PARAM_OSC2_SEMITONES,"SEMITONES"),C(SP_PARAM_OSC2_CENTS,"CENTS"),C(SP_PARAM_VARIATION,"VARIATION"));
    bank(a,SP_UI_OSC,4,6,E(SP_BIND_SUB_WAVE,p->sub_wave,3,"SUB WAVE",waves[p->sub_wave]),C(SP_PARAM_SUB_LEVEL,"SUB LEVEL"),C(SP_PARAM_NOISE_LEVEL,"NOISE"));
    bank(a,SP_UI_OSC,5,6,C(SP_PARAM_NOISE_LEVEL,"NOISE"),C(SP_PARAM_NOISE_COLOR,"COLOR"),C(SP_PARAM_SUB_LEVEL,"SUB LEVEL"));
}

static SP_UI_NOINLINE void refresh_filter_envelopes(SpSynthApp *a) {
    const SpSynthPatch *p=&a->edited.patch;
    bank(a,SP_UI_FILTER,0,2,C(SP_PARAM_CUTOFF,"CUTOFF"),C(SP_PARAM_RESONANCE,"RESONANCE"),C(SP_PARAM_FILTER_ENV,"ENV AMT"));
    bank(a,SP_UI_FILTER,1,2,E(SP_BIND_FILTER_MODE,p->filter_mode,4,"MODEL",modes[p->filter_mode]),C(SP_PARAM_DRIVE,"DRIVE"),C(SP_PARAM_KEY_TRACK,"KEY TRACK"));
    bank(a,SP_UI_AMP,0,3,C(SP_PARAM_AMP_ATTACK,"ATTACK"),C(SP_PARAM_AMP_DECAY,"DECAY"),C(SP_PARAM_AMP_SUSTAIN,"SUSTAIN"));
    bank(a,SP_UI_AMP,1,3,C(SP_PARAM_AMP_RELEASE,"RELEASE"),C(SP_PARAM_AMP_CURVE,"CURVE"),C(SP_PARAM_VELOCITY,"VELOCITY"));
    bank(a,SP_UI_AMP,2,3,E(SP_BIND_AMP_CYCLE,p->amp_cycle,1,"CYCLE",p->amp_cycle?"ON":"OFF"),C(SP_PARAM_GAIN,"PATCH GAIN"),C(SP_PARAM_PAN,"PAN"));
    bank(a,SP_UI_ENV2,0,2,C(SP_PARAM_MOD_ATTACK,"ATTACK"),C(SP_PARAM_MOD_DECAY,"DECAY"),C(SP_PARAM_MOD_SUSTAIN,"SUSTAIN"));
    bank(a,SP_UI_ENV2,1,2,C(SP_PARAM_MOD_RELEASE,"RELEASE"),C(SP_PARAM_MOD_CURVE,"CURVE"),E(SP_BIND_MOD_CYCLE,p->mod_cycle,1,"CYCLE",p->mod_cycle?"ON":"OFF"));
}

static SP_UI_NOINLINE void refresh_mod_voice(SpSynthApp *a) {
    const SpSynthPatch *p=&a->edited.patch;
    for(unsigned i=0;i<8;++i)bank(a,SP_UI_MOD,i,8,
        E(SP_BIND_ROUTE_SOURCE+2*i,p->route[i].source,SP_MOD_SOURCE_COUNT-1,"SOURCE",sources[p->route[i].source]),
        E(SP_BIND_ROUTE_SOURCE+2*i+1,p->route[i].destination,SP_DEST_COUNT-1,"DESTINATION",destinations[p->route[i].destination]),C(SP_PARAM_ROUTE1_AMOUNT+i,"AMOUNT"));
    bank(a,SP_UI_VOICE,0,3,E(SP_BIND_MODE,p->mode,1,"MODE",p->mode?"MONO":"POLY"),E(SP_BIND_UNISON,p->unison==4?2:p->unison==2?1:0,2,"UNISON",p->unison==4?"4":p->unison==2?"2":"1"),E(SP_BIND_LEGATO,p->legato,1,"LEGATO",p->legato?"ON":"OFF"));
    bank(a,SP_UI_VOICE,1,3,C(SP_PARAM_GLIDE,"GLIDE"),C(SP_PARAM_VARIATION,"VARIATION"),C(SP_PARAM_BEND_RANGE,"BEND RANGE"));
    bank(a,SP_UI_VOICE,2,3,C(SP_PARAM_UNISON_DETUNE,"DETUNE"),C(SP_PARAM_UNISON_SPREAD,"SPREAD"),C(SP_PARAM_PAN,"PAN"));
}

static SP_UI_NOINLINE void refresh_lfo_keys(SpSynthApp *a) {
    const SpSynthPatch *p=&a->edited.patch;
    for(unsigned i=0;i<2;++i) {
        unsigned first=i?SP_PARAM_LFO2_RATE:SP_PARAM_LFO1_RATE;unsigned binding=i?SP_BIND_LFO2_WAVE:SP_BIND_LFO1_WAVE;
        bank(a,SP_UI_LFO,2*i,4,E(binding,p->lfo[i].wave,SP_LFO_SAMPLE_HOLD,"WAVE",lfos[p->lfo[i].wave]),C(first,"RATE"),C(first+1,"BEATS"));
        bank(a,SP_UI_LFO,2*i+1,4,E(binding+1,p->lfo[i].tempo_sync,1,"SYNC",p->lfo[i].tempo_sync?"ON":"OFF"),E(binding+2,p->lfo[i].retrigger,1,"RETRIGGER",p->lfo[i].retrigger?"ON":"OFF"),C(first+2,"START PHASE"));
    }
    char channel[4];format(channel,4,(float)a->pad_channel+1,0,"");
    bank(a,SP_UI_KEYS,0,1,E(SP_BIND_ROOT,a->root,11,"ROOT",roots[a->root]),E(SP_BIND_SCALE,a->scale,SP_APP_SCALE_COUNT-1,"SCALE",scales[a->scale]),E(SP_BIND_PAD_CHANNEL,a->pad_channel,15,"MIDI CH",channel));
}

static SP_UI_NOINLINE void refresh_macros_capture(SpSynthApp *a) {
    for(unsigned i=0;i<3;++i) {
        const SpPresetMacro *m=&a->edited.macro_controls[i];SpSynthParamRange r;sp_synth_param_range((SpSynthParam)m->parameter,&r);
        sp_ui_binding low=app_value(SP_BIND_MACRO_TARGET+3*i+1,m->minimum,r.minimum,r.maximum,"LOW");
        sp_ui_binding high=app_value(SP_BIND_MACRO_TARGET+3*i+2,m->maximum,r.minimum,r.maximum,"HIGH");
        low.value=(uint16_t)normalized(m->parameter,m->minimum);high.value=(uint16_t)normalized(m->parameter,m->maximum);
        low.step=high.step=64;
        bank(a,SP_UI_MACROS,i,3,E(SP_BIND_MACRO_TARGET+3*i,target_index(m->parameter),SP_PARAM_COUNT-5,"TARGET",parameters[m->parameter]),low,high);
    }
    bank(a,SP_UI_CAPTURE_READY,0,2,E(SP_BIND_CAPTURE_MODE,a->capture.mode,1,"LENGTH",a->capture.mode?"BARS":"SECONDS"),
         app_value(a->capture.mode?SP_BIND_CAPTURE_BARS:SP_BIND_CAPTURE_SECONDS,a->capture.mode?a->capture.bars:a->capture.seconds,1,a->capture.mode?64:120,"DURATION"),
         E(SP_BIND_COUNT_IN,a->capture.count_in_bars,4,"COUNT IN",0));
    bank(a,SP_UI_CAPTURE_READY,1,2,E(SP_BIND_CAPTURE_TAIL,a->capture.include_release_tail,1,"TAIL",a->capture.include_release_tail?"ON":"OFF"),
         app_value(SP_BIND_TEMPO,a->capture.tempo_bpm,20,300,"BPM"),C(SP_PARAM_AMP_RELEASE,"RELEASE"));}

void sp_synth_app_refresh(SpSynthApp *a) {
    if(!a)return;
    refresh_play(a);
    refresh_osc(a);
    refresh_filter_envelopes(a);
    refresh_mod_voice(a);
    refresh_lfo_keys(a);
    refresh_macros_capture(a);
    a->bindings_dirty=0;++a->refresh_count;
}
#undef C
#undef E
int sp_app_parameter(SpSynthApp *a,unsigned id,unsigned value) {
    if(!a || !sp_app_audio_can_control(a) || value>16383)return 0;
    a->bindings_dirty=1;
    float x=value/16383.0f;SpPreset p=a->edited;SpSynthPatch *s=&p.patch;
    if(id<SP_PARAM_COUNT)sp_synth_patch_set_param(s,(SpSynthParam)id,denorm(id,value));
    else if(id>=SP_BIND_MACRO1 && id<=SP_BIND_MACRO3) {
        unsigned macro=id-SP_BIND_MACRO1;SpSynthParam target;float native;
        if(!sp_synth_preset_macro_value(&p,macro,x,&target,&native))return 0;
        s->macro[macro]=x;sp_synth_patch_set_param(s,target,native);
    } else if(id>=SP_BIND_ROUTE_SOURCE && id<SP_BIND_ROUTE_SOURCE+16) {
        unsigned slot=(id-SP_BIND_ROUTE_SOURCE)/2;
        if((id-SP_BIND_ROUTE_SOURCE)&1)s->route[slot].destination=discrete(value,SP_DEST_COUNT-1);
        else s->route[slot].source=discrete(value,SP_MOD_SOURCE_COUNT-1);
    } else if(id>=SP_BIND_MACRO_TARGET && id<SP_BIND_MACRO_TARGET+9) {
        unsigned macro=(id-SP_BIND_MACRO_TARGET)/3,part=(id-SP_BIND_MACRO_TARGET)%3;SpPresetMacro *m=&p.macro_controls[macro];
        SpSynthParamRange r;
        if(!part) {
            unsigned target=target_at(discrete(value,SP_PARAM_COUNT-5));
            m->parameter=target;sp_synth_param_range((SpSynthParam)target,&r);m->minimum=r.minimum;m->maximum=r.maximum;m->logarithmic=logarithmic(target);
        } else {
            float v=denorm(m->parameter,value);
            if(part==1)m->minimum=v;else m->maximum=v;
        }
    } else switch(id) {
    case SP_BIND_OSC1_WAVE:s->osc[0].wave=discrete(value,3);break;
    case SP_BIND_OSC2_WAVE:s->osc[1].wave=discrete(value,3);break;
    case SP_BIND_SUB_WAVE:s->sub_wave=discrete(value,3);break;
    case SP_BIND_FILTER_MODE:s->filter_mode=discrete(value,4);break;
    case SP_BIND_MODE:s->mode=discrete(value,1);break;
    case SP_BIND_UNISON:s->unison=1u<<discrete(value,2);break;
    case SP_BIND_LEGATO:s->legato=discrete(value,1);break;
    case SP_BIND_AMP_CYCLE:s->amp_cycle=discrete(value,1);break;
    case SP_BIND_MOD_CYCLE:s->mod_cycle=discrete(value,1);break;
    case SP_BIND_LFO1_WAVE:case SP_BIND_LFO2_WAVE:s->lfo[id==SP_BIND_LFO2_WAVE].wave=discrete(value,SP_LFO_SAMPLE_HOLD);break;
    case SP_BIND_LFO1_SYNC:case SP_BIND_LFO2_SYNC:s->lfo[id==SP_BIND_LFO2_SYNC].tempo_sync=discrete(value,1);break;
    case SP_BIND_LFO1_RETRIGGER:case SP_BIND_LFO2_RETRIGGER:s->lfo[id==SP_BIND_LFO2_RETRIGGER].retrigger=discrete(value,1);break;
    case SP_BIND_ROOT:case SP_BIND_SCALE:case SP_BIND_PAD_CHANNEL:
        /* Release all physical pad identities before changing their pitch map. */
        sp_app_release_pads(a);
        if(id==SP_BIND_ROOT)a->root=(uint8_t)discrete(value,11);
        else if(id==SP_BIND_SCALE)a->scale=(uint8_t)discrete(value,SP_APP_SCALE_COUNT-1);
        else a->pad_channel=(uint8_t)discrete(value,15);
        return 1;
    case SP_BIND_CAPTURE_MODE:a->capture.mode=discrete(value,1);return 1;
    case SP_BIND_CAPTURE_SECONDS:a->capture.seconds=1+119*x;return 1;
    case SP_BIND_CAPTURE_BARS:a->capture.bars=1+63*x;return 1;
    case SP_BIND_COUNT_IN:a->capture.count_in_bars=discrete(value,4);return 1;
    case SP_BIND_CAPTURE_TAIL:a->capture.include_release_tail=discrete(value,1);return 1;
    case SP_BIND_TEMPO: {
        a->capture.tempo_bpm=20+280*x;SpSynthEvent e={0,SP_EVENT_TEMPO,0,0,a->capture.tempo_bpm,0};return sp_app_audio_control(a,&e);
    }
    default:return 0;
    }
    return sp_app_apply_patch(a,&p,1);
}
