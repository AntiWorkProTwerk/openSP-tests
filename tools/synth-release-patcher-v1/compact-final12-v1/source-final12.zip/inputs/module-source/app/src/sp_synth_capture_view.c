#include "sp_synth_app.h"
#include <math.h>
#include <string.h>

/* Requested settings, frozen with START. Two decimals, without trailing zeroes;
 * no floating printf or dependency on native recorder storage. */
static void number(char out[8],float x,float maximum) {
    if(!isfinite(x) || x<0 || x>maximum){strcpy(out,"?");return;}
    unsigned n=(unsigned)(x*100.0f+.5f),whole=n/100,count=0,used=0;char digits[4];
    do{digits[count++]=(char)('0'+whole%10);whole/=10;}while(whole);
    while(count)out[used++]=digits[--count];
    if(n%100){out[used++]='.';out[used++]=(char)('0'+n%100/10);if(n%10)out[used++]=(char)('0'+n%10);}
    out[used]=0;
}
int sp_synth_app_capture_view(const SpSynthApp *a,sp_ui_view *v) {
    if(!a || !v)return 0;
    if(!a->capture_cancel_state && a->ui.busy && a->ui.pending==SP_UI_CMD_CAPTURE_STOP) {
        memset(v,0,sizeof(*v));v->busy=1;v->take_held=a->ui.take_held;v->row_count=2;
        strcpy(v->header,"FINALIZING TAKE");strcpy(v->hero,a->ui.tail_cut_reason?"TAIL CUT":"PLEASE WAIT");
        strcpy(v->rows[0],"ENDING RECORDING");strcpy(v->rows[1],"CHOOSING A PAD NEXT");
        strcpy(v->footer,"NOTES PAUSED");return 1;
    }
    if(!a->capture_cancel_state && a->capture_tail_state && a->ui.page==SP_UI_RECORDING &&
       !a->capture_progress.fault) {
        const SpAppCaptureProgress *p=&a->capture_progress;
        uint64_t frames=p->accepted_frames>=a->capture_tail_start_frames?
            p->accepted_frames-a->capture_tail_start_frames:0;
        unsigned tenths=0;
        if(p->sample_rate_hz) {
            uint64_t maximum=(uint64_t)p->sample_rate_hz*5;
            if(frames>maximum)frames=maximum;
            tenths=(unsigned)(frames*10/p->sample_rate_hz);
        }
        memset(v,0,sizeof(*v));v->take_held=a->ui.take_held;v->row_count=2;
        strcpy(v->header,"RELEASE TAIL");strcpy(v->hero,"00:00.0 / 5s");
        v->hero[4]=(char)('0'+tenths/10);v->hero[6]=(char)('0'+tenths%10);
        strcpy(v->rows[0],"NEW NOTES PAUSED");strcpy(v->rows[1],"SYNTH RELEASE ONLY");
        strcpy(v->footer,"REC:CUT TAIL");return 1;
    }
    if(!a->capture_cancel_state && !(a->ui.busy && a->ui.pending==SP_UI_CMD_CAPTURE_START))return 0;
    memset(v,0,sizeof(*v));v->busy=a->ui.busy;v->take_held=a->ui.take_held;v->row_count=2;
    if(a->capture_cancel_state==SP_APP_CANCEL_FAILED) {
        if(a->capture_failure_details) {
            strcpy(v->header,"CAPTURE DETAILS");
            strcpy(v->hero,a->capture_failure_stage==SP_APP_CAPTURE_FAIL_PREPARE?"PREPARATION":
                a->capture_failure_stage==SP_APP_CAPTURE_FAIL_DISCARD?"RECORDER CLEANUP":
                a->capture_failure_stage==SP_APP_CAPTURE_FAIL_FINALIZE?"FINALIZING TAKE":"CANCEL REQUEST");
            strcpy(v->rows[0],"TAKE NOT CONFIRMED");strcpy(v->footer,"EXIT:BACK");
        } else {
            strcpy(v->header,"CAPTURE STOPPED");strcpy(v->hero,"TAKE NEEDS REVIEW");
            strcpy(v->rows[0],"RECORDING PAUSED");strcpy(v->footer,"VALUE:DETAILS");
        }
        strcpy(v->rows[1],"KEEP POWER ON");return 1;
    }
    if(a->capture_cancel_state) {
        strcpy(v->header,"CANCELING TAKE");strcpy(v->hero,"PLEASE WAIT");
        strcpy(v->rows[0],"RELEASING NOTES");strcpy(v->rows[1],"ENDING RECORDING");
        strcpy(v->footer,"CANCEL REQUESTED");return 1;
    }
    const SpAppCapture *plan=&a->capture_plan;const SpAppCaptureProgress *p=&a->capture_progress;
    strcpy(v->footer,"EXIT:CANCEL");
    if(p->has_rx_notice && !p->accepted_frames && p->count_in_frames &&
       plan->count_in_bars>=1 && plan->count_in_bars<=4) {
        unsigned beats=plan->count_in_bars*4,beat=0;
        /* floor(observed*beats/total) without overflowing the 64-bit product.
         * Clamp the final observation while waiting for the first accepted PCM. */
        uint64_t q=p->count_in_frames/beats,r=p->count_in_frames%beats;
        for(unsigned n=1;n<beats;++n)
            if(p->observed_frames>=q*n+(r*n+beats-1)/beats)beat=n;
        strcpy(v->header,"COUNT IN 1/1");v->header[9]=(char)('1'+beat/4);v->header[11]=(char)('0'+plan->count_in_bars);
        strcpy(v->hero,"BEAT 1 / 4");v->hero[5]=(char)('1'+beat%4);
        strcpy(v->rows[0],"PADS:PLAY ALONG");strcpy(v->rows[1],"NOT RECORDED YET");return 1;
    }
    char duration[8],tempo[8];
    number(duration,plan->mode?plan->bars:plan->seconds,plan->mode?64:120);
    number(tempo,plan->tempo_bpm,300);
    /* Each number is at most six bytes; these composed strings fit hero[32]. */
    if(plan->mode==1){strcpy(v->hero,duration);strcat(v->hero," BARS / ");strcat(v->hero,tempo);strcat(v->hero," BPM");}
    else if(plan->mode==0){strcpy(v->hero,duration);strcat(v->hero," SECONDS");}
    else strcpy(v->hero,"INVALID LENGTH");
    if(p->accepted_frames) {
        strcpy(v->header,"STARTING TAKE");strcpy(v->rows[0],"CAPTURE IN PROGRESS");
        strcpy(v->rows[1],"WAITING FOR START");return 1;
    }
    strcpy(v->header,"PREPARING TAKE");
    if(plan->count_in_bars<=4){strcpy(v->rows[0],plan->count_in_bars==1?"COUNT IN: 1 BAR":"COUNT IN: 0 BARS");
        v->rows[0][10]=(char)('0'+plan->count_in_bars);}
    else strcpy(v->rows[0],"COUNT IN: ?");
    strcpy(v->rows[1],plan->include_release_tail?"TAIL: ON / MAX 5s":"TAIL: OFF");return 1;
}
