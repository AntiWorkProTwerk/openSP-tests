#include "sp_synth_preview.h"
#include <math.h>
#include <stddef.h>
#include <string.h>
/* plot_valid consumes former tail padding; every preceding field stays put. */
_Static_assert(sizeof(sp_ui_view)==380,"view ABI size");
_Static_assert(offsetof(sp_ui_view,elapsed_ms)==372,"view elapsed ABI");
_Static_assert(offsetof(sp_ui_view,row_selection)==376,"view row ABI");
_Static_assert(offsetof(sp_ui_view,show_focus)==377,"view focus ABI");
_Static_assert(offsetof(sp_ui_view,plot_valid)==378,"view plot ABI");
static uint8_t ordinate(float value) {
    if(!isfinite(value) || value>=1.0f)return 255;
    if(value<=0.0f)return 0;
    return (uint8_t)(value*255.0f+.5f);
}
static float oscillator(unsigned wave,float width,float ratio,float position) {
    float phase=2.0f*position*ratio;
    SpOsc osc={phase-floorf(phase)};
    return sp_synth_osc(&osc,(SpWave)wave,(261.625565f/48000.0f)*ratio,width);
}
static void wave(const SpSynthPatch *p,unsigned selected,uint8_t *out) {
    float ratio[2];
    for(unsigned j=0;j<2;++j)
        ratio[j]=sp_synth_exp2((p->osc[j].semitones+p->osc[j].cents*.01f)/12.0f);
    float scale=1.0f;
    if(selected==3) {
        float sum=p->osc[0].level+p->osc[1].level+p->sub_level;
        if(sum>1.0f)scale=1.0f/sum;
    }
    for(unsigned i=0;i<120;++i) {
        float x=(float)i/119.0f,y=0.0f;
        for(unsigned j=0;j<2;++j)if(selected==j || selected==3)
            y+=p->osc[j].level*oscillator(p->osc[j].wave,p->osc[j].pulse_width,ratio[j],x);
        if(selected==2 || selected==3)y+=p->sub_level*oscillator(p->sub_wave,.5f,.5f,x);
        out[i]=ordinate(.5f-.5f*y*scale);
    }
}
static void filter(const SpSynthPatch *p,uint8_t *out) {
    SpFilter f;
    sp_synth_filter_init(&f,(SpFilterMode)p->filter_mode,48000,p->cutoff_hz,p->resonance);
    float g2=f.g*f.g;
    for(unsigned i=0;i<120;++i) {
        /* Bilinear SVF response from implemented g/k; LP24's second stage
         * has fixed sqrt(2) damping. Horizontal axis: 20 Hz..20 kHz. */
        float hz=20.0f*sp_synth_exp2(9.965784285f*((float)i/119.0f));
        float q=tanf((3.14159265359f/48000.0f)*hz),q2=q*q;
        float a=g2-q2,d=a*a+f.k*f.k*g2*q2,n=g2*g2;
        if(p->filter_mode==SP_FILTER_HP12)n=q2*q2;
        else if(p->filter_mode==SP_FILTER_BP12)n=g2*q2;
        else if(p->filter_mode==SP_FILTER_NOTCH)n=a*a;
        float power=n/d;
        if(p->filter_mode==SP_FILTER_LP24)
            power*=g2*g2/(a*a+1.41421356f*1.41421356f*g2*q2);
        float db=power>0.000001f?10.0f*log10f(power):-60.0f;
        out[i]=ordinate((18.0f-db)/60.0f); /* +18..-42 dB */
    }
}
static float curve(float progress,float shape) {
    return progress*(1.0f+shape*(1.0f-progress));
}
static float duration(float seconds) {
    float samples=ceilf(seconds*48000.0f);
    return samples<1.0f?1.0f:samples;
}
static void envelope(const SpEnvConfig *e,unsigned cycle,uint8_t *out) {
    /* Relative sample durations match DSP, including one-sample zero stages.
     * Sustain hold is one third of A+D+R; no logarithmic compression. */
    float a=duration(e->attack),d=duration(e->decay),r=duration(e->release);
    float hold=(a+d+r)/3.0f,total=cycle?2.0f*(a+d):a+d+hold+r;
    for(unsigned i=0;i<120;++i) {
        float t=total*((float)i/119.0f),start=0.0f,y;
        if(cycle && t>=a+d){t-=a+d;start=e->sustain;}
        if(t<a)y=start+(1.0f-start)*curve(t/a,e->curve);
        else if(t<a+d)y=1.0f+(e->sustain-1.0f)*curve((t-a)/d,e->curve);
        else if(cycle || t<a+d+hold)y=e->sustain;
        else y=e->sustain*(1.0f-curve((t-a-d-hold)/r,e->curve));
        out[i]=ordinate(1.0f-y);
    }
}
static void lfo(const SpSynthLfoConfig *l,uint8_t *out) {
    for(unsigned i=0;i<120;++i) {
        float phase=l->phase+(float)i/119.0f;
        phase-=floorf(phase);
        float y=sp_synth_sine(phase);
        if(l->wave==SP_LFO_TRIANGLE)y=1.0f-4.0f*fabsf(phase-.5f);
        else if(l->wave==SP_LFO_SAW)y=2.0f*phase-1.0f;
        else if(l->wave==SP_LFO_SQUARE)y=phase<.5f?1.0f:-1.0f;
        out[i]=ordinate(.5f-.5f*y);
    }
}
void sp_synth_app_make_view(const SpSynthApp *app,sp_ui_view *view,uint8_t plot[120]) {
    if(plot)memset(plot,0,120);
    sp_ui_make_view(app?&app->ui:NULL,view);
    if(app && view && sp_synth_app_capture_view(app,view))return;
    if(!app || !view || !plot || app->ui.shift || view->row_count || view->error[0])return;
    const SpSynthPatch *p=&app->edited.patch;
    if(!sp_synth_patch_valid(p))return;
    unsigned page=(unsigned)app->ui.page;
    unsigned bank=page<SP_UI_PAGE_COUNT?app->ui.banks[page]:0;
    switch(page) {
    case SP_UI_PLAY:wave(p,3,plot);break;
    case SP_UI_OSC:
        if(bank>4)return;
        wave(p,bank/2,plot);break;
    case SP_UI_FILTER:filter(p,plot);break;
    case SP_UI_AMP:envelope(&p->amp,p->amp_cycle,plot);break;
    case SP_UI_ENV2:envelope(&p->mod,p->mod_cycle,plot);break;
    case SP_UI_LFO:
        if(bank>3 || p->lfo[bank/2].wave==SP_LFO_SAMPLE_HOLD)return;
        lfo(&p->lfo[bank/2],plot);break;
    default:return;
    }
    view->plot_valid=1;
}
