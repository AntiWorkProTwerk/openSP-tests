#ifndef SP_SYNTH_AUDIO_INTERNAL_H
#define SP_SYNTH_AUDIO_INTERNAL_H
#include "sp_synth_audio_batch.h"
int sp_app_audio_can_control(const SpSynthApp *app);
int sp_app_audio_control(SpSynthApp *app, const SpSynthEvent *event);
int sp_app_audio_load(SpSynthApp *app, const SpSynthPatch *patch);
int sp_app_audio_edit(SpSynthApp *app, const SpSynthPatch *patch);
void sp_app_audio_panic(SpSynthApp *app);
/* Shared controller-side render bookkeeping; never called by audio owner. */
int sp_app_audio_prepare(SpSynthApp *app, uint32_t frames);
#endif
