#ifndef SP_SYNTH_PREVIEW_H
#define SP_SYNTH_PREVIEW_H
#include "sp_synth_app.h"
/* Serialized control owner only. Read the accepted edited patch and UI; never
 * inspect the embedded engine or audio-owned state. Outputs must be disjoint
 * from each other and app. No retained pointers, allocation or callbacks.
 * Produces the semantic view and its deterministic 120-column illustration.
 * plot_valid=0 means absent, including unsupported pages, errors and NULL plot.
 * This is a 48 kHz patch schematic; see app/PREVIEW.md for axes and exclusions. */
void sp_synth_app_make_view(const SpSynthApp *app,sp_ui_view *view,uint8_t plot[120]);
#endif
