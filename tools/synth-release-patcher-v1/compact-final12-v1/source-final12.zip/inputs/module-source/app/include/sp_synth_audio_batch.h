#ifndef SP_SYNTH_AUDIO_BATCH_H
#define SP_SYNTH_AUDIO_BATCH_H
#include "sp_synth_app.h"

/* Original control/audio boundary, not a concurrent queue. The platform must
 * transfer exclusive ownership of a sealed batch and its completion. One
 * transaction may be outstanding. No shared app access from the audio owner. */
#define SP_APP_AUDIO_OPS 256u
#define SP_APP_AUDIO_PATCHES 16u
#define SP_APP_AUDIO_EVENTS 256u
typedef enum {
    SP_APP_AUDIO_CONTROL, SP_APP_AUDIO_LOAD, SP_APP_AUDIO_EDIT, SP_APP_AUDIO_PANIC
} SpAppAudioOpType;
typedef struct { uint16_t type, index; uint32_t expected; } SpAppAudioOp;
typedef struct SpAppAudioBatch {
    SpAppAudioOp ops[SP_APP_AUDIO_OPS];
    SpSynthPatch patches[SP_APP_AUDIO_PATCHES];
    SpSynthEvent controls[SP_APP_AUDIO_EVENTS];
    SpSynthEvent events[SP_SYNTH_MAX_EVENTS];
    uint32_t op_count, patch_count, control_count, event_count;
    uint32_t sequence, frames, sealed, failed;
    float gain;
} SpAppAudioBatch;
typedef struct {
    SpSynthEngine engine;
    uint32_t sequence, faulted;
    float gain; /* Last successfully applied browser/output gain. */
} SpAppAudioState;

/* Both owners must be stopped. Copies the current engine once; no alias to
 * app is retained by audio. Existing pending MIDI or failed batches reject. */
int sp_synth_app_audio_transfer(SpSynthApp *app, SpAppAudioState *audio);
/* Controller only. Begin -> normal app calls -> seal -> ownership transfer.
 * No new transaction until matching completion. Failure latches: reinitialize
 * both sides while stopped before resuming. No automatic retry. */
int sp_synth_app_audio_begin(SpSynthApp *app, SpAppAudioBatch *batch);
int sp_synth_app_audio_seal(SpSynthApp *app, uint32_t frames);
int sp_synth_app_audio_complete(SpSynthApp *app, uint32_t sequence, int success);
/* Audio owner only. Applies one complete transaction and renders its frames.
 * Batch is immutable and must be disjoint from audio/output. Any protocol or
 * engine failure panics and latches audio; output is zeroed for a valid frame
 * count. Caller must not retry. No UI, app, storage or allocation calls. */
int sp_synth_app_audio_render(SpAppAudioState *audio,
                            const SpAppAudioBatch *batch, float *out);
/* Audio owner only, when no new batch is delivered. Advances samples and
 * release tails using the last applied gain; sequence stays unchanged.
 * No controller access or completion. A faulted state emits silence and fails.
 * Invalid frame count or output/state overlap rejects without mutation. */
int sp_synth_app_audio_continue(SpAppAudioState *audio,float *out,uint32_t frames);
#endif
