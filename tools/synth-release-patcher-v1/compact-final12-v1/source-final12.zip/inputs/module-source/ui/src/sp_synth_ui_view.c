#include "sp_synth_ui.h"
#include <stddef.h>
#include <string.h>
static void copy(char *out,size_t n,const char *in) {
    size_t i=0;if(!n)return;
    while(i+1<n && in[i]) {out[i]=in[i];++i;}out[i]=0;
}
static void number(char *out,size_t n,unsigned x) {
    char digits[11];unsigned count=0;
    do {digits[count++]=(char)('0'+x%10);x/=10;}while(x);
    unsigned i=0;while(count && i+1<n)out[i++]=digits[--count];if(n)out[i]=0;
}
static void append(char *out,size_t n,const char *in) {
    size_t len=0;while(len<n && out[len])++len;if(len<n)copy(out+len,n-len,in);
}
static void choice(sp_ui_view *v,const char *title,const char *safe,const char *action) {
    v->row_selection=1;
    copy(v->header,32,title);copy(v->rows[0],32,safe);copy(v->rows[1],32,action);v->row_count=2;
    copy(v->footer,48,"VALUE:CONFIRM  EXIT:BACK");
}
static void pad_id(const sp_ui *u,char id[4]) {
    if(u->dest_bank>=10 || !u->dest_pad || u->dest_pad>16) {copy(id,4,"???");return;}
    id[0]=(char)('A'+u->dest_bank);id[1]=(char)('0'+u->dest_pad/10);
    id[2]=(char)('0'+u->dest_pad%10);id[3]=0;
}
static const char *save_stage(uint32_t fault) {
    if(fault&SP_UI_SAVE_FAULT_CONTEXT)return "SAVE INTERRUPTED";
    if(fault&SP_UI_SAVE_FAULT_LEASE)return "PROJECT UNAVAILABLE";
    if(fault&SP_UI_SAVE_FAULT_DEST)return "PAD CHECK FAILED";
    if(fault&SP_UI_SAVE_FAULT_CHANGED)return "PAD CHANGED";
    if(fault&SP_UI_SAVE_FAULT_SAMPLE)return "SAMPLE NOT SAVED";
    if(fault&SP_UI_SAVE_FAULT_SYNC)return "SAMPLE NOT SYNCED";
    if(fault&SP_UI_SAVE_FAULT_CLOSE)return "SAMPLE CLOSE FAILED";
    if(fault&SP_UI_SAVE_FAULT_UNLINK)return "REPLACE NOT FINISHED";
    if(fault&SP_UI_SAVE_FAULT_RENAME)return "SAMPLE NOT RENAMED";
    if(fault&SP_UI_SAVE_FAULT_READY)return "PAD NOT UPDATED";
    if(fault&SP_UI_SAVE_FAULT_PROJECT)return "PROJECT NOT SAVED";
    if(fault&SP_UI_SAVE_FAULT_RETIRE)return "RECORDER CLEANUP";
    return "SAVE NOT CONFIRMED";
}
void sp_ui_make_view(const sp_ui *u,sp_ui_view *v) {
    if(!v)return;
    memset(v,0,sizeof(*v));if(!u)return;
    v->busy=u->busy;v->dirty=u->dirty;v->take_held=u->take_held;v->selected=u->selection;
    v->focused=u->focused;v->pickup_visible=u->pickup_visible;v->pickup_knob=u->pickup_knob;
    v->pickup_direction=u->pickup_direction;v->elapsed_ms=u->elapsed_ms;
    static const char *const errors[]={"","STORAGE ERROR","NO CARD","STORAGE FULL","READ ONLY","CAPTURE ERROR","BACKEND ERROR","REOPEN SYNTH"};
    if((unsigned)u->error<sizeof(errors)/sizeof(errors[0]))copy(v->error,24,errors[u->error]);
    if(u->busy && (u->pending==SP_UI_CMD_TAKE_WRITE || u->pending==SP_UI_CMD_TAKE_RECOVER)) {
        char id[4];pad_id(u,id);v->error[0]=0;v->row_count=2;
        copy(v->header,32,"SAVING TAKE");copy(v->hero,32,"BANK A / PAD 00");
        v->hero[5]=id[0];v->hero[13]=id[1];v->hero[14]=id[2];
        copy(v->rows[0],32,u->pending==SP_UI_CMD_TAKE_RECOVER?"WRITING PROJECT":"WRITING SAMPLE");
        copy(v->rows[1],32,"KEEP POWER ON");copy(v->footer,48,"PLEASE WAIT");
        if(u->tail_cut_reason) {copy(v->rows[2],32,"TAIL CUT");v->row_count=3;}
        return;
    }
    if(u->save_flags&SP_UI_SAVE_RECOVERY_REQUIRED) {
        char id[4];pad_id(u,id);v->error[0]=0;v->take_held=0;v->row_count=2;
        if(u->save_details) {
            copy(v->header,32,"SAVE DETAILS");copy(v->hero,32,save_stage(u->save_fault));
            if(u->save_flags&(SP_UI_SAVE_DEST_REMOVED|SP_UI_SAVE_RENAMED)) {
                copy(v->rows[0],32,id);append(v->rows[0],32," MAY HAVE CHANGED");
            } else copy(v->rows[0],32,"PAD NOT CONFIRMED");
            copy(v->rows[1],32,"KEEP POWER ON");copy(v->footer,48,"EXIT:BACK");
            if(u->save_flags&SP_UI_SAVE_REPAIR_ALLOWED)copy(v->footer,48,"V:REPAIR PROJECT EXIT:BACK");
        } else {
            copy(v->header,32,"SAVE INCOMPLETE");copy(v->hero,32,"CHECK PAD ");append(v->hero,32,id);
            copy(v->rows[0],32,"TAKE NOT CONFIRMED");copy(v->rows[1],32,"RECORDING PAUSED");
            copy(v->footer,48,"VALUE:DETAILS");
        }
        if(u->tail_cut_reason) {copy(v->rows[2],32,"TAIL CUT");v->row_count=3;}
        return;
    }
    if(u->shift) {
        copy(v->header,32,u->map?"SHIFT  9-16":"SHIFT  1-8");v->row_count=4;
        static const char *const rows[8]={"1 PLAY     2 OSC","3 FILTER   4 AMP","5 MOD      6 VOICE","7 PATCH    8 CAPTURE",
            "9 LFO     10 ENV2","11 KEYS   12 MACROS","13 INIT   14 STORE","15 PANIC  16 MAP"};
        for(unsigned i=0;i<4;++i)copy(v->rows[i],32,rows[i+4*u->map]);
        copy(v->footer,48,"PAD:SELECT  RELEASE SHIFT:BACK");return;
    }
    static const char *const names[SP_UI_PAGE_COUNT]={"SYNTH","OSC","FILTER","AMP","MOD","VOICE","LFO","ENV2","KEYS","MACROS","CAPTURE","PATCHES"};
    if((unsigned)u->page<SP_UI_PAGE_COUNT)copy(v->header,32,names[u->page]);
    if(u->page==SP_UI_PLAY || u->page==SP_UI_SAVED) {
        copy(v->header,32,"SYNTH  OCT ");char oct[12];if(u->octave<0)copy(oct,12,"-1");else number(oct,12,(unsigned)u->octave);
        append(v->header,32,oct);copy(v->hero,32,u->patch.name);if(u->dirty)append(v->hero,32,"*");
        copy(v->footer,48,u->take_held?"TAKE HELD  REC:RECALL":"V:PATCH  TURN:OCT  REC:TAKE");
        if(u->page==SP_UI_SAVED) {
            char id[4];pad_id(u,id);copy(v->header,32,"SAVED TO ");append(v->header,32,id);
            if(u->tail_cut_reason) {copy(v->rows[0],32,"TAIL CUT");v->row_count=1;}
        } else if(u->take_held && u->tail_cut_reason) {
            copy(v->rows[0],32,"TAKE HELD / TAIL CUT");v->row_count=1;
        }
    } else if(u->page==SP_UI_BROWSER) {
        v->row_selection=1;
        unsigned start=u->browse_index;v->row_count=0;v->selected=0;
        for(unsigned n=0;n<u->catalog_count && v->row_count<3;++n) {
            unsigned i=(start+n)%u->catalog_count;const sp_ui_patch *p=&u->catalog[i];
            if((!u->browse_family || p->family==u->browse_family) && (!u->browse_favorites || p->favorite)) {
                char name[25];memcpy(name,p->name,25);name[24]=0;copy(v->rows[v->row_count++],32,name);
            }
        }
        if(!v->row_count)copy(v->hero,32,"NO MATCHES");
        copy(v->footer,48,"VALUE:LOAD  EXIT:RESTORE");
    } else if(u->page==SP_UI_RECORDING) {
        copy(v->header,32,"RECORDING");number(v->hero,32,u->elapsed_ms/1000);append(v->hero,32," SEC");
        copy(v->footer,48,"REC:STOP  PADS:PLAY");
    } else if(u->page==SP_UI_DESTINATION) {
        copy(v->header,32,"SAVE TAKE");char dest[12];number(dest,12,u->dest_pad);
        v->hero[0]=(char)('A'+u->dest_bank);v->hero[1]='-';v->hero[2]=0;append(v->hero,32,dest);
        copy(v->rows[0],32,!u->dest_known?"CHECKING PAD":u->dest_occupied?u->destination_name:"EMPTY");v->row_count=1;
        if(u->tail_cut_reason) {copy(v->rows[1],32,"TAIL CUT");v->row_count=2;}
        copy(v->footer,48,"REC:SAVE  EXIT:KEEP TAKE");
    } else if(u->page==SP_UI_OVERWRITE) {
        choice(v,"REPLACE SAMPLE?","Cancel","Replace sample");
        if(u->tail_cut_reason)copy(v->hero,32,"TAIL CUT");
    }
    else if(u->page==SP_UI_NEW_CONFIRM)choice(v,"DISCARD TAKE?","Cancel","Discard and record");
    else if(u->page==SP_UI_LEAVE_CONFIRM)choice(v,"TAKE HELD","Keep playing","Discard and leave");
    else if(u->page==SP_UI_INIT_CONFIRM)choice(v,"INITIALIZE PATCH?","Cancel","Initialize");
    else if(u->page==SP_UI_PATCH_REPLACE)choice(v,"REPLACE USER PATCH?","Cancel","Replace patch");
    else if(u->page==SP_UI_STORE) {
        copy(v->header,32,"STORE PATCH");copy(v->hero,32,u->patch.name);
        number(v->rows[0],32,(unsigned)u->store_slot+1);append(v->rows[0],32,": ");
        append(v->rows[0],32,!u->store_known?"CHECKING":u->store_factory?"FACTORY READ ONLY":u->store_occupied?u->slot_name:"EMPTY");
        v->row_count=1;copy(v->footer,48,"VALUE:SAVE  EXIT:CANCEL");
    } else if(u->page==SP_UI_SAVE_ERROR || u->page==SP_UI_PATCH_ERROR) {
        copy(v->header,32,u->page==SP_UI_SAVE_ERROR?"SAVE NOT STARTED":"SAVE FAILED");
        copy(v->hero,32,u->page==SP_UI_SAVE_ERROR?"TAKE HELD":"EDITS KEPT");
        copy(v->footer,48,u->page==SP_UI_SAVE_ERROR?"VALUE:RETRY EXIT:KEEP":"VALUE:RETRY  EXIT:BACK");
        if(u->page==SP_UI_SAVE_ERROR && u->tail_cut_reason) {
            copy(v->rows[1],32,"TAIL CUT");v->row_count=2;
        }
    } else if(u->page==SP_UI_CAPTURE_ERROR) {
        copy(v->header,32,"CAPTURE FAILED");copy(v->footer,48,"REC:RETRY  EXIT:BACK");
    } else if(u->page==SP_UI_INACTIVE)copy(v->header,32,"SYNTH CLOSED");
    else if(u->page==SP_UI_CAPTURE_READY)copy(v->footer,48,"REC:START  PADS:PLAY");
    else copy(v->footer,48,"VALUE:BANK  SHIFT:MAP");
    unsigned p=u->page==SP_UI_SAVED?SP_UI_PLAY:(unsigned)u->page;
    if(p>SP_UI_PLAY && p<SP_UI_BROWSER && u->bank_count[p]>1) {
        char count[12];append(v->header,32," ");number(count,12,(unsigned)u->banks[p]+1);append(v->header,32,count);
        append(v->header,32,"/");number(count,12,u->bank_count[p]);append(v->header,32,count);
    }
    if(p<SP_UI_PAGE_COUNT && p!=SP_UI_BROWSER && u->bank_count[p]) {
        v->controls=1;
        v->show_focus=p!=SP_UI_PLAY && p!=SP_UI_CAPTURE_READY;
        for(unsigned i=0;i<3;++i) {
            const sp_ui_binding *b=&u->bindings[p][u->banks[p]][i];copy(v->labels[i],16,b->label);
            if(b->display[0])copy(v->values[i],16,b->display);else number(v->values[i],16,b->value);
        }
    }
    if(u->busy)copy(v->footer,48,"WORKING...");
}
