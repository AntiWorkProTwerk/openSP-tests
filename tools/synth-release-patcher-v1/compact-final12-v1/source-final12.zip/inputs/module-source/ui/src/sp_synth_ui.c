#include "sp_synth_ui.h"
#include <limits.h>
#include <stddef.h>
#include <string.h>

static void text(char *out,size_t n,const char *in,size_t bound) {
    size_t i=0;
    if (!n) return;
    if (in) while (i+1<n && i<bound && in[i]) { out[i]=in[i]; ++i; }
    out[i]=0;
}
static int clamp(int64_t x,int lo,int hi) { return x<lo?lo:x>hi?hi:(int)x; }
static sp_ui_command *emit(sp_ui_commands *out,sp_ui_command_type type) {
    /* Dispatch paths emit at most four commands; no queue or allocation. */
    if (out->count>=SP_UI_COMMAND_CAPACITY) return 0;
    sp_ui_command *c=&out->items[out->count++];memset(c,0,sizeof(*c));c->type=type;return c;
}
static void pickup_reset(sp_ui *u) {
    memset(u->picked_up,0,sizeof(u->picked_up));u->focused=0;u->pickup_visible=0;
}
static void page(sp_ui *u,sp_ui_page p) {
    if(u->page==SP_UI_SAVED && p!=SP_UI_SAVED)u->tail_cut_reason=0;
    u->page=p;u->selection=0;pickup_reset(u);
}
static void release_pads(sp_ui *u,sp_ui_commands *out) {
    emit(out,SP_UI_CMD_RELEASE_PADS);u->active_pads=0;
}
static void panic(sp_ui *u,sp_ui_commands *out) { emit(out,SP_UI_CMD_PANIC);u->active_pads=0; }
static int recovery(const sp_ui *u) {return (u->save_flags&SP_UI_SAVE_RECOVERY_REQUIRED)!=0;}
static int begin(sp_ui *u,sp_ui_commands *out,sp_ui_command_type type) {
    if (u->busy) return 0;
    if(recovery(u) && (type==SP_UI_CMD_CAPTURE_START || type==SP_UI_CMD_TAKE_WRITE ||
       type==SP_UI_CMD_TAKE_DISCARD))return 0;
    if(type==SP_UI_CMD_TAKE_RECOVER && (!recovery(u) || !(u->save_flags&SP_UI_SAVE_REPAIR_ALLOWED)))return 0;
    if (u->generation==UINT32_MAX) { u->error=SP_UI_ERR_GENERATION_EXHAUSTED;return 0; }
    sp_ui_command *c=emit(out,type);if (!c) return 0;
    c->generation=++u->generation;c->revision=u->revision;c->token=u->take_token;
    c->index=u->dest_pad;c->bank=u->dest_bank;
    if (type==SP_UI_CMD_PATCH_QUERY || type==SP_UI_CMD_PATCH_WRITE) c->index=u->store_slot;
    if (type==SP_UI_CMD_PATCH_WRITE) {
        c->token=u->patch.token;c->replace=u->store_occupied;
        text(c->name,sizeof(c->name),u->patch.name,sizeof(u->patch.name));
    }
    if (type==SP_UI_CMD_TAKE_WRITE) {
        c->replace=u->dest_occupied;u->save_flags=u->save_fault=0;u->save_details=0;
    }
    u->busy=1;u->pending=type;u->error=SP_UI_OK;return 1;
}
static void query_destination(sp_ui *u,sp_ui_commands *out) {
    u->dest_known=0;begin(u,out,SP_UI_CMD_DEST_QUERY);
}
static int matches(const sp_ui *u,unsigned i) {
    return i<u->catalog_count && (!u->browse_family || u->catalog[i].family==u->browse_family) &&
        (!u->browse_favorites || u->catalog[i].favorite);
}
static void audition(sp_ui *u,sp_ui_commands *out) {
    if (!matches(u,u->browse_index)) return;
    if(u->patch.token==u->catalog[u->browse_index].token && u->error==SP_UI_OK)return;
    release_pads(u,out);
    if (begin(u,out,SP_UI_CMD_BROWSE_AUDITION)) out->items[out->count-1].token=u->catalog[u->browse_index].token;
}
static void browse(sp_ui *u,sp_ui_commands *out) {
    if (!u->catalog_count) return;
    u->browse_original=u->patch;u->browse_dirty=u->dirty;u->browse_revision=u->revision;
    u->browse_snapshot=1;u->browse_family=0;u->browse_favorites=0;u->browse_index=0;
    for (unsigned i=0;i<u->catalog_count;++i) if (u->catalog[i].token==u->patch.token) {u->browse_index=(uint16_t)i;break;}
    emit(out,SP_UI_CMD_BROWSE_BEGIN);page(u,SP_UI_BROWSER);
    /* Preserve the edited patch until the player actually selects another one. */
    if(u->patch.token!=u->catalog[u->browse_index].token)audition(u,out);
}
static void browse_move(sp_ui *u,sp_ui_commands *out,int delta) {
    if (!delta || !u->catalog_count) return;
    int pos=u->browse_index;int direction=delta<0?-1:1;
    /* One physical detent chooses one matching item; magnitude is coalesced. */
    for (unsigned n=0;n<u->catalog_count;++n) {
        pos+=direction;if (pos<0)pos=u->catalog_count-1;if (pos>=u->catalog_count)pos=0;
        if (matches(u,(unsigned)pos)) {u->browse_index=(uint16_t)pos;audition(u,out);return;}
    }
}
static void capture(sp_ui *u,sp_ui_commands *out) {
    if (u->take_held) { page(u,SP_UI_DESTINATION);query_destination(u,out); }
    else page(u,SP_UI_CAPTURE_READY);
}
static int playable(const sp_ui *u) {
    return u->page<=SP_UI_RECORDING || u->page==SP_UI_SAVED;
}
static void leave(sp_ui *u,sp_ui_commands *out) {
    panic(u,out);emit(out,SP_UI_CMD_LEAVE);page(u,SP_UI_INACTIVE);
}
void sp_ui_init(sp_ui *u,const sp_ui_patch *patch,const sp_ui_patch *catalog,uint16_t count) {
    if (!u) return;
    memset(u,0,sizeof(*u));if (patch)u->patch=*patch;
    u->patch.name[SP_UI_NAME_CAPACITY-1]=0;
    u->catalog=catalog;u->catalog_count=catalog?count:0;u->dest_pad=1;u->octave=3;
    page(u,SP_UI_PLAY);
}
int sp_ui_reenter(sp_ui *u,uint32_t generation,uint16_t physical_pads,uint8_t shift) {
    if(!u || u->page!=SP_UI_INACTIVE || u->busy || u->take_held || u->take_token ||
       u->browse_snapshot || u->active_pads || recovery(u) || generation!=u->generation ||
       u->generation==UINT32_MAX || shift>1)return 0;
    ++u->generation;
    u->tail_cut_reason=0;
    u->save_flags=u->save_fault=0;u->save_details=0;
    u->shift=shift;u->map=0;u->physical_pads=physical_pads;
    memset(u->knob_known,0,sizeof(u->knob_known));
    memset(u->knob_position,0,sizeof(u->knob_position));
    u->pickup_direction=0;u->pickup_knob=0;
    page(u,SP_UI_PLAY);return 1;
}
int sp_ui_set_catalog(sp_ui *u,const sp_ui_patch *catalog,uint16_t count) {
    if(!u || u->busy || u->page==SP_UI_BROWSER || count>256 || (count && !catalog))return 0;
    for(unsigned i=0;i<count;++i) {
        const sp_ui_patch *p=&catalog[i];
        if(!p->token || !p->name[0] || p->name[24] || p->family<1 || p->family>8 || p->favorite>1 || p->factory>1)return 0;
        for(unsigned j=0;j<i;++j)if(catalog[j].token==p->token)return 0;
    }
    u->catalog=count?catalog:0;u->catalog_count=count;u->browse_index=0;return 1;
}
void sp_ui_set_bank(sp_ui *u,sp_ui_page p,uint8_t bank,uint8_t count,const sp_ui_binding controls[3]) {
    if (!u || !controls || (unsigned)p>=SP_UI_PAGE_COUNT || !count || count>SP_UI_BANK_CAPACITY || bank>=count)return;
    int changed=u->bank_count[p]!=count;
    for(unsigned i=0;i<3;++i)
        changed|=u->bindings[p][bank][i].parameter_id!=controls[i].parameter_id ||
            u->bindings[p][bank][i].value!=controls[i].value;
    u->bank_count[p]=count;
    if (u->banks[p]>=count)u->banks[p]=0;
    for (unsigned i=0;i<3;++i) {
        u->bindings[p][bank][i]=controls[i];sp_ui_binding *b=&u->bindings[p][bank][i];
        b->value=(uint16_t)clamp(b->value,0,SP_UI_VALUE_MAX);b->label[15]=b->display[15]=0;
    }
    if(changed && u->page==p && u->banks[p]==bank)pickup_reset(u);
}
static void shortcut(sp_ui *u,sp_ui_commands *out,unsigned pad) {
    static const sp_ui_page map[12]={SP_UI_PLAY,SP_UI_OSC,SP_UI_FILTER,SP_UI_AMP,SP_UI_MOD,SP_UI_VOICE,
        SP_UI_BROWSER,SP_UI_CAPTURE_READY,SP_UI_LFO,SP_UI_ENV2,SP_UI_KEYS,SP_UI_MACROS};
    if (pad==15) {panic(u,out);return;}
    if (pad==16) {u->map^=1;return;}
    /* Capturing and pending take decisions cannot be left through a shortcut. */
    if (u->page>=SP_UI_RECORDING && u->page!=SP_UI_SAVED)return;
    if (u->page==SP_UI_BROWSER) {
        emit(out,SP_UI_CMD_BROWSE_RESTORE);u->patch=u->browse_original;
        u->dirty=u->browse_dirty;u->revision=u->browse_revision;u->browse_snapshot=0;
        release_pads(u,out);
    }
    if (pad==7)browse(u,out);
    else if (pad==8)capture(u,out);
    else if (pad==13) {u->return_page=u->page;page(u,SP_UI_INIT_CONFIRM);}
    else if (pad==14) {page(u,SP_UI_STORE);u->store_known=0;begin(u,out,SP_UI_CMD_PATCH_QUERY);}
    else if (pad>=1 && pad<=12)page(u,map[pad-1]);
}
static void set_parameter(sp_ui *u,sp_ui_commands *out,unsigned knob,unsigned value) {
    if ((unsigned)u->page>=SP_UI_PAGE_COUNT || u->page==SP_UI_BROWSER || !u->bank_count[u->page])return;
    sp_ui_binding *b=&u->bindings[u->page][u->banks[u->page]][knob];
    if (b->value==value)return;
    if (u->revision==UINT32_MAX) {u->error=SP_UI_ERR_GENERATION_EXHAUSTED;return;}
    b->value=(uint16_t)value;u->dirty=1;++u->revision;
    sp_ui_command *c=emit(out,SP_UI_CMD_PARAM_SET);c->index=b->parameter_id;c->value=(int32_t)value;c->revision=u->revision;
    /* Adapter supplies a formatted value through set_bank after applying it. */
    b->display[0]=0;
}
static void complete(sp_ui *u,const sp_ui_event *e,sp_ui_commands *out) {
    if (!u->busy || e->generation!=u->generation) {++u->stale_completions;return;}
    sp_ui_command_type pending=u->pending;sp_ui_error error=e->error;
    if(pending==SP_UI_CMD_TAKE_WRITE || pending==SP_UI_CMD_TAKE_RECOVER) {
        if((e->save_flags&~SP_UI_SAVE_FLAGS_ALL) ||
           ((e->save_flags || e->save_fault) && (!e->token || e->token!=u->take_token))) {
            ++u->stale_completions;return;
        }
        uint32_t old_flags=u->save_flags,old_fault=u->save_fault;uint8_t old_details=u->save_details;
        u->save_flags=e->save_flags;u->save_fault=e->save_fault;u->save_details=0;
        if(error==SP_UI_OK && (pending==SP_UI_CMD_TAKE_RECOVER || e->save_flags || e->save_fault) &&
           ((e->save_flags&SP_UI_SAVE_SAVED_MASK)!=SP_UI_SAVE_SAVED_MASK ||
            (e->save_flags&(SP_UI_SAVE_RECOVERY_REQUIRED|SP_UI_SAVE_INTACT)) || e->save_fault))
            error=SP_UI_ERR_BACKEND;
        if(error!=SP_UI_OK && e->save_flags!=SP_UI_SAVE_INTACT)
            u->save_flags|=SP_UI_SAVE_RECOVERY_REQUIRED;
        if(pending==SP_UI_CMD_TAKE_RECOVER && error!=SP_UI_OK) {
            /* Effect history survives; permission belongs to this response. */
            u->save_flags|=(old_flags&~SP_UI_SAVE_REPAIR_ALLOWED)|SP_UI_SAVE_RECOVERY_REQUIRED;
            if(old_fault)u->save_fault=old_fault;
            u->save_details=old_details;
        }
    } else if(e->save_flags || e->save_fault) {++u->stale_completions;return;}
    u->busy=0;u->error=error;
    if (error!=SP_UI_OK) {
        if (pending==SP_UI_CMD_TAKE_WRITE || pending==SP_UI_CMD_TAKE_RECOVER)page(u,SP_UI_SAVE_ERROR);
        else if (pending==SP_UI_CMD_PATCH_WRITE)page(u,SP_UI_PATCH_ERROR);
        else if (pending==SP_UI_CMD_CAPTURE_START || pending==SP_UI_CMD_CAPTURE_STOP)
            page(u,e->capture_active?SP_UI_RECORDING:SP_UI_CAPTURE_ERROR);
        /* Only explicit INTACT save evidence licenses another write attempt. */
        return;
    }
    switch (pending) {
    case SP_UI_CMD_BROWSE_AUDITION:
        u->patch=u->catalog[u->browse_index];u->patch.name[24]=0;u->dirty=0;pickup_reset(u);break;
    case SP_UI_CMD_CAPTURE_START:u->elapsed_ms=0;page(u,SP_UI_RECORDING);break;
    case SP_UI_CMD_CAPTURE_STOP:
        if (!e->token) {u->error=SP_UI_ERR_CAPTURE;page(u,e->capture_active?SP_UI_RECORDING:SP_UI_CAPTURE_ERROR);return;}
        u->take_token=e->token;u->take_held=1;panic(u,out);page(u,SP_UI_DESTINATION);query_destination(u,out);break;
    case SP_UI_CMD_DEST_QUERY:
        u->dest_known=1;u->dest_occupied=e->occupied!=0;text(u->destination_name,25,e->name,25);break;
    case SP_UI_CMD_TAKE_WRITE:case SP_UI_CMD_TAKE_RECOVER:
        u->take_held=0;u->take_token=0;page(u,SP_UI_SAVED);break;
    case SP_UI_CMD_TAKE_DISCARD:
        u->take_held=0;u->take_token=0;u->tail_cut_reason=0;
        u->save_flags=u->save_fault=0;u->save_details=0;
        if (u->discard_leaves)leave(u,out);else page(u,SP_UI_CAPTURE_READY);
        break;
    case SP_UI_CMD_PATCH_QUERY:
        u->store_known=1;u->store_occupied=e->occupied!=0;u->store_factory=e->factory!=0;
        text(u->slot_name,25,e->name,25);break;
    case SP_UI_CMD_PATCH_WRITE:
        u->dirty=0;u->patch.factory=0;
        if (e->token)u->patch.token=e->token;
        page(u,SP_UI_PLAY);break;
    default:break;
    }
}
static void confirm(sp_ui *u,sp_ui_commands *out) {
    switch(u->page) {
    case SP_UI_PLAY:case SP_UI_SAVED:browse(u,out);break;
    case SP_UI_BROWSER:
        if(matches(u,u->browse_index) && u->patch.token==u->catalog[u->browse_index].token) {
            emit(out,SP_UI_CMD_BROWSE_COMMIT);u->browse_snapshot=0;page(u,SP_UI_PLAY);
        }
        break;
    case SP_UI_OVERWRITE:
        if (u->selection)begin(u,out,SP_UI_CMD_TAKE_WRITE);else page(u,SP_UI_DESTINATION);break;
    case SP_UI_INIT_CONFIRM:
        if (u->selection && u->revision!=UINT32_MAX) {
            release_pads(u,out);emit(out,SP_UI_CMD_INITIALIZE);u->dirty=1;u->initialized=1;++u->revision;
            u->patch.token=0;u->patch.factory=0;u->patch.favorite=0;text(u->patch.name,25,"INIT",4);
        }
        page(u,SP_UI_PLAY);break;
    case SP_UI_NEW_CONFIRM:case SP_UI_LEAVE_CONFIRM:
        if (u->selection) {u->discard_leaves=u->page==SP_UI_LEAVE_CONFIRM;begin(u,out,SP_UI_CMD_TAKE_DISCARD);}
        else page(u,u->page==SP_UI_LEAVE_CONFIRM?SP_UI_PLAY:SP_UI_DESTINATION);
        break;
    case SP_UI_STORE:
        if (!u->store_known)begin(u,out,SP_UI_CMD_PATCH_QUERY);
        else if (u->store_factory)u->error=SP_UI_ERR_READ_ONLY;
        else if (u->store_occupied)page(u,SP_UI_PATCH_REPLACE);
        else begin(u,out,SP_UI_CMD_PATCH_WRITE);
        break;
    case SP_UI_PATCH_REPLACE:
        if (u->selection && !u->store_factory)begin(u,out,SP_UI_CMD_PATCH_WRITE);else page(u,SP_UI_STORE);break;
    case SP_UI_SAVE_ERROR:begin(u,out,SP_UI_CMD_TAKE_WRITE);break;
    case SP_UI_PATCH_ERROR:begin(u,out,SP_UI_CMD_PATCH_WRITE);break;
    default:
        if ((unsigned)u->page<SP_UI_PAGE_COUNT && u->bank_count[u->page]) {
            u->banks[u->page]=(uint8_t)((u->banks[u->page]+1)%u->bank_count[u->page]);pickup_reset(u);
        }break;
    }
}
void sp_ui_dispatch(sp_ui *u,const sp_ui_event *e,sp_ui_commands *out) {
    if (!out)return;
    memset(out,0,sizeof(*out));if (!u || !e)return;
    unsigned previous_knob=0;int knob_was_known=0;
    if(e->type==SP_UI_CTRL_MOVE && e->index<3 && e->value>=0 && (uint32_t)e->value<=SP_UI_VALUE_MAX) {
        previous_knob=u->knob_position[e->index];knob_was_known=u->knob_known[e->index];
        u->knob_position[e->index]=(uint16_t)e->value;u->knob_known[e->index]=1;
    }
    if (e->type==SP_UI_COMPLETE) {complete(u,e,out);return;}
    if (u->page==SP_UI_INACTIVE)return;
    if (e->type==SP_UI_SHIFT_DOWN) {u->shift=1;u->map=0;return;}
    if (e->type==SP_UI_SHIFT_UP) {u->shift=0;return;}
    if (e->type==SP_UI_SYNTH_PANIC) {panic(u,out);return;}
    if (e->type==SP_UI_PAD_UP) {
        if (e->index<1 || e->index>16)return;
        uint16_t mask=(uint16_t)(1u<<(e->index-1));u->physical_pads&=(uint16_t)~mask;
        if (u->active_pads&mask) {emit(out,SP_UI_CMD_PAD_OFF)->index=e->index;u->active_pads&=(uint16_t)~mask;}
        return;
    }
    if (e->type==SP_UI_MIDI_DOWN || e->type==SP_UI_MIDI_UP || e->type==SP_UI_MIDI_SUSTAIN) {
        if (e->channel>15 || e->index>127 || e->value<0 || e->value>127)return;
        sp_ui_command *c=emit(out,e->type==SP_UI_MIDI_DOWN?SP_UI_CMD_MIDI_ON:e->type==SP_UI_MIDI_UP?SP_UI_CMD_MIDI_OFF:SP_UI_CMD_SUSTAIN);
        c->index=e->index;c->channel=e->channel;c->value=e->value;return;
    }
    if (e->type==SP_UI_CAPTURE_PROGRESS) {
        if (u->page==SP_UI_RECORDING && e->value>=0)u->elapsed_ms=(uint32_t)e->value;
        return;
    }
    if (e->type==SP_UI_SET_METADATA) {
        if(u->busy)return;
        text(u->patch.name,25,e->name,25);u->patch.token=e->token;u->patch.factory=e->factory;return;
    }
    /* Record physical downs even during storage; no deferred note-on on return. */
    if (e->type==SP_UI_PAD_DOWN) {
        if (e->index<1 || e->index>16 || e->value<0 || e->value>127)return;
        uint16_t mask=(uint16_t)(1u<<(e->index-1));if (u->physical_pads&mask)return;
        u->physical_pads|=mask;
        if(recovery(u))return;
        if (u->shift) {if (e->index==15 || !u->busy)shortcut(u,out,e->index);return;}
        if (!u->busy && u->page==SP_UI_DESTINATION) {u->dest_pad=(uint8_t)e->index;query_destination(u,out);return;}
        if (playable(u)) {sp_ui_command *c=emit(out,SP_UI_CMD_PAD_ON);c->index=e->index;c->value=e->value;u->active_pads|=mask;}
        return;
    }
    if(recovery(u)) {
        /* Keep location/token frozen; an explicit scoped repair is separate
         * from SAVE and must retain the verified provider's permission. */
        if(u->busy)return;
        if(e->type==SP_UI_VALUE_PRESS) {
            if(u->save_details && (u->save_flags&SP_UI_SAVE_REPAIR_ALLOWED))
                begin(u,out,SP_UI_CMD_TAKE_RECOVER);
            else u->save_details=1;
        }
        if(e->type==SP_UI_EXIT_PRESS)u->save_details=0;
        return;
    }
    if(u->busy && u->pending==SP_UI_CMD_TAKE_WRITE)return;
    if (e->type==SP_UI_EXIT_PRESS && u->shift) {panic(u,out);emit(out,SP_UI_CMD_GLOBAL_STOP);return;}
    if (u->busy)return;
    if(u->shift && (e->type==SP_UI_CTRL_MOVE || e->type==SP_UI_VALUE_PRESS || e->type==SP_UI_VALUE_TURN))return;
    if (e->type==SP_UI_NOTICE_EXPIRED) {if (u->page==SP_UI_SAVED)page(u,SP_UI_PLAY);u->pickup_visible=0;return;}
    if (e->type==SP_UI_VALUE_PRESS) {confirm(u,out);return;}
    if (e->type==SP_UI_REC_PRESS) {
        if (u->page==SP_UI_RECORDING)begin(u,out,SP_UI_CMD_CAPTURE_STOP);
        else if (u->page==SP_UI_CAPTURE_READY || u->page==SP_UI_CAPTURE_ERROR)begin(u,out,SP_UI_CMD_CAPTURE_START);
        else if (u->page==SP_UI_DESTINATION && u->shift)page(u,SP_UI_NEW_CONFIRM);
        else if (u->page==SP_UI_DESTINATION) {
            if (!u->dest_known)query_destination(u,out);
            else if (u->dest_occupied)page(u,SP_UI_OVERWRITE);
            else begin(u,out,SP_UI_CMD_TAKE_WRITE);
        } else if (u->page==SP_UI_PLAY || u->page==SP_UI_SAVED || u->page<SP_UI_CAPTURE_READY)capture(u,out);
        return;
    }
    if (e->type==SP_UI_EXIT_PRESS) {
        switch(u->page) {
        case SP_UI_PLAY:case SP_UI_SAVED:if(u->take_held)page(u,SP_UI_LEAVE_CONFIRM);else leave(u,out);break;
        case SP_UI_RECORDING:begin(u,out,SP_UI_CMD_CAPTURE_STOP);break;
        case SP_UI_BROWSER:
            release_pads(u,out);emit(out,SP_UI_CMD_BROWSE_RESTORE);u->patch=u->browse_original;
            u->dirty=u->browse_dirty;u->revision=u->browse_revision;u->browse_snapshot=0;page(u,SP_UI_PLAY);break;
        case SP_UI_OVERWRITE:case SP_UI_NEW_CONFIRM:page(u,SP_UI_DESTINATION);break;
        case SP_UI_PATCH_REPLACE:page(u,SP_UI_STORE);break;
        default:page(u,SP_UI_PLAY);break;
        }return;
    }
    if (e->type==SP_UI_VALUE_TURN) {
        if (!e->value)return;
        if (u->page==SP_UI_PLAY || u->page==SP_UI_SAVED) {
            int octave=clamp((int64_t)u->octave+e->value,-1,8);
            if (octave!=u->octave) {release_pads(u,out);u->octave=(int8_t)octave;emit(out,SP_UI_CMD_OCTAVE)->value=octave;}
        } else if (u->page==SP_UI_BROWSER)browse_move(u,out,e->value);
        else if (u->page==SP_UI_OVERWRITE || u->page==SP_UI_NEW_CONFIRM || u->page==SP_UI_LEAVE_CONFIRM ||
                 u->page==SP_UI_INIT_CONFIRM || u->page==SP_UI_PATCH_REPLACE)u->selection=e->value>0;
        else if (u->page==SP_UI_STORE) {u->store_slot=(uint8_t)clamp((int64_t)u->store_slot+e->value,0,127);u->store_known=0;begin(u,out,SP_UI_CMD_PATCH_QUERY);}
        else if (u->page==SP_UI_DESTINATION) {u->dest_bank=(uint8_t)clamp((int64_t)u->dest_bank+e->value,0,9);query_destination(u,out);}
        else if ((unsigned)u->page<SP_UI_PAGE_COUNT && u->bank_count[u->page]) {
            sp_ui_binding *b=&u->bindings[u->page][u->banks[u->page]][u->focused];
            unsigned step=b->step?b->step:1;
            set_parameter(u,out,u->focused,(unsigned)clamp((int64_t)b->value+(int64_t)e->value*step,0,SP_UI_VALUE_MAX));
            u->picked_up[u->focused]=0;
        }return;
    }
    if (e->type==SP_UI_CTRL_MOVE && e->index<3 && e->value>=0 && (uint32_t)e->value<=SP_UI_VALUE_MAX) {
        if(u->page==SP_UI_SAVED)page(u,SP_UI_PLAY);
        unsigned k=e->index;unsigned value=(unsigned)e->value;
        if (u->page==SP_UI_BROWSER) {
            if (k==2)emit(out,SP_UI_CMD_PREVIEW_LEVEL)->value=e->value;
            else {
                if(k==0)u->browse_family=(uint8_t)(value*9u/16384u);else u->browse_favorites=value>=8192;
                for(unsigned i=0;i<u->catalog_count;++i)if(matches(u,i)){u->browse_index=(uint16_t)i;audition(u,out);break;}
            }return;
        }
        if ((unsigned)u->page>=SP_UI_PAGE_COUNT || !u->bank_count[u->page])return;
        u->focused=(uint8_t)k;unsigned target=u->bindings[u->page][u->banks[u->page]][k].value;
        if (value==target || (knob_was_known && ((previous_knob<=target && value>=target)||(previous_knob>=target && value<=target))))u->picked_up[k]=1;
        if (u->picked_up[k]) {u->pickup_visible=0;set_parameter(u,out,k,value);}
        else {u->pickup_visible=1;u->pickup_knob=(uint8_t)k;u->pickup_direction=value<target?1:-1;}
    }
}

/* Authenticated adapter intent enters here; no backend acknowledgment or
 * held take can be replaced. The next distinct REC still owns START. */
int sp_ui_capture_destination(sp_ui *u,uint8_t bank,uint8_t pad) {
    if(!u || bank>=10 || pad<1 || pad>16 || u->busy || u->take_held ||
       u->take_token || recovery(u) || (u->page!=SP_UI_PLAY && u->page!=SP_UI_SAVED &&
       u->page!=SP_UI_CAPTURE_READY))return 0;
    u->dest_bank=bank;u->dest_pad=pad;u->dest_known=0;u->dest_occupied=0;return 1;
}
