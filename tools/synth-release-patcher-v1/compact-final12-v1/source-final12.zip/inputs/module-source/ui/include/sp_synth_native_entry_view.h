#ifndef SP_SYNTH_NATIVE_ENTRY_VIEW_H
#define SP_SYNTH_NATIVE_ENTRY_VIEW_H

#include "sp_synth_ui_render.h"

/* UI-only status values. The native provider must verify its mapping when
 * integrating this helper; this header has no provider/API dependency. */
enum {
    SP_UI_NATIVE_ENTRY_WAIT_DRAIN=0,
    SP_UI_NATIVE_ENTRY_READY=1,
    SP_UI_NATIVE_ENTRY_STOP_PLAYBACK=2,
    SP_UI_NATIVE_ENTRY_CANCELING=3,
    SP_UI_NATIVE_ENTRY_UNAVAILABLE=-1,
    SP_UI_NATIVE_ENTRY_FAULT=-2
};

/* Make the saved native-entry view for WAIT_DRAIN, STOP_PLAYBACK or CANCELING.
 * Returns 1 and replaces the complete view only for those statuses. Returns 0
 * for a NULL view, READY, UNAVAILABLE, FAULT or an unknown status; an existing
 * view remains byte-for-byte unchanged. No app state, inputs, I/O, native calls
 * or Synth admission are performed. The presenter owns all control behavior. */
int sp_ui_make_native_entry_view(int32_t native_status,sp_ui_view *view);

#endif
