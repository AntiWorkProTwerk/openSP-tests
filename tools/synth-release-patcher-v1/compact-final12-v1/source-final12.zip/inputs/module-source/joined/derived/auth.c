#include "sp_p6_record_backend_v552.h"
#include "sp_p6_production_join.h"
#include "sp_p6_record_audio_v552.h"
#include "sp_p6_record_request_v552.h"
#include "sp_p6_record_retirement_v552.h"
#include "sp_p6_session_binding_v552.h"
#include "sp_p6_record_producer_v552.h"
#include <string.h>

/* Separate fail-closed imports keep the backend buildable before the request
 * and preview-audio peers are linked. Strong source-owned owners replace these
 * leaves in a later reviewed composition. None grants admission. */
__attribute__((weak)) const SpAppRequest *sp_p6_record_request_v552_claim(void) {return 0;}
__attribute__((weak)) int sp_p6_record_request_v552_finished(void) {return 0;}
__attribute__((weak)) SpSynthSessionV552 *sp_p6_record_audio_v552_session(void) {return 0;}
__attribute__((weak)) int sp_p6_record_audio_v552_receipt(SpP6RecordAudioReceiptV552 *r) {(void)r;return 0;}
__attribute__((weak)) int sp_p6_record_audio_v552_source_current(uint32_t v,uint32_t i,uint32_t g) {(void)v;(void)i;(void)g;return 0;}

static int envelope(SpSynthCaptureTimedV552 *c,SpSynthBackendLink *b) {
    SpSynthSessionV552 *s=sp_p6_record_audio_v552_session();
    return c==&sp_p6_production_capture && s==&sp_p6_production_session && b==&s->backend &&
        atomic_load_explicit(&c->backend,memory_order_acquire)==b &&
        !atomic_load_explicit(&b->responses.stopped,memory_order_acquire);
}
/* Only the source-owned retiring LEAVE may outlive its native page.
 * Initial acquisition still requires the normal live PCM receipt. This lane
 * retains an already acquired exact request after retirement starts; it never
 * admits START, tokenless ordinary STOP, SAVE or a fresh phase1 request. */
static const SpAppRequest *retiring_leave(SpSynthCaptureTimedV552 *c,SpSynthBackendLink *b) {
    SpP6RecordRequestV552 *owner=&sp_p6_record_request_v552;
    if(c!=&sp_p6_production_capture || b!=&sp_p6_production_session.backend ||
       atomic_load_explicit(&c->backend,memory_order_acquire)!=b ||
       atomic_load_explicit(&b->responses.stopped,memory_order_acquire) ||
       atomic_load_explicit(&b->request_phase,memory_order_acquire)!=2 || !c->working ||
       c->work.type!=SP_APP_REQUEST_LEAVE || c->work.token ||
       memcmp(&c->work,&b->request,sizeof(c->work)) ||
       atomic_load_explicit(&owner->fault,memory_order_acquire) ||
       atomic_load_explicit(&owner->phase,memory_order_acquire)!=SP_P6_RQ_WORKING ||
       owner->request_type!=SP_APP_REQUEST_LEAVE || owner->request_token ||
       owner->generation!=c->work.generation || owner->working_generation!=c->work.generation ||
       !owner->visit || !owner->intent || !owner->audio_sequence ||
       !sp_p6_record_retirement_v552_request_current(owner->visit,owner->intent,
           owner->generation,owner->audio_sequence))return 0;
    const SpAppRequest *r=sp_p6_record_request_v552_claim();
    return r==&b->request && r->type==SP_APP_REQUEST_LEAVE && !r->token &&
        !memcmp(r,&c->work,sizeof(*r))?r:0;
}
const SpAppRequest *sp_p6_record_backend_v552_claim(SpSynthCaptureTimedV552 *c,SpSynthBackendLink *b) {
    if(!envelope(c,b))return retiring_leave(c,b);
    const SpAppRequest *r=sp_p6_record_request_v552_claim();
    if(r!=&b->request || atomic_load_explicit(&b->request_phase,memory_order_acquire)!=2)return 0;
    SpP6RecordAudioReceiptV552 receipt;
    return sp_p6_record_audio_v552_receipt(&receipt) && receipt.generation==r->generation &&
        sp_p6_record_audio_v552_source_current(receipt.visit,receipt.intent,r->generation)?r:0;
}
int sp_p6_record_backend_v552_retained(SpSynthCaptureTimedV552 *c,SpSynthBackendLink *b) {
    const SpAppRequest *r=sp_p6_record_backend_v552_claim(c,b);
    return r && c->working && !memcmp(r,&c->work,sizeof(*r));
}
int sp_p6_record_backend_v552_finished(void) {return sp_p6_record_request_v552_finished();}
int sp_p6_record_backend_v552_panel(void) {
    SpSynthSessionV552 *s=sp_p6_record_audio_v552_session();
    SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    SpSynthCaptureTimedV552 *c=&sp_p6_production_capture;
    if(!s || s!=&sp_p6_production_session)return 0;
    uint32_t pm,fm,bp,ip;
    __asm__ volatile("mrs %0,primask":"=r"(pm));__asm__ volatile("mrs %0,faultmask":"=r"(fm));
    __asm__ volatile("mrs %0,basepri":"=r"(bp));__asm__ volatile("mrs %0,ipsr":"=r"(ip));
    if(pm || fm || bp || ip || *(volatile const uint32_t *)(uintptr_t)0x202BBBF8 ||
       *(volatile const uint32_t *)(uintptr_t)0x80245764 || !b->task ||
       ((uint32_t (*)(void))(uintptr_t)0x800D3163)()!=b->task ||
       *(volatile const uint32_t *)(uintptr_t)0x8300A3E8!=b->task ||
       atomic_load_explicit(&b->phase,memory_order_acquire)!=SP_P6_SB_PREPARED ||
       atomic_load_explicit(&b->fault,memory_order_acquire) || !b->sequence ||
       atomic_load_explicit(&b->pending,memory_order_acquire)!=b->sequence ||
       m->voice_used!=b->visit || atomic_load_explicit(&m->ready,memory_order_acquire)!=1 ||
       atomic_load_explicit(&m->terminal,memory_order_acquire) ||
       atomic_load_explicit(&m->phase,memory_order_acquire)!=SP_PREVIEW_NATIVE_ACTIVE ||
       atomic_load_explicit(&m->entry.fault,memory_order_acquire) ||
       (uintptr_t)atomic_load_explicit(&m->active_page,memory_order_acquire)!=b->page || !b->page ||
       *(volatile const uint32_t *)(uintptr_t)0x80CFD4FC!=b->page ||
       *(volatile const uint32_t *)(uintptr_t)b->page!=(uintptr_t)(m->primary+2) ||
       sp_p6_record_producer_v552.capture!=c || c->sample_rate_hz!=48000)return 0;
    SpSynthBackendLink *link=atomic_load_explicit(&c->backend,memory_order_acquire);
    if(link)return link==&s->backend?2:0;
    return sp_synth_capture_timed_v552_publish(s);
}
uint32_t sp_p6_record_backend_v552_blocked(void) {
    uint32_t blocked=SP_P6_RB_NATIVE_ADMISSION;
    SpSynthCaptureTimedV552 *c=&sp_p6_production_capture;
    SpSynthSessionV552 *s=sp_p6_record_audio_v552_session();
    if(!s || s!=&sp_p6_production_session)return blocked|SP_P6_RB_REQUEST|SP_P6_RB_SOURCE|SP_P6_RB_TAKE;
    SpSynthBackendLink *b=&s->backend;
    if(!envelope(c,b) || !c->working || atomic_load_explicit(&b->request_phase,memory_order_acquire)!=2 ||
       memcmp(&c->work,&b->request,sizeof(c->work)))blocked|=SP_P6_RB_REQUEST;
    SpP6RecordAudioReceiptV552 receipt;
    if(!sp_p6_record_audio_v552_receipt(&receipt) || receipt.generation!=b->request.generation ||
       !sp_p6_record_audio_v552_source_current(receipt.visit,receipt.intent,b->request.generation))blocked|=SP_P6_RB_SOURCE;
    uint32_t pm,fm,bp,ip;
    __asm__ volatile("mrs %0,primask":"=r"(pm));__asm__ volatile("mrs %0,faultmask":"=r"(fm));
    __asm__ volatile("mrs %0,basepri":"=r"(bp));__asm__ volatile("mrs %0,ipsr":"=r"(ip));
    if(pm || fm || bp || ip)blocked|=SP_P6_RB_CONTEXT;
    if(atomic_load_explicit(&c->state,memory_order_acquire)!=SP_TCAP_HELD ||
       !atomic_load_explicit(&c->token,memory_order_acquire))blocked|=SP_P6_RB_TAKE;
    for(unsigned i=0;i<30;i++)if(*(volatile const uint8_t *)(uintptr_t)(UINT32_C(0x82FE4F08)+60u+12u*i))blocked|=SP_P6_RB_DRAIN;
    return blocked;
}
