#include "sp_p6_record_retirement_v552.h"
#include "sp_p6_record_retirement_join_v552.h"
#include "sp_p6_record_audio_v552.h"
#include "sp_p6_record_request_v552.h"
#include "sp_synth_memory_v552.h"
#include "sp_p6_production_join.h"
#include "sp_p6_session_binding_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_token_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_project_gate_v552.h"
#include "sp_p6_record_ingress_alias_v552.h"
#include "sp_p6_save_handover_v552.h"
#include "sp_p6_transaction_ingress_v552.h"
#include "sp_p6_record_mutation_closure_v552.h"
#include <limits.h>

SpP6RecordRetirementV552 sp_p6_record_retirement_v552;
_Static_assert(sizeof(SpP6RecordRetirementV552)==52,"Compact retirement owner");
_Static_assert(sizeof(SpSynthSessionV552)==3824,"Pinned session ABI");
_Static_assert(sizeof(SpSynthCaptureTimedV552)==1336,"Pinned capture ABI");
_Static_assert(sizeof(SpSynthRuntimeStorage)==116032,"Pinned runtime ABI");
#define C (&sp_p6_production_capture)
#define S (&sp_p6_production_session)
#define M (&sp_synth_preview_native_v552)
#define B (&sp_p6_session_binding_v552)
#define O (&sp_p6_record_retirement_v552)
#define val(p) atomic_load_explicit((p),memory_order_acquire)
static uint32_t rd(uint32_t a) { return *(volatile const uint32_t *)(uintptr_t)a; }
static uint16_t half(uint32_t a) { return *(volatile const uint16_t *)(uintptr_t)a; }
static uint8_t byte(uint32_t a) { return *(volatile const uint8_t *)(uintptr_t)a; }
static uint32_t lock(void) { uint32_t p;__asm__ volatile("mrs %0,primask\n cpsid i":"=r"(p)::"memory");return p; }
static void unlock(uint32_t p) { __asm__ volatile("dmb\n msr primask,%0"::"r"(p):"memory"); }
static uint32_t current(void) {
    uint32_t i,p,b,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));__asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(b));__asm__ volatile("mrs %0,faultmask":"=r"(f));
    if(i || p || b || f || rd(0x202BBBF8) || rd(0x80245764))return 0;
    return ((uint32_t (*)(void))(uintptr_t)0x800D3163)();
}
static int smpl(void) { return current() && sp_p6_record_context_v552_current(1); }
static int panel(void) { uint32_t t=current();return t && t==M->task_id && t==rd(0x8300A3E8); }
/* App/mailbox park is an independently source-owned dependency. This selected
 * component has no linked audio provider, so its default can only refuse. */
__attribute__((weak)) int sp_p6_record_audio_v552_parked(uint32_t visit,uint32_t intent,uint32_t ticket) {
    (void)visit;(void)intent;(void)ticket;return 0;
}
__attribute__((weak)) int sp_p6_record_audio_v552_stop_current(uint32_t visit,uint32_t intent,uint32_t sequence) {
    (void)visit;(void)intent;(void)sequence;return 0;
}
/* Added to the exact local token derivation, reading its private last_retired.
 * No caller supplies that token, and no native/file operation runs here. */
extern uint32_t sp_p6_record_retirement_v552_token_retired(void);
static int session(void) {
    return sp_p6_production_cold_started() && val(&B->phase)==SP_P6_SB_PREPARED &&
        !val(&B->fault) && val(&B->pending) && B->sequence==val(&B->pending) && B->visit && S->startup.ready==1 &&
        S->startup.memory.attached==1 && S->startup.memory.storage && !val(&S->terminal);
}
static int request(void) {
    return session() && val(&C->backend)==&S->backend && val(&S->backend.request_phase)==2 &&
        C->working && C->work.type==SP_APP_REQUEST_LEAVE && C->work.token==0 &&
        S->backend.request.type==C->work.type && S->backend.request.generation==C->work.generation &&
        S->backend.request.token==C->work.token && !val(&S->backend.responses.stopped);
}
/* Called with interrupts masked; only source fields and volatile native state
 * are read. No RTOS/native/file callback executes under this final snapshot. */
static uint32_t leases(void) {
    uint32_t fail=0,token=C->last_token;
    SpP6RecordProducerV552 *p=&sp_p6_record_producer_v552;
    SpP6RecordFilesV552 *f=&sp_p6_record_files_v552;
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    SpP6RecordIngressAliasV552 *a=&sp_p6_record_ingress_alias_v552;
    SpP6SaveHandoverV552 *save=&sp_p6_save_handover_v552;
    unsigned state=val(&C->state);
    if((state!=SP_TCAP_WAIT_DELETE && state!=SP_TCAP_RELEASE_BARRIER && state!=SP_TCAP_FREE &&
        state!=SP_TCAP_EXCLUSIVE_IDLE) || val(&C->token) || val(&C->rx_active) || C->window.inflight ||
        C->file_owned || val(&C->fault) || val(&C->handoff_fault) || val(&C->record_ready)!=1 ||
        byte(0x82E0E755) || byte(0x82E0E96A) || (int32_t)rd(0x82E0E764)>=0 ||
        rd(0x82E0E96C) || rd(0x82E0E970)!=0x82FE4F08 || rd(0x82FE4F08)!=0x8021E020 ||
        (int32_t)rd(0x82FE50B8)>=0 || rd(0x82FE50AC)>=30 || rd(0x82FE50B0)>=30)fail|=SP_P6_RR_CAPTURE;
    for(unsigned i=0;i<30;i++)if(byte(0x82FE4F44+12*i) || rd(0x82FE4F48+12*i))fail|=SP_P6_RR_CAPTURE;
    if(p->capture!=C || p->fault || p->held || p->active || p->token || p->pending || p->drain_requested ||
       g->fault || g->active || g->count || a->fault || a->active || a->busy || a->outer_count || a->inner_size ||
       rd(0x8300A4D8)!=0x8021D034 || !p->task || p->task>32 || rd(0x8300A4DC)!=p->task ||
       rd(0x82E0D654)!=p->task || rd(0x82E0D658)!=0x80064E39 ||
       rd(0x82E0D630)!=0x80B0D538 || rd(0x82E0D648)!=0x80B14F00 ||
       half(0x82E0D634)>=128 || half(0x82E0D636)>=128 || half(0x82E0D64C)>=128 || half(0x82E0D64E)>=128 ||
       rd(0x82E0E5F8)!=0x8022CFE8 || rd(0x82E0E5FC)>8 || rd(0x82E0E600)>8 ||
       rd(0x82E0E5FC)!=rd(0x82E0E600) || half(0x82E0D638) || half(0x82E0D650) ||
       half(0x82E0D63A)!=128 || half(0x82E0D652)!=128 ||
       rd(0x805917E0)!=rd(0x805917E4) || rd(0x805917A4)!=rd(0x805917A8))fail|=SP_P6_RR_QUEUE;
    if(f->active || f->fault || f->smpl_operation || f->record_operation || f->cache_depth ||
       sp_p6_record_files_v552_outstanding())fail|=SP_P6_RR_FILES;
    if(token) {
        unsigned seq=val(&C->barrier_sequence);
        if(C->plan.take_token!=token || !C->plan.start_generation || val(&C->cleanup_token)!=token ||
           val(&C->rx_ack)!=token || p->last_retired!=token ||
           sp_p6_record_retirement_v552_token_retired()!=token)fail|=SP_P6_RR_TOKEN;
        if(save->state==SP_P6_SAVE_TRANSFERRED && save->token==token) {
            /* Historical native transfer; stock may later close/replace its
             * live cache FILE. Never dereference or reclose the old receipt. */
            if(save->capture!=C || save->fault || save->generation!=C->plan.start_generation ||
               !save->sequence || save->wait_sequence!=save->sequence || save->ack_sequence!=save->sequence ||
               save->cache.kind!=SP_P6_RF_CACHE || save->cache.state!=SP_P6_RF_LIVE ||
               save->cache.close_attempted || !save->cache.fd || !save->cache.file)fail|=SP_P6_RR_FILES;
        } else if(!C->discard_attempted || C->close_raw || C->unlink_raw || !seq ||
                  val(&C->barrier_token)!=token || val(&C->barrier_ack)!=seq || val(&C->wait_sequence)!=seq)
            fail|=SP_P6_RR_FILES;
    } else if(val(&C->cleanup_token) || C->plan.take_token || p->last_retired ||
              sp_p6_record_retirement_v552_token_retired())fail|=SP_P6_RR_TOKEN;
    return fail;
}
uint32_t sp_p6_record_retirement_v552_lease_blocks(void) {
    if(!smpl())return SP_P6_RR_CONTEXT;
    uint32_t p=lock(),b=leases();unlock(p);return b;
}
static int identity(void) {
    return request() && O->ticket==val(&C->exit_ticket) && O->lifetime==B->visit &&
        O->lifetime==M->voice_used && O->intent==val(&B->pending) &&
        O->start_generation==C->plan.start_generation && O->take_token==C->last_token &&
        O->generation==C->work.generation && O->token==C->work.token;
}
static int retained(uint32_t visit,uint32_t intent,uint32_t generation,uint32_t sequence) {
    return session() && visit && intent && sequence && visit==O->lifetime && intent==O->intent &&
        generation==O->generation && !O->token && O->ticket && O->ticket==val(&C->exit_ticket) &&
        visit==B->visit && visit==M->voice_used && intent==val(&B->pending) &&
        O->start_generation==C->plan.start_generation && O->take_token==C->last_token &&
        val(&C->backend)==&S->backend && C->working && C->work.type==SP_APP_REQUEST_LEAVE &&
        C->work.generation==generation && !C->work.token && !val(&S->backend.responses.stopped) &&
        S->backend.request.type==SP_APP_REQUEST_LEAVE && S->backend.request.generation==generation &&
        !S->backend.request.token && sp_p6_record_audio_v552_stop_current(visit,intent,sequence);
}
static int native_quiet(void) {
    return val(&M->ready)==1 && !val(&M->terminal) && !val(&M->entry.fault) &&
        !M->entry.input.enabled && !M->entry.dispatch_depth && !M->entry.sample_depth &&
        !M->command && M->normal_stop_ticket && !sp_synth_preview_voice_faults(&M->voice) &&
        sp_synth_preview_voice_idle_ack(&M->voice)==M->normal_stop_ticket &&
        sp_synth_preview_voice_permission_ack(&M->voice)==M->normal_stop_ticket &&
        M->route_ticket && !(M->route_ticket&1u) && !val(&M->generator.fault) &&
        val(&M->generator.requested)==M->route_ticket &&
        sp_synth_generator_route_v552_ack(&M->generator)==M->route_ticket;
}
int sp_synth_live_session_v552_exit_request(uint32_t ticket,uint32_t generation,uint32_t token) {
    if(!smpl() || !ticket || val(&O->phase)!=SP_P6_RR_EMPTY || !request() ||
       generation!=C->work.generation || token!=C->work.token || ticket!=val(&C->exit_ticket) ||
       !sp_synth_capture_timed_v552_exit_ready(ticket) || B->visit!=M->voice_used ||
       val(&M->phase)!=SP_PREVIEW_NATIVE_ACTIVE || !val(&M->active_page) ||
       (uintptr_t)val(&M->active_page)!=rd(0x80CFD4FC) ||
       rd(rd(0x80CFD4FC))!=(uintptr_t)(M->primary+2))return 0;
    uint32_t p=lock(),b=leases();
    if(b || !request() || val(&O->phase)!=SP_P6_RR_EMPTY) { unlock(p);return 0; }
    O->ticket=ticket;O->lifetime=B->visit;O->intent=val(&B->pending);
    O->start_generation=C->plan.start_generation;O->take_token=C->last_token;
    O->generation=generation;O->token=token;
    atomic_store_explicit(&O->blocked,SP_P6_RR_PARK|SP_P6_RR_PAGE|SP_P6_RR_NATIVE_COVERAGE,memory_order_relaxed);
    atomic_store_explicit(&O->phase,SP_P6_RR_REQUESTED,memory_order_release);unlock(p);return 1;
}
void sp_p6_record_retirement_v552_panel(void) {
    if(!panel() || val(&O->phase)!=SP_P6_RR_REQUESTED || !identity() ||
       M->entry.dispatch_depth || M->entry.sample_depth || val(&M->terminal))return;
    /* Existing preview owner quiesces its permanent voice, restores NATIVE and
     * invokes stock EXIT. Full recording release still waits for separate park. */
    if(val(&M->phase)==SP_PREVIEW_NATIVE_ACTIVE && !M->command)
        (void)sp_synth_preview_native_v552_select((void *)0x8300A3E4,SP_PREVIEW_EXIT);
}
int sp_p6_record_retirement_v552_native_exit_allowed(void) {
    if(val(&O->phase)==SP_P6_RR_EMPTY)return 1;
    if(!panel() || val(&O->phase)!=SP_P6_RR_REQUESTED || !identity() || !native_quiet())return 0;
    uint32_t p=lock(),b=leases();unlock(p);
    b|=sp_p6_record_retirement_v552_mode_hook_blocks();
    if(!sp_p6_record_audio_v552_parked(O->lifetime,O->intent,M->normal_stop_ticket))b|=SP_P6_RR_PARK;
    atomic_store_explicit(&O->blocked,b|SP_P6_RR_PAGE|SP_P6_RR_NATIVE_COVERAGE,memory_order_release);
    return b==0;
}
void sp_p6_record_retirement_v552_factory_enter(const uint16_t *event) {
    if(!event || *event!=2 || !panel() || val(&O->phase)!=SP_P6_RR_REQUESTED || !identity() ||
       !native_quiet() || !sp_p6_record_audio_v552_parked(O->lifetime,O->intent,M->normal_stop_ticket) ||
       val(&M->phase)!=SP_PREVIEW_NATIVE_WAIT_NATIVE || !M->exit_requested ||
       !val(&M->active_page) || (uintptr_t)val(&M->active_page)!=rd(0x80CFD4FC) ||
       rd(rd(0x80CFD4FC))!=(uintptr_t)(M->primary+2))return;
    O->destructor_returned=0;
    atomic_store_explicit(&O->phase,SP_P6_RR_DELETING,memory_order_release);
}
void sp_p6_record_retirement_v552_destructor_return(void) {
    if(panel() && val(&O->phase)==SP_P6_RR_DELETING && identity() &&
       !val(&M->active_page) && !val(&M->retired_page) && native_quiet())O->destructor_returned=1;
}
void sp_p6_record_retirement_v552_factory_return(const uint16_t *event) {
    if(!event || *event!=2 || !panel() || val(&O->phase)!=SP_P6_RR_DELETING || !identity() ||
       !O->destructor_returned || rd(0x80CFD4FC) || val(&M->active_page) || val(&M->retired_page) ||
       val(&M->phase)!=SP_PREVIEW_NATIVE_LEFT || !M->exit_requested || !native_quiet())return;
    atomic_fetch_and_explicit(&O->blocked,~SP_P6_RR_PAGE,memory_order_relaxed);
    atomic_store_explicit(&O->phase,SP_P6_RR_DELETED,memory_order_release);
}
/* Alias/media/interior/bulk ordering and physical native leases remain
 * unclosed in the sealed provider. An empty snapshot cannot repair that. */
uint32_t sp_p6_record_retirement_v552_hook_blocks(void) {
    return (!sp_p6_ia_v552_quiescent() || !sp_p6_tx_v552_quiescent() ||
            !sp_p6_mc_v552_hook_coverage())?SP_P6_RR_NATIVE_COVERAGE:
            sp_p6_record_retirement_v552_mode_hook_blocks();
}
static int recording_owned(void) {
    if(val(&O->phase)==SP_P6_RR_RELEASED && val(&O->released)==1 && O->destructor_returned &&
       O->released_ticket==O->ticket && O->released_lifetime==O->lifetime &&
       val(&C->state)==SP_TCAP_FREE && val(&C->released_ticket)==O->ticket)return 0;
    return val(&O->phase)!=SP_P6_RR_EMPTY ||
        (val(&B->phase)==SP_P6_SB_PREPARED && val(&B->pending)) || val(&C->token) ||
        val(&C->rx_active) || C->file_owned || sp_p6_record_producer_v552.held ||
        sp_p6_record_files_v552.active;
}
static int ordered_mode_exit(unsigned published) {
    if(!panel() || val(&O->phase)!=SP_P6_RR_REQUESTED || !identity() || !native_quiet() ||
       val(&M->phase)!=SP_PREVIEW_NATIVE_WAIT_NATIVE || (published?!M->exit_requested:M->exit_requested) ||
       half(0x8024587A)!=30 || half(0x80245880)!=30 || !val(&M->active_page) ||
       (uintptr_t)val(&M->active_page)!=rd(0x80CFD4FC) ||
       rd(rd(0x80CFD4FC))!=(uintptr_t)(M->primary+2) ||
       !sp_p6_record_audio_v552_parked(O->lifetime,O->intent,M->normal_stop_ticket) ||
       sp_p6_record_retirement_v552_mode_hook_blocks())return 0;
    uint32_t p=lock(),b=leases();unlock(p);return !b;
}
int sp_p6_record_retirement_v552_mode_allowed(uint32_t mode,uint32_t link) {
    if(mode==30 && val(&O->phase)==SP_P6_RR_RELEASED && !sp_p6_record_rearm_v552_preconstructed()) {
        atomic_fetch_or_explicit(&O->blocked,SP_P6_RR_ROUTE,memory_order_release);return 0;
    }
    if(!recording_owned())return 1;
    /* Exact stock Generator EXIT's BL continuation. Expected mode/LR are
     * matched to real source retirement; callers cannot grant readiness. */
    if(mode==1 && (link&~1u)==0x8015C96E && ordered_mode_exit(0))return 1;
    atomic_fetch_or_explicit(&O->blocked,SP_P6_RR_ROUTE,memory_order_release);return 0;
}
int sp_p6_record_retirement_v552_coordinator_allowed(void) {
    if((rd(0x8059245C)&0x8000u) && half(0x8024587C)==30 &&
       val(&O->phase)==SP_P6_RR_RELEASED && !sp_p6_record_rearm_v552_preconstructed()) {
        atomic_fetch_or_explicit(&O->blocked,SP_P6_RR_ROUTE,memory_order_release);return 0;
    }
    if(!recording_owned() || !(rd(0x8059245C)&0x8000u) || half(0x8024587C)==0xFFFFu)return 1;
    if(half(0x8024587C)==1 && ordered_mode_exit(1))return 1;
    atomic_fetch_or_explicit(&O->blocked,SP_P6_RR_ROUTE,memory_order_release);return 0;
}
uint32_t sp_p6_record_retirement_v552_unclosed(void) {
    /* Selected join's declared proof gaps. This is an inventory, never a
     * caller-supplied qualification input or a zero queue pretending coverage.
     * Setter132, case3/1F9 and whole-load enclosing hooks are already installed. */
    return SP_P6_RR_UNCLOSED_SECONDARY_ORDER|SP_P6_RR_UNCLOSED_HEAP_REFERENCE|
           SP_P6_RR_UNCLOSED_CWD_VOLUME|SP_P6_RR_UNCLOSED_LOWER_INTERIOR;
}
static int coverage(void) {
    return !sp_p6_record_retirement_join_v552_bounded_blocks();
}
int sp_synth_live_session_v552_exit_ack(uint32_t ticket) {
    if(!smpl() || !ticket || ticket!=O->ticket || val(&O->phase)!=SP_P6_RR_DELETED ||
       !identity() || !native_quiet() || rd(0x80CFD4FC) || val(&M->active_page) || val(&M->retired_page))return 0;
    uint32_t p=lock(),b=leases();unlock(p);
    if(!sp_p6_record_audio_v552_parked(O->lifetime,O->intent,M->normal_stop_ticket))b|=SP_P6_RR_PARK;
    if(!coverage())b|=SP_P6_RR_NATIVE_COVERAGE;
    atomic_store_explicit(&O->blocked,b,memory_order_release);return b==0;
}
int sp_synth_live_session_v552_backend_released(uint32_t ticket,uint32_t lifetime,uint32_t generation,uint32_t token) {
    if(!smpl() || ticket!=O->ticket || !ticket || lifetime!=O->lifetime || generation!=O->generation ||
       token!=O->token || val(&O->phase)!=SP_P6_RR_DELETED || val(&O->released) ||
       !session() || val(&C->backend)!=&S->backend || !C->working ||
       C->work.type!=SP_APP_REQUEST_LEAVE || C->work.generation!=generation || C->work.token!=token ||
       !O->destructor_returned || rd(0x80CFD4FC) || val(&M->active_page) || val(&M->retired_page) ||
       val(&M->phase)!=SP_PREVIEW_NATIVE_LEFT || val(&S->backend.responses.stopped) ||
       val(&C->state)!=SP_TCAP_FREE || val(&C->released_ticket)!=ticket ||
       val(&S->backend.request_phase) || S->backend.request.type!=SP_APP_REQUEST_LEAVE ||
       S->backend.request.generation!=generation || S->backend.request.token!=token ||
       !native_quiet() || !sp_p6_record_audio_v552_parked(lifetime,O->intent,M->normal_stop_ticket) ||
       !coverage())return 0;
    uint32_t p=lock(),b=leases();
    if(b || O->lifetime!=B->visit || O->lifetime!=M->voice_used || O->intent!=val(&B->pending) ||
       O->start_generation!=C->plan.start_generation || O->take_token!=C->last_token || val(&O->released)) {
        unlock(p);return 0;
    }
    O->released_ticket=ticket;O->released_lifetime=lifetime;
    atomic_store_explicit(&O->phase,SP_P6_RR_RELEASED,memory_order_relaxed);
    atomic_store_explicit(&O->released,1,memory_order_release);unlock(p);return 1;
}
int sp_p6_record_retirement_v552_request_current(uint32_t visit,uint32_t intent,uint32_t generation,uint32_t sequence) {
    unsigned phase=val(&O->phase);
    if(phase==SP_P6_RR_RELEASED)
        return sp_p6_record_retirement_v552_request_finished(visit,intent,generation,sequence);
    if((!smpl() && !panel()) || (phase!=SP_P6_RR_REQUESTED && phase!=SP_P6_RR_DELETING && phase!=SP_P6_RR_DELETED) ||
       !retained(visit,intent,generation,sequence) || !identity() || val(&M->terminal) || val(&M->entry.fault))return 0;
    if(phase==SP_P6_RR_REQUESTED)return val(&M->phase)==SP_PREVIEW_NATIVE_STOPPING ||
        val(&M->phase)==SP_PREVIEW_NATIVE_WAIT_NATIVE;
    return native_quiet() && sp_p6_record_audio_v552_parked(visit,intent,M->normal_stop_ticket) &&
        (phase!=SP_P6_RR_DELETED || (O->destructor_returned && val(&M->phase)==SP_PREVIEW_NATIVE_LEFT &&
         !rd(0x80CFD4FC) && !val(&M->active_page) && !val(&M->retired_page)));
}
int sp_p6_record_retirement_v552_request_finished(uint32_t visit,uint32_t intent,uint32_t generation,uint32_t sequence) {
    return smpl() && val(&O->phase)==SP_P6_RR_RELEASED && val(&O->released)==1 &&
        retained(visit,intent,generation,sequence) && !val(&S->backend.request_phase) &&
        O->destructor_returned && O->released_ticket==O->ticket && O->released_lifetime==visit &&
        val(&C->state)==SP_TCAP_FREE && val(&C->released_ticket)==O->ticket && native_quiet() &&
        val(&M->phase)==SP_PREVIEW_NATIVE_LEFT && !rd(0x80CFD4FC) &&
        !val(&M->active_page) && !val(&M->retired_page) &&
        sp_p6_record_audio_v552_parked(visit,intent,M->normal_stop_ticket) && coverage();
}
uint32_t sp_p6_record_retirement_v552_admission(void) { return 0; }

/* The historical inventory remains15. This source-supported policy is only
 * the bounded manual120s, synth-only, tail-off, empty-pad contract. */
uint32_t sp_p6_record_retirement_join_v552_bounded_blocks(void) {
    uint32_t b=0;
    if(B->settings.source!=SP_P6_SOURCE_SYNTH_ONLY || B->settings.mode!=SP_P6_PHRASE_MANUAL ||
       B->settings.bars!=4 || B->settings.include_release_tail || B->settings.count_in_bars ||
       B->settings.alignment!=SP_P6_PHRASE_ALIGN_CALLBACK ||
       B->settings.destination_bank>=10 || B->settings.destination_pad<1 || B->settings.destination_pad>16)
        b|=SP_P6_RJ_POLICY;
    if(!session() || val(&S->ready)!=1 || !S->startup.memory.allocation ||
       !val(&M->ready) || val(&M->terminal) || val(&M->entry.fault))b|=SP_P6_RJ_SESSION;
    if(sp_p6_record_retirement_v552_hook_blocks())b|=SP_P6_RJ_HOOK;
    if(B->destination.channels || B->destination.cache_busy || B->pattern.project>=128 ||
       B->destination.project!=B->pattern.project || B->pattern.tempo100<2000 ||
       B->pattern.tempo100>30000 || B->pattern.storage_mode)b|=SP_P6_RJ_DESTINATION;
    uintptr_t p=(uintptr_t)S->startup.memory.storage;
    if(!p || (p&7u) || p<SP_SYNTH_V552_POOL_BEGIN || p>SP_SYNTH_V552_POOL_END-sizeof(SpSynthRuntimeStorage))
        b|=SP_P6_RJ_SESSION;
    else {
        const SpAppCapture *c=&S->startup.memory.storage->controller.capture;
        if(c->mode!=0 || c->seconds!=120.0f || c->bars!=4.0f || c->include_release_tail || c->count_in_bars ||
           c->tempo_bpm!=(float)B->pattern.tempo100*0.01f)b|=SP_P6_RJ_POLICY;
    }
    unsigned phase=val(&M->phase);
    if(phase==SP_PREVIEW_NATIVE_ACTIVE) {
        if(sp_p6_record_audio_v552_session()!=S || B->visit!=M->voice_used ||
           !val(&M->active_page) || (uintptr_t)val(&M->active_page)!=rd(0x80CFD4FC) ||
           rd(rd(0x80CFD4FC))!=(uintptr_t)(M->primary+2))b|=SP_P6_RJ_IDENTITY;
    } else if((val(&O->phase)!=SP_P6_RR_DELETED && val(&O->phase)!=SP_P6_RR_RELEASED) ||
       !O->destructor_returned || O->lifetime!=B->visit || O->lifetime!=M->voice_used ||
       O->intent!=val(&B->pending) || phase!=SP_PREVIEW_NATIVE_LEFT || rd(0x80CFD4FC) ||
       val(&M->active_page) || val(&M->retired_page) || !native_quiet() ||
       !sp_p6_record_audio_v552_parked(O->lifetime,O->intent,M->normal_stop_ticket))b|=SP_P6_RJ_IDENTITY;
    return b;
}
int sp_p6_record_retirement_v552_rearm_ready(void) {
    uint32_t task=current();
    if(!task || (task!=M->task_id && !sp_p6_record_context_v552_current(1)) ||
       (task==M->task_id && task!=rd(0x8300A3E8)) || val(&O->phase)!=SP_P6_RR_RELEASED ||
       val(&O->released)!=1 || !O->destructor_returned || !O->ticket ||
       O->released_ticket!=O->ticket || O->released_lifetime!=O->lifetime ||
       O->ticket!=val(&C->exit_ticket) || O->ticket!=val(&C->released_ticket) ||
       O->start_generation!=C->plan.start_generation || O->take_token!=C->last_token ||
       val(&C->state)!=SP_TCAP_FREE || C->working || val(&C->handoff_pending) ||
       (val(&C->backend) && val(&C->backend)!=&S->backend) ||
       C->work.type!=SP_APP_REQUEST_LEAVE || C->work.generation!=O->generation || C->work.token ||
       val(&S->backend.request_phase) || val(&S->backend.responses.phase) ||
       val(&S->backend.responses.stopped) || val(&S->backend.capture_cancel_phase) ||
       val(&S->backend.capture_feedback_ready) || S->backend.request.type!=SP_APP_REQUEST_LEAVE ||
       S->backend.request.generation!=O->generation || S->backend.request.token ||
       half(0x8024587A)!=1 || half(0x80245880)!=1 || !native_quiet() ||
       sp_p6_record_retirement_join_v552_bounded_blocks())return 0;
    uint32_t p=lock(),b=leases();unlock(p);return !b;
}
__attribute__((weak)) int sp_p6_record_rearm_v552_reentered(void) {return 0;}
__attribute__((weak)) int sp_p6_record_rearm_v552_preconstructed(void) {return 0;}
int sp_p6_record_retirement_v552_rearm_commit(void) {
    if(!panel() || val(&O->phase)!=SP_P6_RR_RELEASED || val(&O->released)!=1 ||
       !O->destructor_returned || O->released_ticket!=O->ticket || O->released_lifetime!=O->lifetime ||
       val(&C->state)!=SP_TCAP_FREE || C->working || val(&C->backend) || val(&C->token) ||
       val(&C->fault) || val(&C->handoff_fault) || C->file_owned || val(&C->rx_active) || C->window.inflight ||
       val(&M->phase)!=SP_PREVIEW_NATIVE_ACTIVE || !val(&M->active_page) ||
       (uintptr_t)val(&M->active_page)!=rd(0x80CFD4FC) || rd(rd(0x80CFD4FC))!=(uintptr_t)(M->primary+2) ||
       val(&M->terminal) || val(&M->entry.fault) || !M->entry.input.enabled ||
       M->entry.dispatch_depth || M->entry.sample_depth || B->visit!=M->voice_used ||
       B->visit<=O->lifetime || B->sequence<=O->intent || val(&B->pending)!=B->sequence ||
       val(&B->phase)!=SP_P6_SB_PREPARED || val(&B->fault) ||
       !sp_p6_record_rearm_v552_reentered())return 0;
    O->destructor_returned=0;
    atomic_store_explicit(&O->blocked,0,memory_order_relaxed);
    atomic_store_explicit(&O->released,0,memory_order_relaxed);
    atomic_store_explicit(&O->phase,SP_P6_RR_EMPTY,memory_order_release);return 1;
}
int sp_p6_record_retirement_v552_rearmed_no_io(void) {
    if(!panel() || val(&O->phase)!=SP_P6_RR_EMPTY || val(&O->released) || O->destructor_returned ||
       !O->ticket || O->released_ticket!=O->ticket || O->released_lifetime!=O->lifetime ||
       val(&C->state)!=SP_TCAP_FREE || C->working || val(&C->token) || val(&C->handoff_pending) ||
       val(&C->released_ticket)!=O->ticket || val(&C->exit_ticket)!=O->ticket ||
       C->plan.start_generation!=O->start_generation || C->last_token!=O->take_token ||
       val(&M->phase)!=SP_PREVIEW_NATIVE_ACTIVE || !val(&M->active_page) ||
       (uintptr_t)val(&M->active_page)!=rd(0x80CFD4FC) || rd(rd(0x80CFD4FC))!=(uintptr_t)(M->primary+2) ||
       !M->entry.input.enabled || M->entry.sample_depth ||
       B->visit!=M->voice_used || B->visit<=O->lifetime || B->sequence<=O->intent ||
       val(&B->pending)!=B->sequence || sp_p6_record_audio_v552_session()!=S ||
       sp_p6_record_retirement_join_v552_bounded_blocks())return 0;
    uint32_t p=lock(),b=leases();unlock(p);return !b;
}
