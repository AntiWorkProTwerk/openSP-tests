#include "sp_p6_record_controls_v552.h"
#include "sp_p6_record_controls_v552_private.h"
#include "sp_p6_record_rearm_v552.h"
#include "sp_p6_menu.h"
#include "sp_synth_oled_font.h"
#include <string.h>
extern int sp_p6_record_direct_view(uint32_t out[4]);

/* Shared Penpot header/footer positions and existing selected OLED fonts.
 * Every primitive clips to the permanent 128x64 MSB-first buffer. No mutable
 * display allocation, elapsed wall clock or invented capture acknowledgment. */
static void pixel(uint8_t *f,int x,int y) {
    if((unsigned)x<128 && (unsigned)y<64)f[(unsigned)y*16+(unsigned)x/8]|=(uint8_t)(128u>>(x&7));
}
static void horizontal(uint8_t *f,int x,int y,int n) {for(int i=0;i<n;++i)pixel(f,x+i,y);}
static void vertical(uint8_t *f,int x,int a,int b) {if(a>b){int t=a;a=b;b=t;}for(int y=a;y<=b;++y)pixel(f,x,y);}
static void box(uint8_t *f,int x,int y,int w,int h) {
    horizontal(f,x,y,w);horizontal(f,x,y+h-1,w);vertical(f,x,y,y+h-1);vertical(f,x+w-1,y,y+h-1);
}
static void text(uint8_t *f,int x,int y,const char *s,int large,int limit) {
    int w=large?5:3,h=large?7:5,advance=w+1;
    while(*s && x+w<=limit) {
        unsigned ch=(unsigned char)*s++;if(ch>='a' && ch<='z')ch-='a'-'A';if(ch<32 || ch>90)ch='?';
        const uint8_t *rows=large?sp_oled_font_large[ch-32]:sp_oled_font_small[ch-32];
        for(int r=0;r<h;++r)for(int c=0;c<w;++c)if(rows[r]&(1u<<(w-1-c)))pixel(f,x+c,y+r);
        x+=advance;
    }
}
static void header(uint8_t *f,const char *s) {text(f,3,1,s,0,125);horizontal(f,3,9,122);}
static void footer(uint8_t *f,const char *s) {horizontal(f,3,55,122);text(f,3,58,s,0,125);}
static void destination(char out[4],const sp_ui *u) {
    unsigned pad=u->dest_pad;out[0]=u->dest_bank<10?(char)('A'+u->dest_bank):'?';
    out[1]=pad>=1 && pad<=16?(char)('0'+pad/10):'?';out[2]=pad>=1 && pad<=16?(char)('0'+pad%10):'?';out[3]=0;
}
static unsigned fraction(uint64_t n,uint64_t total,unsigned width) {
    if(!total)return 0;
    if(n>=total)return width;
    uint64_t q=total/width,r=total%width;unsigned done=0;
    for(unsigned i=1;i<=width;++i)if(n>=q*i+(r*i+width-1)/width)done=i;
    return done;
}
static int sample_y(int n,int center,int amp) {
    n*=3;if(n<-127)n=-127;if(n>127)n=127;return center-n*amp/127;
}
static void pcm(uint8_t *f,const SpPreviewVisualSnapshot *s,int center,int amp) {
    if(!s){horizontal(f,3,center,96);return;}
    for(unsigned i=0;i<96;++i)vertical(f,3+(int)i,sample_y(s->maximum[i],center,amp),sample_y(s->minimum[i],center,amp));
}
static void pad_grid(uint8_t *f,const sp_ui *u) {
    for(unsigned p=1;p<=16;++p) {
        int x=69+(int)((p-1)%4)*14,y=13+(int)((p-1)/4)*10;
        char num[3]={(char)('0'+p/10),(char)('0'+p%10),0};
        box(f,x,y,12,8);text(f,x+2,y+2,num,0,x+11);
        if(p==u->dest_pad){horizontal(f,x,y-1,12);vertical(f,x-1,y,y+7);}
    }
}
static void unknown(uint8_t *f,const char *title,const char *reason) {
    header(f,title);text(f,3,14,reason,1,125);text(f,3,30,"RECORD NOT RELEASED",0,125);
    text(f,3,42,"PADS AND KNOBS: PLAY",0,125);footer(f,"EXIT:BACK / DO NOT DELIVER");
}
/* Pure pixel construction is separately testable. Its caller owns the current
 * copied app observation; a constructed image grants no native request route. */
int sp_p6_record_controls_v552_draw(const SpSynthApp *a,const SpPreviewVisualSnapshot *visual,uint8_t frame[1024]) {
    if(!frame)return 0;
    memset(frame,0,1024);
    uint32_t d[4];
    if(sp_p6_record_direct_view(d) && d[0]==1) {
        header(frame,"openSynth / CHOOSE PAD");
        for(unsigned pad=1;pad<=16;pad++) {
            int x=3+(int)((pad-1)%4)*30,y=13+(int)((pad-1)/4)*10;
            char id[4]={(char)('A'+d[2]),(char)('0'+pad/10),(char)('0'+pad%10),0};
            box(frame,x,y,28,8);text(frame,x+2,y+2,id,0,x+17);
            if(d[1]&(1u<<(pad-1)))box(frame,x+21,y+2,4,4);
            else {horizontal(frame,x+20,y+3,6);horizontal(frame,x+20,y+4,6);}
        }
        footer(frame,d[1]?"PAD:SELECT EXIT:CANCEL":"NO EMPTY PADS / TURN:BANK");return 1;
    }
    if(sp_p6_record_direct_view(d) && d[0]==2) {
        char id[4]={(char)('A'+d[2]),(char)('0'+d[3]/10),(char)('0'+d[3]%10),0};
        int armed=a && a->ui.page==SP_UI_CAPTURE_READY && !a->ui.busy;
        header(frame,armed?"openSynth / ARMED":"openSynth / PREPARING");
        text(frame,3,14,id,1,125);text(frame,3,29,"MANUAL / MAX 02:00",0,125);
        text(frame,3,42,"SYNTH ONLY / TAIL OFF",0,125);
        footer(frame,armed?"REC:START / EXIT:CANCEL":"WAIT FOR RECORDER OWNER");return 1;
    }
    if(!a){unknown(frame,"RECORD OFFLINE","WAIT FOR OWNER");return 1;}
    const sp_ui *u=&a->ui;const SpAppCaptureProgress *p=&a->capture_progress;
    char id[4];destination(id,u);
    if(a->capture_plan.include_release_tail || a->capture_tail_state) {
        unknown(frame,"RELEASE TAIL","UNAVAILABLE");return 1;
    }
    if(u->page==SP_UI_INACTIVE) {
        header(frame,"CLOSING SESSION");text(frame,3,15,"PLEASE WAIT",1,125);
        text(frame,3,31,"RETIREMENT PENDING",0,125);text(frame,3,43,"KEEP POWER ON",0,125);
        footer(frame,"WAIT FOR NATIVE RETURN");return 1;
    }
    if(u->save_flags&SP_UI_SAVE_RECOVERY_REQUIRED) {
        header(frame,u->save_details?"SAVE DETAILS":"SAVE INCOMPLETE");text(frame,3,13,id,1,125);
        text(frame,3,26,"TAKE NOT CONFIRMED",0,125);text(frame,3,37,"KEEP POWER ON",0,125);
        footer(frame,u->save_details?"EXIT:BACK":"VAL:DETAILS / SAVE BLOCKED");return 1;
    }
    if(a->capture_cancel_state && sp_p6_record_rearm_v552_no_io_exit(a)) {
        unknown(frame,"CAPTURE UNAVAILABLE","NO TAKE STARTED");
        footer(frame,u->page==SP_UI_PLAY?"EXIT:CLOSE SESSION":"EXIT:BACK");return 1;
    }
    if(a->capture_cancel_state) {
        unknown(frame,"CAPTURE STOPPED",a->capture_cancel_state==SP_APP_CANCEL_FAILED?"NEEDS REVIEW":"WAIT FOR CLEANUP");return 1;
    }
    if(u->busy && u->pending==SP_UI_CMD_TAKE_WRITE) {
        header(frame,"openSynth / SAVING");text(frame,3,13,id,1,125);text(frame,3,28,"WRITING SAMPLE",0,125);
        box(frame,3,39,96,6);text(frame,3,47,"KEEP POWER ON",0,125);footer(frame,"PLEASE WAIT");return 1;
    }
    if(u->busy && u->pending==SP_UI_CMD_TAKE_DISCARD) {
        header(frame,"DISCARDING TAKE");text(frame,3,15,"PLEASE WAIT",1,125);text(frame,3,31,"ENDING RECORDER OWNERSHIP",0,125);
        footer(frame,"KEEP POWER ON");return 1;
    }
    if(u->busy && u->pending==SP_UI_CMD_CAPTURE_STOP) {
        header(frame,"FINALIZING TAKE");text(frame,3,14,"PLEASE WAIT",1,125);text(frame,3,29,"ENDING RECORDING",0,125);
        text(frame,3,42,"SAVING SELECTED PAD",0,125);footer(frame,"WAIT FOR NATIVE STOP");return 1;
    }
    if(u->busy && u->pending==SP_UI_CMD_CAPTURE_START) {
        if(p->has_rx_notice && p->count_in_frames && !p->accepted_frames) {
            unsigned count=a->capture_plan.count_in_bars;
            if(!count || count>4){unknown(frame,"COUNT IN","INVALID PLAN");return 1;}
            unsigned beat=fraction(p->observed_frames,p->count_in_frames,count*4);
            if(beat>=count*4)beat=count*4-1;
            char title[]="COUNT IN 1/1",hero[]="BEAT 1 / 4";title[9]=(char)('1'+beat/4);title[11]=(char)('0'+count);hero[5]=(char)('1'+beat%4);
            header(frame,title);text(frame,3,12,hero,1,125);
            for(unsigned i=0;i<4;++i){int x=4+(int)i*24;box(frame,x,25,18,7);if(i==beat%4)horizontal(frame,x+2,28,14);}
            text(frame,3,38,"NOT RECORDED YET",0,125);text(frame,3,47,"PADS:PLAY ALONG",0,125);footer(frame,"WAIT / TAIL OFF");return 1;
        }
        header(frame,p->accepted_frames?"STARTING TAKE":"PREPARING TAKE");
        sp_ui_view v;if(!sp_synth_app_capture_view(a,&v)){unknown(frame,"RECORD OFFLINE","WAIT FOR START");return 1;}
        text(frame,3,12,v.hero,1,125);text(frame,3,28,p->accepted_frames?"WAITING FOR START RESULT":"PROJECT TEMPO",0,125);
        text(frame,3,40,"TAIL OFF / SYNTH ONLY",0,125);footer(frame,"WAIT / PADS:PLAY");return 1;
    }
    if(u->page==SP_UI_RECORDING) {
        header(frame,"openSynth / RECORDING");
        uint64_t accepted=p->accepted_frames;
        unsigned seconds=(unsigned)(accepted/48000u);if(seconds>120)seconds=120;
        char elapsed[]="00:00 / 02:00";
        elapsed[0]=(char)('0'+seconds/600);elapsed[1]=(char)('0'+(seconds/60)%10);
        elapsed[3]=(char)('0'+(seconds%60)/10);elapsed[4]=(char)('0'+seconds%10);
        text(frame,3,14,elapsed,1,125);text(frame,3,27,"AUTO STOP AT 02:00",0,125);
        horizontal(frame,3,35,122);
        unsigned done=fraction(accepted,UINT64_C(5760000),122);
        for(unsigned x=0;x<done;++x)horizontal(frame,3+(int)x,34,1);
        pcm(frame,visual,45,6);footer(frame,"REC:STOP + SAVE / PADS:PLAY");return 1;
    }
    if(u->page==SP_UI_DESTINATION || u->page==SP_UI_SAVE_ERROR) {
        header(frame,u->page==SP_UI_SAVE_ERROR?"SAVE NOT STARTED":"SAVE TAKE");text(frame,3,13,id,1,65);
        text(frame,3,26,u->busy || !u->dest_known?"CHECKING PAD":u->dest_occupied?"OCCUPIED":"EMPTY",0,65);
        text(frame,3,37,u->dest_occupied?"CHOOSE EMPTY":"TAKE HELD",0,65);pad_grid(frame,u);
        footer(frame,u->busy?"WAIT FOR PAD QUERY":u->page==SP_UI_SAVE_ERROR?"VAL:RETRY EXIT:KEEP":u->dest_occupied?"PADS:SELECT / REPLACE OFF":"VAL:SAVE SH+VAL:DISCARD");return 1;
    }
    if(u->page==SP_UI_NEW_CONFIRM || u->page==SP_UI_LEAVE_CONFIRM || u->page==SP_UI_OVERWRITE) {
        header(frame,u->page==SP_UI_OVERWRITE?"REPLACE UNAVAILABLE":"DISCARD TAKE?");
        text(frame,13,18,"KEEP TAKE",1,125);text(frame,13,33,u->page==SP_UI_OVERWRITE?"CHOOSE EMPTY":"DISCARD",1,125);
        int y=u->selection?35:20;pixel(frame,4,y);horizontal(frame,4,y+1,4);pixel(frame,4,y+2);
        footer(frame,u->page==SP_UI_OVERWRITE?"EXIT:BACK / REPLACE OFF":"TURN:CHOOSE VAL:CONFIRM");return 1;
    }
    if(u->page==SP_UI_SAVED) {
        header(frame,"SAVED TO PAD");text(frame,3,13,id,1,125);text(frame,3,29,"SAMPLE + PROJECT COMPLETE",0,125);
        pcm(frame,visual,44,5);footer(frame,"PADS:PLAY / EXIT:BACK");return 1;
    }
    if(u->page==SP_UI_CAPTURE_ERROR) {
        unknown(frame,"CAPTURE UNAVAILABLE",u->error==SP_UI_ERR_CAPTURE?"OWNER GATE CLOSED":"BACKEND REFUSED");return 1;
    }
    if(u->page==SP_UI_PLAY && u->take_held) {
        header(frame,"TAKE HELD");text(frame,3,13,id,1,125);pcm(frame,visual,33,7);
        text(frame,3,46,"UNSAVED / PADS:PLAY",0,125);footer(frame,"VAL:RECALL EXIT:LEAVE");return 1;
    }
    header(frame,"RECORD SETUP");text(frame,3,13,"SYNTH ONLY",1,125);text(frame,3,27,"MANUAL / MAX 02:00",0,125);
    text(frame,3,38,"NO COUNT IN / TAIL OFF",0,125);
    footer(frame,u->page==SP_UI_PLAY?"REC:CHOOSE PAD EXIT:CLOSE":"REC:START / PADS:PLAY");return 1;
}
int sp_p6_record_controls_v552_render(const SpPreviewNativeView *view,const SpPreviewVisualSnapshot *visual,uint8_t frame[1024]) {
    if(!view || !frame || view->state!=SP_PREVIEW_NATIVE_ACTIVE || sp_p6_menu.view.page!=SP_P6_RECORD)return 0;
    return sp_p6_record_controls_v552_draw(sp_p6_record_controls_v552_app(),visual,frame);
}
