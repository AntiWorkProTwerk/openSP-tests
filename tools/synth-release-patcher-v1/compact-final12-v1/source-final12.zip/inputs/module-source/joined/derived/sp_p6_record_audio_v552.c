#include "sp_p6_record_audio_v552.h"
#include "sp_p6_record_rearm_v552.h"
#include "sp_p6_session_binding_v552.h"
#include "sp_p6_production_join.h"
#include "sp_synth_memory_v552.h"
#include <limits.h>
#include <stddef.h>

SpP6RecordAudioV552 sp_p6_record_audio_v552;
extern const unsigned char sp_p6_record_audio_native_return[];
_Static_assert(sizeof(SpP6RecordAudioV552)==96,"Compact source audio owner");
_Static_assert(sizeof(SpSynthSessionV552)==3824,"Current session ABI");
_Static_assert(sizeof(SpSynthCaptureTimedV552)==1336,"Current capture ABI");
_Static_assert(sizeof(SpSynthRuntimeStorage)==116032,"Current runtime ABI");
#define value(a) atomic_load_explicit((a),memory_order_acquire)
static uint32_t rd(uint32_t a) {return *(volatile const uint32_t *)(uintptr_t)a;}
static uint32_t task(void) {
    uint32_t i,p,b,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));
    __asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(b));
    __asm__ volatile("mrs %0,faultmask":"=r"(f));
    if(i || p || b || f || rd(0x202BBBF8) || rd(0x80245764))return 0;
    return ((uint32_t (*)(void))(uintptr_t)0x800D3163)();
}
static void fail(uint32_t reason) {
    atomic_fetch_or_explicit(&sp_p6_record_audio_v552.fault,reason,memory_order_release);
    atomic_store_explicit(&sp_p6_record_audio_v552.phase,SP_P6_RA_FAILED,memory_order_release);
}
static int acquire(unsigned lane) {
    unsigned expected=0;
    return atomic_compare_exchange_strong_explicit(&sp_p6_record_audio_v552.gate,&expected,lane,
        memory_order_acq_rel,memory_order_acquire);
}
static void release(void) {atomic_store_explicit(&sp_p6_record_audio_v552.gate,0,memory_order_release);}
static int storage(void) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    SpSynthSessionV552 *s=&sp_p6_production_session;
    uintptr_t r=(uintptr_t)s->startup.memory.storage;
    return s->startup.ready==1 && s->startup.memory.attached==1 && r && !(r&7u) &&
        r>=SP_SYNTH_V552_POOL_BEGIN && r<=SP_SYNTH_V552_POOL_END-sizeof(SpSynthRuntimeStorage) &&
        s->startup.memory.allocation && !value(&s->terminal) && !s->clock_handoff &&
        (!o->runtime || (o->runtime==r && o->allocation==(uintptr_t)s->startup.memory.allocation));
}
static int live(unsigned active) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    uint32_t page=(uint32_t)(uintptr_t)atomic_load_explicit(&m->active_page,memory_order_acquire);
    unsigned phase=value(&m->phase);
    if(value(&b->phase)!=SP_P6_SB_PREPARED || value(&b->fault) || !b->sequence ||
       value(&b->pending)!=b->sequence || !value(&m->ready) || value(&m->terminal) ||
       value(&m->entry.fault) || sp_synth_preview_voice_faults(&m->voice) ||
       !page || page!=b->page || rd(0x80CFD4FC)!=page ||
       rd(page)!=(uintptr_t)(m->primary+2) || b->visit!=m->voice_used || !b->visit ||
       b->task!=m->task_id || !storage())return 0;
    if(active && phase!=SP_PREVIEW_NATIVE_ACTIVE)return 0;
    if(!active && phase!=SP_PREVIEW_NATIVE_ACTIVE && phase!=SP_PREVIEW_NATIVE_STOPPING &&
       phase!=SP_PREVIEW_NATIVE_WAIT_NATIVE)return 0;
    return !o->intent || (b->sequence==o->intent && b->visit==o->visit && page==o->page &&
        b->task==o->task && m->config.audio_task==o->audio_task);
}
int sp_p6_record_audio_v552_shadow_allowed(const SpSynthAudioMailbox *m,const SpAppAudioState *a,int consume) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    if(!value(&o->audio_active) || !o->runtime || m!=&((SpSynthRuntimeStorage *)o->runtime)->mailbox ||
       a!=&((SpSynthRuntimeStorage *)o->runtime)->audio || task()!=o->audio_task)return 0;
    if(!m->timed || value(&m->stop_requested) || value(&m->stopped) || a->faulted ||
       !sp_synth_engine_quiescent(&a->engine))return 0;
    /* The consumer has acquired READY and determined whether this exact block
     * consumes it. WRITING/FREE/DONE and future-target READY are silent work;
     * no mutable control-owned batch is inspected in those cases. */
    if(!consume)return 1;
    const SpAppAudioBatch *b=&m->batch;
    if(!b->sealed || b->failed || b->frames!=64 || b->event_count || b->control_count ||
       b->patch_count || b->op_count>SP_APP_AUDIO_OPS || a->sequence==UINT32_MAX ||
       b->sequence!=a->sequence+1)return 0;
    for(unsigned i=0;i<b->op_count;++i)
        if(b->ops[i].type!=SP_APP_AUDIO_PANIC || b->ops[i].index || b->ops[i].expected!=1)return 0;
    if(b->op_count)atomic_store_explicit(&o->panic_sequence,b->sequence,memory_order_release);
    return 1;
}
static void receipt(SpP6RecordAudioReceiptV552 *r) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    *r=(SpP6RecordAudioReceiptV552){o->visit,o->intent,o->sequence,o->sample-64,o->sample,
        o->permission_ack,o->command_ack,o->idle_ack,o->done_sequence,o->sample,o->generation,o->whole_zero};
}
__attribute__((weak)) void sp_p6_record_backend_v552_pcm(const SpP6RecordAudioReceiptV552 *r,
    const int16_t *pcm,uint32_t frames) {(void)r;(void)pcm;(void)frames;}
int sp_p6_record_audio_v552_native(const void *voice,const int16_t *pcm,uint32_t frames,int32_t *work) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    /* A direct call supplies no render proof even with matching pointer values. */
    if(((uintptr_t)__builtin_return_address(0)&~1u)!=(uintptr_t)sp_p6_record_audio_native_return ||
       voice!=&m->voice || pcm!=m->scratch.stereo || frames!=64 ||
       (uintptr_t)work!=0x202AD3A0 || task()!=m->config.audio_task)return 0;
    if(value(&o->fault) || value(&o->phase)==SP_P6_RA_RETIRED ||
       !value(&sp_p6_session_binding_v552.pending))return 0;
    unsigned expected=0;int result=0;
    if(!atomic_compare_exchange_strong_explicit(&o->audio_active,&expected,1,memory_order_acq_rel,memory_order_acquire)) {
        fail(SP_P6_RA_CONCURRENT);return 0;
    }
    atomic_fetch_add_explicit(&o->revision,1,memory_order_acq_rel);
    /* A callback paused before its claim cannot consume an old epoch. */
    if(!value(&sp_p6_session_binding_v552.pending) || value(&o->phase)==SP_P6_RA_RETIRED)goto done;
    if(value(&o->phase)==SP_P6_RA_ARMED) {
        if(!sp_p6_record_rearm_v552_bind_current())goto done;
        SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
        SpSynthRuntimeStorage *r=sp_p6_production_session.startup.memory.storage;
        o->audio_sequence_floor=r->controller.audio_sequence;
        o->task=b->task;o->audio_task=m->config.audio_task;
        o->page=b->page;o->visit=b->visit;o->intent=b->sequence;
        atomic_store_explicit(&o->panic_sequence,0,memory_order_relaxed);
        atomic_store_explicit(&o->park_ticket,0,memory_order_relaxed);
        atomic_store_explicit(&o->generation,0,memory_order_relaxed);
        atomic_store_explicit(&o->phase,SP_P6_RA_BOUND,memory_order_release);
    }
    if(!live(0)) {
        unsigned phase=value(&m->phase);
        /* Native audio keeps running after the ordered page retirement. An
         * authenticated parked lifetime has no further preview PCM to offer;
         * retain its receipts until SMPL consumes LEAVE, without old-page access. */
        if((phase==SP_PREVIEW_NATIVE_LEFT || phase==SP_PREVIEW_NATIVE_GENERATOR ||
            phase==SP_PREVIEW_NATIVE_WAIT_NATIVE) &&
           !atomic_load_explicit(&m->active_page,memory_order_acquire) &&
           m->route_ticket && sp_synth_generator_route_v552_ack(&m->generator)==m->route_ticket &&
           sp_p6_record_audio_v552_parked(o->visit,o->intent,m->normal_stop_ticket))goto done;
        fail(SP_P6_RA_IDENTITY);goto done;
    }
    SpSynthSessionV552 *s=&sp_p6_production_session;
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    if(value(&o->phase)==SP_P6_RA_EMPTY) {
        const unsigned char *clock=(const void *)&r->clock;
        for(size_t i=0;i<sizeof(r->clock);++i)if(clock[i]) {fail(SP_P6_RA_IDENTITY);goto done;}
        if(value(&s->ready) || value(&s->control_ready) || value(&r->mailbox.phase)!=SP_AUDIO_FREE ||
           value(&r->mailbox.sample_cursor) || r->controller.audio_sequence || r->controller.audio_pending ||
           r->controller.audio_batch || r->controls.count || r->controls.faulted ||
           r->input.enabled || r->input.physical || r->input.captured || r->input.delivered || r->input.shift) {
            fail(SP_P6_RA_IDENTITY);goto done;
        }
        o->task=sp_p6_session_binding_v552.task;o->audio_task=m->config.audio_task;
        o->page=sp_p6_session_binding_v552.page;o->visit=m->voice_used;
        o->intent=sp_p6_session_binding_v552.sequence;o->runtime=(uintptr_t)r;
        o->allocation=(uintptr_t)s->startup.memory.allocation;
    }
    if(value(&o->phase)!=SP_P6_RA_EMPTY && value(&o->phase)!=SP_P6_RA_BOUND)goto done;
    if(o->sequence==UINT32_MAX || o->sample>UINT32_MAX-64 || value(&r->mailbox.sample_cursor)!=o->sample) {
        fail(SP_P6_RA_SEQUENCE);goto done;
    }
    if(!r->mailbox.timed || value(&r->mailbox.stop_requested) || value(&r->mailbox.stopped)) {
        fail(SP_P6_RA_MAILBOX);goto done;
    }
    SpSynthStockBlock block={work,896,64,(uint8_t)m->config.pair_index};
    if(sp_synth_audio_mailbox_mix(&r->mailbox,&r->audio,&block,&r->audio_scratch)!=SP_SYNTH_STOCK_OK ||
       value(&r->mailbox.sample_cursor)!=o->sample+64) {fail(SP_P6_RA_MAILBOX);goto done;}
    /* The restricted shadow engine has no notes and can only execute PANIC.
     * It renders real batches without adding another audible synth to work. */
    for(unsigned i=0;i<128;++i)if(r->audio_scratch.pcm.stereo[i]) {fail(SP_P6_RA_SOURCE);goto done;}
    ++o->sequence;o->sample+=64;
    /* Successful stock mixing advances this actual audio-owned consecutive
     * sequence. The producer may consume DONE and begin WRITING before our
     * return; never reread its now-mutable batch to reconstruct PANIC. */
    o->done_sequence=r->audio.sequence;
    o->permission_ack=sp_synth_preview_voice_permission_ack(&m->voice);
    o->command_ack=sp_synth_preview_voice_command_ack(&m->voice);
    o->idle_ack=sp_synth_preview_voice_idle_ack(&m->voice);o->whole_zero=1;
    for(unsigned i=0;i<128;++i)if(pcm[i]) {o->whole_zero=0;break;}
    if(o->whole_zero && m->normal_stop_ticket && o->permission_ack==m->normal_stop_ticket &&
       o->idle_ack==m->normal_stop_ticket)o->park_ticket=m->normal_stop_ticket;
    unsigned request=value(&s->backend.request_phase);
    o->generation=request==2?s->backend.request.generation:0;
    if(value(&o->phase)==SP_P6_RA_EMPTY) {
        if(!sp_synth_input_clock_init(&r->clock,o->sample,o->sample,48000,48000,128)) {
            fail(SP_P6_RA_SOURCE);goto done;
        }
        /* A software rendered-sample anchor, not DWT/USB/DAC calibration. */
        atomic_store_explicit(&s->ready,1,memory_order_release);
        atomic_store_explicit(&o->phase,SP_P6_RA_BOUND,memory_order_release);
    }
    SpP6RecordAudioReceiptV552 snap;receipt(&snap);
    sp_p6_record_backend_v552_pcm(&snap,pcm,64);
    result=1;
done:
    atomic_fetch_add_explicit(&o->revision,1,memory_order_release);
    atomic_store_explicit(&o->audio_active,0,memory_order_release);
    return result;
}
SpSynthSessionV552 *sp_p6_record_audio_v552_session(void) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    return !value(&o->fault) && value(&o->phase)==SP_P6_RA_BOUND && live(1) &&
        value(&sp_p6_production_session.ready)==1?&sp_p6_production_session:0;
}
static int out_span(uintptr_t p,size_t n);
int sp_p6_record_audio_v552_control_window(uint32_t *target) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    uintptr_t t=(uintptr_t)target;
    if(!out_span(t,4) || task()!=o->task || task()!=rd(0x8300A3E8) ||
       m->entry.sample_depth || !sp_p6_record_audio_v552_session() || !acquire(1))return 0;
    SpSynthSessionV552 *s=&sp_p6_production_session;SpSynthRuntimeStorage *r=s->startup.memory.storage;
    if((t<(uintptr_t)r+sizeof(*r) && t+4>(uintptr_t)r) ||
       (t<(uintptr_t)s+sizeof(*s) && t+4>(uintptr_t)s) ||
       (t<(uintptr_t)o+sizeof(*o) && t+4>(uintptr_t)o) ||
       r->midi.count || r->midi.fault || value(&r->mailbox.stop_requested) || r->audio.faulted ||
       value(&o->audio_active)) {release();return 0;}
    uint32_t sample=value(&r->mailbox.sample_cursor);
    if(sample!=value(&o->sample) || !sp_synth_input_clock_watermark(&r->clock,&r->midi,&r->mailbox,sample) ||
       !sp_synth_input_clock_map(&r->clock,sample,target)) {release();return 0;}
    /* This private MIDI domain is empty. The real observed cutoff is sample
     * +128; place the next complete64 batch at sample+64 inside that cutoff. */
    *target-=64;
    atomic_store_explicit(&s->control_ready,1,memory_order_release);return 1;
}
void sp_p6_record_audio_v552_control_done(void) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    if(task()==o->task && value(&o->gate)==1) {
        SpSynthRuntimeStorage *r=(void *)o->runtime;
        if(r && !r->controller.audio_faulted && !value(&o->fault)) {
            uint32_t prefix=r->controller.audio_sequence-(r->controller.audio_pending!=0);
            if(prefix<=value(&o->done_sequence) && prefix>=value(&o->consumed_sequence))
                atomic_store_explicit(&o->consumed_sequence,prefix,memory_order_release);
        }
        release();
    }
}
int sp_p6_record_audio_v552_acknowledged(uint32_t sequence) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    if(!sequence || sequence<=o->audio_sequence_floor || !sp_p6_record_audio_v552_session())return 0;
    if(task()==o->task && value(&o->gate)==1) {
        SpSynthRuntimeStorage *r=(void *)o->runtime;
        if(!r->controller.audio_faulted) {
            uint32_t prefix=r->controller.audio_sequence-(r->controller.audio_pending!=0);
            if(prefix<=value(&o->done_sequence) && prefix>=value(&o->consumed_sequence))
                atomic_store_explicit(&o->consumed_sequence,prefix,memory_order_release);
        }
    }
    /* Actual audio sequences are consecutive. A retained successful consumed
     * prefix remains valid after a later control batch is published/rendered. */
    return sequence<=value(&o->done_sequence) && sequence<=value(&o->consumed_sequence);
}
static int out_span(uintptr_t p,size_t n) {
    if(!p || p%4u || p>UINTPTR_MAX-n)return 0;
    uintptr_t bases[]={ (uintptr_t)&sp_p6_record_audio_v552,(uintptr_t)&sp_p6_production_session,
        sp_p6_record_audio_v552.runtime,(uintptr_t)&sp_synth_preview_native_v552,0x202AD3A0 };
    size_t sizes[]={sizeof(SpP6RecordAudioV552),sizeof(SpSynthSessionV552),sizeof(SpSynthRuntimeStorage),
        sizeof(SpPreviewNativeV552),896*sizeof(int32_t)};
    for(unsigned i=0;i<5;++i)if(bases[i] && p<bases[i]+sizes[i] && p+n>bases[i])return 0;
    return 1;
}
int sp_p6_record_audio_v552_receipt(SpP6RecordAudioReceiptV552 *out) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    if(!out_span((uintptr_t)out,sizeof(*out)) || !sp_p6_record_audio_v552_session())return 0;
    uint32_t before=value(&o->revision);
    if(before&1u)return 0;
    SpP6RecordAudioReceiptV552 snap;receipt(&snap);
    if(value(&o->revision)!=before || value(&o->fault))return 0;
    *out=snap;return 1;
}
int sp_p6_record_audio_v552_source_current(uint32_t visit,uint32_t intent,uint32_t generation) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    SpSynthSessionV552 *s=sp_p6_record_audio_v552_session();
    if(!s && !generation && sp_synth_preview_native_v552.voice_used==visit &&
       sp_p6_record_audio_v552_stop_current(visit,intent,value(&o->panic_sequence)))s=&sp_p6_production_session;
    if(!s || visit!=o->visit || intent!=o->intent || generation!=value(&o->generation) ||
       value(&s->backend.request_phase)!=2 || s->backend.request.generation!=generation)return 0;
    return generation || s->backend.request.type==SP_APP_REQUEST_GLOBAL_STOP ||
        s->backend.request.type==SP_APP_REQUEST_LEAVE;
}
int sp_p6_record_audio_v552_stop_current(uint32_t visit,uint32_t intent,uint32_t sequence) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    if(value(&o->fault) || value(&o->phase)!=SP_P6_RA_BOUND || !storage() || !sequence ||
       sequence<=o->audio_sequence_floor ||
       visit!=o->visit || intent!=o->intent || sequence!=value(&o->panic_sequence) ||
       sequence!=value(&o->done_sequence) || sequence>value(&o->consumed_sequence))return 0;
    SpSynthRuntimeStorage *r=(void *)o->runtime;
    return value(&r->mailbox.phase)==SP_AUDIO_FREE && !r->controller.audio_pending &&
        !r->controller.audio_faulted && r->controller.audio_sequence==sequence && !r->audio.faulted &&
        r->mailbox.completion.sequence==sequence && r->mailbox.completion.result==SP_SYNTH_STOCK_OK &&
        r->mailbox.completion.quiescent && sp_synth_engine_quiescent(&r->audio.engine);
}
int sp_p6_record_audio_v552_parked(uint32_t visit,uint32_t intent,uint32_t ticket) {
    SpP6RecordAudioV552 *o=&sp_p6_record_audio_v552;
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(value(&o->fault) || value(&o->phase)!=SP_P6_RA_BOUND || !storage() || !ticket ||
       visit!=o->visit || intent!=o->intent || m->voice_used!=visit || o->park_ticket!=ticket ||
       m->normal_stop_ticket!=ticket || sp_synth_preview_voice_faults(&m->voice) ||
       sp_synth_preview_voice_permission_ack(&m->voice)!=ticket ||
       sp_synth_preview_voice_idle_ack(&m->voice)!=ticket || !o->panic_sequence ||
       o->done_sequence!=o->panic_sequence)return 0;
    return sp_p6_record_audio_v552_stop_current(visit,intent,value(&o->panic_sequence));
}
uint32_t sp_p6_record_audio_v552_admission(void) {return 0;}
/* The frozen native preview retains its P5 input/event projection. Recording
 * session calls use this private current-ABI copy; no shared symbol changes. */
#define sp_synth_input_init sp_p6_record_input_v552_init
#define sp_synth_input_enable sp_p6_record_input_v552_enable
#define sp_synth_input_route sp_p6_record_input_v552_route
#include "input_owner_current.inc"
