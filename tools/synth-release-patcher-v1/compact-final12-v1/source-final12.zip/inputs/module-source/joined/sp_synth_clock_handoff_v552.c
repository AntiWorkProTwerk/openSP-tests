#include "sp_synth_clock_handoff_v552.h"
#include "sp_synth_audio_binding_v552.h"
#include "sp_synth_memory_v552.h"
#include <stddef.h>

_Static_assert(ATOMIC_INT_LOCK_FREE==2,"Clock handoff requires lock-free atomics");
_Static_assert(sizeof(void *)==4,"Clock handoff requires ARM32");
static int object(const void *p,size_t n,size_t align) {
    uintptr_t a=(uintptr_t)p;return a && a%align==0 && a<=UINTPTR_MAX-n;
}
static int overlap(const void *a,size_t an,const void *b,size_t bn) {
    return (uintptr_t)a<(uintptr_t)b+bn && (uintptr_t)b<(uintptr_t)a+an;
}
static int outside(const void *p,size_t n) {
    return (uintptr_t)p+n<=SP_SYNTH_V552_POOL_BEGIN || (uintptr_t)p>=SP_SYNTH_V552_POOL_END;
}
static uint32_t task_id(void) {
    return ((uint32_t (*)(void))(uintptr_t)UINT32_C(0x800D3163))();
}
static int span(uint32_t n) {return n && n<=UINT32_MAX/2u;}
static int failed(SpSynthClockHandoffV552 *h,int result) {
    sp_synth_clock_handoff_v552_cancel(h);return result;
}
int sp_synth_clock_handoff_v552_init(SpSynthClockHandoffV552 *h,
    SpSynthSessionV552 *s,SpSynthAudioBindingV552 *b) {
    if(!object(h,sizeof(*h),_Alignof(SpSynthClockHandoffV552)) ||
       !object(s,sizeof(*s),_Alignof(SpSynthSessionV552)) ||
       !object(b,sizeof(*b),_Alignof(SpSynthAudioBindingV552)) ||
       !outside(h,sizeof(*h)) || !outside(s,sizeof(*s)) || !outside(b,sizeof(*b)) ||
       overlap(h,sizeof(*h),s,sizeof(*s)) || overlap(h,sizeof(*h),b,sizeof(*b)) ||
       overlap(s,sizeof(*s),b,sizeof(*b)) || b->session!=s || b->handoff ||
       atomic_load_explicit(&b->admitted,memory_order_relaxed))return 0;
    const unsigned char *bytes=(const unsigned char *)h;
    for(size_t i=0;i<sizeof(*h);++i)if(bytes[i])return 0;
    bytes=(const unsigned char *)s;
    for(size_t i=0;i<sizeof(*s);++i)if(bytes[i])return 0;
    atomic_init(&s->ready,0);atomic_init(&s->terminal,0);atomic_init(&s->control_ready,0);
    h->session=s;h->audio=b;
    atomic_init(&h->task_id,0);atomic_init(&h->phase,SP_CLOCK_EMPTY);atomic_init(&h->heartbeat,0);
    b->handoff=h;return 1;
}
int sp_synth_clock_handoff_v552_control_owner(const SpSynthClockHandoffV552 *h) {
    if(!h)return 0;
    uint32_t id=atomic_load_explicit(&h->task_id,memory_order_acquire);
    return id && task_id()==id;
}
void sp_synth_clock_handoff_v552_cancel(SpSynthClockHandoffV552 *h) {
    if(!h || !h->session || !h->audio)return;
    /* The phase is the only admission decision. A racing BINDING->BOUND CAS
     * either precedes this store (started), or fails (never started). */
    atomic_store_explicit(&h->phase,SP_CLOCK_TERMINAL,memory_order_release);
    sp_synth_session_v552_stop(h->session);
}
static int empty(SpSynthClockHandoffV552 *h,int origin) {
    SpSynthSessionV552 *s=h->session;
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    if(!r || s->startup.ready!=1 || s->startup.memory.attached!=1 ||
       atomic_load_explicit(&s->terminal,memory_order_acquire) ||
       atomic_load_explicit(&s->control_ready,memory_order_acquire) ||
       atomic_load_explicit(&r->mailbox.phase,memory_order_acquire)!=SP_AUDIO_FREE ||
       atomic_load_explicit(&r->mailbox.stop_requested,memory_order_acquire) ||
       atomic_load_explicit(&r->mailbox.stopped,memory_order_acquire) ||
       !r->mailbox.timed ||
       (origin && atomic_load_explicit(&r->mailbox.sample_cursor,memory_order_acquire)!=h->sample) ||
       r->controls.count || r->controls.faulted || r->midi.count || r->midi.fault ||
       r->midi.has_last || r->midi.has_closed || r->midi.has_watermark ||
       r->input.enabled || r->input.physical || r->input.captured || r->input.delivered ||
       r->input.shift || r->input_batch.count || r->controller.audio_batch ||
       r->controller.audio_pending || r->controller.event_count || r->controller.request_count ||
       atomic_load_explicit(&s->backend.request_phase,memory_order_acquire) ||
       atomic_load_explicit(&s->backend.responses.phase,memory_order_acquire) ||
       atomic_load_explicit(&s->backend.responses.stopped,memory_order_acquire))return 0;
    if(origin) {
        const unsigned char *bytes=(const unsigned char *)&r->clock;
        for(size_t i=0;i<sizeof(r->clock);++i)if(bytes[i])return 0;
    }
    return 1;
}
int sp_synth_clock_handoff_v552_prepare(SpSynthClockHandoffV552 *h,
    const SpSynthClockConfigV552 *c,void *panel) {
    if(!h || !h->session || !h->audio)return -1031;
    unsigned expected=SP_CLOCK_EMPTY;
    if(!atomic_compare_exchange_weak_explicit(&h->phase,&expected,SP_CLOCK_PREPARING,
        memory_order_acq_rel,memory_order_acquire))
        return expected==SP_CLOCK_EMPTY?failed(h,-1031):-1031;
    if((uintptr_t)panel!=UINT32_C(0x8300A3E4) ||
       !object(c,sizeof(*c),_Alignof(SpSynthClockConfigV552)) ||
       !outside(c,sizeof(*c)) ||
       overlap(c,sizeof(*c),h,sizeof(*h)) || overlap(c,sizeof(*c),h->session,sizeof(*h->session)) ||
       overlap(c,sizeof(*c),h->audio,sizeof(*h->audio)))return failed(h,-1030);
    if((uintptr_t)c->counter!=UINT32_C(0xE0001004) || c->qualified!=SP_CLOCK_QUAL_ALL ||
       !span(c->max_audio_gap) || !span(c->first_control_age) || !span(c->control_age))
        return failed(h,-1030);
    uint32_t id=task_id();
    if(id<1 || id>32)return failed(h,-1030);
    int result=sp_synth_session_v552_prepare_deferred(h->session,&c->startup);
    if(result)return failed(h,result);
    h->counter=c->counter;h->sample=c->startup.sample;h->tick_hz=c->startup.tick_hz;
    h->latency=c->startup.latency;h->max_audio_gap=c->max_audio_gap;
    h->first_control_age=c->first_control_age;h->control_age=c->control_age;
    atomic_store_explicit(&h->task_id,id,memory_order_release);
    h->session->clock_handoff=h;
    expected=SP_CLOCK_PREPARING;
    if(!atomic_compare_exchange_weak_explicit(&h->phase,&expected,SP_CLOCK_PREPARED,
        memory_order_acq_rel,memory_order_acquire))return failed(h,-1031);
    return 0;
}
int sp_synth_clock_handoff_v552_arm(SpSynthClockHandoffV552 *h) {
    if(!h || atomic_load_explicit(&h->phase,memory_order_acquire)!=SP_CLOCK_PREPARED ||
       !sp_synth_clock_handoff_v552_control_owner(h))return 0;
    if(atomic_load_explicit(&h->session->ready,memory_order_acquire) || !empty(h,1))
        return failed(h,0);
    unsigned expected=SP_CLOCK_PREPARED;
    if(!atomic_compare_exchange_weak_explicit(&h->phase,&expected,SP_CLOCK_ARMED,
        memory_order_acq_rel,memory_order_acquire))return failed(h,0);
    return 1;
}
void sp_synth_clock_handoff_v552_audio(SpSynthClockHandoffV552 *h,int exact) {
    if(!h)return;
    unsigned phase=atomic_load_explicit(&h->phase,memory_order_acquire);
    if(phase<SP_CLOCK_ARMED || phase==SP_CLOCK_TERMINAL)return;
    if(!exact) {
        atomic_store_explicit(&h->audio->fault,SP_SYNTH_STOCK_INVALID_ARGUMENT,memory_order_release);
        sp_synth_clock_handoff_v552_cancel(h);return;
    }
    if(phase==SP_CLOCK_ARMED) {
        unsigned expected=SP_CLOCK_ARMED;
        if(!atomic_compare_exchange_weak_explicit(&h->phase,&expected,SP_CLOCK_BINDING,
            memory_order_acq_rel,memory_order_acquire)) {
            sp_synth_clock_handoff_v552_cancel(h);return;
        }
        uint32_t tick=*h->counter;
        SpSynthSessionV552 *s=h->session;
        SpSynthRuntimeStorage *r=s->startup.memory.storage;
        if(!sp_synth_input_clock_init(&r->clock,tick,h->sample,h->tick_hz,48000,h->latency)) {
            sp_synth_clock_handoff_v552_cancel(h);return;
        }
        h->epoch=tick;h->last_audio_tick=tick;h->age=0;h->seen_heartbeat=tick;
        atomic_store_explicit(&h->heartbeat,tick,memory_order_relaxed);
        atomic_store_explicit(&s->ready,1,memory_order_release);
        expected=SP_CLOCK_BINDING;
        if(!atomic_compare_exchange_weak_explicit(&h->phase,&expected,SP_CLOCK_BOUND,
            memory_order_acq_rel,memory_order_acquire)) {
            sp_synth_clock_handoff_v552_cancel(h);return;
        }
        atomic_store_explicit(&h->audio->admitted,1,memory_order_release);
        return;
    }
    /* Load the heartbeat before observing the counter, so a newer control
     * observation cannot look as if it came from the future. */
    uint32_t beat=atomic_load_explicit(&h->heartbeat,memory_order_acquire);
    uint32_t tick=*h->counter,delta=tick-h->last_audio_tick;
    if(delta>h->max_audio_gap || delta>UINT32_MAX/2u) {
        sp_synth_clock_handoff_v552_cancel(h);return;
    }
    h->last_audio_tick=tick;
    uint32_t limit=phase==SP_CLOCK_CLAIMED?h->control_age:h->first_control_age;
    if(phase==SP_CLOCK_CLAIMED && beat!=h->seen_heartbeat) {
        h->seen_heartbeat=beat;h->age=tick-beat;
    } else {
        h->age=delta>UINT32_MAX-h->age?UINT32_MAX:h->age+delta;
    }
    if(h->age>limit)sp_synth_clock_handoff_v552_cancel(h);
}
static int admitted(SpSynthClockHandoffV552 *h) {
    SpSynthSessionV552 *s=h->session;
    return atomic_load_explicit(&h->audio->admitted,memory_order_acquire)==1 &&
        atomic_load_explicit(&s->ready,memory_order_acquire)==1 &&
        !atomic_load_explicit(&s->terminal,memory_order_acquire) &&
        !atomic_load_explicit(&s->startup.memory.storage->mailbox.stop_requested,memory_order_acquire);
}
int sp_synth_clock_handoff_v552_claim(SpSynthClockHandoffV552 *h,
    const SpSynthClockClaimV552 *snap) {
    if(!h || !sp_synth_clock_handoff_v552_control_owner(h) ||
       atomic_load_explicit(&h->phase,memory_order_acquire)!=SP_CLOCK_BOUND)return 0;
    /* A control preemption in the commit/mirror interval is an unavailable
     * observation, not a failed first claim. No mutable runtime is read. */
    if(atomic_load_explicit(&h->audio->admitted,memory_order_acquire)!=1)return 0;
    if(!object(snap,sizeof(*snap),_Alignof(SpSynthClockClaimV552)) ||
       overlap(snap,sizeof(*snap),h,sizeof(*h)) ||
       overlap(snap,sizeof(*snap),h->session,sizeof(*h->session)) ||
       overlap(snap,sizeof(*snap),h->session->startup.memory.storage,sizeof(SpSynthRuntimeStorage)) ||
       snap->held_pads>65535 || snap->shift>1 || snap->qualified!=SP_CLOCK_CLAIM_ALL ||
       !admitted(h) || !empty(h,0))return failed(h,0);
    uint32_t tick=*h->counter;
    if(tick-h->epoch>h->first_control_age)return failed(h,0);
    SpSynthSessionV552 *s=h->session;
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    if(!sp_synth_input_clock_watermark(&r->clock,&r->midi,&r->mailbox,tick))return failed(h,0);
    sp_synth_input_init(&r->input,(uint16_t)snap->held_pads,(int)snap->shift);
    atomic_store_explicit(&h->heartbeat,tick,memory_order_release);
    unsigned expected=SP_CLOCK_BOUND;
    if(!atomic_compare_exchange_weak_explicit(&h->phase,&expected,SP_CLOCK_CLAIMED,
        memory_order_acq_rel,memory_order_acquire))return failed(h,0);
    atomic_store_explicit(&s->control_ready,1,memory_order_release);
    if(atomic_load_explicit(&h->phase,memory_order_acquire)!=SP_CLOCK_CLAIMED || !admitted(h))
        return failed(h,0);
    return 1;
}
int sp_synth_clock_handoff_v552_check(SpSynthClockHandoffV552 *h) {
    if(!h || !sp_synth_clock_handoff_v552_control_owner(h))return 0;
    if(atomic_load_explicit(&h->phase,memory_order_acquire)!=SP_CLOCK_CLAIMED || !admitted(h))return 0;
    uint32_t beat=atomic_load_explicit(&h->heartbeat,memory_order_acquire);
    uint32_t tick=*h->counter;
    if(tick-beat>h->control_age)return failed(h,0);
    return 1;
}
static int observation(SpSynthClockHandoffV552 *h,uint32_t tick) {
    if(!sp_synth_clock_handoff_v552_check(h))return 0;
    uint32_t now=*h->counter;
    if(now-tick>h->control_age)return failed(h,0);
    return 1;
}
int sp_synth_clock_handoff_v552_watermark(SpSynthClockHandoffV552 *h,uint32_t tick) {
    if(!observation(h,tick))return 0;
    SpSynthRuntimeStorage *r=h->session->startup.memory.storage;
    if(!sp_synth_input_clock_watermark(&r->clock,&r->midi,&r->mailbox,tick))return failed(h,0);
    atomic_store_explicit(&h->heartbeat,tick,memory_order_release);
    return sp_synth_clock_handoff_v552_check(h);
}
int sp_synth_clock_handoff_v552_midi(SpSynthClockHandoffV552 *h,uint32_t tick,const SpSynthEvent *event) {
    if(!observation(h,tick))return 0;
    SpSynthRuntimeStorage *r=h->session->startup.memory.storage;
    if(!sp_synth_input_clock_midi(&r->clock,&r->midi,&r->mailbox,tick,event))return failed(h,0);
    return sp_synth_clock_handoff_v552_check(h);
}
