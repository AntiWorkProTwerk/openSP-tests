#ifndef SP_P6_RECORD_START_GATE_V552_H
#define SP_P6_RECORD_START_GATE_V552_H
#include <stdint.h>

enum {
    SP_P6_SG_CONTEXT=1, SP_P6_SG_BOOTSTRAP=2, SP_P6_SG_SESSION=4,
    SP_P6_SG_REQUEST=8, SP_P6_SG_PROFILE=16, SP_P6_SG_AUDIO=32,
    SP_P6_SG_CAPTURE=64, SP_P6_SG_PRODUCER=128, SP_P6_SG_NATIVE=256,
    SP_P6_SG_DESTINATION=512, SP_P6_SG_HOOK=1024, SP_P6_SG_EXHAUSTED=2048
};
/* No caller supplies readiness, a request, a generation or a qualification
 * token. Only the current authenticated native SMPL START can pass. This
 * callback-relative one-bar/synth-only/tail-off predicate is an observation;
 * the existing BEGIN owner still acquires its actual native exclusions. */
uint32_t sp_p6_record_start_gate_v552_blocked(void);
uint32_t sp_p6_record_start_gate_v552_admit(void);
/* Read-only source-derived observers of the private capture/source and native
 * token provider. Missing derivations refuse. These APIs reset no ownership. */
uint32_t sp_p6_record_start_capture_idle_v552(void);
uint32_t sp_p6_record_start_token_idle_v552(void);
/* Native REC cold init can precede late capture bootstrap. The installed
 * initializer retains one receipt; this observer checks its live identity. */
uint32_t sp_p6_record_start_rec_init_v552_current(void);
#endif
