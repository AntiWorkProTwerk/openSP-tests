#ifndef SP_P6_RECORD_RETIREMENT_V552_H
#define SP_P6_RECORD_RETIREMENT_V552_H
#include <stdint.h>
#include <stdatomic.h>

enum { SP_P6_RR_EMPTY, SP_P6_RR_REQUESTED, SP_P6_RR_DELETING,
       SP_P6_RR_DELETED, SP_P6_RR_RELEASED };
enum { SP_P6_RR_SESSION=1, SP_P6_RR_REQUEST=2, SP_P6_RR_CAPTURE=4,
       SP_P6_RR_TOKEN=8, SP_P6_RR_FILES=16, SP_P6_RR_QUEUE=32,
       SP_P6_RR_ROUTE=64, SP_P6_RR_PARK=128, SP_P6_RR_PAGE=256,
       SP_P6_RR_NATIVE_COVERAGE=512, SP_P6_RR_CONTEXT=1024 };
enum { SP_P6_RR_UNCLOSED_SECONDARY_ORDER=1, SP_P6_RR_UNCLOSED_HEAP_REFERENCE=2,
       SP_P6_RR_UNCLOSED_CWD_VOLUME=4, SP_P6_RR_UNCLOSED_LOWER_INTERIOR=8 };
/* Permanent cold BSS. Only numeric source identities survive deletion. */
typedef struct {
    atomic_uint phase, blocked, released;
    uint32_t ticket, lifetime, intent, start_generation, take_token;
    uint32_t generation, token, destructor_returned;
    uint32_t released_ticket, released_lifetime;
} SpP6RecordRetirementV552;
extern SpP6RecordRetirementV552 sp_p6_record_retirement_v552;

/* Actual SMPL handback. Arguments must match the immutable native worker and
 * canonical backend request; they confer no ownership. An accepted request is
 * retained while native/audio/deletion dependencies remain incomplete. */
int sp_synth_live_session_v552_exit_request(uint32_t,uint32_t,uint32_t);
int sp_synth_live_session_v552_exit_ack(uint32_t);
int sp_synth_live_session_v552_backend_released(uint32_t,uint32_t,uint32_t,uint32_t);
/* Retained canonical LEAVE identity for the request owner. Expected numeric
 * arguments confer no authority; actual source park/deletion state decides. */
int sp_p6_record_retirement_v552_request_current(uint32_t,uint32_t,uint32_t,uint32_t);
int sp_p6_record_retirement_v552_request_finished(uint32_t,uint32_t,uint32_t,uint32_t);
/* Installed serialized panel service, after dispatch/sample frames close. */
void sp_p6_record_retirement_v552_panel(void);
/* Exact stock request_sampler enclosure. Ordinary synth EXIT is unaffected;
 * recording-owned deletion waits for the separate actual audio park receipt. */
int sp_p6_record_retirement_v552_native_exit_allowed(void);
/* Exact factory type2 enclosure and post-native destructor return. These hooks
 * inspect their real source owner, accept no completion/readiness/token flag,
 * and never retain or inspect a pointer after native deletion returns. */
void sp_p6_record_retirement_v552_factory_enter(const uint16_t *);
void sp_p6_record_retirement_v552_destructor_return(void);
void sp_p6_record_retirement_v552_factory_return(const uint16_t *);
/* Read-only source snapshot, not a publication/admission receipt. */
uint32_t sp_p6_record_retirement_v552_lease_blocks(void);
uint32_t sp_p6_record_retirement_v552_hook_blocks(void);
uint32_t sp_p6_record_retirement_v552_unclosed(void);
uint32_t sp_p6_record_retirement_v552_admission(void);
/* Exact native mode-entry enclosures, before coordinator/global-mode writes. */
int sp_p6_record_retirement_v552_mode_allowed(uint32_t,uint32_t);
int sp_p6_record_retirement_v552_coordinator_allowed(void);
uint32_t sp_p6_record_retirement_v552_mode_hook_blocks(void);
#endif
