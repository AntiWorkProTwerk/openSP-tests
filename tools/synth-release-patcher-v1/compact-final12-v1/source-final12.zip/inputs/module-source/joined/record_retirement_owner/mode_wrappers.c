#include "sp_p6_record_retirement_v552.h"
extern uint32_t sp_p6_record_retirement_mode_request_original(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_record_retirement_mode_coordinator_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_retirement_mode_request(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    uint32_t link;__asm__ volatile("mov %0,lr":"=r"(link));
    if(!sp_p6_record_retirement_v552_mode_allowed(a,link))return 0;
    return sp_p6_record_retirement_mode_request_original(a,b,c,d);
}
uint32_t sp_p6_record_retirement_mode_coordinator(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    if(!sp_p6_record_retirement_v552_coordinator_allowed())return *(volatile const uint32_t *)0x8059245C;
    return sp_p6_record_retirement_mode_coordinator_original(a,b,c,d);
}
uint32_t sp_p6_record_retirement_v552_mode_hook_blocks(void) {
    if(*(volatile const uint32_t *)0x800DA598!=0xF000F8DF ||
       *(volatile const uint32_t *)0x800DA59C!=((uintptr_t)sp_p6_record_retirement_mode_request|1u) ||
       *(volatile const uint32_t *)0x800D0040!=0xF000F8DF ||
       *(volatile const uint32_t *)0x800D0044!=((uintptr_t)sp_p6_record_retirement_mode_coordinator|1u) ||
       *(volatile const uint16_t *)0x800D0048!=0xBF00)return SP_P6_RR_NATIVE_COVERAGE;
    return 0;
}
