#ifndef SP_P6_RECORD_AUDIO_V552_H
#define SP_P6_RECORD_AUDIO_V552_H
#include "sp_synth_session_v552.h"

enum { SP_P6_RA_EMPTY, SP_P6_RA_BOUND, SP_P6_RA_FAILED };
enum { SP_P6_RA_IDENTITY=1, SP_P6_RA_CONTEXT=2, SP_P6_RA_CONCURRENT=4,
       SP_P6_RA_MAILBOX=8, SP_P6_RA_SEQUENCE=16, SP_P6_RA_SOURCE=32 };
typedef struct {
    atomic_uint phase, gate, fault, audio_active, revision;
    uint32_t task, audio_task, page, visit, intent;
    atomic_uint sequence, sample, done_sequence, panic_sequence;
    atomic_uint permission_ack, command_ack, idle_ack, whole_zero;
    atomic_uint park_ticket, consumed_sequence, generation;
    uintptr_t runtime, allocation;
} SpP6RecordAudioV552;
extern SpP6RecordAudioV552 sp_p6_record_audio_v552;
typedef struct {
    uint32_t visit, intent, sequence, sample_start, sample_end;
    uint32_t permission_ack, command_ack, idle_ack;
    uint32_t mailbox_sequence, mailbox_sample_end, generation, whole_zero;
} SpP6RecordAudioReceiptV552;

/* Exact prepared session only after a completed native64 render establishes
 * its software sample clock. No caller supplies readiness or qualification.
 * This silent private app engine is separate from the audible preview voice. */
SpSynthSessionV552 *sp_p6_record_audio_v552_session(void);
/* Serialized native panel only. Acquires a nonblocking control window, maps
 * the completed sample cursor and publishes the private empty MIDI cutoff.
 * Every successful window requires control_done(), including failed requests.
 * Normal native audio preemption remains allowed. Unpublished WRITING batches
 * are retained while the silent private engine renders the next native block. */
int sp_p6_record_audio_v552_control_window(uint32_t *target);
void sp_p6_record_audio_v552_control_done(void);
/* Identifies the retained actual shadow mailbox completion after control has
 * consumed it. Sequence is an expected identity, never an authority flag. */
int sp_p6_record_audio_v552_acknowledged(uint32_t sequence);
/* Copies source metadata only. It grants no delayed access to scratch PCM. */
int sp_p6_record_audio_v552_receipt(SpP6RecordAudioReceiptV552 *receipt);
/* Exact current phase2 request/lifetime observation. BEGIN stays unavailable. */
int sp_p6_record_audio_v552_source_current(uint32_t visit,uint32_t intent,uint32_t generation);
/* Positive wholly silent preview64 receipt plus matching native QUIESCE
 * permission/idle acknowledgments and completed silent-app PANIC. Cached page
 * identity is numeric; this query never dereferences a retired native page.
 * This observation supplies neither generator return nor RELEASED authority. */
int sp_p6_record_audio_v552_parked(uint32_t visit,uint32_t intent,uint32_t normal_stop_ticket);
int sp_p6_record_audio_v552_stop_current(uint32_t visit,uint32_t intent,uint32_t audio_sequence);
uint32_t sp_p6_record_audio_v552_admission(void);

/* Called once after successful native stock mixing. The source transform's
 * exact return label authenticates this edge; direct calls refuse. Complete
 * preview PCM is already in the permanent scratch. No filesystem work occurs. */
int sp_p6_record_audio_v552_native(const void *voice,const int16_t *pcm,uint32_t frames,int32_t *work);
/* Exact copied mailbox consumer validates its acquired immutable batch here.
 * This is an internal source edge, not a caller qualification interface. */
int sp_p6_record_audio_v552_shadow_allowed(const SpSynthAudioMailbox *,const SpAppAudioState *,int consume);
/* Optional bounded synchronous backend observer. PCM expires on return. This
 * default observer does nothing, and grants no capture or native token. */
void sp_p6_record_backend_v552_pcm(const SpP6RecordAudioReceiptV552 *,const int16_t *,uint32_t);
#endif
