#include "sp_p6_record_controls_v552.h"
#include "sp_p6_record_controls_v552_private.h"
#include "sp_p6_session_binding_v552.h"
#include "sp_p6_menu.h"
#include "sp_p6_record_request_v552.h"
#include <stddef.h>

_Static_assert(sizeof(SpSynthSessionV552)==3824,"Preserved session ABI");
_Static_assert(sizeof(SpSynthRuntimeStorage)==116032,"Preserved private runtime ABI");
#define value(a) atomic_load_explicit((a),memory_order_acquire)
/* This is the source-owned copied drain frame, never a caller-supplied receipt.
 * The inspected entry source owns its stack lifetime and offered bit. */
typedef struct { uint32_t record[3],old,offered;void *previous; } NativeFrame;
_Static_assert(sizeof(NativeFrame)==24,"Inspected ARM32 copied frame");
static uint32_t rd(uint32_t a) {return *(volatile const uint32_t *)(uintptr_t)a;}
static int panel(void *page) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
    uint32_t i,p,z,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));
    __asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(z));
    __asm__ volatile("mrs %0,faultmask":"=r"(f));
    if(i || p || z || f || rd(0x202BBBF8) || rd(0x80245764))return 0;
    uint32_t task=((uint32_t (*)(void))(uintptr_t)0x800D3163)();
    return task && task==m->task_id && task==b->task && task==rd(0x8300A3E8) &&
        value(&m->ready)==1 && !value(&m->terminal) && !value(&m->entry.fault) &&
        value(&m->phase)==SP_PREVIEW_NATIVE_ACTIVE && sp_p6_menu.view.page==SP_P6_RECORD &&
        page && page==atomic_load_explicit(&m->active_page,memory_order_acquire) &&
        (uintptr_t)page==rd(0x80CFD4FC) && rd((uint32_t)(uintptr_t)page)==(uintptr_t)(m->primary+2) &&
        value(&b->phase)==SP_P6_SB_PREPARED && !value(&b->fault) && b->sequence &&
        value(&b->pending)==b->sequence && b->page==(uintptr_t)page && b->visit==m->voice_used;
}
static int offered(void *page,uint32_t kind,int32_t id,int32_t data,int pad_up) {
    SpSynthEntryOwnerV552 *e=&sp_synth_preview_native_v552.entry;
    if(!panel(page) || e->dispatch_depth!=1 || e->sample_depth || !e->input.enabled)return 0;
    const NativeFrame *f=e->dispatch;
    return f && !f->old && f->offered==(uint32_t)!pad_up &&
        (f->record[0]&65535u)==kind && (int16_t)(f->record[0]>>16)==id &&
        (kind==5 || kind==17 || (int16_t)(f->record[1]&65535u)==data);
}
static SpSynthSessionV552 *session(void) {
    SpSynthSessionV552 *s=sp_p6_record_audio_v552_session();
    return s && s->startup.memory.storage && !value(&s->terminal)?s:NULL;
}
static void enqueue(SpSynthSessionV552 *s,sp_ui_event_type type,uint16_t index,int32_t data) {
    const sp_ui_event event={.type=type,.index=index,.value=data};
    /* Overflow keeps the existing queue's terminal stop and captured release
     * behavior. There is no replacement queue, retry or caller generation. */
    (void)sp_synth_session_v552_route(s,&event);
}

/* PANEL-owned intent only. This owner never supplies a native token, FILE,
 * ready flag or copied input record. A selected pad's release stays swallowed
 * after the chooser changes phase; it cannot become a second choice or note. */
static struct {
    uint32_t phase,empty,project,visit,page,bank,pad,captured,auto_save,pressed;
} direct;
_Static_assert(sizeof(direct)==40,"Bounded direct recording intent");
extern int sp_p6_session_binding_v552_record_choose(void *,uint32_t,uint32_t);
extern int sp_ui_capture_destination(sp_ui *,uint8_t,uint8_t);
extern uint32_t sp_p6_record_retirement_v552_token_retired(void);
static int direct_panel(void *page) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
    uint32_t i,p,z,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));
    __asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(z));
    __asm__ volatile("mrs %0,faultmask":"=r"(f));
    if(i || p || z || f || rd(0x202BBBF8) || rd(0x80245764))return 0;
    uint32_t task=((uint32_t (*)(void))(uintptr_t)0x800D3163)();
    return task && task==m->task_id && task==b->task && task==rd(0x8300A3E8) &&
        value(&m->ready)==1 && !value(&m->terminal) && !value(&m->entry.fault) &&
        value(&m->phase)==SP_PREVIEW_NATIVE_ACTIVE && page &&
        page==atomic_load_explicit(&m->active_page,memory_order_acquire) &&
        (uintptr_t)page==rd(0x80CFD4FC) && rd((uintptr_t)page)==(uintptr_t)(m->primary+2) &&
        value(&b->phase)==SP_P6_SB_PREPARED && !value(&b->fault);
}
static int direct_offer(void *page,uint32_t kind,int32_t id,int32_t data,int up) {
    SpSynthEntryOwnerV552 *e=&sp_synth_preview_native_v552.entry;
    if(!direct_panel(page) || e->dispatch_depth!=1 || e->sample_depth || !e->input.enabled)return 0;
    const NativeFrame *f=e->dispatch;
    return f && !f->old && f->offered==(uint32_t)!up &&
        (f->record[0]&65535u)==kind && (int16_t)(f->record[0]>>16)==id &&
        (kind==5 || kind==17 || (int16_t)f->record[1]==data);
}
static int direct_current(void *page) {
    return direct_panel(page) && direct.page==(uintptr_t)page &&
        direct.visit==sp_synth_preview_native_v552.voice_used;
}
void sp_p6_record_direct_edge(void) {
    void *page=atomic_load_explicit(&sp_synth_preview_native_v552.active_page,memory_order_acquire);
    SpSynthEntryOwnerV552 *e=&sp_synth_preview_native_v552.entry;
    const NativeFrame *f=e->dispatch;
    if(!direct_panel(page) || e->dispatch_depth!=1 || e->sample_depth || !f ||
       f->old || f->offered || (f->record[0]&65535u)!=6)return;
    int32_t id=(int16_t)(f->record[0]>>16);
    if(id==27)direct.pressed&=~1u;
    if(id==49)direct.pressed&=~2u;
}
static int direct_empty(uint32_t project,uint32_t bank,uint32_t pad) {
    SpP6EmptyPadSnapshotV552 d;
    return bank<10 && pad>=1 && pad<=16 &&
        !rd(0x82E2CD08u+172u*(bank*16u+pad-1u)+208u) &&
        sp_p6_pattern_v552_empty_pad(bank,pad,&d) && d.project==project &&
        !d.channels && !d.cache_busy;
}
static void direct_scan(void) {
    direct.empty=0;
    for(uint32_t pad=1;pad<=16;pad++)
        if(direct_empty(direct.project,direct.bank,pad))direct.empty|=1u<<(pad-1);
}
int sp_p6_record_direct_destination_offered(void *page,uint32_t bank,uint32_t pad) {
    const NativeFrame *f=sp_synth_preview_native_v552.entry.dispatch;
    if(!f)return 0;
    return direct_current(page) && direct.phase==1 && bank==direct.bank &&
        pad>=1 && pad<=16 && (direct.empty&(1u<<(pad-1))) &&
        direct_offer(page,16,(int32_t)pad-1,(int16_t)f->record[1],0) &&
        direct_empty(direct.project,bank,pad);
}
static int direct_button(void *page,uint32_t id,int shift) {
    if(!direct_offer(page,5,(int32_t)id,0,0))return 0;
    if(direct.page && !direct_current(page)) {
        /* A witnessed new page/visit cannot inherit selection/edge ownership.
         * The existing entry owner retains physical-pad quarantine on reentry. */
        direct.phase=0;direct.captured=0;direct.auto_save=0;direct.pressed=0;
    }
    if(id==34 && direct_current(page) && direct.phase==1) {
        direct.phase=0;direct.auto_save=0;sp_p6_menu.view.page=SP_P6_PLAY;return 1;
    }
    if(id==34 && direct_current(page) && direct.phase==2) {
        /* No START was requested. Cancel the selected intent on this actual
         * EXIT; the retained session/request owners keep their enable/arm ACKs.
         * A later chooser can reuse only the same idle prepared lifetime. */
        direct.phase=0;direct.auto_save=0;sp_p6_menu.view.page=SP_P6_PLAY;return 1;
    }
    if(id!=27 && !(id==49 && sp_p6_menu.view.page==SP_P6_RECORD))return 0;
    uint32_t press=id==27?1u:2u;
    if(direct.pressed&press)return 1;
    direct.pressed|=press;
    SpSynthSessionV552 *s=session();
    if(shift) {
        if(s && s->startup.memory.storage->controller.ui.take_held &&
           s->startup.memory.storage->controller.ui.page==SP_UI_DESTINATION)
            return 0; /* Existing authenticated discard confirmation owns this. */
        return direct_current(page) && direct.phase?1:0;
    }
    if(!direct_current(page) || !direct.phase) {
        if(s) {
            const sp_ui *u=&s->startup.memory.storage->controller.ui;
            if(u->busy || u->take_held || (u->page!=SP_UI_PLAY && u->page!=SP_UI_SAVED &&
               u->page!=SP_UI_CAPTURE_READY))return 0;
        }
        SpP6PatternSnapshotV552 p;
        if(!sp_p6_pattern_v552_snapshot(&p))return 1;
        direct.phase=1;direct.project=p.project;
        direct.visit=sp_synth_preview_native_v552.voice_used;direct.page=(uintptr_t)page;
        direct.bank=sp_p6_session_binding_v552.settings.destination_bank;
        direct.pad=0;direct.auto_save=0;direct_scan();sp_p6_menu.view.page=SP_P6_RECORD;return 1;
    }
    if(direct.phase==1)return 1;
    if(direct.phase==2) {
        if(!s)return 1;
        const sp_ui *u=&s->startup.memory.storage->controller.ui;
        if(u->page!=SP_UI_CAPTURE_READY || u->busy || u->take_held)return 1;
        enqueue(s,SP_UI_REC_PRESS,0,0);direct.phase=3;direct.auto_save=1;return 1;
    }
    if(direct.phase==3 && s) {
        const sp_ui *u=&s->startup.memory.storage->controller.ui;
        if(u->page==SP_UI_RECORDING && !u->busy) {
            enqueue(s,SP_UI_REC_PRESS,0,0);direct.phase=4;
        }
        return u->page==SP_UI_RECORDING || u->busy;
    }
    if(s && (s->startup.memory.storage->controller.ui.page==SP_UI_NEW_CONFIRM ||
       s->startup.memory.storage->controller.ui.page==SP_UI_LEAVE_CONFIRM ||
       s->startup.memory.storage->controller.ui.page==SP_UI_SAVE_ERROR ||
       (s->startup.memory.storage->controller.ui.page==SP_UI_DESTINATION &&
        s->startup.memory.storage->controller.ui.take_held && !direct.auto_save)))return 0;
    return direct.phase==4 || direct.phase==5;
}
static int direct_pad(const sp_ui_event *event) {
    void *page=atomic_load_explicit(&sp_synth_preview_native_v552.active_page,memory_order_acquire);
    int up=event->type==SP_UI_PAD_UP;
    if(!direct_offer(page,up?17:16,(int32_t)event->index-1,up?0:event->value,up))return 0;
    uint32_t bit=1u<<(event->index-1);
    if(!direct_current(page)) {
        direct.captured=0;return 0;
    }
    if(up) {
        if(!(direct.captured&bit))return 0;
        direct.captured&=~bit;return 1;
    }
    if(direct.captured&bit)return 1;
    if(direct.phase!=1)return 0;
    /* Every chooser press is consumed, including an occupied pad. */
    direct.captured|=bit;
    if(event->value<0 || event->value>127 || !(direct.empty&bit) ||
       !direct_empty(direct.project,direct.bank,event->index)) {direct_scan();return 1;}
    SpSynthSessionV552 *s=session();
    if(s) {
        sp_ui *u=&s->startup.memory.storage->controller.ui;
        if(u->busy || u->take_held || (u->page!=SP_UI_PLAY && u->page!=SP_UI_SAVED &&
           u->page!=SP_UI_CAPTURE_READY))return 1;
    }
    if(!sp_p6_session_binding_v552_record_choose(page,direct.bank,event->index))return 1;
    direct.pad=event->index;direct.phase=2;
    if(s) {
        sp_ui *u=&s->startup.memory.storage->controller.ui;
        if(!sp_ui_capture_destination(u,(uint8_t)direct.bank,(uint8_t)direct.pad))return 1;
        if(u->page!=SP_UI_CAPTURE_READY)enqueue(s,SP_UI_REC_PRESS,0,0);
    }
    return 1;
}
void sp_p6_record_direct_panel(void) {
    void *page=atomic_load_explicit(&sp_synth_preview_native_v552.active_page,memory_order_acquire);
    if(!direct_current(page) || !direct.phase)return;
    SpSynthSessionV552 *s=session();if(!s)return;
    const sp_ui *u=&s->startup.memory.storage->controller.ui;
    SpP6RecordRequestV552 *q=&sp_p6_record_request_v552;
    if(u->page==SP_UI_SAVED && !u->busy && !u->take_held) {
        direct.phase=0;direct.auto_save=0;return;
    }
    if((direct.phase==4 || direct.phase==5) && u->page==SP_UI_CAPTURE_READY &&
       !u->busy && !u->take_held && !u->take_token && u->pending==SP_UI_CMD_TAKE_DISCARD &&
       q->request_type==SP_APP_REQUEST_TAKE_DISCARD && q->generation==u->generation &&
       q->working_generation==u->generation && q->request_token &&
       sp_p6_record_retirement_v552_token_retired()==q->request_token &&
       sp_p6_record_request_v552_idle()) {
        /* Only the accepted canonical DISCARD completion retires this intent.
         * Native token/journal cleanup remains the backend's obligation. */
        direct.phase=0;direct.auto_save=0;sp_p6_menu.view.page=SP_P6_PLAY;return;
    }
    if(direct.auto_save && (direct.phase==3 || direct.phase==4) &&
       u->page==SP_UI_DESTINATION && u->take_held && !u->busy && u->dest_known &&
       !(u->save_flags&SP_UI_SAVE_RECOVERY_REQUIRED) &&
       q->request_type==SP_APP_REQUEST_DEST_QUERY && q->generation==u->generation &&
       q->working_generation==u->generation && q->request_token==u->take_token &&
       q->destination==(direct.pad|(direct.bank<<16)) && sp_p6_record_request_v552_idle()) {
        if(u->dest_bank!=direct.bank || u->dest_pad!=direct.pad || u->dest_occupied ||
           !direct_empty(direct.project,direct.bank,direct.pad)) {direct.auto_save=0;return;}
        /* The retained actual START/STOP intent requests SAVE only after the
         * native STOP/RX return and canonical destination-query completion. */
        enqueue(s,SP_UI_REC_PRESS,0,0);direct.phase=5;direct.auto_save=0;
    }
}
int sp_p6_record_direct_view(uint32_t out[4]) {
    void *page=atomic_load_explicit(&sp_synth_preview_native_v552.active_page,memory_order_acquire);
    if(!out || !direct_current(page) || !direct.phase)return 0;
    out[0]=direct.phase;out[1]=direct.empty;out[2]=direct.bank;out[3]=direct.pad;return 1;
}

static int selection(const sp_ui *u) {
    return u->page==SP_UI_DESTINATION || u->page==SP_UI_OVERWRITE ||
        u->page==SP_UI_NEW_CONFIRM || u->page==SP_UI_LEAVE_CONFIRM || u->page==SP_UI_SAVE_ERROR;
}
int sp_p6_record_controls_v552_button(void *page,uint32_t id,int shift) {
    if((shift==0 || shift==1) && (id==27 || id==49 || id==34) &&
       direct_button(page,id,shift))return 1;
    if((id!=49 && id!=27 && id!=34) || (shift!=0 && shift!=1) || !offered(page,5,(int32_t)id,0,0))return 0;
    SpSynthSessionV552 *s=session();
    if(!s)return id==34?0:1;
    const sp_ui *u=&s->startup.memory.storage->controller.ui;
    if((id==49 || id==27) && shift) {
        if(u->take_held && u->page==SP_UI_DESTINATION && !u->busy &&
           !(u->save_flags&SP_UI_SAVE_RECOVERY_REQUIRED)) {
            /* Normalize the actual SHIFT+VALUE gesture to the app's existing
             * SHIFT+REC discard confirmation. Always restore shadow SHIFT. */
            enqueue(s,SP_UI_SHIFT_DOWN,0,0);enqueue(s,SP_UI_REC_PRESS,0,0);enqueue(s,SP_UI_SHIFT_UP,0,0);
            return 1;
        }
        return 1; /* Keep this joined session in its recording controls. */
    }
    if(id==34) {
        if(u->page==SP_UI_INACTIVE)return 1;
        enqueue(s,SP_UI_EXIT_PRESS,0,0);return 1;
    }
    /* Empty destinations only. The current backend has no destructive replace
     * ownership. Keep the held take and let the player choose another pad. */
    if(u->page==SP_UI_DESTINATION && u->dest_known && u->dest_occupied && !u->busy)return 1;
    if(u->page==SP_UI_OVERWRITE)return 1;
    if(u->page==SP_UI_INACTIVE)return 1;
    if(u->page==SP_UI_RECORDING || u->page==SP_UI_CAPTURE_READY || u->page==SP_UI_CAPTURE_ERROR ||
       u->page==SP_UI_DESTINATION || u->page==SP_UI_PLAY || u->page==SP_UI_SAVED)
        enqueue(s,SP_UI_REC_PRESS,0,0);
    else if(selection(u) || (u->save_flags&SP_UI_SAVE_RECOVERY_REQUIRED))
        enqueue(s,SP_UI_VALUE_PRESS,0,0);
    return 1;
}
int sp_p6_record_controls_v552_turn(void *page,int32_t delta,int shift) {
    if(delta && !shift && direct_current(page) && direct.phase==1 &&
       direct_offer(page,7,0,delta,0)) {
        if(delta<0) {if(direct.bank)--direct.bank;} else if(direct.bank<9)++direct.bank;
        direct_scan();return 1;
    }
    if(!delta || (shift!=0 && shift!=1) || !offered(page,7,0,delta,0))return 0;
    if(shift)return 0; /* Existing live-preview octave route remains intact. */
    SpSynthSessionV552 *s=session();
    if(s && selection(&s->startup.memory.storage->controller.ui))enqueue(s,SP_UI_VALUE_TURN,0,delta);
    return 1;
}
int sp_p6_record_controls_v552_pad(const sp_ui_event *event) {
    if(!event || event->index<1 || event->index>16 ||
       (event->type!=SP_UI_PAD_DOWN && event->type!=SP_UI_PAD_UP))return 0;
    if(direct_pad(event))return 1;
    int up=event->type==SP_UI_PAD_UP;
    void *page=atomic_load_explicit(&sp_synth_preview_native_v552.active_page,memory_order_acquire);
    if(!offered(page,up?17:16,(int32_t)event->index-1,up?0:event->value,up))return 0;
    SpSynthSessionV552 *s=session();if(!s)return 0;
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    uint16_t bit=(uint16_t)(1u<<(event->index-1));
    if(up) {
        if(!(r->input.captured&bit))return 0;
        enqueue(s,SP_UI_PAD_UP,event->index,0);return 1;
    }
    if(event->value<0 || event->value>127 || r->controller.ui.page!=SP_UI_DESTINATION ||
       !r->controller.ui.take_held || r->controller.ui.busy ||
       (r->controller.ui.save_flags&SP_UI_SAVE_RECOVERY_REQUIRED))return 0;
    enqueue(s,SP_UI_PAD_DOWN,event->index,event->value);return 1;
}
uint32_t sp_p6_record_controls_v552_admission(void) {return 0;}
const SpSynthApp *sp_p6_record_controls_v552_app(void) {
    void *page=atomic_load_explicit(&sp_synth_preview_native_v552.active_page,memory_order_acquire);
    if(!panel(page))return NULL;
    SpSynthSessionV552 *s=session();return s?&s->startup.memory.storage->controller:NULL;
}
