#ifndef SP_P6_RECORD_CONTROLS_V552_PRIVATE_H
#define SP_P6_RECORD_CONTROLS_V552_PRIVATE_H
#include "sp_synth_session_v552.h"
/* Stable audio-owner observation ABI. Its implementation authenticates the
 * selected prepared lifetime; changing audio-owner storage stays private. */
SpSynthSessionV552 *sp_p6_record_audio_v552_session(void);
/* Full private controller/session types remain out of the projected native
 * callback and screen compilation. These observations grant no ownership. */
const SpSynthApp *sp_p6_record_controls_v552_app(void);
int sp_p6_record_controls_v552_draw(const SpSynthApp *app,
    const SpPreviewVisualSnapshot *visual,uint8_t frame[1024]);
#endif
