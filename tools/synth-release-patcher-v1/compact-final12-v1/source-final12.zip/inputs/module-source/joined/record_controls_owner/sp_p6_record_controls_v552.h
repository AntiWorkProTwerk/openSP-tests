#ifndef SP_P6_RECORD_CONTROLS_V552_H
#define SP_P6_RECORD_CONTROLS_V552_H
#include "sp_synth_preview_native_v552.h"
#include "sp_synth_preview_visual.h"

/* Called only after the copied native callback has offered its exact current
 * record. The source checks the frame, selected task, active page and retained
 * intent again. It enqueues through the existing session input/control queue;
 * it never runs control, app dispatch, backend IO or an audio window here. */
int sp_p6_record_controls_v552_button(void *page,uint32_t id,int shift);
int sp_p6_record_controls_v552_turn(void *page,int32_t delta,int shift);
/* Existing native entry publication only. Destination downs enter the private
 * UI; all other downs remain live preview notes. Private destination releases
 * are retained, and the caller still releases any existing preview voice. */
int sp_p6_record_controls_v552_pad(const sp_ui_event *event);

/* Selected panel presentation only, with its existing permanent OLED buffer.
 * Returns0 outside the RECORD menu. No capture/retirement authority is added.
 * The caller first draws its ordinary view, then this bounded record overlay. */
int sp_p6_record_controls_v552_render(const SpPreviewNativeView *view,
    const SpPreviewVisualSnapshot *visual,uint8_t frame[1024]);
uint32_t sp_p6_record_controls_v552_admission(void);
#endif
