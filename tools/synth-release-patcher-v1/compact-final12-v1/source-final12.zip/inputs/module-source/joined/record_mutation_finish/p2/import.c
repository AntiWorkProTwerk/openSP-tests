#include "../guard.h"
#include <stdint.h>
extern uint32_t sp_p6_mf_v552_import_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_mf_v552_import(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    /* Native import itself returns -117 on cancellation. All observed callers
     * select a negative-result branch; -1 has a separate format fallback. */
    if(!sp_p6_mf_v552_enter(1))return (uint32_t)-117;
    uint32_t result=sp_p6_mf_v552_import_original(a,b,c,d);
    sp_p6_mf_v552_leave();return result;
}
uint32_t sp_p6_mf_v552_import_coverage(void) {
    return *(volatile const uint32_t *)0x80096CB0u==0xF000F8DFu &&
        *(volatile const uint32_t *)0x80096CB4u==((uint32_t)(uintptr_t)sp_p6_mf_v552_import|1u);
}
