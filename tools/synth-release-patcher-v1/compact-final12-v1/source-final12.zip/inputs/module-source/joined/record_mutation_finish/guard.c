#include "guard.h"
#include "sp_p6_record_ingress_alias_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_record_project_gate_v552.h"
/* Reuse the ingress scope that producer BEGIN already checks under its mask.
 * No pointer, caller token, ready Boolean or new persistent storage is accepted. */
uint32_t sp_p6_mf_v552_enter(uint32_t ordered) {
    uint32_t p;
    __asm__ volatile("mrs %0, primask\n cpsid i\n dmb":"=r"(p)::"memory");
    SpP6RecordIngressAliasV552 *i=&sp_p6_record_ingress_alias_v552;
    uint32_t ok=!sp_p6_record_producer_v552.held && !sp_p6_record_files_v552.active &&
        (!ordered || !sp_p6_record_project_gate_v552.count) && i->active<UINT32_MAX;
    if(ok)++i->active;
    else if(i->refused<UINT32_MAX)++i->refused;
    if(i->active==UINT32_MAX)i->fault|=1u;
    __asm__ volatile("dmb\n msr primask, %0"::"r"(p):"memory");
    return ok;
}
void sp_p6_mf_v552_leave(void) {
    uint32_t p;
    __asm__ volatile("mrs %0, primask\n cpsid i\n dmb":"=r"(p)::"memory");
    SpP6RecordIngressAliasV552 *i=&sp_p6_record_ingress_alias_v552;
    if(i->active)--i->active;else i->fault|=2u;
    __asm__ volatile("dmb\n msr primask, %0"::"r"(p):"memory");
}
