#ifndef SP_P6_MUTATION_FINISH_H
#define SP_P6_MUTATION_FINISH_H
#include <stdint.h>
/* Lower-bound list, pinned to actual dispatcher branches in audit.json. */
static inline int sp_p6_mf_v552_command(uint32_t n) {
    return n<=5u || n==0x65u || n==0x66u || n==0x3F8u || n==0x3F9u ||
        n==0x405u || n==0x413u || n==0x1F9u;
}
uint32_t sp_p6_mf_v552_enter(uint32_t ordered);
void sp_p6_mf_v552_leave(void);
#endif
