#include "sp_p6_record_backend_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_token_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_save_handover_v552.h"
#include "sp_p6_record_fullbar_v552.h"
#include "sp_synth_take_save_v552.h"
#include <string.h>

#define PARAM UINT32_C(0x82E2CD08)
#define POOL UINT32_C(0x82E111C8)
_Static_assert(sizeof(SpSynthCaptureTimedV552)==1336,"Existing timed owner ABI");
_Static_assert(sizeof(SpSynthSessionV552)==3824,"Existing session ABI");
static uint32_t rd(uint32_t p) {return *(volatile const uint32_t *)(uintptr_t)p;}
static uint32_t val(const atomic_uint *p) {return atomic_load_explicit(p,memory_order_acquire);}
static uint32_t native(uint32_t p,uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return ((uint32_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(uintptr_t)(p|1u))(a,b,c,d);
}
static int context(void) {
    uint32_t i,p,b,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));
    __asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(b));
    __asm__ volatile("mrs %0,faultmask":"=r"(f));
    return !i && !p && !b && !f && !rd(0x202BBBF8) && !rd(0x80245764) &&
        sp_p6_record_context_v552_current(1);
}
static int request(SpSynthCaptureTimedV552 *c) {
    if(!c || c!=sp_p6_record_producer_v552.capture || !context() || !c->working ||
       !c->work.generation || c->completion.generation!=c->work.generation)return 0;
    SpSynthBackendLink *b=atomic_load_explicit(&c->backend,memory_order_acquire);
    return b && !val(&b->responses.stopped) && val(&b->request_phase)==2 &&
        !memcmp(&c->work,&b->request,sizeof(c->work));
}
static int held(SpSynthCaptureTimedV552 *c) {
    uint32_t token=val(&c->token);
    return request(c) && token && c->work.token==token && c->work_token==token &&
        sp_p6_record_token_v552_actual_token()==token && c->plan.take_token==token &&
        c->plan.start_generation && c->last_token==token && val(&c->state)==SP_TCAP_HELD &&
        !val(&c->fault) && !val(&c->handoff_fault) && !val(&c->rx_active) &&
        val(&c->rx_ack)==token && !c->window.inflight && c->file_owned &&
        sp_p6_record_producer_v552.held && !sp_p6_record_producer_v552.active &&
        !sp_p6_record_producer_v552.fault && sp_p6_record_producer_v552.token==token &&
        sp_p6_record_files_v552.active && !sp_p6_record_files_v552.fault &&
        !sp_p6_record_files_v552.smpl_operation && !sp_p6_record_files_v552.record_operation &&
        !sp_p6_record_files_v552.cache_depth;
}
static int pad(SpSynthCaptureTimedV552 *c,uint32_t *out) {
    if(c->work.bank>=10 || c->work.index<1 || c->work.index>16 || c->work.replace || c->work.revision)return 0;
    *out=16u*c->work.bank+c->work.index-1u;return 1;
}
static int occupied(uint32_t pad) {
    /* DC6B8 tests this complete word before interpreting channel metadata.
     * A logical slot with absent/corrupt channel metadata is still occupied. */
    if(rd(PARAM+172u*pad+208u))return 1;
    if(native(0x800DC6B8,PARAM,101,pad,0) || native(0x800D8998,pad,0,0,0))return 1;
    for(unsigned i=0;i<38;i++) {
        uint32_t p=POOL+304u*pad+8u*i;
        if(*(volatile const uint8_t *)(uintptr_t)p || rd(p+4)!=UINT32_MAX)return 1;
    }
    return 0;
}
static uint32_t save_fault(SpP6SaveHandoverV552 *s) {
    uint32_t f=0;
    if(s->fault&(SP_P6_SAVE_CONTEXT|SP_P6_SAVE_EXHAUSTED))f|=SP_TAKE_SAVE_CONTEXT;
    if(s->fault&(SP_P6_SAVE_IDENTITY|SP_P6_SAVE_METADATA))f|=SP_TAKE_SAVE_CHANGED;
    if(s->fault&SP_P6_SAVE_IO)f|=SP_TAKE_SAVE_SAMPLE;
    if(s->capture && val(&s->capture->fault)==(uint32_t)SP_TCAP_PROJECT)f|=SP_TAKE_SAVE_PROJECT;
    return f;
}
int sp_p6_record_backend_v552_begin(SpSynthCaptureTimedV552 *c) {
    if(!request(c))return -1;
    uint32_t dest;
    c->completion.token=c->work.token;c->completion.capture_active=0;
    if(c->work.type!=SP_APP_REQUEST_DEST_QUERY && c->work.type!=SP_APP_REQUEST_TAKE_WRITE)return -1;
    int intact=held(c);
    if(!intact || !pad(c,&dest)) {
        c->completion.error=SP_UI_ERR_CAPTURE;
        if(intact && c->work.type==SP_APP_REQUEST_TAKE_WRITE)c->completion.save_flags=SP_TAKE_SAVE_INTACT;
        return 1;
    }
    if(c->work.type==SP_APP_REQUEST_DEST_QUERY) {
        c->completion.occupied=(uint8_t)occupied(dest);
        /* Getter/descriptor result is a current observation under this exact
         * native take, not an overwrite reservation or filename promise. */
        if(!held(c)) {c->completion.error=SP_UI_ERR_CAPTURE;return 1;}
        if(c->completion.occupied)memcpy(c->completion.name,(const void *)(uintptr_t)(PARAM+27900+24u*dest),24);
        return 1;
    }
    if(occupied(dest)) {
        c->completion.error=SP_UI_ERR_STORAGE;c->completion.save_flags=SP_TAKE_SAVE_INTACT;return 1;
    }
    /* REC must retire every full slot before SAVE flushes the sole partial
     * slot. Failed event posts retry on the next actual SMPL visit. */
    c->closed_request=3;
    if(!sp_p6_record_fullbar_v552_save_ready(c)) {
        c->completion.error=SP_UI_ERR_CAPTURE;
        c->completion.save_flags=SP_TAKE_SAVE_RECOVERY_REQUIRED;return 1;
    }
    for(unsigned i=0;i<30;i++) {
        if(*(volatile const uint8_t *)(uintptr_t)(UINT32_C(0x82FE4F08)+60u+12u*i)) {
            return 0;
        }
    }
    c->closed_request=4;
    if(sp_p6_save_v552_write(c,dest)<=0) {
        c->completion.error=SP_UI_ERR_STORAGE;
        c->completion.save_flags=val(&c->state)==SP_TCAP_HELD && !sp_p6_save_handover_v552.fault?
            SP_TAKE_SAVE_INTACT:SP_TAKE_SAVE_RECOVERY_REQUIRED;
        c->completion.save_fault=save_fault(&sp_p6_save_handover_v552);return 1;
    }
    return sp_p6_record_backend_v552_poll(c);
}
int sp_p6_record_backend_v552_poll(SpSynthCaptureTimedV552 *c) {
    if(!request(c) || c->work.type!=SP_APP_REQUEST_TAKE_WRITE)return -1;
    if(c->closed_request==3) {
        int result=sp_p6_record_backend_v552_begin(c);
        if(!result && c->closed_request==3)(void)sp_p6_record_fullbar_v552_service();
        return result;
    }
    if(c->closed_request!=4)return -1;
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    /* A previous take's TRANSFERRED receipt cannot complete the current SAVE. */
    if(s->capture!=c || s->token!=c->work.token || s->generation!=c->plan.start_generation ||
       s->pad!=16u*c->work.bank+c->work.index-1u)return -1;
    int result=sp_p6_save_v552_poll(c);
    if(!result)return 0;
    c->completion.token=c->work.token;c->completion.capture_active=0;
    c->completion.save_fault=save_fault(s);
    if(result<0 || s->state!=SP_P6_SAVE_TRANSFERRED || s->fault || val(&c->token) ||
       val(&c->cleanup_token)!=c->work.token || val(&c->state)!=SP_TCAP_EXCLUSIVE_IDLE ||
       !s->sequence || s->ack_sequence!=s->sequence || s->wait_sequence!=s->sequence ||
       c->file_owned || val(&c->rx_active) || c->window.inflight) {
        c->completion.error=SP_UI_ERR_STORAGE;
        c->completion.save_flags=SP_TAKE_SAVE_RECOVERY_REQUIRED;return 1;
    }
    /* Cache FILE stays native-owned and LIVE. The existing handover verified
     * its identity, sample/rename/PADCONF and fresh actual REC retirement. */
    c->completion.error=SP_UI_OK;
    c->completion.save_flags=SP_TAKE_SAVE_CLOSED|SP_TAKE_SAVE_RENAMED|
        SP_TAKE_SAVE_PROJECT_DONE|SP_TAKE_SAVE_RETIRED;
    memcpy(c->completion.name,s->name,24);return 1;
}
int sp_p6_record_backend_v552_discarded(SpSynthCaptureTimedV552 *c) {
    return request(c) && c->work.type==SP_APP_REQUEST_TAKE_DISCARD && c->work.token &&
        c->work_token==c->work.token && c->plan.take_token==c->work.token &&
        val(&c->cleanup_token)==c->work.token && !val(&c->token) &&
        val(&c->state)==SP_TCAP_EXCLUSIVE_IDLE && !val(&c->fault) && !val(&c->handoff_fault) &&
        !c->file_owned && !val(&c->rx_active) && !c->window.inflight &&
        !sp_p6_record_files_v552.active && !sp_p6_record_files_v552.fault &&
        !sp_p6_record_files_v552_outstanding() && !sp_p6_record_producer_v552.held &&
        !sp_p6_record_producer_v552.active && !sp_p6_record_producer_v552.fault &&
        sp_p6_record_producer_v552.last_retired==c->work.token;
}
uint32_t sp_p6_record_backend_v552_admission(void) {return 0;}
