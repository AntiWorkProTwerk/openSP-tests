#ifndef SP_P6_RECORD_BACKEND_V552_H
#define SP_P6_RECORD_BACKEND_V552_H
#include "sp_synth_capture_timed_v552.h"
#include "sp_synth_take_save_v552.h"

/* Intrinsic SMPL continuation, after the request owner has acquired the
 * canonical link request. No extra owner, request or SAVE buffer exists.
 * These operations grant no capture/project/producer admission. */
int sp_p6_record_backend_v552_begin(SpSynthCaptureTimedV552 *);
int sp_p6_record_backend_v552_poll(SpSynthCaptureTimedV552 *);
/* Exact source-owned DISCARD retirement observation; never token0 alone. */
int sp_p6_record_backend_v552_discarded(SpSynthCaptureTimedV552 *);

/* Installed composition only. The request owner alone authenticates and takes
 * phase1. Its claim stays canonical until the actual link finish. Missing
 * request/audio owners leave these functions unavailable. */
const SpAppRequest *sp_p6_record_backend_v552_claim(SpSynthCaptureTimedV552 *,SpSynthBackendLink *);
int sp_p6_record_backend_v552_retained(SpSynthCaptureTimedV552 *,SpSynthBackendLink *);
int sp_p6_record_backend_v552_finished(void);
/* Actual native PANEL service, after source-owned audio/session publication.
 * 1 newly published,2 already exact,0 refused. No request/admission granted. */
int sp_p6_record_backend_v552_panel(void);
enum {SP_P6_RB_CONTEXT=1,SP_P6_RB_REQUEST=2,SP_P6_RB_SOURCE=4,
      SP_P6_RB_TAKE=8,SP_P6_RB_DRAIN=16,SP_P6_RB_NATIVE_ADMISSION=32};
/* SMPL read-only blocker mask. Observation never takes a request or grants IO. */
uint32_t sp_p6_record_backend_v552_blocked(void);
uint32_t sp_p6_record_backend_v552_admission(void);
#endif
