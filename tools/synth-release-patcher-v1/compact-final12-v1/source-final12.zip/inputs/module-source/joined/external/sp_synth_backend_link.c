#include "sp_synth_backend_link.h"
#include "sp_synth_capture_window.h"
#include <string.h>
_Static_assert(ATOMIC_INT_LOCK_FREE==2,"Capture feedback requires lock-free atomics");

void sp_synth_backend_link_init(SpSynthBackendLink *b) {
    if(!b)return;
    sp_synth_backend_inbox_init(&b->responses);
    memset(&b->request,0,sizeof(b->request));atomic_init(&b->request_phase,0);
    memset(&b->capture_feedback,0,sizeof(b->capture_feedback));
    atomic_init(&b->capture_feedback_ready,0);
    b->capture_feedback_released=0;
    memset(&b->capture_cancel_request,0,sizeof(b->capture_cancel_request));
    memset(&b->capture_cancel_result,0,sizeof(b->capture_cancel_result));
    atomic_init(&b->capture_cancel_phase,SP_CAPTURE_CANCEL_EMPTY);
}
static SpControlService stopped(SpSynthBackendLink *b,SpSynthControlQueue *q,SpSynthAudioMailbox *m) {
    if(b)atomic_store_explicit(&b->responses.stopped,1,memory_order_release);
    if(q)q->faulted=1;
    sp_synth_audio_mailbox_stop(m);return SP_CONTROL_STOPPED;
}
SpControlService sp_synth_backend_link_service(SpSynthBackendLink *b,
    SpSynthControlQueue *q,SpSynthMidiQueue *midi,SpSynthAudioMailbox *m,
    SpSynthApp *a,uint32_t target) {
    if(!b || !q || !midi || !m || !a || !m->timed || !a->audio_deferred ||
       target%SP_AUDIO_TIMED_FRAMES || q->faulted || midi->fault || a->audio_faulted ||
       atomic_load_explicit(&b->responses.stopped,memory_order_acquire) ||
       atomic_load_explicit(&m->stop_requested,memory_order_acquire))return stopped(b,q,m);
    SpAudioCompletion out;
    if(sp_synth_audio_mailbox_complete(m,a,&out)==SP_AUDIO_COMPLETED_FAILED)return stopped(b,q,m);
    if(!a->audio_pending && !a->audio_batch && !a->event_count && !a->batch_failed &&
       atomic_load_explicit(&m->phase,memory_order_acquire)==SP_AUDIO_FREE &&
       !atomic_load_explicit(&b->request_phase,memory_order_acquire) &&
       atomic_load_explicit(&b->capture_cancel_phase,memory_order_acquire)==SP_CAPTURE_CANCEL_EMPTY &&
       !atomic_load_explicit(&b->responses.phase,memory_order_acquire) && a->request_count) {
        if(!sp_synth_app_request(a,&b->request))return stopped(b,q,m);
        atomic_store_explicit(&b->request_phase,1,memory_order_release);
    }
    if(a->capture_cancel_state==SP_APP_CANCEL_READY) {
        /* READY is set only by the exact successful PANIC batch acknowledgment.
         * START is issued above if it had not yet reached this link. Publish
         * before consuming its possibly already queued response. */
        SpSynthCaptureCancelRequest request={a->capture_progress.start_generation,
            a->capture_progress.take_token,a->capture_cancel_sequence};
        if(!sp_synth_backend_link_cancel_publish(b,&request))return stopped(b,q,m);
        a->capture_cancel_state=SP_APP_CANCEL_REQUESTED;
    }
    /* Borrow READY without releasing it. Its sole producer cannot overwrite
     * the slot during completion, cutoff or audio waits. No native phases cross
     * into the portable app. A sealed window may request STOP; its ordinary
     * acknowledged transaction still owns native settlement and completion. */
    unsigned ready=atomic_load_explicit(&b->capture_feedback_ready,memory_order_acquire);
    SpAppCaptureProgress progress={0};
    if(ready) {
        const SpSynthCaptureFeedback *p=&b->capture_feedback;
        progress=(SpAppCaptureProgress){.start_generation=p->start_generation,
            .take_token=p->take_token,.sample_rate_hz=p->sample_rate_hz,
            .has_rx_notice=p->has_rx_notice,.fault=p->fault,
            .sealed=p->has_rx_notice && p->window_phase==SP_CAPTURE_WINDOW_SEALED,
            .observed_frames=p->observed_frames,.accepted_frames=p->accepted_frames,
            .count_in_frames=p->count_in_frames,.duration_frames=p->duration_frames,
            .tail_cut_reason=p->tail_cut_reason};
    }
    unsigned canceled=a->capture_cancel_state==SP_APP_CANCEL_REQUESTED &&
        atomic_load_explicit(&b->capture_cancel_phase,memory_order_acquire)==SP_CAPTURE_CANCEL_RESULT;
    SpAppCaptureCancelCompletion cancel={0};
    if(canceled) {
        const SpSynthCaptureCancelResult *r=&b->capture_cancel_result;
        cancel=(SpAppCaptureCancelCompletion){r->start_generation,r->take_token,r->audio_sequence,r->result};
    }
    SpBackendDelivery delivery=SP_BACKEND_WAITING,cancel_delivery=SP_BACKEND_WAITING;
    SpControlService result=sp_synth_backend_inbox_service_capture(&b->responses,q,midi,m,a,target,
        ready?&progress:0,&delivery,canceled?&cancel:0,&cancel_delivery);
    if(result!=SP_CONTROL_STOPPED && ready && delivery!=SP_BACKEND_WAITING) {
        atomic_store_explicit(&b->capture_feedback_ready,0,memory_order_release);
        b->capture_feedback_released=1;
    }
    if(result!=SP_CONTROL_STOPPED && canceled && cancel_delivery==SP_BACKEND_APPLIED)
        atomic_store_explicit(&b->capture_cancel_phase,SP_CAPTURE_CANCEL_EMPTY,memory_order_release);
    return result;
}
int sp_synth_backend_link_take(SpSynthBackendLink *b,SpAppRequest *out) {
    if(!b || !out || atomic_load_explicit(&b->responses.stopped,memory_order_acquire) ||
       atomic_load_explicit(&b->request_phase,memory_order_acquire)!=1)return 0;
    *out=b->request;atomic_store_explicit(&b->request_phase,2,memory_order_release);return 1;
}
int sp_synth_backend_link_finish(SpSynthBackendLink *b,const SpAppCompletion *c) {
    if(!b || atomic_load_explicit(&b->responses.stopped,memory_order_acquire) ||
       atomic_load_explicit(&b->request_phase,memory_order_acquire)!=2)return 0;
    if(b->request.generation) {
        if(!c || c->generation!=b->request.generation || !sp_synth_backend_inbox_publish(&b->responses,c))return 0;
    } else if(c)return 0;
    atomic_store_explicit(&b->request_phase,0,memory_order_release);return 1;
}
int sp_synth_backend_link_capture_publish(SpSynthBackendLink *b,const SpSynthCaptureFeedback *s) {
    if(!b || !s || !s->start_generation || !s->take_token || !s->sample_rate_hz ||
       !s->duration_frames || s->has_rx_notice>1 || s->accepted_frames>s->observed_frames ||
       (!s->has_rx_notice && (s->window_phase || s->milestones || s->observed_frames || s->accepted_frames)) ||
       atomic_load_explicit(&b->responses.stopped,memory_order_acquire) ||
       atomic_load_explicit(&b->capture_feedback_ready,memory_order_acquire))return 0;
    /* The sole consumer never writes this payload. After its release, avoid
     * republishing an identical observation and creating a wake/consume loop. */
    if(!memcmp(&b->capture_feedback,s,sizeof(*s)))return 1;
    b->capture_feedback=*s;
    atomic_store_explicit(&b->capture_feedback_ready,1,memory_order_release);return 1;
}
SpCaptureFeedbackDelivery sp_synth_backend_link_capture_take(SpSynthBackendLink *b,
    uint32_t generation,uint32_t token,SpSynthCaptureFeedback *out) {
    if(!b || !out || !generation ||
       atomic_load_explicit(&b->responses.stopped,memory_order_acquire) ||
       !atomic_load_explicit(&b->capture_feedback_ready,memory_order_acquire))return SP_CAPTURE_FEEDBACK_WAITING;
    int match=b->capture_feedback.start_generation==generation &&
        (!token || b->capture_feedback.take_token==token);
    if(match)*out=b->capture_feedback;
    atomic_store_explicit(&b->capture_feedback_ready,0,memory_order_release);
    b->capture_feedback_released=1;
    return match?SP_CAPTURE_FEEDBACK_READY:SP_CAPTURE_FEEDBACK_STALE;
}
int sp_synth_backend_link_cancel_publish(SpSynthBackendLink *b,const SpSynthCaptureCancelRequest *r) {
    if(!b || !r || !r->start_generation || !r->audio_sequence ||
       b->request.type!=SP_APP_REQUEST_CAPTURE_START || b->request.generation!=r->start_generation ||
       atomic_load_explicit(&b->responses.stopped,memory_order_acquire) ||
       atomic_load_explicit(&b->capture_cancel_phase,memory_order_acquire)!=SP_CAPTURE_CANCEL_EMPTY)return 0;
    b->capture_cancel_request=*r;
    atomic_store_explicit(&b->capture_cancel_phase,SP_CAPTURE_CANCEL_REQUEST,memory_order_release);return 1;
}
int sp_synth_backend_link_cancel_take(SpSynthBackendLink *b,uint32_t generation,uint32_t sequence,SpSynthCaptureCancelResult *out) {
    if(!b || !out || !generation || !sequence ||
       atomic_load_explicit(&b->responses.stopped,memory_order_acquire) ||
       atomic_load_explicit(&b->capture_cancel_phase,memory_order_acquire)!=SP_CAPTURE_CANCEL_RESULT ||
       b->capture_cancel_result.start_generation!=generation || b->capture_cancel_result.audio_sequence!=sequence)return 0;
    *out=b->capture_cancel_result;
    atomic_store_explicit(&b->capture_cancel_phase,SP_CAPTURE_CANCEL_EMPTY,memory_order_release);return 1;
}
