#include "sp_synth_audio_mailbox.h"
extern int sp_p6_record_audio_v552_shadow_allowed(const SpSynthAudioMailbox *,const SpAppAudioState *,int);
#include <limits.h>
#include <string.h>

_Static_assert(ATOMIC_INT_LOCK_FREE==2 && UINT_MAX==UINT32_MAX,"Mailbox requires lock-free 32-bit unsigned atomics");
void sp_synth_audio_mailbox_init(SpSynthAudioMailbox *m) {
    if(!m)return;
    memset(&m->batch,0,sizeof(m->batch));memset(&m->completion,0,sizeof(m->completion));
    atomic_init(&m->phase,SP_AUDIO_FREE);atomic_init(&m->stop_requested,0);atomic_init(&m->stopped,0);
    atomic_init(&m->sample_cursor,0);m->target_sample=0;m->timed=0;
}
int sp_synth_audio_mailbox_init_timed(SpSynthAudioMailbox *m,uint32_t initial) {
    if(!m || initial%SP_AUDIO_TIMED_FRAMES)return 0;
    sp_synth_audio_mailbox_init(m);m->timed=1;
    atomic_store_explicit(&m->sample_cursor,initial,memory_order_relaxed);return 1;
}
int sp_synth_audio_mailbox_cursor(const SpSynthAudioMailbox *m,uint32_t *sample) {
    if(!m || !sample || !m->timed)return 0;
    *sample=atomic_load_explicit(&m->sample_cursor,memory_order_acquire);return 1;
}
int sp_synth_audio_mailbox_begin(SpSynthAudioMailbox *m,SpSynthApp *a) {
    if(!m || !a || atomic_load_explicit(&m->stop_requested,memory_order_acquire) ||
       atomic_load_explicit(&m->phase,memory_order_acquire)!=SP_AUDIO_FREE)return 0;
    if(!sp_synth_app_audio_begin(a,&m->batch))return 0;
    atomic_store_explicit(&m->phase,SP_AUDIO_WRITING,memory_order_release);return 1;
}
static SpAudioPublication publish(SpSynthAudioMailbox *m,SpSynthApp *a,uint32_t frames,uint32_t target) {
    if(!m || !a || atomic_load_explicit(&m->stop_requested,memory_order_acquire) ||
       atomic_load_explicit(&m->phase,memory_order_acquire)!=SP_AUDIO_WRITING || a->audio_batch!=&m->batch)
        return SP_AUDIO_NOT_PUBLISHED;
    int ok=sp_synth_app_audio_seal(a,frames);
    if(!m->batch.sealed)return SP_AUDIO_NOT_PUBLISHED;
    m->target_sample=target;
    atomic_store_explicit(&m->phase,SP_AUDIO_READY,memory_order_release);
    return ok?SP_AUDIO_PUBLISHED:SP_AUDIO_PUBLISHED_FAILED;
}
SpAudioPublication sp_synth_audio_mailbox_publish(SpSynthAudioMailbox *m,SpSynthApp *a,uint32_t frames) {
    if(!m || m->timed)return SP_AUDIO_NOT_PUBLISHED;
    return publish(m,a,frames,0);
}
SpAudioPublication sp_synth_audio_mailbox_publish_at(SpSynthAudioMailbox *m,SpSynthApp *a,uint32_t target) {
    if(!m || !m->timed)return SP_AUDIO_NOT_PUBLISHED;
    uint32_t distance=target-atomic_load_explicit(&m->sample_cursor,memory_order_acquire);
    if(distance>SP_AUDIO_MAX_LOOKAHEAD || distance%SP_AUDIO_TIMED_FRAMES)
        return SP_AUDIO_NOT_PUBLISHED;
    return publish(m,a,SP_AUDIO_TIMED_FRAMES,target);
}
SpAudioCompletionStatus sp_synth_audio_mailbox_complete(SpSynthAudioMailbox *m,SpSynthApp *a,SpAudioCompletion *out) {
    if(!m || !a || !out || atomic_load_explicit(&m->phase,memory_order_acquire)!=SP_AUDIO_DONE ||
       !a->audio_pending || a->audio_sequence!=m->completion.sequence)return SP_AUDIO_NO_COMPLETION;
    *out=m->completion;
    int ok=sp_synth_app_audio_complete(a,out->sequence,out->result==SP_SYNTH_STOCK_OK);
    if(ok && m->timed)(void)sp_synth_app_capture_tail_observe(a,out->sequence,out->quiescent,out->sample_end);
    atomic_store_explicit(&m->phase,SP_AUDIO_FREE,memory_order_release);
    return ok?SP_AUDIO_COMPLETED:SP_AUDIO_COMPLETED_FAILED;
}
void sp_synth_audio_mailbox_stop(SpSynthAudioMailbox *m) {
    if(m)atomic_store_explicit(&m->stop_requested,1,memory_order_release);
}
int sp_synth_audio_mailbox_stopped(const SpSynthAudioMailbox *m) {
    return m && atomic_load_explicit(&m->stopped,memory_order_acquire)!=0;
}
static void stop_audio(SpSynthAudioMailbox *m,SpAppAudioState *s) {
    sp_synth_engine_panic(&s->engine);s->faulted=1;
    atomic_store_explicit(&m->stop_requested,1,memory_order_release);
    atomic_store_explicit(&m->stopped,1,memory_order_release);
}
SpSynthStockResult sp_synth_audio_mailbox_mix(SpSynthAudioMailbox *m,SpAppAudioState *s,
    const SpSynthStockBlock *block,SpSynthAppMixScratch *scratch) {
    if(!m || !s)return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    if(atomic_load_explicit(&m->stop_requested,memory_order_acquire)) {
        if(!atomic_load_explicit(&m->stopped,memory_order_acquire))stop_audio(m,s);
        return SP_SYNTH_STOCK_OK;
    }
    unsigned phase=atomic_load_explicit(&m->phase,memory_order_acquire);
    int consume=phase==SP_AUDIO_READY && (!block || block->frames!=0);
    uint32_t start=atomic_load_explicit(&m->sample_cursor,memory_order_relaxed);
    SpSynthStockResult result=SP_SYNTH_STOCK_OK;
    if(m->timed) {
        if(!block || (block->frames && block->frames!=SP_AUDIO_TIMED_FRAMES))result=SP_SYNTH_STOCK_INVALID_ARGUMENT;
        else if(consume) {
            uint32_t distance=m->target_sample-start;
            if(distance && distance<=SP_AUDIO_MAX_LOOKAHEAD && distance%SP_AUDIO_TIMED_FRAMES==0)consume=0;
            else if(distance)result=SP_SYNTH_STOCK_DEADLINE_MISSED;
        }
    }
    if(result==SP_SYNTH_STOCK_OK && !sp_p6_record_audio_v552_shadow_allowed(m,s,consume))result=SP_SYNTH_STOCK_INVALID_ARGUMENT;
    if(result==SP_SYNTH_STOCK_OK)result=sp_synth_audio_mix_stock(s,consume?&m->batch:0,block,scratch);
    if(m->timed && result==SP_SYNTH_STOCK_OK && block && block->frames)
        atomic_store_explicit(&m->sample_cursor,start+SP_AUDIO_TIMED_FRAMES,memory_order_release);
    if(consume) {
        m->completion=(SpAudioCompletion){.sequence=m->batch.sequence,.result=result,
            .quiescent=result==SP_SYNTH_STOCK_OK && sp_synth_engine_quiescent(&s->engine),
            .sample_end=m->timed?start+SP_AUDIO_TIMED_FRAMES:0};
        atomic_store_explicit(&m->phase,SP_AUDIO_DONE,memory_order_release);
    }
    if(result!=SP_SYNTH_STOCK_OK)stop_audio(m,s);
    return result;
}
