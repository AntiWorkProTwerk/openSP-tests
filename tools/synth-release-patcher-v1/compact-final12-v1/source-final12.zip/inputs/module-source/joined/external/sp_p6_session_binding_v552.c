#include "sp_p6_session_binding_v552.h"
#include "sp_p6_production_join.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_joint_v552.h"
#include "sp_p6_menu.h"
#include <limits.h>

SpP6SessionBindingV552 sp_p6_session_binding_v552;
extern int sp_p6_record_direct_destination_offered(void *,uint32_t,uint32_t);
_Static_assert(sizeof(SpSynthSessionV552)==3824,"Sealed permanent session ABI");
_Static_assert(sizeof(SpP6SessionBindingV552)<=256,"Existing reservation spare");
#define value(a) atomic_load_explicit((a),memory_order_acquire)
static uint32_t rd(uint32_t a) { return *(volatile const uint32_t *)(uintptr_t)a; }
static uint32_t task(void) {
    uint32_t i,p,b,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));
    __asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(b));
    __asm__ volatile("mrs %0,faultmask":"=r"(f));
    if(i || p || b || f || rd(0x202BBBF8) || rd(0x80245764))return 0;
    return ((uint32_t (*)(void))(uintptr_t)0x800D3163)();
}
static int panel(void) {
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    uint32_t id=task();
    void *page=atomic_load_explicit(&m->active_page,memory_order_acquire);
    return sp_p6_production_cold_started() && id>=1 && id<=32 &&
        id==m->task_id && id==rd(0x8300A3E8) && value(&m->ready)==1 &&
        !value(&m->terminal) && value(&m->phase)==SP_PREVIEW_NATIVE_ACTIVE &&
        !value(&m->entry.fault) && !m->entry.sample_depth &&
        page && (uintptr_t)page==rd(0x80CFD4FC) &&
        *(volatile const uint32_t *)page==(uintptr_t)(m->primary+2);
}
void sp_p6_session_binding_v552_panel(void) {
    SpP6SessionBindingV552 *o=&sp_p6_session_binding_v552;
    if(!panel() || value(&o->fault) || sp_synth_preview_native_v552.entry.dispatch_depth)return;
    uint32_t phase=value(&o->phase);
    if(phase==SP_P6_SB_PREPARED)return;
    if(phase!=SP_P6_SB_EMPTY)return;
    o->task=task();
    atomic_store_explicit(&o->phase,SP_P6_SB_PREPARING,memory_order_release);
    /* Software origin only. This config asserts no simultaneous physical
     * tick/sample anchor, pad ownership or render deadline. */
    const SpSynthDeferredStartupConfig config={0,4,0x50465342,0,48000,128};
    int result=sp_synth_session_v552_prepare_deferred(&sp_p6_production_session,&config);
    o->prepare_result=result;
    if(result) {
        atomic_fetch_or_explicit(&o->fault,1,memory_order_release);
        atomic_store_explicit(&o->phase,SP_P6_SB_FAILED,memory_order_release);
        return;
    }
    /* Initial callback-relative native test, before any RECORD intent. */
    o->settings=(SpP6PhraseSettings){SP_P6_SOURCE_SYNTH_ONLY,SP_P6_PHRASE_MANUAL,
        4,0,0,0,1,SP_P6_PHRASE_ALIGN_CALLBACK};
    atomic_store_explicit(&o->blocked,SP_P6_SB_CONTROL_CLOCK|SP_P6_SB_BACKEND|
        SP_P6_SB_DOWNBEAT|SP_P6_SB_RETIREMENT|SP_P6_SB_NATIVE_SERVICE,memory_order_relaxed);
    atomic_store_explicit(&o->phase,SP_P6_SB_PREPARED,memory_order_release);
}
/* Initial capture needs an empty lease destination before the later held-
 * take chooser exists. Inspect the configured pad, then this bank only. The
 * START gate and SAVE backend recheck the selected logical marker and cache. */
static int intent_destination(uint32_t project,uint32_t bank,uint32_t pad,
    SpP6EmptyPadSnapshotV552 *out) {
    if(bank>=10 || pad<1 || pad>16 ||
       rd(UINT32_C(0x82E2CD08)+172u*(bank*16u+pad-1u)+208u) ||
       !sp_p6_pattern_v552_empty_pad(bank,pad,out))return 0;
    return out->project==project && !out->channels && !out->cache_busy;
}
int sp_p6_session_binding_v552_record_choose(void *page,uint32_t bank,uint32_t pad) {
    SpP6SessionBindingV552 *o=&sp_p6_session_binding_v552;
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(!panel() || !sp_p6_record_direct_destination_offered(page,bank,pad) ||
       page!=atomic_load_explicit(&m->active_page,memory_order_acquire) ||
       sp_p6_menu.view.page!=SP_P6_RECORD || value(&o->phase)!=SP_P6_SB_PREPARED ||
       value(&o->fault) || task()!=o->task)return 0;
    uint32_t repeat=value(&o->pending);
    if(repeat && (repeat!=o->sequence || o->visit!=m->voice_used || o->page!=(uintptr_t)page))return 0;
    if(!repeat && o->sequence==UINT32_MAX) {
        atomic_fetch_or_explicit(&o->fault,2,memory_order_release);return 0;
    }
    SpP6PatternSnapshotV552 pattern;
    SpP6EmptyPadSnapshotV552 destination;
    if(!sp_p6_pattern_v552_snapshot(&pattern)) {
        atomic_fetch_or_explicit(&o->blocked,SP_P6_SB_DESTINATION,memory_order_release);return 0;
    }
    if((repeat && pattern.project!=o->pattern.project) ||
       !intent_destination(pattern.project,bank,pad,&destination)) {
        atomic_fetch_or_explicit(&o->blocked,SP_P6_SB_DESTINATION,memory_order_release);return 0;
    }
    o->settings.destination_bank=bank;o->settings.destination_pad=pad;
    o->pattern=pattern;o->destination=destination;
    o->visit=m->voice_used;o->page=(uint32_t)(uintptr_t)page;
    /* This sequence identifies a UI intent only. The native BEGIN owner alone
     * owns take_token and last_token. No SpAppRequest is dequeued or fabricated. */
    if(!repeat)++o->sequence;
    atomic_fetch_and_explicit(&o->blocked,~SP_P6_SB_DESTINATION,memory_order_relaxed);
    atomic_store_explicit(&o->pending,o->sequence,memory_order_release);
    return 1;
}
void sp_p6_session_binding_v552_smpl(void) {
    SpP6SessionBindingV552 *o=&sp_p6_session_binding_v552;
    if(!sp_p6_record_context_v552_current(1) || value(&o->phase)!=SP_P6_SB_PREPARED ||
       value(&o->fault) || !value(&o->pending))return;
    if(value(&sp_synth_preview_native_v552.phase)!=SP_PREVIEW_NATIVE_ACTIVE ||
       sp_synth_preview_native_v552.voice_used!=o->visit ||
       (uintptr_t)atomic_load_explicit(&sp_synth_preview_native_v552.active_page,memory_order_acquire)!=o->page) {
        atomic_fetch_or_explicit(&o->blocked,SP_P6_SB_RETIREMENT,memory_order_release);return;
    }
    SpP6ClockReceiptV552 clock;
    if(sp_p6_record_joint_v552_read(&clock,0) &&
       (clock.flags&SP_P6_CLOCK_DOWNBEAT) && clock.project==o->pattern.project &&
       clock.tempo100==o->pattern.tempo100) {
        o->clock=clock;
        atomic_fetch_and_explicit(&o->blocked,~SP_P6_SB_DOWNBEAT,memory_order_release);
    } else {
        atomic_fetch_or_explicit(&o->blocked,SP_P6_SB_DOWNBEAT,memory_order_release);
    }
    /* A source-owned downbeat is an observation. The deferred full session has
     * no control cutoff/audio batch/backend/request/retirement attachment.
     * Preserve the intent and every native token/file/producer obligation. */
}
uint32_t sp_p6_session_binding_v552_admission(void) { return 0; }
SpSynthSessionV552 *sp_p6_session_binding_v552_session(void) { return 0; }
const SpAppRequest *sp_p6_session_binding_v552_request(void) { return 0; }
