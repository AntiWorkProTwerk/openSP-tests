#define sp_synth_input_init sp_p6_record_input_v552_init
#define sp_synth_input_enable sp_p6_record_input_v552_enable
#define sp_synth_input_route sp_p6_record_input_v552_route
#include "sp_synth_session_v552.h"
#include "sp_synth_memory_v552.h"
#include "sp_synth_clock_handoff_v552.h"
#include "sp_synth_preview.h"
#include <stddef.h>

_Static_assert(sizeof(void *)==4,"Pinned v5.52 session requires ARM32");
static int valid(const void *p,size_t size,size_t alignment) {
    uintptr_t a=(uintptr_t)p;
    return a && a%alignment==0 && a<=UINTPTR_MAX-size;
}
static int ready(SpSynthSessionV552 *s) {
    return s && atomic_load_explicit(&s->ready,memory_order_acquire)==1;
}
static int prepare(SpSynthSessionV552 *s,const void *c,int deferred) {
    size_t config_size=deferred?sizeof(SpSynthDeferredStartupConfig):sizeof(SpSynthStartupConfig);
    if(!valid(s,sizeof(*s),_Alignof(SpSynthSessionV552)) ||
       !valid(c,config_size,_Alignof(SpSynthStartupConfig)))return -1010;
    uintptr_t a=(uintptr_t)s,b=(uintptr_t)c;
    if((a<b+config_size && b<a+sizeof(*s)) ||
       (a<SP_SYNTH_V552_POOL_END && a+sizeof(*s)>SP_SYNTH_V552_POOL_BEGIN))return -1010;
    const unsigned char *bytes=(const unsigned char *)s;
    for(size_t i=0;i<sizeof(*s);++i)if(bytes[i])return -1010;
    int result=deferred?sp_synth_startup_v552_prepare_deferred(&s->startup,c):
        sp_synth_startup_v552_prepare(&s->startup,c);
    if(result)return result;
    sp_synth_backend_link_init(&s->backend);
    sp_synth_view_exchange_init(&s->views);
    /* Deferred cold init already established these shared atomic objects.
     * Cancellation can acquire ready while the private fields are prepared. */
    atomic_store_explicit(&s->ready,0,memory_order_relaxed);
    atomic_store_explicit(&s->terminal,0,memory_order_relaxed);
    atomic_store_explicit(&s->control_ready,0,memory_order_relaxed);
    /* The legacy runtime page member stays unused. Its view/plot are private
     * control-side sources; the UI owns the separate page.frontend copies. */
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    result=sp_synth_startup_v552_pin(&s->startup);
    if(result)return result;
    if(sp_synth_view_exchange_publish(&s->views,&r->view,r->plot)!=1) {
        atomic_store_explicit(&s->terminal,1,memory_order_relaxed);
        return -1010;
    }
    if(!deferred) {
        atomic_store_explicit(&s->control_ready,1,memory_order_relaxed);
        atomic_store_explicit(&s->ready,1,memory_order_release);
    }
    return 0;
}
int sp_synth_session_v552_prepare(SpSynthSessionV552 *s,const SpSynthStartupConfig *c) {
    return prepare(s,c,0);
}
int sp_synth_session_v552_prepare_deferred(SpSynthSessionV552 *s,const SpSynthDeferredStartupConfig *c) {
    return prepare(s,c,1);
}
static int control_owner(SpSynthSessionV552 *s) {
    return ready(s) && atomic_load_explicit(&s->control_ready,memory_order_acquire)==1 &&
        (!s->clock_handoff || sp_synth_clock_handoff_v552_control_owner(s->clock_handoff));
}
static int control_access(SpSynthSessionV552 *s) {
    if(!control_owner(s))return 0;
    if(s->clock_handoff && !sp_synth_clock_handoff_v552_check(s->clock_handoff))
        sp_synth_session_v552_stop(s);
    return 1;
}
void sp_synth_session_v552_stop(SpSynthSessionV552 *s) {
    if(!ready(s))return;
    if(s->clock_handoff)
        atomic_store_explicit(&s->clock_handoff->phase,SP_CLOCK_TERMINAL,memory_order_release);
    atomic_store_explicit(&s->terminal,1,memory_order_release);
    sp_synth_audio_mailbox_stop(&s->startup.memory.storage->mailbox);
    atomic_store_explicit(&s->backend.responses.stopped,1,memory_order_release);
    sp_synth_view_exchange_stop(&s->views);
}
int sp_synth_session_v552_register_ui(SpSynthSessionV552 *s) {
    if(!control_access(s) || atomic_load_explicit(&s->terminal,memory_order_acquire))return 0;
    if(s->ui_registered)return 1;
    if(!sp_synth_page_binding_v552_init(&s->page,&s->views) ||
       !sp_synth_factory_v552_init(&s->page)) {
        sp_synth_session_v552_stop(s);return 0;
    }
    s->ui_registered=1;
    return 1;
}
static void disable_input(SpSynthRuntimeStorage *r) {
    /* Only the control owner touches this state. Keep captured/physical bits
     * until their real releases; the terminal audio path supplies the panic. */
    (void)sp_synth_input_enable(&r->input,0,r->input.shift,&r->input_batch);
}
int sp_synth_session_v552_enable(SpSynthSessionV552 *s,int enabled,int shift) {
    if(!control_access(s))return 0;
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    if(atomic_load_explicit(&s->terminal,memory_order_acquire)) {
        disable_input(r);return 0;
    }
    if(!sp_synth_input_enable(&r->input,enabled,shift,&r->input_batch))return 0;
    if(!sp_synth_control_queue_push(&r->controls,&r->mailbox,&r->input_batch)) {
        sp_synth_session_v552_stop(s);disable_input(r);return 0;
    }
    return 1;
}
int sp_synth_session_v552_route(SpSynthSessionV552 *s,const sp_ui_event *event) {
    if(!control_access(s))return 0;
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    int terminal=atomic_load_explicit(&s->terminal,memory_order_acquire)!=0;
    if(terminal)disable_input(r);
    int consumed=sp_synth_input_route(&r->input,event,&r->input_batch);
    if(!terminal && !sp_synth_control_queue_push(&r->controls,&r->mailbox,&r->input_batch)) {
        sp_synth_session_v552_stop(s);disable_input(r);
    }
    return consumed;
}
SpControlService sp_synth_session_v552_control(SpSynthSessionV552 *s,uint32_t target) {
    if(!control_access(s))return SP_CONTROL_STOPPED;
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    if(atomic_load_explicit(&s->terminal,memory_order_acquire)) {
        disable_input(r);return SP_CONTROL_STOPPED;
    }
    SpControlService result=sp_synth_backend_link_service(&s->backend,
        &r->controls,&r->midi,&r->mailbox,&r->controller,target);
    if(result==SP_CONTROL_STOPPED) {sp_synth_session_v552_stop(s);disable_input(r);return result;}
    sp_synth_app_make_view(&r->controller,&r->view,r->plot);
    if(sp_synth_view_exchange_publish(&s->views,&r->view,r->plot)<0) {
        sp_synth_session_v552_stop(s);return SP_CONTROL_STOPPED;
    }
    return result;
}
SpSynthStockResult sp_synth_session_v552_mix(SpSynthSessionV552 *s,
    const SpSynthStockBlock *block) {
    if(!ready(s))return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    SpSynthStockResult result=sp_synth_audio_mailbox_mix(&r->mailbox,&r->audio,
        block,&r->audio_scratch);
    if(result!=SP_SYNTH_STOCK_OK)sp_synth_session_v552_stop(s);
    return result;
}
