#include "guard.h"
#include "sp_p6_transaction_ingress_v552.h"
#include "sp_p6_record_mutation_closure_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_record_token_v552.h"
#include "sp_p6_record_ingress_alias_v552.h"
#include "sp_p6_pattern_clock_v552.h"
typedef uint32_t (*Call)(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_tx_packet_original(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_tx_load_original(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_tx_dequeue_original(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_synth_capture_timed_v552_dispatch(uint32_t,uint32_t,uint32_t,uint32_t);
/* Private execution identity. UI visits have no reset API. */
static uint32_t executing;
static uint32_t rd(uint32_t a){return *(volatile const uint32_t *)(uintptr_t)a;}
static uint32_t task(void){uint32_t i,p,b,f;
    __asm__ volatile("mrs %0, ipsr":"=r"(i));__asm__ volatile("mrs %0, primask":"=r"(p));
    __asm__ volatile("mrs %0, basepri":"=r"(b));__asm__ volatile("mrs %0, faultmask":"=r"(f));
    if(i||p||b||f||rd(0x202BBBF8u)||rd(0x80245764u))return 0;
    uint32_t t=((uint32_t (*)(void))(uintptr_t)0x800D3163u)();return t<=32?t:0;
}
static int source_owner(uint32_t current){
    return current && sp_p6_record_context_v552_registered() &&
        current==sp_p6_record_contexts_v552.smpl_task &&
        rd(0x202ACD00u)==0x8022D244u && rd(0x202ACD04u)==current;
}
uint32_t sp_p6_tx_v552_quiescent(void){return !executing && !sp_p6_record_project_gate_v552.active &&
    !sp_p6_record_project_gate_v552.fault && sp_p6_tx_v552_coverage();}
uint32_t sp_p6_tx_v552_admission(void){return 0;}
/* Called at the existing clock entry, with its actual native link register. */
uint32_t sp_p6_tx_v552_nested(uint32_t operation,uint32_t link){
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    uint32_t current=sp_p6_record_producer_v552.capture?task():0;
    if(!g->active || g->task!=current || !executing || !sp_p6_tx_v552_coverage()){
        g->fault|=256;return SP_P6_PROJECT_DEFERRED;
    }
    if(operation==SP_P6_MC_RESET && executing==0x1F9u && link==0x8004F013u){
        uint32_t watched=sp_p6_clock_v552_mutation_enter(14,0);
        uint32_t result=sp_p6_mc_v552_reset_original();sp_p6_clock_v552_mutation_leave(watched);return result;
    }
    if(operation==SP_P6_MC_INITIALIZE && (executing==SP_P6_TX_LOAD || executing==3u) && link==0x800554DFu){
        uint32_t watched=sp_p6_clock_v552_mutation_enter(15,0);
        uint32_t result=sp_p6_mc_v552_initialize_original();sp_p6_clock_v552_mutation_leave(watched);return result;
    }
    g->fault|=256;return SP_P6_PROJECT_DEFERRED;
}
/* No caller-supplied token or readiness value enters this API. */
uint32_t sp_p6_tx_v552_original(SpP6ProjectCommandV552 c){
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    uint32_t current=sp_p6_record_producer_v552.capture?task():0;
    uint32_t kind=sp_p6_tx_v552_command(c);
    if(executing || !g->active || g->task!=c.task || current!=c.task || !kind){
        g->fault|=256;return SP_P6_PROJECT_DEFERRED;
    }
    uint32_t packet[4]={c.object,c.operation,c.project,c.selector};
    executing=kind==2?SP_P6_TX_LOAD:((c.object>>16)&0xFFFFu);
    uint32_t result=kind==2?sp_p6_tx_load_original(0,0,0,0):
        sp_p6_tx_packet_original((uint32_t)(uintptr_t)packet,0,0,0);
    executing=0;return result;
}
extern uint32_t sp_p6_tx_gate_request(SpP6ProjectCommandV552);
uint32_t sp_p6_tx_v552_packet(uint32_t a,uint32_t b,uint32_t c,uint32_t d){
    if(a<0x80000000u || a>0x84000000u-16u || (a&3u)){
        sp_p6_record_project_gate_v552.fault|=256;return SP_P6_PROJECT_DEFERRED;
    }
    uint32_t head=rd(a),command=(head>>16)&0xFFFFu;
    if((head&255u)==0xA4u && command!=3u && command!=0x1F9u && sp_p6_mf_v552_command(command)) {
        if(!sp_p6_mf_v552_enter(1))return SP_P6_PROJECT_DEFERRED;
        uint32_t result=sp_synth_capture_timed_v552_dispatch(a,b,c,d);
        sp_p6_mf_v552_leave();return result;
    }
    if((head&255u)!=0xA4u || (command!=0x1F9u && command!=3u))
        return sp_synth_capture_timed_v552_dispatch(a,b,c,d);
    return sp_p6_tx_gate_request((SpP6ProjectCommandV552){head,rd(a+4),rd(a+8),rd(a+12),0,0});
}
uint32_t sp_p6_tx_v552_load(uint32_t a,uint32_t b,uint32_t c,uint32_t d){
    uint32_t link;__asm__ volatile("mov %0, lr":"=r"(link));
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    uint32_t current=sp_p6_record_producer_v552.capture?task():0;
    if(executing==3u && g->active && g->task==current && link==0x8004E1AFu)
        return sp_p6_tx_load_original(a,b,c,d);
    return sp_p6_tx_gate_request((SpP6ProjectCommandV552){0,SP_P6_TX_LOAD,0,0,0,0});
}
extern uint32_t sp_p6_tx_gate_service(uint32_t);
uint32_t sp_p6_tx_v552_service(void){
    uint32_t current=task();return source_owner(current)?sp_p6_tx_gate_service(current):0;
}
uint32_t sp_p6_tx_v552_dequeue(uint32_t a,uint32_t b,uint32_t c,uint32_t d){
    /* Native SMPL action2 stops before taking the next packet. Sample READ and
     * pattern/audio queues do not use this primary mutation dequeue. */
    if(sp_p6_record_project_gate_v552.count){
        if(!sp_p6_tx_v552_service() || sp_p6_record_project_gate_v552.count)return 0;
    }
    return sp_p6_tx_dequeue_original(a,b,c,d);
}
uint32_t sp_p6_tx_v552_wake(void){
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    if(!g->count || o->held || o->fault || g->fault || !sp_p6_ia_v552_quiescent() || !sp_p6_record_context_v552_current(1))return 0;
    SpP6ProjectCommandV552 command=g->commands[g->head];
    if(!sp_p6_tx_v552_command(command) ||
       command.task!=sp_p6_record_contexts_v552.smpl_task || !command.token || command.token>o->last_retired)return 0;
    /* Native initializer 80194A98 maps event32 to action2. A post never
     * removes the packet or acknowledges the retained mutation. */
    uint32_t result=((Call)(uintptr_t)0x800D30A5u)(0x202ACD00u,32,0,0);
    return result==1?1:0;
}
