#include "sp_synth_backend_inbox.h"
#include <string.h>

_Static_assert(ATOMIC_INT_LOCK_FREE==2,"Backend inbox requires lock-free atomics");
void sp_synth_backend_inbox_init(SpSynthBackendInbox *b) {
    if(!b)return;
    memset(&b->completion,0,sizeof(b->completion));
    memset(&b->preset,0,sizeof(b->preset));atomic_init(&b->phase,0);atomic_init(&b->stopped,0);
}
int sp_synth_backend_inbox_publish(SpSynthBackendInbox *b,const SpAppCompletion *c) {
    if(!b || !c || atomic_load_explicit(&b->stopped,memory_order_acquire) ||
       atomic_load_explicit(&b->phase,memory_order_acquire))return 0;
    b->completion=*c;
    if(c->preset) {b->preset=*c->preset;b->completion.preset=&b->preset;}
    atomic_store_explicit(&b->phase,1,memory_order_release);return 1;
}
SpControlService sp_synth_backend_inbox_service(SpSynthBackendInbox *b,
    SpSynthControlQueue *q,SpSynthMidiQueue *midi,SpSynthAudioMailbox *m,
    SpSynthApp *a,uint32_t target) {
    return sp_synth_backend_inbox_service_observed(b,q,midi,m,a,target,0,0);
}
SpControlService sp_synth_backend_inbox_service_observed(SpSynthBackendInbox *b,
    SpSynthControlQueue *q,SpSynthMidiQueue *midi,SpSynthAudioMailbox *m,
    SpSynthApp *a,uint32_t target,const SpAppCaptureProgress *progress,
    SpBackendDelivery *progress_delivery) {
    return sp_synth_backend_inbox_service_capture(b,q,midi,m,a,target,progress,progress_delivery,0,0);
}
SpControlService sp_synth_backend_inbox_service_capture(SpSynthBackendInbox *b,
    SpSynthControlQueue *q,SpSynthMidiQueue *midi,SpSynthAudioMailbox *m,
    SpSynthApp *a,uint32_t target,const SpAppCaptureProgress *progress,
    SpBackendDelivery *progress_delivery,const SpAppCaptureCancelCompletion *cancel,
    SpBackendDelivery *cancel_delivery) {
    if(progress_delivery)*progress_delivery=SP_BACKEND_WAITING;
    if(cancel_delivery)*cancel_delivery=SP_BACKEND_WAITING;
    if(!b || atomic_load_explicit(&b->stopped,memory_order_acquire)) {
        if(q)q->faulted=1;
        sp_synth_audio_mailbox_stop(m);return SP_CONTROL_STOPPED;
    }
    /* Only this consumer can release READY; producer cannot modify its payload. */
    unsigned ready=atomic_load_explicit(&b->phase,memory_order_acquire);
    SpBackendDelivery delivery=SP_BACKEND_WAITING;
    SpControlService result=sp_synth_control_queue_service_capture(q,midi,m,a,target,
        ready?&b->completion:0,&delivery,progress,progress_delivery,cancel,cancel_delivery);
    if(result==SP_CONTROL_STOPPED)atomic_store_explicit(&b->stopped,1,memory_order_release);
    else if(ready && delivery!=SP_BACKEND_WAITING)
        atomic_store_explicit(&b->phase,0,memory_order_release);
    return result;
}
