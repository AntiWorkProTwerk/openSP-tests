#include "guard.h"
#include "sp_p6_record_project_v552.h"
#include "sp_p6_record_context_v552.h"
#include <stddef.h>
#define PARAM 0x82E2CD08u
#define META 0x82E495E4u
#define POOL 0x80B08CB8u
#define CACHE 0x82E111C8u
#define TABLE 0x80B5F3B4u
typedef uint32_t (*Native)(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_rp_load_original_v552(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_rp_loop_original_v552(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_rp_metadata_original_v552(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_rp_prefetch_original_v552(uint32_t,uint32_t,uint32_t,uint32_t);
typedef struct {
    uint32_t generation,valid,fault,active,task,project,target;
    uint32_t metadata_seen,metadata_ok,loop_seen,loop_returned;
    uint32_t prefetch_object,prefetch_slot,prefetch_loaded,seen[5];
} ProjectObservation;
static ProjectObservation observation;
_Static_assert(sizeof(ProjectObservation)==76,"Native project observation budget");
static uint32_t rd(uint32_t p) { return *(volatile const uint32_t *)(uintptr_t)p; }
static uint8_t byte(uint32_t p) { return *(volatile const uint8_t *)(uintptr_t)p; }
static uint32_t native(uint32_t p,uint32_t a,uint32_t b,uint32_t c,uint32_t d) { return ((Native)(uintptr_t)(p|1u))(a,b,c,d); }
static uint32_t context(void) {
    uint32_t ipsr,basepri,primask,faultmask;
    __asm__ volatile("mrs %0, ipsr":"=r"(ipsr));
    __asm__ volatile("mrs %0, basepri":"=r"(basepri));
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    if(ipsr || basepri || primask || faultmask || rd(0x202BBBF8u) || (int32_t)rd(0x80245764u)>0)return 0;
    uint32_t task=native(0x800D3162u,0,0,0,0);
    return task>=1 && task<=32?task:0;
}
static uint32_t mask(void) { uint32_t p;__asm__ volatile("mrs %0, primask\n cpsid i":"=r"(p)::"memory");return p; }
static void unmask(uint32_t p) { __asm__ volatile("msr primask, %0"::"r"(p):"memory"); }
static uint32_t project(void) { return native(0x800E1190u,0,0,0,0); }
static int storage(void) { return native(0x800D94D8u,0x82E01144u,132,0,0)==0; }
static void failed(void) { observation.valid=0;observation.fault=1; }
static int bit(const uint32_t *bits,uint32_t slot) { return (bits[slot/32]>>(slot%32))&1u; }
static int qualifies(uint32_t slot) {
    uint32_t p=META+36*slot;
    int64_t length=(int64_t)(int32_t)rd(p+28)-(int32_t)rd(p+24);
    return length>=(rd(p+8)==1?2000:4000);
}
static int object_ready(uint32_t object,uint32_t slot) {
    if(object<POOL || object>=POOL+161*104 || (object-POOL)%104 || slot>=160)return 0;
    uint32_t index=(object-POOL)/104,p=META+36*slot;
    int32_t first=(int32_t)rd(p+24),last=(int32_t)rd(p+28);
    int64_t length=(int64_t)last-first;
    if(length<=0 || !qualifies(slot))return 0;
    uint32_t prefix=length>81920?81920:(uint32_t)length;
    return byte(object)==1 && byte(object+1)==1 && rd(object+4)==slot && byte(object+100)==1 &&
        rd(object+84)==prefix && rd(object+80)==0x80D547A0u+81920*index &&
        rd(object+8)==(uint32_t)first && rd(object+12)==(first<0?UINT32_MAX:0) &&
        rd(object+64)==(uint32_t)first && rd(object+68)==(first<0?UINT32_MAX:0) &&
        rd(object+72)==(uint32_t)length && rd(object+76)==(uint32_t)((uint64_t)length>>32);
}
static int all_ready(void) {
    uint32_t found[5];for(unsigned i=0;i<5;i++)*(volatile uint32_t *)&found[i]=0;
    for(unsigned i=0;i<161;i++) {
        uint32_t object=POOL+104*i,slot=rd(object+4);
        if(!byte(object) || slot>=160 || !qualifies(slot))continue;
        if(bit(found,slot) || !bit(observation.seen,slot) || !object_ready(object,slot))return 0;
        found[slot/32]|=1u<<(slot%32);
    }
    for(unsigned slot=0;slot<160;slot++) {
        if(qualifies(slot)!=bit(found,slot))return 0;
        if(!qualifies(slot))continue;
        unsigned valid=0;
        for(unsigned n=0;n<38;n++) {
            uint32_t row=CACHE+304*slot+8*n,fd=rd(row+4);
            if(byte(row))return 0; /* Native borrows have returned. */
            if(fd==UINT32_MAX)continue;
            if(!fd || fd>=1024)return 0;
            uint32_t file=rd(TABLE+4*fd);
            if(file<0x80000000u || file>=0x84000000u || (file&3u) || !(rd(file)&1u))return 0;
            valid++;
        }
        if(!valid)return 0;
    }
    return 1;
}
static int voices_reset(void) {
    for(unsigned n=0;n<32;n++) {
        uint32_t o=0x202AE1A0u+88*n;
        if(rd(o) || rd(o+40)!=n || rd(o+4)!=0x80B08C34u+4*n || rd(0x80B08C34u+4*n) ||
           rd(o+44)!=UINT32_MAX || rd(o+64)!=UINT32_MAX || rd(o+68)!=UINT32_MAX ||
           byte(o+84) || byte(o+85))return 0;
    }
    return rd(0x82E0E71Cu+64)==180187 && rd(0x82E0E71Cu+68)==0 &&
        !byte(0x80591801u) && !byte(0x80591802u);
}
uint32_t sp_p6_record_project_v552_observed_generation(void) {
    if(!observation.valid || observation.active || observation.fault || !sp_p6_record_context_v552_current(1) ||
       project()!=observation.project || !storage())return 0;
    uint32_t p=mask();int ready=project()==observation.project && storage() && all_ready();
    uint32_t result=ready?observation.generation:0;unmask(p);return result;
}
static uint32_t mf_load_body(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    uint32_t task=context(),current=project();int root=0;
    uint32_t p=mask();observation.valid=0;
    if(a==0x80591800u && task && current<128 && storage() && !observation.active && observation.generation<UINT32_MAX) {
        observation.generation++;observation.fault=0;observation.active=1;observation.task=task;
        observation.project=current;observation.target=b;observation.metadata_seen=0;observation.metadata_ok=0;
        observation.loop_seen=0;observation.loop_returned=0;observation.prefetch_object=0;
        for(unsigned i=0;i<5;i++)observation.seen[i]=0;
        root=1;
    } else failed();
    unmask(p);
    uint32_t result=sp_p6_rp_load_original_v552(a,b,c,d);
    task=context();current=project();int media=storage();p=mask();
    if(root) {
        if(!observation.fault && task==observation.task && current==observation.project && media &&
           (observation.target>=128 || observation.target==current) && observation.metadata_seen==1 &&
           observation.metadata_ok && observation.loop_seen==1 && observation.loop_returned &&
           !observation.prefetch_object && all_ready() && voices_reset())observation.valid=1;
        else failed();
        observation.active=0;
    }
    unmask(p);return result;
}
static uint32_t mf_loop_body(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    uint32_t task=context(),p=mask();
    int selected=observation.active && task==observation.task && !observation.loop_seen;
    if(selected)observation.loop_seen=1;else failed();unmask(p);
    uint32_t result=sp_p6_rp_loop_original_v552(a,b,c,d);task=context();p=mask();
    if(selected && task==observation.task && observation.active)observation.loop_returned=1;else failed();
    unmask(p);return result;
}
static uint32_t mf_metadata_body(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    uint32_t task=context(),current=project(),p=mask();
    int selected=observation.active && task==observation.task && observation.loop_seen &&
        !observation.loop_returned && !observation.metadata_seen && a==PARAM && !b && current==observation.project;
    observation.valid=0;if(selected)observation.metadata_seen=1;else failed();unmask(p);
    uint32_t result=sp_p6_rp_metadata_original_v552(a,b,c,d);task=context();current=project();p=mask();
    if(selected && task==observation.task && current==observation.project && observation.active && result==1)
        observation.metadata_ok=1;
    else failed();
    unmask(p);return result;
}
uint32_t sp_p6_record_project_v552_prefetch(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    uint32_t task=context(),p=mask();
    int selected=observation.active && task==observation.task && observation.loop_seen && !observation.loop_returned &&
        !observation.prefetch_object && a>=POOL && a<POOL+161*104 && !((a-POOL)%104);
    if(selected) {
        observation.prefetch_object=a;observation.prefetch_slot=rd(a+4);observation.prefetch_loaded=byte(a+1);
        if(observation.prefetch_slot>=160 || observation.prefetch_loaded)failed();
    } else failed();unmask(p);
    uint32_t result=sp_p6_rp_prefetch_original_v552(a,b,c,d);task=context();p=mask();
    uint32_t slot=observation.prefetch_slot;
    if(selected && !observation.fault && task==observation.task && observation.prefetch_object==a &&
       slot<160 && !bit(observation.seen,slot) && object_ready(a,slot))observation.seen[slot/32]|=1u<<(slot%32);
    else failed();
    if(selected)observation.prefetch_object=0;
    unmask(p);return result;
}

uint32_t sp_p6_record_project_v552_load(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    if(!sp_p6_mf_v552_enter(0))return 0;
    uint32_t result=mf_load_body(a,b,c,d);
    sp_p6_mf_v552_leave();return result;
}

uint32_t sp_p6_record_project_v552_loop(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    if(!sp_p6_mf_v552_enter(0))return 0;
    uint32_t result=mf_loop_body(a,b,c,d);
    sp_p6_mf_v552_leave();return result;
}

uint32_t sp_p6_record_project_v552_metadata(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    if(!sp_p6_mf_v552_enter(0))return 0;
    uint32_t result=mf_metadata_body(a,b,c,d);
    sp_p6_mf_v552_leave();return result;
}
