#include "sp_synth_bindings.h"
#include "sp_synth_audio_internal.h"
#include "sp_p6_record_rearm_v552.h"
#include <math.h>
#include <string.h>

/* Binding table implementation; edits happen on the serialized owner. */
int sp_app_parameter(SpSynthApp *a,unsigned id,unsigned value);
static void metadata(SpSynthApp *a) {
    a->ui.patch.token=a->edited.id;a->ui.patch.family=a->edited.category;
    a->ui.patch.favorite=a->edited.favorite;a->ui.patch.factory=(uint8_t)sp_synth_preset_is_factory(a->edited.id);
    memcpy(a->ui.patch.name,a->edited.name,sizeof(a->ui.patch.name));a->ui.patch.name[24]=0;
}
void sp_synth_app_panic(SpSynthApp *a) {
    if(!a)return;
    sp_app_audio_panic(a);memset(a->keys,0,sizeof(a->keys));
    memset(a->sustain,0,sizeof(a->sustain));a->event_count=0;a->ui.active_pads=0;
}
static int fault(SpSynthApp *a) {
    ++a->event_faults;sp_synth_app_panic(a);a->batch_failed=1;return 0;
}
static int capture_gated(const SpSynthApp *a) {
    return a->capture_cancel_state || a->capture_tail_state ||
        (a->ui.save_flags&SP_UI_SAVE_RECOVERY_REQUIRED) ||
        (a->ui.busy && a->ui.pending==SP_UI_CMD_CAPTURE_STOP);
}
static void capture_tail_clear(SpSynthApp *a) {
    a->capture_tail_state=a->capture_tail_sequence=0;
    a->capture_quiet_sequence=a->capture_quiet_sample=0;
    a->capture_tail_start_frames=0;
}
static void capture_tail_begin(SpSynthApp *a,int early);
int sp_synth_app_event_valid(const SpSynthEvent *e) {
    if(!e || e->type>SP_EVENT_NOTE_CANCEL || !isfinite(e->value) || e->offset>=SP_SYNTH_MAX_FRAMES)return 0;
    if(e->type==SP_EVENT_ALL_NOTES_OFF || e->type==SP_EVENT_ALL_SOUND_OFF)return e->channel<=16;
    if(e->type==SP_EVENT_TEMPO)return e->value>=20 && e->value<=300;
    if(e->type==SP_EVENT_PARAMETER) {
        SpSynthParamRange r;return sp_synth_param_range((SpSynthParam)e->parameter,&r) && e->value>=r.minimum && e->value<=r.maximum;
    }
    if(e->channel>=16 || ((e->type==SP_EVENT_NOTE_ON || e->type==SP_EVENT_NOTE_OFF || e->type==SP_EVENT_POLY_PRESSURE || e->type==SP_EVENT_NOTE_CANCEL) && e->note>127))return 0;
    return e->value>=(e->type==SP_EVENT_PITCH_BEND?-1.0f:0.0f) && e->value<=1;
}
static void scalar(SpSynthApp *a,const SpSynthEvent *e) {
    if(e->type==SP_EVENT_PITCH_BEND)a->bend[e->channel]=e->value;
    else if(e->type==SP_EVENT_PRESSURE)a->pressure[e->channel]=e->value;
    else if(e->type==SP_EVENT_MOD_WHEEL)a->wheel[e->channel]=e->value;
    else if(e->type==SP_EVENT_TEMPO){a->capture.tempo_bpm=e->value;a->bindings_dirty=1;}
    else if(e->type==SP_EVENT_PARAMETER) {
        sp_synth_patch_set_param(&a->edited.patch,(SpSynthParam)e->parameter,e->value);
        a->bindings_dirty=1;
        a->ui.dirty=1;if(a->ui.revision!=UINT32_MAX)++a->ui.revision;
    }
}
static int send(SpSynthApp *a,const SpSynthEvent *input,unsigned source,unsigned identity,int immediate) {
    if(!sp_synth_app_event_valid(input) || a->batch_failed)return fault(a);
    SpSynthEvent e=*input;
    if(!immediate && (a->event_count>=SP_SYNTH_MAX_EVENTS ||
       (a->event_count && e.offset<a->events[a->event_count-1].offset)))return fault(a);
    if(e.type==SP_EVENT_NOTE_ON && e.value==0)e.type=SP_EVENT_NOTE_OFF;
    if(capture_gated(a) && (e.type==SP_EVENT_NOTE_ON ||
       (e.type==SP_EVENT_SUSTAIN && e.value>=.5f)))return 1;
    if(e.type==SP_EVENT_NOTE_ON) {
        if(identity)for(unsigned i=0;i<SP_APP_KEY_CAPACITY;++i) {
            SpAppKey *k=&a->keys[i];
            if(k->active && k->source==source && k->channel==e.channel && k->identity==identity) {
                /* Reuse the engine identity so replacement releases its old voice. */
                e.parameter=k->tag;k->note=(uint8_t)e.note;k->held=1;k->velocity=e.value;goto queued;
            }
        }
        unsigned slot=SP_APP_KEY_CAPACITY;
        for(unsigned i=0;i<SP_APP_KEY_CAPACITY;++i)if(!a->keys[i].active){slot=i;break;}
        if(slot==SP_APP_KEY_CAPACITY || a->next_tag==UINT32_MAX)return fault(a);
        e.parameter=++a->next_tag;
        a->keys[slot]=(SpAppKey){e.parameter,identity,1,1,(uint8_t)source,(uint8_t)e.channel,(uint8_t)e.note,e.value,-1};
    } else if(e.type==SP_EVENT_NOTE_OFF || e.type==SP_EVENT_NOTE_CANCEL) {
        SpAppKey *chosen=0;
        for(unsigned i=0;i<SP_APP_KEY_CAPACITY;++i) {
            SpAppKey *k=&a->keys[i];
            if(k->active && (k->held || e.type==SP_EVENT_NOTE_CANCEL) && k->source==source && k->channel==e.channel && k->note==e.note &&
               (!identity || k->identity==identity) && (!chosen || k->tag<chosen->tag))chosen=k;
        }
        if(!chosen)return 1;
        e.parameter=chosen->tag;chosen->held=0;
        if(e.type==SP_EVENT_NOTE_CANCEL || !a->sustain[e.channel])chosen->active=0;
    } else if(e.type==SP_EVENT_SUSTAIN) {
        a->sustain[e.channel]=e.value>=.5f;
        if(!a->sustain[e.channel])for(unsigned i=0;i<SP_APP_KEY_CAPACITY;++i)
            if(a->keys[i].active && a->keys[i].channel==e.channel && !a->keys[i].held)a->keys[i].active=0;
    } else if(e.type==SP_EVENT_ALL_NOTES_OFF || e.type==SP_EVENT_ALL_SOUND_OFF) {
        for(unsigned i=0;i<SP_APP_KEY_CAPACITY;++i)
            if(e.channel==16 || a->keys[i].channel==e.channel)a->keys[i].active=0;
        for(unsigned c=0;c<16;++c)if(e.channel==16 || c==e.channel)a->sustain[c]=0;
        if(e.channel==16 || e.channel==a->pad_channel)a->ui.active_pads=0;
    } else if(e.type==SP_EVENT_POLY_PRESSURE) {
        for(unsigned i=0;i<SP_APP_KEY_CAPACITY;++i)
            if(a->keys[i].active && a->keys[i].channel==e.channel && a->keys[i].note==e.note)a->keys[i].pressure=e.value;
    }
queued:
    if(immediate) {
        e.offset=0;if(!sp_app_audio_control(a,&e))return fault(a);
        scalar(a,&e);
    } else a->events[a->event_count++]=e;
    return 1;
}
int sp_synth_app_input(SpSynthApp *a,const SpSynthEvent *e) {return a && sp_app_audio_can_control(a)?send(a,e,1,e?e->parameter:0,0):0;}
int sp_synth_app_pad_note(const SpSynthApp *a,uint16_t pad,uint8_t *note) {
    if(!a || !note || pad<1 || pad>16 || a->root>11 || a->scale>=SP_APP_SCALE_COUNT)return 0;
    static const uint8_t degrees[SP_APP_SCALE_COUNT][12]={
        {0,1,2,3,4,5,6,7,8,9,10,11},{0,2,4,5,7,9,11},{0,2,3,5,7,8,10},
        {0,2,3,5,7,9,10},{0,2,4,5,7,9,10},{0,2,4,7,9},{0,3,5,7,10}};
    static const uint8_t lengths[]={12,7,7,7,7,5,5};
    /* Stock-confirmed physical ordering: lower row, left to right, then up. */
    unsigned degree=(3u-(pad-1u)/4u)*4u+(pad-1u)%4u;
    int pitch=12*(a->ui.octave+1)+a->root+(int)(12*(degree/lengths[a->scale])+degrees[a->scale][degree%lengths[a->scale]]);
    if(pitch<0 || pitch>127)return 0;
    *note=(uint8_t)pitch;return 1;
}
void sp_app_release_pads(SpSynthApp *a) {
    /* Cancel pad identities without releasing another source's sustained notes. */
    for(unsigned i=0;i<SP_APP_KEY_CAPACITY;++i) {
        SpAppKey *k=&a->keys[i];if(!k->active || k->source!=0)continue;
        SpSynthEvent off={0,SP_EVENT_NOTE_CANCEL,k->channel,k->note,0,k->tag};
        sp_app_audio_control(a,&off);k->held=0;k->active=0;
    }
    a->ui.active_pads=0;
}
int sp_app_apply_patch(SpSynthApp *a,const SpPreset *p,int preserve_keys) {
    if(!sp_synth_preset_valid(p) || p->patch.unison>a->voice_limit)return 0;
    if(preserve_keys && sp_app_audio_edit(a,&p->patch)) {a->edited=*p;a->bindings_dirty=1;return 1;}
    if(!sp_app_audio_load(a,&p->patch))return 0;
    a->edited=*p;a->bindings_dirty=1;
    if(!preserve_keys) {
        memset(a->keys,0,sizeof(a->keys));memset(a->sustain,0,sizeof(a->sustain));a->ui.active_pads=0;return 1;
    }
    /* Serialized replay may exceed one batch, but advances no audio samples. */
    for(unsigned c=0;c<16;++c)if(a->sustain[c]) {
        SpSynthEvent e={0,SP_EVENT_SUSTAIN,c,0,1,0};sp_app_audio_control(a,&e);
    }
    unsigned previous=0;
    for(unsigned n=0;n<SP_APP_KEY_CAPACITY;++n) {
        SpAppKey *chosen=0;
        for(unsigned i=0;i<SP_APP_KEY_CAPACITY;++i)if(a->keys[i].active && a->keys[i].tag>previous &&
            (!chosen || a->keys[i].tag<chosen->tag))chosen=&a->keys[i];
        if(!chosen)break;
        previous=chosen->tag;SpSynthEvent e={0,SP_EVENT_NOTE_ON,chosen->channel,chosen->note,chosen->velocity,chosen->tag};
        sp_app_audio_control(a,&e);
        if(!chosen->held){e.type=SP_EVENT_NOTE_OFF;e.value=0;sp_app_audio_control(a,&e);}
        if(chosen->pressure>=0){e.type=SP_EVENT_POLY_PRESSURE;e.value=chosen->pressure;sp_app_audio_control(a,&e);}
    }
    return 1;
}
static int queue_request(SpSynthApp *a,const sp_ui_command *c,SpAppRequestType type) {
    if(a->request_count>=SP_APP_REQUEST_CAPACITY){
        ++a->request_faults;
        if(c->generation==a->ui.generation)a->ui.busy=0;
        return 0;
    }
    SpAppRequest *r=&a->requests[a->request_count++];memset(r,0,sizeof(*r));
    r->type=type;r->generation=c->generation;r->token=c->token;r->revision=c->revision;
    r->index=c->index;r->bank=c->bank;r->replace=c->replace;r->capture=a->capture;
    r->release_start_frames=a->capture_tail_start_frames;
    r->tail_cut_reason=a->ui.tail_cut_reason;
    if(type==SP_APP_REQUEST_CAPTURE_STOP) {
        r->capture=a->capture_plan;
        if(a->capture_progress.take_token)r->token=a->capture_progress.take_token;
    }
    if(type==SP_APP_REQUEST_PATCH_WRITE)r->preset=a->edited;
    if(type==SP_APP_REQUEST_CAPTURE_START) {
        capture_tail_clear(a);
        a->ui.tail_cut_reason=SP_APP_TAIL_CUT_NONE;
        r->release_start_frames=0;r->tail_cut_reason=SP_APP_TAIL_CUT_NONE;
        memset(&a->capture_progress,0,sizeof(a->capture_progress));
        a->capture_progress.start_generation=c->generation;
        a->ui.elapsed_ms=0;
        a->capture_plan=a->capture;
    }
    return 1;
}
static int commands(SpSynthApp *a,const sp_ui_commands *out);
static int complete_ui(SpSynthApp *a,const SpAppCompletion *completion) {
    sp_ui_event e={0};e.type=SP_UI_COMPLETE;e.generation=completion->generation;e.token=completion->token;
    e.error=completion->error;e.occupied=completion->occupied;e.factory=completion->factory;e.capture_active=completion->capture_active;
    e.save_flags=completion->save_flags;e.save_fault=completion->save_fault;
    memcpy(e.name,completion->name,sizeof(e.name));e.name[24]=0;sp_ui_commands out;
    sp_ui_dispatch(&a->ui,&e,&out);return commands(a,&out);
}
static int commands(SpSynthApp *a,const sp_ui_commands *out) {
    int ok=1;
    for(unsigned i=0;i<out->count;++i) {
        const sp_ui_command *c=&out->items[i];SpSynthEvent e={0};
        switch(c->type) {
        case SP_UI_CMD_PAD_ON:
            if(capture_gated(a)) {a->ui.active_pads&=(uint16_t)~(1u<<(c->index-1));break;}
            {uint8_t note;if(!sp_synth_app_pad_note(a,c->index,&note)){a->ui.active_pads&=(uint16_t)~(1u<<(c->index-1));break;}
             e=(SpSynthEvent){0,SP_EVENT_NOTE_ON,a->pad_channel,note,c->value/127.0f,0};ok&=send(a,&e,0,c->index,1);}break;
        case SP_UI_CMD_PAD_OFF:
            for(unsigned k=0;k<SP_APP_KEY_CAPACITY;++k)if(a->keys[k].active && a->keys[k].source==0 && a->keys[k].identity==c->index) {
                e=(SpSynthEvent){0,SP_EVENT_NOTE_OFF,a->keys[k].channel,a->keys[k].note,0,0};ok&=send(a,&e,0,c->index,1);break;
            }
            break;
        case SP_UI_CMD_MIDI_ON:case SP_UI_CMD_MIDI_OFF:case SP_UI_CMD_SUSTAIN:
            e=(SpSynthEvent){0,c->type==SP_UI_CMD_MIDI_ON?SP_EVENT_NOTE_ON:c->type==SP_UI_CMD_MIDI_OFF?SP_EVENT_NOTE_OFF:SP_EVENT_SUSTAIN,c->channel,c->index,c->value/127.0f,0};
            ok&=send(a,&e,1,0,1);break;
        case SP_UI_CMD_RELEASE_PADS:sp_app_release_pads(a);break;
        case SP_UI_CMD_PANIC:sp_synth_app_panic(a);break;
        case SP_UI_CMD_OCTAVE:break; /* UI already updated octave after releasing pads. */
        case SP_UI_CMD_PARAM_SET:ok&=sp_app_parameter(a,c->index,(unsigned)c->value);break;
        case SP_UI_CMD_PREVIEW_LEVEL:a->preview_level=c->value/16383.0f;break;
        case SP_UI_CMD_BROWSE_BEGIN:a->browse_snapshot=a->edited;a->snapshot_valid=1;break;
        case SP_UI_CMD_BROWSE_RESTORE:
            if(a->snapshot_valid)ok&=sp_app_apply_patch(a,&a->browse_snapshot,0);
            a->snapshot_valid=0;break;
        case SP_UI_CMD_BROWSE_COMMIT:a->snapshot_valid=0;break;
        case SP_UI_CMD_BROWSE_AUDITION: {
            const SpPreset *p=sp_synth_preset_find(c->token);
            if(p) {
                SpAppCompletion done={0};done.generation=c->generation;done.token=c->token;
                done.error=sp_app_apply_patch(a,p,0)?SP_UI_OK:SP_UI_ERR_BACKEND;ok&=complete_ui(a,&done);
            } else {
                a->pending_load_generation=c->generation;a->pending_load_token=c->token;
                ok&=queue_request(a,c,SP_APP_REQUEST_LOAD_PATCH);
            }break;
        }
        case SP_UI_CMD_INITIALIZE: {
            SpPreset p=*sp_synth_preset_at(0);sp_synth_patch_default(&p.patch);p.id=UINT32_MAX;p.favorite=0;
            memset(p.name,0,sizeof(p.name));memcpy(p.name,"INIT",5);ok&=sp_app_apply_patch(a,&p,0);break;
        }
        case SP_UI_CMD_CAPTURE_START:ok&=queue_request(a,c,SP_APP_REQUEST_CAPTURE_START);break;
        case SP_UI_CMD_CAPTURE_STOP:ok&=queue_request(a,c,SP_APP_REQUEST_CAPTURE_STOP);break;
        case SP_UI_CMD_TAKE_DISCARD:ok&=queue_request(a,c,SP_APP_REQUEST_TAKE_DISCARD);break;
        case SP_UI_CMD_DEST_QUERY:ok&=queue_request(a,c,SP_APP_REQUEST_DEST_QUERY);break;
        case SP_UI_CMD_TAKE_WRITE:ok&=queue_request(a,c,SP_APP_REQUEST_TAKE_WRITE);break;
        case SP_UI_CMD_TAKE_RECOVER:ok&=queue_request(a,c,SP_APP_REQUEST_TAKE_RECOVER);break;
        case SP_UI_CMD_PATCH_QUERY:ok&=queue_request(a,c,SP_APP_REQUEST_PATCH_QUERY);break;
        case SP_UI_CMD_PATCH_WRITE:ok&=queue_request(a,c,SP_APP_REQUEST_PATCH_WRITE);break;
        case SP_UI_CMD_GLOBAL_STOP:ok&=queue_request(a,c,SP_APP_REQUEST_GLOBAL_STOP);break;
        case SP_UI_CMD_LEAVE:ok&=queue_request(a,c,SP_APP_REQUEST_LEAVE);break;
        case SP_UI_CMD_PATCH_METADATA:break;
        }
    }
    if(!ok)a->ui.error=SP_UI_ERR_BACKEND;
    return ok;
}
int sp_synth_app_init(SpSynthApp *a,const SpPreset *initial,const sp_ui_patch *catalog,uint16_t count,float rate,uint32_t limit,uint32_t seed) {
    if(!a || !sp_synth_preset_valid(initial) || !isfinite(rate) || rate<8000 || rate>192000 || !limit || limit>16 || initial->patch.unison>limit)return 0;
    SpPreset p=*initial;memset(a,0,sizeof(*a));a->edited=p;a->voice_limit=limit;a->preview_level=1;
    a->capture=(SpAppCapture){0,4,4,120,0,1};
    if(!sp_synth_engine_init(&a->engine,rate,limit,seed,&p.patch))return 0;
    sp_ui_init(&a->ui,0,catalog,count);metadata(a);sp_synth_app_refresh(a);return 1;
}
int sp_synth_app_reenter(SpSynthApp *a,const SpAppReentryBoundary *b) {
    if(!a || !b || !a->voice_limit || b->fresh_input!=1 || b->leave_complete!=1 ||
       b->backend_quiescent!=1 || b->audio_sequence!=a->audio_sequence ||
       a->event_count || a->request_count || a->request_issued_generation ||
       a->pending_load_generation || a->snapshot_valid || a->batch_failed ||
       (a->capture_cancel_state && !sp_p6_record_rearm_v552_refusal_reentry(a,b)) ||
       a->audio_faulted || a->audio_pending || a->audio_batch || a->next_tag==UINT32_MAX)return 0;
    if(a->audio_deferred && a->audio_sequence==UINT32_MAX)return 0;
    for(unsigned i=0;i<SP_APP_KEY_CAPACITY;++i)
        if(a->keys[i].active || a->keys[i].held)return 0;
    for(unsigned i=0;i<16;++i)if(a->sustain[i])return 0;
    if(!sp_ui_reenter(&a->ui,b->generation,b->physical_pads,b->shift))return 0;
    memset(a->keys,0,sizeof(a->keys));
    memset(&a->capture_progress,0,sizeof(a->capture_progress));
    a->capture_cancel_state=SP_APP_CANCEL_NONE;a->capture_cancel_sequence=0;
    a->capture_failure_stage=a->capture_failure_details=0;
    capture_tail_clear(a);
    return 1;
}
int sp_synth_app_dispatch(SpSynthApp *a,const sp_ui_event *e) {
    if(!a || !e || !sp_app_audio_can_control(a))return 0;
    int phase_ok=!a->event_count;
    if(!phase_ok)fault(a); /* Wrong owner phase must not reorder notes. */
    if(e->type==SP_UI_COMPLETE || e->type==SP_UI_CAPTURE_PROGRESS)return 0; /* Typed backend APIs only. */
    if(e->type==SP_UI_EXIT_PRESS && !a->ui.shift && a->ui.busy &&
       a->ui.pending==SP_UI_CMD_CAPTURE_START && !a->capture_cancel_state &&
       a->capture_progress.start_generation==a->ui.generation) {
        sp_synth_app_panic(a);
        a->capture_cancel_sequence=a->audio_deferred?a->audio_sequence:0;
        a->capture_cancel_state=a->audio_deferred?SP_APP_CANCEL_AUDIO:SP_APP_CANCEL_REQUESTED;
        a->capture_failure_stage=SP_APP_CAPTURE_FAIL_CANCEL;a->capture_failure_details=0;
        return phase_ok && !a->audio_faulted;
    }
    if(a->capture_cancel_state && !(e->type==SP_UI_EXIT_PRESS && !a->ui.shift &&
       sp_p6_record_rearm_v552_no_io_exit(a))) {
        if(a->capture_cancel_state==SP_APP_CANCEL_FAILED) {
            if(e->type==SP_UI_VALUE_PRESS)a->capture_failure_details=1;
            if(e->type==SP_UI_EXIT_PRESS)a->capture_failure_details=0;
        }
        /* Retain physical transitions/releases, but no new navigation, backend
         * request, repeated cancellation or audible note while this take waits. */
        switch(e->type) {
        case SP_UI_PAD_DOWN:case SP_UI_PAD_UP:case SP_UI_MIDI_DOWN:case SP_UI_MIDI_UP:
        case SP_UI_MIDI_SUSTAIN:case SP_UI_SYNTH_PANIC:case SP_UI_SHIFT_UP:case SP_UI_SHIFT_DOWN:break;
        default:return phase_ok;
        }
        if(e->type==SP_UI_PAD_DOWN && a->ui.shift) {
            if(e->index>=1 && e->index<=16)a->ui.physical_pads|=(uint16_t)(1u<<(e->index-1));
            return phase_ok;
        }
    }
    if(a->ui.page==SP_UI_RECORDING && !a->ui.busy && !a->capture_cancel_state &&
       a->capture_plan.include_release_tail && !a->capture_progress.fault) {
        if(!a->capture_tail_state && (e->type==SP_UI_REC_PRESS ||
           (e->type==SP_UI_EXIT_PRESS && !a->ui.shift))) {
            capture_tail_begin(a,1);
            return phase_ok && !a->audio_faulted && !a->batch_failed;
        }
        if(a->capture_tail_state && e->type==SP_UI_EXIT_PRESS && !a->ui.shift)
            return phase_ok;
        if(a->capture_tail_state && e->type==SP_UI_REC_PRESS && !a->ui.tail_cut_reason)
            a->ui.tail_cut_reason=SP_APP_TAIL_CUT_MANUAL;
    }
    uint32_t revision=a->ui.revision;uint8_t dirty=a->ui.dirty;
    sp_ui_commands out;sp_ui_dispatch(&a->ui,e,&out);
    uint8_t focused=a->ui.focused,picked_up[3];memcpy(picked_up,a->ui.picked_up,3);
    int ok=commands(a,&out);
    int parameter=out.count==1 && out.items[0].type==SP_UI_CMD_PARAM_SET;
    if(parameter && (!ok || (out.items[0].index>=SP_BIND_ROOT && out.items[0].index<=SP_BIND_TEMPO))) {
        a->ui.revision=revision;a->ui.dirty=dirty;
    }
    metadata(a);if(a->bindings_dirty)sp_synth_app_refresh(a);
    if(parameter && ok){a->ui.focused=focused;memcpy(a->ui.picked_up,picked_up,3);}
    return ok && phase_ok;
}
int sp_synth_app_render(SpSynthApp *a,float *out,uint32_t frames) {
    if(!a || a->audio_deferred || !out || !frames || frames>SP_SYNTH_MAX_FRAMES)return 0;
    int accepted=!a->batch_failed;
    for(unsigned i=0;i<a->event_count;++i)if(a->events[i].offset>=frames){fault(a);accepted=0;break;}
    int result=sp_synth_engine_render(&a->engine,out,frames,a->events,a->event_count);
    if(!result){fault(a);accepted=0;}
    if(accepted)for(unsigned i=0;i<a->event_count;++i)scalar(a,&a->events[i]);
    a->event_count=0;a->batch_failed=0;
    if(accepted && a->capture_tail_state==SP_APP_TAIL_RELEASING &&
       !a->capture_cancel_state && sp_synth_engine_quiescent(&a->engine)) {
        SpSynthStats stats;sp_synth_engine_stats(&a->engine,&stats);
        a->capture_tail_state=SP_APP_TAIL_QUIET;
        a->capture_quiet_sample=(uint32_t)stats.rendered_frames;
    }
    if(a->ui.page==SP_UI_BROWSER)for(unsigned i=0;i<2*frames;++i)out[i]*=a->preview_level;
    return accepted;
}
int sp_app_audio_prepare(SpSynthApp *a,uint32_t frames) {
    int accepted=!a->batch_failed;
    for(unsigned i=0;i<a->event_count;++i)if(a->events[i].offset>=frames){fault(a);accepted=0;break;}
    if(accepted)for(unsigned i=0;i<a->event_count;++i)scalar(a,&a->events[i]);
    return accepted;
}
int sp_synth_app_request(SpSynthApp *a,SpAppRequest *out) {
    if(!a || !out || !a->request_count)return 0;
    *out=a->requests[0];--a->request_count;
    if(out->generation)a->request_issued_generation=out->generation;
    for(unsigned i=0;i<a->request_count;++i)a->requests[i]=a->requests[i+1];
    return 1;
}
static void capture_timer(SpSynthApp *a) {
    const SpAppCaptureProgress *p=&a->capture_progress;
    if(a->ui.page!=SP_UI_RECORDING || !p->sample_rate_hz)return;
    uint64_t seconds=p->accepted_frames/p->sample_rate_hz;
    uint64_t fraction=(p->accepted_frames%p->sample_rate_hz)*1000/p->sample_rate_hz;
    a->ui.elapsed_ms=seconds>UINT32_MAX/1000u?UINT32_MAX:
        (seconds*1000+fraction>UINT32_MAX?UINT32_MAX:(uint32_t)(seconds*1000+fraction));
}
static void capture_tail_begin(SpSynthApp *a,int early) {
    const SpAppCaptureProgress *p=&a->capture_progress;
    if(a->capture_tail_state || a->capture_cancel_state || !a->capture_plan.include_release_tail ||
       p->sealed || p->fault || !p->start_generation ||
       !(a->ui.page==SP_UI_RECORDING || (a->ui.busy && a->ui.pending==SP_UI_CMD_CAPTURE_START)) ||
       (a->ui.busy && a->ui.pending!=SP_UI_CMD_CAPTURE_START))return;
    if(!early && (!p->has_rx_notice || !p->duration_frames || p->accepted_frames<p->duration_frames))return;
    a->capture_tail_state=a->audio_deferred?SP_APP_TAIL_AUDIO:SP_APP_TAIL_RELEASING;
    a->capture_tail_sequence=a->audio_deferred?a->audio_sequence:0;
    a->capture_tail_start_frames=early?p->accepted_frames:p->duration_frames;
    SpSynthEvent off={0,SP_EVENT_ALL_NOTES_OFF,16,0,0,0};
    if(!send(a,&off,0,0,1))(void)fault(a);
}
static void capture_tail_release(SpSynthApp *a) {capture_tail_begin(a,0);}
int sp_synth_app_capture_tail_poll(const SpSynthApp *a) {
    return a && a->capture_tail_state==SP_APP_TAIL_RELEASING &&
        !a->capture_cancel_state && !a->capture_progress.fault &&
        a->ui.page==SP_UI_RECORDING && !a->ui.busy;
}
int sp_synth_app_capture_tail_observe(SpSynthApp *a,uint32_t sequence,uint32_t quiet,uint32_t sample) {
    if(!a || !a->audio_deferred || a->audio_pending || a->audio_batch || a->audio_faulted ||
       !sequence || sequence!=a->audio_sequence || quiet>1 || a->capture_cancel_state ||
       a->capture_progress.fault || a->capture_tail_state!=SP_APP_TAIL_RELEASING ||
       !a->capture_tail_sequence || sequence<a->capture_tail_sequence)return 0;
    if(quiet) {
        a->capture_tail_state=SP_APP_TAIL_QUIET;
        a->capture_quiet_sequence=sequence;a->capture_quiet_sample=sample;
    }
    return 1;
}
static void capture_sealed(SpSynthApp *a) {
    const SpAppCaptureProgress *p=&a->capture_progress;
    if(a->capture_cancel_state || a->ui.page!=SP_UI_RECORDING || a->ui.busy ||
       a->request_issued_generation || !p->sealed || p->fault || !p->accepted_frames)return;
    /* Use the ordinary UI transaction and generation, never an unsolicited
     * completion. Native STOP and its RX-return barrier still own settlement. */
    sp_ui_event event={.type=SP_UI_REC_PRESS};sp_ui_commands out;
    sp_ui_dispatch(&a->ui,&event,&out);
    if(out.count!=1 || out.items[0].type!=SP_UI_CMD_CAPTURE_STOP) {(void)fault(a);return;}
    out.items[0].token=p->take_token;
    if(!commands(a,&out))(void)fault(a);
}
int sp_synth_app_capture_progress(SpSynthApp *a,const SpAppCaptureProgress *p) {
    if(!a || !p || !sp_app_audio_can_control(a) || a->event_count ||
       a->ui.page==SP_UI_INACTIVE || !p->start_generation || !p->take_token ||
       !p->sample_rate_hz || !p->duration_frames || p->has_rx_notice>1 || p->sealed>1 ||
       p->tail_cut_reason>SP_APP_TAIL_CUT_LIMIT ||
       (p->tail_cut_reason && (!a->capture_plan.include_release_tail || !p->has_rx_notice)) ||
       (p->sealed && !p->accepted_frames) ||
       p->accepted_frames>p->observed_frames ||
       (!p->has_rx_notice && (p->observed_frames || p->accepted_frames || p->sealed)))return 0;
    SpAppCaptureProgress *old=&a->capture_progress;
    if(old->start_generation!=p->start_generation ||
       (old->take_token && old->take_token!=p->take_token) ||
       (old->sample_rate_hz && (old->sample_rate_hz!=p->sample_rate_hz ||
         old->count_in_frames!=p->count_in_frames || old->duration_frames!=p->duration_frames)) ||
       old->has_rx_notice>p->has_rx_notice || old->sealed>p->sealed || old->observed_frames>p->observed_frames ||
       old->accepted_frames>p->accepted_frames ||
       (old->tail_cut_reason && old->tail_cut_reason!=p->tail_cut_reason))return 0;
    int32_t fault=old->fault;*old=*p;if(fault)old->fault=fault;
    if(p->tail_cut_reason && !a->ui.tail_cut_reason)a->ui.tail_cut_reason=(uint8_t)p->tail_cut_reason;
    capture_timer(a);
    if(old->fault && (a->ui.page==SP_UI_RECORDING || a->ui.page==SP_UI_CAPTURE_ERROR ||
       (a->ui.busy && (a->ui.pending==SP_UI_CMD_CAPTURE_START || a->ui.pending==SP_UI_CMD_CAPTURE_STOP))))
        a->ui.error=SP_UI_ERR_CAPTURE;
    capture_tail_release(a);capture_sealed(a);return 1;
}
static void capture_failed(SpSynthApp *a,unsigned stage) {
    a->capture_cancel_state=SP_APP_CANCEL_FAILED;
    a->capture_failure_stage=(uint8_t)stage;a->capture_failure_details=0;
    a->ui.busy=0;a->ui.error=SP_UI_ERR_CAPTURE;a->ui.page=SP_UI_CAPTURE_ERROR;
    sp_synth_app_panic(a);
}
int sp_synth_app_cancel_complete(SpSynthApp *a,uint32_t generation,uint32_t token,uint32_t sequence,int32_t result) {
    if(!a || !sp_app_audio_can_control(a) || a->event_count ||
       a->capture_cancel_state!=SP_APP_CANCEL_REQUESTED || a->request_issued_generation ||
       generation!=a->capture_progress.start_generation || sequence!=a->capture_cancel_sequence ||
       !a->ui.busy || a->ui.pending!=SP_UI_CMD_CAPTURE_START ||
       (result!=1 && result!=-1))return 0;
    if(result<0 || !token || (a->capture_progress.take_token && a->capture_progress.take_token!=token) ||
       a->ui.generation==UINT32_MAX) {capture_failed(a,SP_APP_CAPTURE_FAIL_CANCEL);return 1;}
    a->capture_progress.take_token=token;a->ui.take_token=token;a->ui.take_held=1;a->ui.discard_leaves=0;
    a->ui.pending=SP_UI_CMD_TAKE_DISCARD;++a->ui.generation;
    sp_ui_command command={.type=SP_UI_CMD_TAKE_DISCARD,.generation=a->ui.generation,.token=token,.revision=a->ui.revision};
    a->capture_cancel_state=SP_APP_CANCEL_DISCARD;
    if(!queue_request(a,&command,SP_APP_REQUEST_TAKE_DISCARD))capture_failed(a,SP_APP_CAPTURE_FAIL_DISCARD);
    return 1;
}
int sp_synth_app_complete(SpSynthApp *a,const SpAppCompletion *input) {
    if(!a || !input || !sp_app_audio_can_control(a))return 0;
    if(!a->ui.busy || input->generation!=a->ui.generation || input->generation!=a->request_issued_generation){++a->stale_completions;return 0;}
    if(a->event_count)return 0;
    SpAppCompletion c=*input;
    sp_ui_command_type pending=a->ui.pending;
    if(pending==SP_UI_CMD_TAKE_WRITE || pending==SP_UI_CMD_TAKE_RECOVER) {
        if((c.save_flags&~SP_UI_SAVE_FLAGS_ALL) ||
           ((c.save_flags || c.save_fault) && (!c.token || c.token!=a->ui.take_token)))return 0;
        if(c.error==SP_UI_OK && (pending==SP_UI_CMD_TAKE_RECOVER || c.save_flags || c.save_fault) &&
           ((c.save_flags&SP_UI_SAVE_SAVED_MASK)!=SP_UI_SAVE_SAVED_MASK ||
            (c.save_flags&(SP_UI_SAVE_RECOVERY_REQUIRED|SP_UI_SAVE_INTACT)) || c.save_fault)) {
            c.error=SP_UI_ERR_BACKEND;c.save_flags|=SP_UI_SAVE_RECOVERY_REQUIRED;
        }
        if(c.error!=SP_UI_OK && c.save_flags!=SP_UI_SAVE_INTACT) {
            c.save_flags|=SP_UI_SAVE_RECOVERY_REQUIRED;
            if(!c.token)c.token=a->ui.take_token;
        }
    } else if(c.save_flags || c.save_fault)return 0;
    if(pending==SP_UI_CMD_CAPTURE_STOP && c.error==SP_UI_OK && !c.token)
        c.error=SP_UI_ERR_CAPTURE;
    if((pending==SP_UI_CMD_CAPTURE_START || pending==SP_UI_CMD_CAPTURE_STOP) && c.error==SP_UI_OK && c.token) {
        if(a->capture_progress.take_token && a->capture_progress.take_token!=c.token) {
            c.error=SP_UI_ERR_CAPTURE;
            if(pending==SP_UI_CMD_CAPTURE_START && a->capture_cancel_state)
                capture_failed(a,SP_APP_CAPTURE_FAIL_CANCEL);
        }
        else a->capture_progress.take_token=c.token;
    }
    if(pending==SP_UI_CMD_CAPTURE_START && a->capture_cancel_state) {
        /* A queued START response cannot override the later cancellation intent.
         * Consume it so the independent receipt can progress to checked DISCARD. */
        a->request_issued_generation=0;return c.error==SP_UI_OK;
    }
    if(a->ui.pending==SP_UI_CMD_BROWSE_AUDITION) {
        if(c.error==SP_UI_OK && (c.generation!=a->pending_load_generation || !c.preset ||
           c.preset->id!=a->pending_load_token || !sp_app_apply_patch(a,c.preset,0)))c.error=SP_UI_ERR_BACKEND;
        a->pending_load_generation=0;a->pending_load_token=0;
    }
    if(a->ui.pending==SP_UI_CMD_PATCH_WRITE && c.error==SP_UI_OK) {
        if(!c.token || sp_synth_preset_is_factory(c.token))c.error=SP_UI_ERR_BACKEND;
        else a->edited.id=c.token;
    }
    a->request_issued_generation=0;
    int ok=complete_ui(a,&c);
    /* A rejected STOP must not be regenerated by the retained SEALED notice.
     * Keep the first failure even when later RX feedback reports no fault. */
    if(pending==SP_UI_CMD_CAPTURE_STOP && c.error!=SP_UI_OK) {
        if(!a->capture_progress.fault)a->capture_progress.fault=-(int32_t)c.error;
        capture_failed(a,SP_APP_CAPTURE_FAIL_FINALIZE);
    }
    if(pending==SP_UI_CMD_CAPTURE_START && c.error!=SP_UI_OK)capture_failed(a,SP_APP_CAPTURE_FAIL_PREPARE);
    if(pending==SP_UI_CMD_TAKE_DISCARD && a->capture_cancel_state==SP_APP_CANCEL_DISCARD) {
        if(c.error==SP_UI_OK) {a->capture_cancel_state=SP_APP_CANCEL_NONE;a->capture_cancel_sequence=0;}
        else capture_failed(a,SP_APP_CAPTURE_FAIL_DISCARD);
    }
    if(c.error==SP_UI_OK && (pending==SP_UI_CMD_TAKE_DISCARD || pending==SP_UI_CMD_TAKE_WRITE ||
       pending==SP_UI_CMD_TAKE_RECOVER))
        memset(&a->capture_progress,0,sizeof(a->capture_progress));
    if(c.error==SP_UI_OK && (pending==SP_UI_CMD_CAPTURE_STOP ||
       pending==SP_UI_CMD_TAKE_DISCARD || pending==SP_UI_CMD_TAKE_WRITE ||
       pending==SP_UI_CMD_TAKE_RECOVER))capture_tail_clear(a);
    capture_timer(a);capture_tail_release(a);capture_sealed(a);
    if(a->capture_progress.fault && a->ui.page==SP_UI_RECORDING)a->ui.error=SP_UI_ERR_CAPTURE;
    metadata(a);if(a->bindings_dirty)sp_synth_app_refresh(a);return ok && c.error==SP_UI_OK;
}
int sp_synth_app_set_catalog(SpSynthApp *a,const sp_ui_patch *catalog,uint16_t count) {
    return a && sp_app_audio_can_control(a) && !a->event_count &&
        sp_ui_set_catalog(&a->ui,catalog,count);
}
int sp_synth_app_set_metadata(SpSynthApp *a,const char *name,uint8_t category,uint8_t favorite) {
    if(!a || !sp_app_audio_can_control(a) || !name || a->ui.busy || a->event_count || a->ui.revision==UINT32_MAX)return 0;
    SpPreset p=a->edited;unsigned n=0;memset(p.name,0,sizeof(p.name));
    while(n<sizeof(p.name)-1 && name[n]){p.name[n]=name[n];++n;}
    if(name[n])return 0;
    p.name[n]=0;p.category=category;p.favorite=favorite;if(!sp_synth_preset_valid(&p))return 0;
    a->edited=p;a->ui.dirty=1;++a->ui.revision;metadata(a);return 1;
}
int sp_synth_app_set_macro_label(SpSynthApp *a,uint32_t macro,const char *label) {
    if(!a || !sp_app_audio_can_control(a) || !label || macro>=3 || a->ui.busy || a->event_count || a->ui.revision==UINT32_MAX)return 0;
    SpPreset p=a->edited;unsigned n=0;char *dest=p.macro_controls[macro].label;memset(dest,0,SP_PRESET_MACRO_LABEL_CAPACITY);
    while(n<SP_PRESET_MACRO_LABEL_CAPACITY-1 && label[n]){dest[n]=label[n];++n;}
    if(label[n])return 0;
    dest[n]=0;if(!sp_synth_preset_valid(&p))return 0;
    a->edited=p;a->ui.dirty=1;++a->ui.revision;sp_synth_app_refresh(a);return 1;
}
