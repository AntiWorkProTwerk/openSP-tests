#define SP_SYNTH_NATIVE_BOUND_V552 1
#include "sp_p6_record_rearm_v552.h"
#include "sp_p6_record_audio_v552.h"
#include "sp_p6_record_request_v552.h"
#include "sp_p6_record_retirement_v552.h"
#include "sp_p6_session_binding_v552.h"
#include "sp_p6_production_join.h"
#include <limits.h>

/* Strong peers authenticate native journal/backend retirement. These defaults
 * make the component unavailable until the genuine graph is selected. */
__attribute__((weak)) int sp_p6_record_backend_v552_start_refused_no_io(void){return 0;}
__attribute__((weak)) int sp_p6_record_backend_v552_detached(void){return 0;}
__attribute__((weak)) int sp_p6_record_retirement_v552_rearm_ready(void){return 0;}
__attribute__((weak)) int sp_p6_record_retirement_v552_rearm_commit(void){return 0;}
#define A (&sp_p6_record_audio_v552)
#define Q (&sp_p6_record_request_v552)
#define R (&sp_p6_record_retirement_v552)
#define B (&sp_p6_session_binding_v552)
#define S (&sp_p6_production_session)
#define C (&sp_p6_production_capture)
#define M (&sp_synth_preview_native_v552)
#define value(p) atomic_load_explicit((p),memory_order_acquire)
_Static_assert(sizeof(SpP6RecordAudioV552)==96,"Rearm adds only4B floor");
_Static_assert(sizeof(SpSynthSessionV552)==3824,"Session ABI");
_Static_assert(sizeof(SpSynthCaptureTimedV552)==1336,"Capture ABI");
_Static_assert(sizeof(SpSynthRuntimeStorage)==116032,"Runtime ABI");
static uint32_t rd(uint32_t p){return *(volatile const uint32_t *)(uintptr_t)p;}
static uint32_t lock(void){uint32_t p;__asm__ volatile("mrs %0,primask\n cpsid i":"=r"(p)::"memory");return p;}
static void unlock(uint32_t p){__asm__ volatile("dmb\n msr primask,%0"::"r"(p):"memory");}
static uint32_t task(void){
    uint32_t i,p,b,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));__asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(b));__asm__ volatile("mrs %0,faultmask":"=r"(f));
    if(i||p||b||f||rd(0x202BBBF8)||rd(0x80245764))return 0;
    return ((uint32_t (*)(void))(uintptr_t)0x800D3163)();
}
static SpSynthRuntimeStorage *runtime(void){
    return S->startup.ready==1 && S->startup.memory.attached==1 && S->startup.memory.storage &&
        S->startup.memory.allocation && !value(&S->terminal) && !S->clock_handoff &&
        (uintptr_t)S->startup.memory.storage==A->runtime &&
        (uintptr_t)S->startup.memory.allocation==A->allocation?S->startup.memory.storage:0;
}
static int panel(void){uint32_t t=task();return t && t==B->task && t==M->task_id && t==rd(0x8300A3E8) &&
    value(&M->ready)==1 && !value(&M->terminal) && !value(&M->entry.fault) &&
    !M->entry.dispatch_depth && !M->entry.sample_depth && !value(&B->fault) &&
    value(&B->phase)==SP_P6_SB_PREPARED && !value(&Q->fault) && !value(&A->fault);}
static int between(SpSynthRuntimeStorage *r){
    SpSynthApp *a=&r->controller;
    return !a->audio_pending && !a->audio_batch && !a->audio_faulted && !a->event_count && !a->batch_failed &&
        !a->request_count && !a->request_issued_generation && !a->pending_load_generation && !a->snapshot_valid &&
        !r->controls.count && !r->controls.faulted && !r->midi.count && !r->midi.fault && !r->audio.faulted &&
        !r->input.physical && !r->input.captured && !r->input.delivered && !r->input.shift &&
        value(&r->mailbox.phase)==SP_AUDIO_FREE && !value(&r->mailbox.stop_requested) && !value(&r->mailbox.stopped) &&
        !value(&S->backend.request_phase) && !value(&S->backend.responses.phase) && !value(&S->backend.responses.stopped) &&
        a->audio_sequence==r->audio.sequence && a->audio_sequence==value(&A->done_sequence) &&
        a->audio_sequence<=value(&A->consumed_sequence) && value(&r->mailbox.sample_cursor)==value(&A->sample);
}
static int failed_no_take(const SpSynthApp *a){return a && a->capture_cancel_state==SP_APP_CANCEL_FAILED &&
    a->capture_failure_stage==SP_APP_CAPTURE_FAIL_PREPARE && !a->ui.busy && !a->ui.take_held && !a->ui.take_token &&
    !(a->ui.save_flags&SP_UI_SAVE_RECOVERY_REQUIRED) && !a->capture_progress.take_token &&
    a->capture_progress.start_generation && !a->capture_progress.observed_frames && !a->capture_progress.accepted_frames &&
    !a->capture_cancel_sequence && !a->capture_tail_state && !a->capture_plan.include_release_tail;}
int sp_p6_record_rearm_v552_no_io_exit(const SpSynthApp *a){
    SpSynthRuntimeStorage *r=runtime();
    return r && a==&r->controller && task()==A->task && !value(&A->fault) && !value(&Q->fault) &&
        value(&A->phase)==SP_P6_RA_BOUND && failed_no_take(a) &&
        (a->ui.page==SP_UI_CAPTURE_ERROR || a->ui.page==SP_UI_PLAY) &&
        sp_p6_record_backend_v552_start_refused_no_io();
}
static int old_epoch(void){return value(&R->phase)==SP_P6_RR_RELEASED && value(&R->released)==1 &&
    R->ticket && R->released_ticket==R->ticket && R->released_lifetime==R->lifetime && R->destructor_returned &&
    R->lifetime==A->visit && R->intent==A->intent && Q->visit==A->visit && Q->intent==A->intent &&
    value(&Q->phase)==SP_P6_RQ_DONE && Q->request_type==SP_APP_REQUEST_LEAVE && !Q->generation &&
    !Q->working_generation && !Q->request_token && Q->backend_takes==Q->backend_finishes && Q->backend_finishes &&
    value(&C->state)==SP_TCAP_FREE && value(&C->released_ticket)==R->ticket && !value(&C->backend) &&
    !C->working && !value(&C->handoff_pending) && !value(&C->fault) && !value(&C->handoff_fault) &&
    S->backend.request.type==SP_APP_REQUEST_LEAVE && !S->backend.request.generation && !S->backend.request.token;}
static int fresh_page(void){
    uint32_t page=(uintptr_t)value(&M->active_page);
    return value(&M->phase)==SP_PREVIEW_NATIVE_ACTIVE && page && page==rd(0x80CFD4FC) &&
        rd(page)==(uintptr_t)(M->primary+2) && B->page==page && B->visit==M->voice_used &&
        B->visit>A->visit && B->sequence>A->intent && value(&B->pending)==B->sequence &&
        M->entry.input.enabled && !M->entry.input.physical && !M->entry.input.captured &&
        !M->entry.input.delivered && !M->entry.input.shift && !M->entry.dispatch_depth && !M->entry.sample_depth;
}
int sp_p6_record_rearm_v552_preconstructed(void){
    if(!A->intent)return !value(&A->fault);
    SpSynthRuntimeStorage *r=runtime();
    return r && task()==A->task && task()==rd(0x8300A3E8) &&
        !value(&A->fault) && !value(&Q->fault) && !value(&B->fault) &&
        value(&A->phase)==SP_P6_RA_RETIRED && !value(&A->gate) && !value(&A->audio_active) &&
        !value(&B->pending) && M->voice_used==A->visit &&
        (value(&M->phase)==SP_PREVIEW_NATIVE_LEFT || value(&M->phase)==SP_PREVIEW_NATIVE_HOLD) &&
        old_epoch() && between(r);
}
int sp_p6_record_rearm_v552_constructor_ready(void){return sp_p6_record_rearm_v552_preconstructed();}
int sp_p6_record_rearm_v552_refusal_reentry(const SpSynthApp *a,const SpAppReentryBoundary *b){
    SpSynthRuntimeStorage *r=runtime();
    return r && a==&r->controller && b && panel() && value(&A->phase)==SP_P6_RA_RETIRED &&
        value(&A->gate)==1 && !value(&A->audio_active) && old_epoch() && fresh_page() && between(r) &&
        failed_no_take(a) && R->take_token==C->last_token && R->take_token==C->plan.take_token &&
        R->start_generation==C->plan.start_generation &&
        a->capture_progress.start_generation>C->plan.start_generation && !value(&C->pre_io_abort_token) &&
        b->generation==a->ui.generation && b->audio_sequence==a->audio_sequence &&
        b->physical_pads==M->entry.input.physical && b->shift==M->entry.input.shift &&
        b->fresh_input==1 && b->leave_complete==1 && b->backend_quiescent==1;
}
int sp_p6_record_rearm_v552_reentered(void){
    SpSynthRuntimeStorage *r=runtime();return r && panel() && value(&A->phase)==SP_P6_RA_RETIRED &&
        value(&A->gate)==1 && !value(&A->audio_active) && old_epoch() && fresh_page() && between(r) &&
        r->controller.ui.page==SP_UI_PLAY && !r->controller.capture_cancel_state &&
        !r->controller.capture_tail_state && !r->controller.ui.take_held && !r->controller.ui.take_token &&
        r->controller.ui.physical_pads==M->entry.input.physical && r->controller.ui.shift==M->entry.input.shift;
}
void sp_p6_record_rearm_v552_panel(void){
    if(!panel())return;
    SpSynthRuntimeStorage *r=runtime();if(!r || !between(r))return;
    if(value(&A->phase)==SP_P6_RA_BOUND && value(&M->phase)==SP_PREVIEW_NATIVE_LEFT) {
        if(!sp_p6_record_backend_v552_detached() || !sp_p6_record_retirement_v552_rearm_ready() || !old_epoch() ||
           value(&M->active_page) || value(&M->retired_page) || rd(0x80CFD4FC))return;
        uint32_t p=lock();
        if(!value(&A->gate) && !value(&A->audio_active) && !(value(&A->revision)&1u) && old_epoch() &&
           value(&B->pending)==A->intent && value(&M->phase)==SP_PREVIEW_NATIVE_LEFT) {
            atomic_store_explicit(&A->phase,SP_P6_RA_RETIRED,memory_order_relaxed);
            atomic_store_explicit(&B->pending,0,memory_order_release);
        }
        unlock(p);return;
    }
    if(value(&A->phase)!=SP_P6_RA_RETIRED || !old_epoch() || !fresh_page())return;
    unsigned empty=0;
    if(!atomic_compare_exchange_strong_explicit(&A->gate,&empty,1,memory_order_acq_rel,memory_order_acquire))return;
    if(!value(&A->audio_active) && between(r) && old_epoch() && fresh_page()) {
        SpSynthApp *a=&r->controller;
        const SpAppReentryBoundary boundary={a->ui.generation,a->audio_sequence,
            M->entry.input.physical,M->entry.input.shift,1,1,1};
        if(sp_synth_app_reenter(a,&boundary)) {
            if(sp_p6_record_rearm_v552_reentered() && sp_p6_record_retirement_v552_rearm_commit()) {
                /* Counters, canonical link history and capture history are retained. */
                atomic_store_explicit(&Q->phase,SP_P6_RQ_EMPTY,memory_order_relaxed);
                atomic_store_explicit(&A->phase,SP_P6_RA_ARMED,memory_order_release);
            } else {
                /* The app mutation cannot be retried as a fresh reentry. Retain
                 * every lower receipt and refuse audio until this is diagnosed. */
                atomic_fetch_or_explicit(&A->fault,SP_P6_RA_IDENTITY,memory_order_relaxed);
                atomic_store_explicit(&A->phase,SP_P6_RA_FAILED,memory_order_release);
            }
        }
    }
    atomic_store_explicit(&A->gate,0,memory_order_release);
}
int sp_p6_record_rearm_v552_bind_current(void){
    SpSynthRuntimeStorage *r=runtime();
    return r && task()==M->config.audio_task && value(&A->phase)==SP_P6_RA_ARMED && !value(&A->fault) &&
        value(&A->audio_active)==1 && (value(&A->revision)&1u) && !value(&A->gate) &&
        value(&M->ready)==1 && !value(&M->terminal) && !value(&M->entry.fault) &&
        !value(&B->fault) && value(&B->phase)==SP_P6_SB_PREPARED && fresh_page() &&
        value(&Q->phase)==SP_P6_RQ_EMPTY && !value(&Q->fault) &&
        value(&R->phase)==SP_P6_RR_EMPTY && !value(&R->released) &&
        r->controller.ui.page==SP_UI_PLAY && !r->controller.capture_cancel_state && between(r);
}
uint32_t sp_p6_record_rearm_v552_admission(void){return 0;}
