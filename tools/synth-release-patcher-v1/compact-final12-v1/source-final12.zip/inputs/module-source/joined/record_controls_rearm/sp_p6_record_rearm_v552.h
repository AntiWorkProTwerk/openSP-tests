#ifndef SP_P6_RECORD_REARM_V552_H
#define SP_P6_RECORD_REARM_V552_H
#include "sp_synth_app.h"

/* Serialized source panel only. Retains the permanent runtime and all faults.
 * Consumes authentic old retirement before any fresh native constructor. */
void sp_p6_record_rearm_v552_panel(void);
/* App-private observers; expected pointers confer no native receipt. */
int sp_p6_record_rearm_v552_no_io_exit(const SpSynthApp *);
int sp_p6_record_rearm_v552_refusal_reentry(const SpSynthApp *,const SpAppReentryBoundary *);
/* Source observers used by exact RA/retirement derivatives, no supplied flags. */
int sp_p6_record_rearm_v552_bind_current(void);
int sp_p6_record_rearm_v552_reentered(void);
int sp_p6_record_rearm_v552_preconstructed(void);
int sp_p6_record_rearm_v552_constructor_ready(void);
uint32_t sp_p6_record_rearm_v552_admission(void);
#endif
