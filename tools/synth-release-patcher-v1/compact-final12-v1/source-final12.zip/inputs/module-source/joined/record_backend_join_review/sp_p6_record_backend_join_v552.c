#define SP_SYNTH_NATIVE_BOUND_V552 1
#include "sp_p6_record_backend_join_v552.h"
#include "sp_p6_production_join.h"
#include "sp_p6_session_binding_v552.h"
#include "sp_p6_record_request_v552.h"
#include "sp_p6_record_audio_v552.h"
#include "sp_p6_record_retirement_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_save_handover_v552.h"
#include <string.h>

_Static_assert(sizeof(SpSynthCaptureTimedV552)==1336,"Pinned capture ABI");
_Static_assert(sizeof(SpSynthSessionV552)==3824,"Pinned session ABI");
_Static_assert(sizeof(SpSynthRuntimeStorage)==116032,"Current private runtime ABI");
#define C (&sp_p6_production_capture)
#define S (&sp_p6_production_session)
#define B (&sp_p6_session_binding_v552)
#define Q (&sp_p6_record_request_v552)
#define R (&sp_p6_record_retirement_v552)
#define M (&sp_synth_preview_native_v552)
#define val(p) atomic_load_explicit((p),memory_order_acquire)

/* Sole source retirement owner supplies this proof in the final join. */
__attribute__((weak)) int sp_p6_record_retirement_v552_rearm_ready(void) {return 0;}
__attribute__((weak)) int sp_p6_record_retirement_v552_rearmed_no_io(void) {return 0;}
static uint32_t rd(uint32_t p) {return *(volatile const uint32_t *)(uintptr_t)p;}
static uint32_t current(void) {
    uint32_t i,p,b,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));
    __asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(b));
    __asm__ volatile("mrs %0,faultmask":"=r"(f));
    return i || p || b || f || rd(0x202BBBF8) || rd(0x80245764)?0:
        ((uint32_t (*)(void))(uintptr_t)0x800D3163)();
}
static int panel(void) {
    uint32_t t=current();return t && t==B->task && t==Q->task && t==M->task_id &&
        t==rd(0x8300A3E8) && !M->entry.sample_depth;
}
static int smpl(void) {return current() && sp_p6_record_context_v552_current(1);}
static int empty_link(void) {
    return !val(&S->backend.request_phase) && !val(&S->backend.responses.phase) &&
        !val(&S->backend.responses.stopped) && !val(&S->backend.capture_cancel_phase) &&
        !val(&S->backend.capture_feedback_ready);
}
static int request_identity(void) {
    return C->work.type==Q->request_type && C->work.generation==Q->generation &&
        C->work.token==Q->request_token && C->work.revision==Q->request_revision &&
        ((uint32_t)C->work.index|((uint32_t)C->work.bank<<16)|((uint32_t)C->work.replace<<24))==Q->destination &&
        !memcmp(&C->work,&S->backend.request,sizeof(C->work));
}
static int source(void) {
    return sp_p6_production_cold_started() && S->startup.ready==1 && S->startup.memory.attached==1 &&
        S->startup.memory.storage && !val(&S->terminal) && val(&B->phase)==SP_P6_SB_PREPARED &&
        !val(&B->fault) && B->sequence && B->sequence==val(&B->pending) && B->visit &&
        !val(&Q->fault) && val(&Q->phase)==SP_P6_RQ_DONE && Q->visit==B->visit && Q->intent==B->sequence &&
        Q->page==B->page && Q->task==B->task && Q->backend_takes &&
        Q->backend_takes==Q->backend_finishes && empty_link();
}
static int initial_no_io(void) {
    SpP6RecordProducerV552 *p=&sp_p6_record_producer_v552;
    SpP6RecordFilesV552 *f=&sp_p6_record_files_v552;
    SpP6SaveHandoverV552 *save=&sp_p6_save_handover_v552;
    if(val(&C->state)!=SP_TCAP_FREE || C->working || val(&C->token) || C->last_token || C->work_token ||
       C->plan.take_token || C->plan.start_generation || val(&C->fault) || val(&C->handoff_fault) ||
       val(&C->pre_io_abort_token) || val(&C->rx_active) || C->window.inflight || val(&C->rx_ack) ||
       val(&C->started_token) || val(&C->cleanup_token) || val(&C->notice_ready) ||
       val(&C->fence_phase) || val(&C->tail_cut_reason) || C->file_owned || C->write_count ||
       C->start_admitted || C->start_canceled || C->discard_attempted || C->project_calls ||
       val(&C->native_save_count) || val(&C->handoff_pending) || val(&C->exit_ticket) ||
       val(&C->released_ticket) || C->last_ticket || C->exit_requested ||
       val(&C->barrier_token) || val(&C->barrier_ack) || val(&C->barrier_sequence) || val(&C->wait_sequence) ||
       val(&C->record_ready)!=1 || p->capture!=C || p->fault || p->held || p->active || p->token ||
       p->pending || p->drain_requested || p->last_retired || f->active || f->fault || f->serial ||
       f->smpl_operation || f->record_operation || f->cache_depth || sp_p6_record_files_v552_outstanding() ||
       save->capture!=C || save->state!=SP_P6_SAVE_IDLE || save->fault || save->token ||
       *(volatile const uint8_t *)(uintptr_t)0x82E0E755 ||
       *(volatile const uint8_t *)(uintptr_t)0x82E0E96A || (int32_t)rd(0x82E0E764)>=0 ||
       rd(0x82E0E96C) || rd(0x82E0E970)!=0x82FE4F08 || rd(0x82FE4F08)!=0x8021E020 ||
       (int32_t)rd(0x82FE50B8)>=0 || rd(0x82FE50AC)>=30 || rd(0x82FE50B0)>=30)return 0;
    for(unsigned i=0;i<30;++i)if(*(volatile const uint8_t *)(uintptr_t)(0x82FE4F44+12*i) ||
        rd(0x82FE4F48+12*i))return 0;
    return 1;
}
static int no_new_io(void) {
    if(!R->released_ticket && !R->released_lifetime && !R->ticket && !R->lifetime)
        return Q->backend_takes==1 && initial_no_io();
    /* The prior source-owned release survives genuine rearm commit. A fresh
     * refused START may keep a prior SAVE's transferred cache FILE. The sole
     * native issuer consumes last_token before I/O, including pre-I/O aborts;
     * comparing that history excludes every newly consumed native token. */
    return sp_p6_record_retirement_v552_rearmed_no_io() &&
        val(&R->phase)==SP_P6_RR_EMPTY && !val(&R->released) && !R->destructor_returned &&
        R->ticket && R->released_ticket==R->ticket && R->released_lifetime==R->lifetime &&
        R->ticket==val(&C->exit_ticket) && R->ticket==val(&C->released_ticket) &&
        Q->visit>R->lifetime && Q->intent>R->intent && Q->generation>R->start_generation &&
        R->take_token==C->last_token && R->start_generation==C->plan.start_generation &&
        C->plan.take_token==R->take_token && val(&C->state)==SP_TCAP_FREE && !C->working &&
        !val(&C->token) && !val(&C->fault) && !val(&C->handoff_fault) && !C->file_owned &&
        !val(&C->rx_active) && !C->window.inflight && !val(&C->handoff_pending) &&
        !C->start_admitted && !C->start_canceled && !val(&C->pre_io_abort_token) &&
        val(&C->record_ready)==1;
}
int sp_p6_record_backend_v552_start_refused_no_io(void) {
    if(!panel() || !source() || sp_p6_record_audio_v552_session()!=S ||
       !Q->audio_sequence || !sp_p6_record_audio_v552_acknowledged(Q->audio_sequence) ||
       val(&C->backend)!=&S->backend || Q->request_type!=SP_APP_REQUEST_CAPTURE_START ||
       !Q->generation || Q->generation!=Q->working_generation || Q->request_token ||
       C->work.type!=SP_APP_REQUEST_CAPTURE_START || C->work.generation!=Q->generation || C->work.token ||
       !request_identity() || !C->response_ready ||
       C->completion.generation!=Q->generation || C->completion.error!=SP_UI_ERR_CAPTURE ||
       C->completion.token || C->completion.capture_active || C->completion.save_flags || C->completion.save_fault ||
       val(&R->phase)!=SP_P6_RR_EMPTY || !no_new_io())return 0;
    SpSynthApp *a=&S->startup.memory.storage->controller;
    return !a->request_count && !a->request_issued_generation && !a->audio_faulted && !a->event_faults &&
        !a->request_faults && a->capture_cancel_state==SP_APP_CANCEL_FAILED &&
        a->capture_failure_stage==SP_APP_CAPTURE_FAIL_PREPARE && !a->capture_cancel_sequence &&
        a->capture_progress.start_generation==Q->generation && !a->capture_progress.take_token &&
        !a->capture_progress.has_rx_notice && !a->capture_progress.fault && !a->capture_progress.sealed &&
        !a->capture_progress.observed_frames && !a->capture_progress.accepted_frames &&
        !a->capture_progress.tail_cut_reason && !a->capture_tail_state &&
        !a->capture_tail_sequence && !a->ui.busy && !a->ui.take_token && !a->ui.take_held &&
        !a->ui.save_flags && !a->ui.save_fault &&
        (a->ui.page==SP_UI_CAPTURE_ERROR || a->ui.page==SP_UI_PLAY);
}
static int completed_leave(void) {
    return source() && sp_p6_record_retirement_v552_rearm_ready() &&
        val(&C->state)==SP_TCAP_FREE && !C->working && !val(&C->handoff_pending) &&
        !val(&C->fault) && !val(&C->handoff_fault) &&
        C->work.type==SP_APP_REQUEST_LEAVE && !C->work.generation && !C->work.token &&
        request_identity() && Q->request_type==SP_APP_REQUEST_LEAVE &&
        !Q->generation && !Q->working_generation && !Q->request_token &&
        val(&R->phase)==SP_P6_RR_RELEASED && val(&R->released)==1 && R->destructor_returned &&
        R->ticket && R->ticket==R->released_ticket && R->ticket==val(&C->released_ticket) &&
        R->ticket==val(&C->exit_ticket) && R->lifetime==R->released_lifetime &&
        R->lifetime==Q->visit && R->intent==Q->intent &&
        R->start_generation==C->plan.start_generation && R->take_token==C->last_token;
}
int sp_p6_record_backend_v552_detached(void) {
    return (panel() || smpl()) && val(&C->backend)==0 && completed_leave();
}
int sp_p6_record_backend_v552_rearm(void) {
    if(!smpl() || !completed_leave())return 0;
    SpSynthBackendLink *expected=&S->backend;
    if(atomic_compare_exchange_strong_explicit(&C->backend,&expected,0,memory_order_acq_rel,memory_order_acquire))return 1;
    return expected==0?2:0;
}
