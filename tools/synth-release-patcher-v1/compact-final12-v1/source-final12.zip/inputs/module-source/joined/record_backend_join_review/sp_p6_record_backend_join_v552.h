#ifndef SP_P6_RECORD_BACKEND_JOIN_V552_H
#define SP_P6_RECORD_BACKEND_JOIN_V552_H

/* Actual PANEL/control owner only. Observes a completed, consumed START
 * refusal before any native issuance, or a strictly fresh lifetime with the
 * prior genuine release's token/plan/FILE history unchanged. It never clears
 * FAILED, advances a request, grants capture, or admits partial-I/O recovery. */
int sp_p6_record_backend_v552_start_refused_no_io(void);
/* Actual SMPL only, after genuine full LEAVE/native sampler return. Detaches
 * only capture.backend; all old canonical payload, token/FILE history stays.
 * 1 newly detached,2 already exact,0 unavailable. */
int sp_p6_record_backend_v552_rearm(void);
/* Actual PANEL or SMPL read-only old-release observation before the other
 * source owners consume their old lifetime. No constructor/reset flag input. */
int sp_p6_record_backend_v552_detached(void);

#endif
