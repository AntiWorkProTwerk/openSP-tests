#ifndef SP_P6_RECORD_REQUEST_V552_H
#define SP_P6_RECORD_REQUEST_V552_H
#include "sp_synth_session_v552.h"

enum {
    SP_P6_RQ_EMPTY, SP_P6_RQ_ENABLE, SP_P6_RQ_SETUP, SP_P6_RQ_START,
    SP_P6_RQ_AVAILABLE, SP_P6_RQ_WORKING, SP_P6_RQ_REPLY, SP_P6_RQ_DONE
};
enum {
    SP_P6_RQ_IDENTITY=1, SP_P6_RQ_AUDIO=2, SP_P6_RQ_REQUEST=4,
    SP_P6_RQ_SERVICE=8, SP_P6_RQ_ADMISSION=16
};
typedef struct {
    atomic_uint phase, fault;
    uint32_t task, page, visit, intent;
    uint32_t audio_sequence, generation, working_generation;
    uint32_t control_calls, backend_takes, backend_finishes;
    uint32_t request_type, request_token, request_revision, destination;
} SpP6RecordRequestV552;
extern SpP6RecordRequestV552 sp_p6_record_request_v552;

/* Installed selected panel service. This owner consumes only the immutable
 * native RECORD intent and the audio owner's actual software-clock window.
 * No caller supplies a task, generation, ready flag, request or receipt. */
void sp_p6_record_request_v552_panel(void);
/* Installed native SMPL service. It acquires phase1 with the real backend-link
 * API, retains phase2, then publishes the same generation's honest refusal.
 * Production BEGIN remains unavailable. No native token or IO is fabricated. */
void sp_p6_record_request_v552_smpl(void);
/* Native SMPL only. Acquires the real available link once, or returns its
 * already retained exact phase2 request. The pointer remains canonical and
 * immutable until the sole backend publishes a result. It grants no BEGIN,
 * lease, file operation or success. Other owners receive NULL. */
const SpAppRequest *sp_p6_record_request_v552_claim(void);
/* Native SMPL only, after the sole backend's actual link_finish succeeds.
 * Observes the exact canonical request now phase0 and the matching published
 * response. Takes no completion, result, token or qualification argument. */
int sp_p6_record_request_v552_finished(void);
/* Observational request-side idleness only. This is not preview silence,
 * native recorder retirement, permission to delete a page or RELEASED. */
int sp_p6_record_request_v552_idle(void);
uint32_t sp_p6_record_request_v552_admission(void);
#endif
