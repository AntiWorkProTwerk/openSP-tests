#include "sp_p6_record_request_v552.h"
#include "sp_p6_record_audio_v552.h"
#include "sp_p6_session_binding_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_production_join.h"
#include <limits.h>
extern void sp_p6_record_direct_panel(void);

SpP6RecordRequestV552 sp_p6_record_request_v552;
_Static_assert(sizeof(SpP6RecordRequestV552)==64,"Compact request owner");
_Static_assert(sizeof(SpSynthSessionV552)==3824,"Current recording session ABI");
#define value(a) atomic_load_explicit((a),memory_order_acquire)
static uint32_t rd(uint32_t a) { return *(volatile const uint32_t *)(uintptr_t)a; }
static uint32_t task(void) {
    uint32_t i,p,b,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));
    __asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(b));
    __asm__ volatile("mrs %0,faultmask":"=r"(f));
    if(i || p || b || f || rd(0x202BBBF8) || rd(0x80245764))return 0;
    return ((uint32_t (*)(void))(uintptr_t)0x800D3163)();
}
static void fail(uint32_t reason) {
    atomic_fetch_or_explicit(&sp_p6_record_request_v552.fault,reason,memory_order_release);
}
static int identity(void) {
    SpP6RecordRequestV552 *o=&sp_p6_record_request_v552;
    SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    return value(&b->phase)==SP_P6_SB_PREPARED && !value(&b->fault) &&
        value(&b->pending)==o->intent && b->sequence==o->intent &&
        b->page==o->page && b->visit==o->visit && b->task==o->task &&
        m->voice_used==o->visit && value(&m->ready)==1 && !value(&m->terminal) &&
        value(&m->phase)==SP_PREVIEW_NATIVE_ACTIVE && !value(&m->entry.fault) &&
        (uintptr_t)atomic_load_explicit(&m->active_page,memory_order_acquire)==o->page &&
        rd(0x80CFD4FC)==o->page && o->page && rd(o->page)==(uintptr_t)(m->primary+2);
}
/* Strong retirement implementations exist only in the separately checked
 * full composition. This standalone owner cannot qualify deleted-page use. */
__attribute__((weak)) int sp_p6_record_retirement_v552_request_current(
    uint32_t visit,uint32_t intent,uint32_t generation,uint32_t audio_sequence) {
    (void)visit;(void)intent;(void)generation;(void)audio_sequence;return 0;
}
__attribute__((weak)) int sp_p6_record_retirement_v552_request_finished(
    uint32_t visit,uint32_t intent,uint32_t generation,uint32_t audio_sequence) {
    (void)visit;(void)intent;(void)generation;(void)audio_sequence;return 0;
}
static int backend_identity(int finished) {
    SpP6RecordRequestV552 *o=&sp_p6_record_request_v552;
    if(finished && o->request_type==SP_APP_REQUEST_LEAVE)
        return o->intent && o->audio_sequence && sp_p6_record_retirement_v552_request_finished(
            o->visit,o->intent,o->generation,o->audio_sequence);
    if(identity())return 1;
    if(o->request_type!=SP_APP_REQUEST_LEAVE || !o->intent || !o->audio_sequence)return 0;
    return finished?sp_p6_record_retirement_v552_request_finished(o->visit,o->intent,
        o->generation,o->audio_sequence):sp_p6_record_retirement_v552_request_current(
        o->visit,o->intent,o->generation,o->audio_sequence);
}
static SpSynthSessionV552 *backend_session(int finished) {
    SpSynthSessionV552 *s=sp_p6_record_audio_v552_session();
    if(s)return s;
    SpP6RecordRequestV552 *o=&sp_p6_record_request_v552;
    return o->request_type==SP_APP_REQUEST_LEAVE && backend_identity(finished)?
        &sp_p6_production_session:0;
}
static int between(SpSynthSessionV552 *s) {
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    SpSynthApp *a=&r->controller;
    return !value(&s->terminal) && !a->audio_pending && !a->audio_batch &&
        !a->audio_faulted && !a->event_count && !a->batch_failed &&
        !r->controls.count && !r->controls.faulted && !r->midi.count && !r->midi.fault &&
        value(&r->mailbox.phase)==SP_AUDIO_FREE && !value(&r->mailbox.stop_requested);
}
static int exact_request(const SpAppRequest *r) {
    SpP6RecordRequestV552 *o=&sp_p6_record_request_v552;
    SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
    return (uint32_t)r->type==o->request_type && r->generation==o->generation &&
        r->token==o->request_token && r->revision==o->request_revision &&
        ((uint32_t)r->index|((uint32_t)r->bank<<16)|((uint32_t)r->replace<<24))==o->destination &&
        r->capture.mode==0 && r->capture.seconds==120.0f &&
        r->capture.bars==(float)b->settings.bars &&
        r->capture.tempo_bpm==(float)b->pattern.tempo100*0.01f &&
        r->capture.count_in_bars==b->settings.count_in_bars &&
        !r->capture.include_release_tail && !r->release_start_frames && !r->tail_cut_reason;
}
static int remember(SpSynthApp *a) {
    SpP6RecordRequestV552 *o=&sp_p6_record_request_v552;
    if(!a->request_count)return 1;
    if(a->request_count!=1 || !a->audio_sequence)return 0;
    const SpAppRequest *r=&a->requests[0];
    sp_ui_command_type command;
    switch(r->type) {
    case SP_APP_REQUEST_CAPTURE_START:command=SP_UI_CMD_CAPTURE_START;break;
    case SP_APP_REQUEST_CAPTURE_STOP:command=SP_UI_CMD_CAPTURE_STOP;break;
    case SP_APP_REQUEST_DEST_QUERY:command=SP_UI_CMD_DEST_QUERY;break;
    case SP_APP_REQUEST_TAKE_WRITE:command=SP_UI_CMD_TAKE_WRITE;break;
    case SP_APP_REQUEST_TAKE_DISCARD:command=SP_UI_CMD_TAKE_DISCARD;break;
    case SP_APP_REQUEST_TAKE_RECOVER:command=SP_UI_CMD_TAKE_RECOVER;break;
    case SP_APP_REQUEST_LEAVE:command=SP_UI_CMD_LEAVE;break;
    case SP_APP_REQUEST_GLOBAL_STOP:command=SP_UI_CMD_GLOBAL_STOP;break;
    default:return 0;
    }
    if(command==SP_UI_CMD_LEAVE || command==SP_UI_CMD_GLOBAL_STOP) {
        if(r->generation || r->token || r->revision || r->index || r->bank || r->replace ||
           (command==SP_UI_CMD_LEAVE && (a->ui.page!=SP_UI_INACTIVE || a->ui.busy)) ||
           (command==SP_UI_CMD_GLOBAL_STOP && !a->ui.shift))return 0;
    } else if(!r->generation || r->generation!=a->ui.generation || !a->ui.busy ||
       a->ui.pending!=command || (o->generation && r->generation<o->generation) ||
       r->revision!=a->ui.revision ||
       r->index!=a->ui.dest_pad || r->bank!=a->ui.dest_bank || r->index<1 || r->index>16 ||
       r->bank>9 || r->replace>1)return 0;
    if(command==SP_UI_CMD_CAPTURE_STOP) {
        if(!a->capture_progress.start_generation || !a->capture_progress.take_token ||
           r->token!=a->capture_progress.take_token || a->ui.page!=SP_UI_RECORDING)return 0;
    } else if(command!=SP_UI_CMD_LEAVE && command!=SP_UI_CMD_GLOBAL_STOP &&
              r->token!=a->ui.take_token)return 0;
    o->generation=r->generation;o->audio_sequence=a->audio_sequence;
    o->request_type=r->type;o->request_token=r->token;o->request_revision=r->revision;
    o->destination=(uint32_t)r->index|((uint32_t)r->bank<<16)|((uint32_t)r->replace<<24);
    return exact_request(r);
}
void sp_p6_record_request_v552_panel(void) {
    SpP6RecordRequestV552 *o=&sp_p6_record_request_v552;
    SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
    uint32_t id=task();
    if(!id || id!=b->task || id!=rd(0x8300A3E8) || value(&o->fault) ||
       value(&b->phase)!=SP_P6_SB_PREPARED || !value(&b->pending))return;
    SpSynthSessionV552 *s=sp_p6_record_audio_v552_session();
    if(!s)return;
    uint32_t target;
    if(!sp_p6_record_audio_v552_control_window(&target))return;
    SpSynthRuntimeStorage *r=s->startup.memory.storage;
    unsigned phase=value(&o->phase);
    if(phase==SP_P6_RQ_EMPTY) {
        if(!b->sequence || b->sequence!=value(&b->pending) || !between(s) ||
           r->controller.request_count || r->controller.request_issued_generation ||
           value(&s->backend.request_phase) || value(&s->backend.responses.phase) ||
           b->settings.mode!=SP_P6_PHRASE_MANUAL || !b->settings.bars ||
           b->settings.count_in_bars>8 || !b->pattern.tempo100)goto done;
        o->task=id;o->page=b->page;o->visit=b->visit;o->intent=b->sequence;
        if(!identity()) {fail(SP_P6_RQ_IDENTITY);goto done;}
        /* This staged silent app domain cannot release the separate preview
         * engine. The first native test deliberately excludes release tails. */
        if(!sp_p6_phrase_capture_profile(&b->settings,b->pattern.tempo100,&r->controller.capture)) {
            fail(SP_P6_RQ_SERVICE);goto done;
        }
        r->controller.ui.dest_pad=(uint16_t)b->settings.destination_pad;
        r->controller.ui.dest_bank=(uint8_t)b->settings.destination_bank;
        if(!sp_synth_session_v552_enable(s,1,0)) {fail(SP_P6_RQ_SERVICE);goto done;}
        atomic_store_explicit(&o->phase,SP_P6_RQ_ENABLE,memory_order_release);
    } else if(!backend_identity(0)) {fail(SP_P6_RQ_IDENTITY);goto done;}
    /* A matching finish must be observed by SMPL before control can borrow its
     * response. This closes finish-publication/preemption without a new slot. */
    if(value(&o->phase)==SP_P6_RQ_WORKING || value(&o->phase)==SP_P6_RQ_AVAILABLE)goto done;
    phase=value(&o->phase);
    if((phase==SP_P6_RQ_SETUP || phase==SP_P6_RQ_START || phase==SP_P6_RQ_DONE || phase==SP_P6_RQ_REPLY) &&
       !value(&s->backend.request_phase) && !remember(&r->controller)) {
        fail(SP_P6_RQ_REQUEST);goto done;
    }
    if(o->control_calls==UINT32_MAX) {fail(SP_P6_RQ_SERVICE);goto done;}
    ++o->control_calls;
    if(sp_synth_session_v552_control(s,target)==SP_CONTROL_STOPPED) {
        fail(SP_P6_RQ_SERVICE);goto done;
    }
    phase=value(&o->phase);
    if(phase==SP_P6_RQ_ENABLE) {
        if(!between(s) || !r->controller.audio_sequence ||
           !sp_p6_record_audio_v552_acknowledged(r->controller.audio_sequence))goto done;
        /* The first native REC intent arms the existing capture page after
         * enable acknowledgment. START needs the next offered physical press. */
        sp_ui_event event={.type=SP_UI_REC_PRESS};
        if(!sp_synth_session_v552_route(s,&event)) {fail(SP_P6_RQ_SERVICE);goto done;}
        atomic_store_explicit(&o->phase,SP_P6_RQ_SETUP,memory_order_release);
    } else if(phase==SP_P6_RQ_SETUP) {
        if(!r->controller.request_count)goto done;
        /* The existing control queue/app produced this request. Retain its
         * canonical generation, destination and audio acknowledgment before
         * the original backend service can publish it on the next visit. */
        if(!remember(&r->controller) || o->request_type!=SP_APP_REQUEST_CAPTURE_START) {
            fail(SP_P6_RQ_REQUEST);goto done;
        }
        atomic_store_explicit(&o->phase,SP_P6_RQ_START,memory_order_release);
    } else if(phase==SP_P6_RQ_START || phase==SP_P6_RQ_DONE || phase==SP_P6_RQ_REPLY) {
        if(value(&s->backend.request_phase)==1) {
            if(!o->audio_sequence ||
               !sp_p6_record_audio_v552_acknowledged(o->audio_sequence) ||
               !exact_request(&s->backend.request) ||
               r->controller.request_issued_generation!=o->generation) {
                fail(SP_P6_RQ_REQUEST|SP_P6_RQ_AUDIO);goto done;
            }
            atomic_store_explicit(&o->phase,SP_P6_RQ_AVAILABLE,memory_order_release);
        } else {
            if(!remember(&r->controller)) {fail(SP_P6_RQ_REQUEST);goto done;}
            if(phase==SP_P6_RQ_REPLY && !value(&s->backend.responses.phase) &&
               !r->controller.request_count && !r->controller.request_issued_generation && between(s) &&
               sp_p6_record_audio_v552_acknowledged(r->controller.audio_sequence))
                atomic_store_explicit(&o->phase,SP_P6_RQ_DONE,memory_order_release);
        }
    }
done:
    sp_p6_record_direct_panel();
    sp_p6_record_audio_v552_control_done();
}
const SpAppRequest *sp_p6_record_request_v552_claim(void) {
    SpP6RecordRequestV552 *o=&sp_p6_record_request_v552;
    if(value(&o->fault) || !sp_p6_record_context_v552_current(1) || !backend_identity(0))return 0;
    SpSynthSessionV552 *s=backend_session(0);
    if(!s)return 0;
    unsigned phase=value(&o->phase);
    if(phase==SP_P6_RQ_AVAILABLE) {
        int audio=o->request_type==SP_APP_REQUEST_LEAVE?
            sp_p6_record_audio_v552_stop_current(o->visit,o->intent,o->audio_sequence):
            sp_p6_record_audio_v552_acknowledged(o->audio_sequence);
        if(!audio ||
           !exact_request(&s->backend.request) || value(&s->backend.request_phase)!=1)return 0;
        if(o->backend_takes==UINT32_MAX) {fail(SP_P6_RQ_REQUEST);return 0;}
        SpAppRequest request;
        if(!sp_synth_backend_link_take(&s->backend,&request))return 0;
        if(!exact_request(&request)) {fail(SP_P6_RQ_REQUEST);return 0;}
        o->working_generation=request.generation;++o->backend_takes;
        atomic_store_explicit(&o->phase,SP_P6_RQ_WORKING,memory_order_release);
    } else if(phase!=SP_P6_RQ_WORKING)return 0;
    if(value(&s->backend.request_phase)!=2 || !exact_request(&s->backend.request) ||
       o->working_generation!=o->generation) {fail(SP_P6_RQ_REQUEST);return 0;}
    return &s->backend.request;
}
int sp_p6_record_request_v552_finished(void) {
    SpP6RecordRequestV552 *o=&sp_p6_record_request_v552;
    if(value(&o->fault) || !sp_p6_record_context_v552_current(1) || !backend_identity(1) ||
       value(&o->phase)!=SP_P6_RQ_WORKING)return 0;
    SpSynthSessionV552 *s=backend_session(1);
    if(!s || value(&s->backend.request_phase) ||
       value(&s->backend.responses.stopped) || !exact_request(&s->backend.request) ||
       o->working_generation!=o->generation)return 0;
    if(o->generation ? (value(&s->backend.responses.phase)!=1 ||
        s->backend.responses.completion.generation!=o->working_generation) :
        value(&s->backend.responses.phase)!=0)return 0;
    if(o->backend_finishes==UINT32_MAX) {fail(SP_P6_RQ_REQUEST);return 0;}
    ++o->backend_finishes;
    atomic_store_explicit(&o->phase,o->generation?SP_P6_RQ_REPLY:SP_P6_RQ_DONE,memory_order_release);
    return 1;
}
void sp_p6_record_request_v552_smpl(void) {
    SpP6RecordRequestV552 *o=&sp_p6_record_request_v552;
    unsigned phase=value(&o->phase);
    const SpAppRequest *request=sp_p6_record_request_v552_claim();
    if(!request || phase==SP_P6_RQ_AVAILABLE)return;
    SpSynthSessionV552 *s=sp_p6_record_audio_v552_session();
    if(!s)return;
    if(phase==SP_P6_RQ_WORKING) {
        if(request->type!=SP_APP_REQUEST_CAPTURE_START)return;
        if(value(&s->backend.request_phase)!=2 || !exact_request(&s->backend.request) ||
           o->working_generation!=o->generation) {fail(SP_P6_RQ_REQUEST);return;}
        /* No backend IO ran. Its actual source admission is permanently zero;
         * retain the canonical phase2 request until the real finish publishes. */
        if(sp_p6_production_admission() || sp_p6_session_binding_v552_admission()) {
            fail(SP_P6_RQ_ADMISSION);return;
        }
        const SpAppCompletion result={.generation=o->working_generation,
            .error=SP_UI_ERR_CAPTURE};
        if(!sp_synth_backend_link_finish(&s->backend,&result))return;
        (void)sp_p6_record_request_v552_finished();
    }
}
int sp_p6_record_request_v552_idle(void) {
    SpP6RecordRequestV552 *o=&sp_p6_record_request_v552;
    SpSynthSessionV552 *s=backend_session(1);
    return s && task()==o->task && !value(&o->fault) && value(&o->phase)==SP_P6_RQ_DONE && backend_identity(1) &&
        between(s) && !value(&s->backend.request_phase) && !value(&s->backend.responses.phase) &&
        !s->startup.memory.storage->controller.request_count &&
        !s->startup.memory.storage->controller.request_issued_generation;
}
uint32_t sp_p6_record_request_v552_admission(void) { return 0; }
