#ifndef SP_P6_RECORD_RETIREMENT_JOIN_V552_H
#define SP_P6_RECORD_RETIREMENT_JOIN_V552_H
#include <stdint.h>
enum { SP_P6_RJ_POLICY=1,SP_P6_RJ_SESSION=2,SP_P6_RJ_HOOK=4,
       SP_P6_RJ_DESTINATION=8,SP_P6_RJ_IDENTITY=16 };
/* Actual source policy and selected entry coverage, bounded to the first test.
 * This is not total native coverage, acquisition or a caller ready setter. */
uint32_t sp_p6_record_retirement_join_v552_bounded_blocks(void);
/* Old genuinely released epoch, before normal reentry clears its quiet ticket.
 * Called by native SMPL before backend detach, or PANEL after detach. */
int sp_p6_record_retirement_v552_rearm_ready(void);
/* Source-observed new app reentry, fresh actual RECORD intent and preview
 * activation. Consumes only the old retirement phase; preserves history. */
int sp_p6_record_retirement_v552_rearm_commit(void);
/* Fresh rearmed recording visit with no new native take, retaining the exact
 * genuinely released old cleanup/token history. Pure source observation. */
int sp_p6_record_retirement_v552_rearmed_no_io(void);
/* Supplied by the source rearm owner; absence conservatively refuses a new
 * Generator until the old released park receipt has been consumed. */
int sp_p6_record_rearm_v552_preconstructed(void);
#endif
