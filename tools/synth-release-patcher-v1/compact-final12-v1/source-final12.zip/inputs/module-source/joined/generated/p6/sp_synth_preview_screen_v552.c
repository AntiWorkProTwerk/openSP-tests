#include "sp_p6_pattern_transport_v552.h"
#include "sp_synth_preview_native_v552.h"
#include "sp_synth_preview_view_v552.h"
#include "sp_synth_page_v552.h"
#include "sp_p6_view.h"
#include "sp_p6_record_controls_v552.h"
#include "sp_demo_v552.h"
#include <stddef.h>

/* Permanent selected-UI-owner storage. Preserve the P5 owner names/ABIs for
 * integration checks. No control or display hook reads audio-owned DSP state. */
static sp_synth_page_v552 screen;
static SpPreviewVisualReader p5_visual_reader;
static SpPreviewVisualSnapshot p5_visual_snapshot;
static sp_ui_view p5_fallback_view;
static uint8_t p5_present_busy;
static SpP6MenuView p6_menu_copy;
static SpDemoMeta p6_demo_meta;
static uint32_t p6_frame_sequence;

static void capture(const SpPreviewNativeView *v,const SpPreviewVisualSnapshot *s) {
    if(p6_frame_sequence==UINT32_MAX)return;
    p6_demo_meta=(SpDemoMeta){0};
    p6_demo_meta.frame_sequence=++p6_frame_sequence;
    p6_demo_meta.command_ticket=v->controls.command_ticket;
    p6_demo_meta.command_ack=v->controls.command_ack;
    p6_demo_meta.preset=(uint8_t)v->controls.preset;
    p6_demo_meta.page=(uint8_t)v->controls.page;
    p6_demo_meta.requested_mono=(uint8_t)v->controls.mono;
    p6_demo_meta.octave=(int8_t)v->controls.octave;
    p6_demo_meta.visual_flags=SP_VISUAL_FALLBACK|SP_VISUAL_SILENT;
    /* pcm_end_frame=0 is the no-completed-window state. Applied labels in
     * that bitmap say WAIT; zero metadata is not an audio acknowledgment. */
    if(s){
        p6_demo_meta.command_ticket=s->command_ticket;
        p6_demo_meta.pcm_end_frame=s->frame_sequence;
        p6_demo_meta.applied_preset=s->applied_preset;
        p6_demo_meta.applied_mono=s->applied_mono;
        p6_demo_meta.active_voices=s->active_voices;
        p6_demo_meta.visual_flags=s->flags;
        for(unsigned i=0;i<4;++i){
            p6_demo_meta.envelope[i]=s->envelope[i];
            p6_demo_meta.envelope_stage[i]=s->envelope_stage[i];
            p6_demo_meta.envelope_progress[i]=s->envelope_progress[i];
        }
    }
    /* The adapter adds retained input state/ticks. This is the exact frame
     * accepted by the native widget, before foreign native overlays. */
    sp_demo_v552_capture(screen.scratch.bytes,&p6_demo_meta);
}
int sp_synth_preview_native_v552_present(void *page,const SpPreviewNativeView *view) {
    if(!page || !view)return 0;
    if(p5_present_busy)return 1;
    p5_present_busy=1;
    int result=0;
    if(view->state!=SP_PREVIEW_NATIVE_ACTIVE){
        if(!sp_synth_preview_view_v552_build(view->state,view->choice,view->fault,&p5_fallback_view)){
            sp_synth_page_v552_detach(&screen);result=1;
        }else result=sp_synth_page_v552_after_entry(&screen,page,&p5_fallback_view,NULL)!=0;
    }else{
        if(!p5_visual_reader.initialized)sp_synth_preview_visual_reader_init(&p5_visual_reader);
        SpPreviewVisualResult read=sp_synth_preview_voice_visual_read(
            &sp_synth_preview_native_v552.voice,&p5_visual_reader,&p5_visual_snapshot);
        const SpPreviewVisualSnapshot *snapshot=read==SP_VISUAL_INVALID ||
            !p5_visual_snapshot.sequence?NULL:&p5_visual_snapshot;
        if(sp_p6_menu_snapshot(&p6_menu_copy) &&
           sp_p6_view_render(view,snapshot,&p6_menu_copy,screen.scratch.bytes)){
            (void)sp_p6_record_controls_v552_render(view,snapshot,screen.scratch.bytes);
            (void)sp_p6_pattern_transport_v552_draw(screen.scratch.bytes);
            if(!(screen.widget && screen.page!=page)){
                if(!screen.widget){
                    screen.page=NULL;
                    if(sp_synth_widget_v552_add_owned((uint8_t *)page+56,&screen.widget))screen.page=page;
                }
                if(screen.widget && screen.page==page){
                    result=sp_synth_widget_v552_update(screen.widget,&screen.scratch)!=0;
                    if(result)capture(view,snapshot);
                }
            }
        }
    }
    p5_present_busy=0;
    return result;
}
void sp_synth_preview_native_v552_detach(void *page) {
    if(screen.page==page)sp_synth_page_v552_detach(&screen);
}
void sp_synth_preview_native_v552_retire(void *page) {
    if(screen.page==page){screen.widget=NULL;screen.page=NULL;}
}
