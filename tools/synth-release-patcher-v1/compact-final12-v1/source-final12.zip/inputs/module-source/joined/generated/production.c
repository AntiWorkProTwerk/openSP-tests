#include "sp_p6_record_start_gate_v552.h"
#include "sp_p6_production_join.h"
#include "sp_p6_session_binding_v552.h"
#include "sp_p6_record_request_v552.h"
#include "sp_p6_native_service_v552.h"
#include "sp_p6_session_join.h"
#include "sp_p6_record_joint_v552.h"
#include "sp_p6_record_fullbar_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_producer_v552.h"
#include <stdatomic.h>

/* Stock scatter zero record10 owns this reservation before the early pool
 * call. One joint clear covers every linked owner. Page visits never clear it. */
typedef struct {
    atomic_uint cold, bootstrap, fault;
    uint64_t result;
} SpP6ProductionState;
SpP6ProductionState sp_p6_production_state;
SpSynthCaptureTimedV552 sp_p6_production_capture;
SpSynthSessionV552 sp_p6_production_session;
_Static_assert(sizeof(SpSynthCaptureTimedV552)==1336,"Sealed timed capture ABI");
_Static_assert(sizeof(SpSynthSessionV552)==3824,"Permanent session ABI");

uint32_t sp_p6_production_admission(void) { return sp_p6_record_start_gate_v552_admit(); }
uint32_t sp_p6_production_cold_started(void) {
    return atomic_load_explicit(&sp_p6_production_state.cold,memory_order_acquire);
}
uint64_t sp_p6_production_cold_result(void) { return sp_p6_production_state.result; }
void sp_p6_production_cold_done(uint64_t result) {
    sp_p6_production_state.result=result;
    atomic_store_explicit(&sp_p6_production_state.cold,1,memory_order_release);
}
void sp_p6_production_smpl(void) {
    SpP6ProductionState *p=&sp_p6_production_state;
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(!sp_p6_production_cold_started() ||
       atomic_load_explicit(&p->fault,memory_order_acquire) ||
       !sp_p6_record_context_v552_current(1))return;
    uint32_t phase=atomic_load_explicit(&p->bootstrap,memory_order_acquire);
    if(!phase) {
        if(atomic_load_explicit(&m->ready,memory_order_acquire)!=1 ||
           atomic_load_explicit(&m->terminal,memory_order_acquire))return;
        /* Consume this initialization attempt before any source publication. */
        atomic_store_explicit(&p->bootstrap,1,memory_order_release);
        if(!sp_p6_native_service_v552_install() || !sp_synth_capture_timed_v552_init(&sp_p6_production_capture,48000) ||
           !sp_p6_record_joint_v552_bind(&m->voice,m->scratch.stereo)) {
            atomic_fetch_or_explicit(&p->fault,1,memory_order_release);return;
        }
        atomic_store_explicit(&p->bootstrap,2,memory_order_release);
    }
    if(atomic_load_explicit(&p->bootstrap,memory_order_acquire)==2)
        (void)sp_p6_native_service_v552_smpl();
    sp_p6_session_binding_v552_smpl();
    /* Sole timed backend owns the retained request and finish. */
    /* Panel wait may prepare private storage. Public readiness and backend
     * request publication stay unavailable. BEGIN refuses until the complete
     * native audio/control/backend/retirement contract is established. */
}
void sp_p6_production_pcm(const SpSynthPreviewVoice *voice,const int16_t *pcm,uint32_t frames) {
    if(atomic_load_explicit(&sp_p6_production_state.bootstrap,memory_order_acquire)==2 &&
       !atomic_load_explicit(&sp_p6_production_state.fault,memory_order_acquire))
    {
        if(sp_p6_record_joint_v552_pcm(voice,pcm,frames))
            sp_p6_native_service_v552_pcm(frames);
    }
}
/* Full-session retirement is supplied by the bounded owned component. */
