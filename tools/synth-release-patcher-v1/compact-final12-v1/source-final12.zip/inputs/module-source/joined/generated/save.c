#include "sp_p6_save_handover_v552.h"
#include <limits.h>
#define SP_P6_SAVE_ROW_COUNT 15u
#define SP_P6_SAVE_ROW(i) (&sp_p6_record_files_v552.files[i])
#include "sp_p6_record_fullbar_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_token_v552.h"
#include "sp_p6_record_producer_v552.h"
#include <string.h>
#define OUTER 0x82E0E71Cu
#define NORMAL 0x82FE4F08u
#define PARAM 0x82E2CD08u
#define META 0x82E495E4u
#define POOL 0x82E111C8u
#define TABLE 0x80B5F3B4u
#define RECORD 0x202ACFA0u
SpP6SaveHandoverV552 sp_p6_save_handover_v552;
_Static_assert(sizeof(SpP6SaveHandoverV552)==332,"SAVE receipt budget");
static uint32_t rd(uint32_t p) { return *(volatile const uint32_t *)(uintptr_t)p; }
static uint8_t byte(uint32_t p) { return *(volatile const uint8_t *)(uintptr_t)p; }
static void wr(uint32_t p,uint32_t v) { *(volatile uint32_t *)(uintptr_t)p=v; }
static uint32_t val(const atomic_uint *p) { return atomic_load_explicit(p,memory_order_acquire); }
static uint32_t native(uint32_t p,uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return ((uint32_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(uintptr_t)(p|1u))(a,b,c,d);
}
static int unmasked(void) {
    uint32_t p,f;__asm__ volatile("mrs %0, primask":"=r"(p));
    __asm__ volatile("mrs %0, faultmask":"=r"(f));return !p && !f;
}
static int smpl(void) { return unmasked() && !rd(0x202BBBF8u) && sp_p6_record_context_v552_current(1); }
static int fail(uint32_t why) {
    sp_p6_save_handover_v552.fault|=why;sp_p6_save_handover_v552.state=SP_P6_SAVE_FAULT;return -1;
}
static int exact(void) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;SpSynthCaptureTimedV552 *c=s->capture;
    return smpl() && c && !s->fault && s->token && val(&c->token)==s->token &&
        c->last_token==s->token && c->plan.take_token==s->token &&
        c->plan.start_generation==s->generation && !val(&c->fault) && !val(&c->handoff_fault) &&
        !val(&c->rx_active) && val(&c->rx_ack)==s->token && !c->window.inflight &&
        c->window.start.take_token==s->token && c->window.accepted_frames==s->frames &&
        sp_p6_record_token_v552_actual_token()==s->token &&
        sp_p6_record_files_v552.project==s->project && sp_p6_record_files_v552.pad==s->pad;
}
int sp_p6_save_v552_bind(SpSynthCaptureTimedV552 *c) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    uintptr_t p=(uintptr_t)c,q=(uintptr_t)s;
    if(s->capture || p<0x80000000u || p>0x84000000u-sizeof(*c) || (p&7u) ||
       !(p+sizeof(*c)<=q || q+sizeof(*s)<=p) || sp_p6_record_producer_v552.capture!=c ||
       val(&c->state)!=SP_TCAP_FREE || val(&c->token) || !smpl())return 0;
    s->capture=c;return 1;
}
static int empty_pad(uint32_t pad) {
    if(native(0x800DC6B8u,PARAM,101,pad,0) || native(0x800D8998u,pad,0,0,0))return 0;
    for(unsigned i=0;i<38;i++)if(byte(POOL+304*pad+8*i) || rd(POOL+304*pad+8*i+4)!=UINT32_MAX)return 0;
    return 1;
}
static int metadata(void) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    return native(0x800DC6B8u,PARAM,101,s->pad,0)==2 &&
        native(0x800DC6B8u,PARAM,103,s->pad,0)==0 &&
        native(0x800DC6B8u,PARAM,104,s->pad,0)==s->frames &&
        rd(PARAM+208+172*s->pad) && rd(PARAM+212+172*s->pad)==512 &&
        rd(PARAM+216+172*s->pad)==s->bytes && rd(META+16+36*s->pad)==s->bytes;
}
static int snapshot(int remember) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    const void *r=(const void *)(uintptr_t)(PARAM+208+172*s->pad);
    const void *m=(const void *)(uintptr_t)(META+36*s->pad);
    const void *n=(const void *)(uintptr_t)(PARAM+27900+24*s->pad);
    if(remember) { memcpy(s->record,r,172);memcpy(s->metadata,m,36);memcpy(s->name,n,24);return 1; }
    return !memcmp(s->record,r,172) && !memcmp(s->metadata,m,36) && !memcmp(s->name,n,24);
}

static int cache_pool(uint32_t pad,uint32_t fd[3],uint32_t file[3]) {
    if(pad>=160)return 0;
    for(unsigned i=0;i<3;i++) {
        uint32_t p=POOL+304*pad+8*i;
        if(byte(p))return 0;
        fd[i]=rd(p+4);
        if(fd[i]<1 || fd[i]>=1024)return 0;
        file[i]=rd(TABLE+4*fd[i]);
        if(file[i]<0x80000000u || file[i]>=0x84000000u || !(rd(file[i])&1u))return 0;
        for(unsigned j=0;j<i;j++)if(fd[i]==fd[j] || file[i]==file[j])return 0;
    }
    for(unsigned i=3;i<38;i++) {
        uint32_t p=POOL+304*pad+8*i;
        if(byte(p) || rd(p+4)!=UINT32_MAX)return 0;
    }
    return 1;
}
static int cache_row_shape(const SpP6RecordFileIdentityV552 *f,uint32_t fd,uint32_t file,
                           uint32_t context) {
    return f && f->kind==SP_P6_RF_CACHE && f->state==SP_P6_RF_LIVE &&
        f->fd==fd && f->file==file && f->context && f->context==context &&
        f->task==rd(0x202ACD04u) && f->operation==SP_P6_RF_SAVE &&
        f->calls==1 && !f->close_attempted && f->close_raw==INT32_MIN &&
        !f->directory_context && f->fd<1024 && f->file>=0x80000000u &&
        f->file<0x84000000u && rd(TABLE+4*f->fd)==f->file && (rd(f->file)&1u);
}
static int cache_rows_live(SpP6SaveHandoverV552 *s,
                           SpP6RecordFileIdentityV552 *slot_rows[3],int compare_primary) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    uint32_t fd[3],file[3],context=0;unsigned cache_count=0;
    slot_rows[0]=slot_rows[1]=slot_rows[2]=0;
    if(!s || !o->active || o->fault || o->record_operation || o->cache_depth ||
       o->project!=s->project || o->pad!=s->pad || !cache_pool(s->pad,fd,file))return 0;
    for(unsigned i=0;i<SP_P6_SAVE_ROW_COUNT;++i) {
        SpP6RecordFileIdentityV552 *f=SP_P6_SAVE_ROW(i);
        if(!f)return 0;
        if(f->kind!=SP_P6_RF_CACHE)continue;
        if(cache_count>=3)return 0;
        unsigned slot=3;
        for(unsigned j=0;j<3;j++)if(f->fd==fd[j]) {
            if(slot!=3)return 0;
            slot=j;
        }
        if(slot>=3 || slot_rows[slot] || f->file!=file[slot] ||
           (cache_count && f->context!=context))return 0;
        if(!cache_row_shape(f,fd[slot],file[slot],cache_count?context:f->context))return 0;
        context=f->context;slot_rows[slot]=f;cache_count++;
    }
    if(cache_count!=3 || !slot_rows[0] || !slot_rows[1] || !slot_rows[2])return 0;
    if(compare_primary && memcmp(&s->cache,slot_rows[0],sizeof(s->cache)))return 0;
    return 1;
}

static int journal(int remember,unsigned expected_projects,int inflight) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    unsigned project=0,temp=0,readers=0,project_readers=0,directories=0,missing=0;
    SpP6RecordFileIdentityV552 *cache_rows[3];
    if(!o->active || o->fault || o->smpl_operation!=(inflight?SP_P6_RF_SAVE:0u) ||
       o->record_operation || o->cache_depth ||
       o->project!=s->project || o->pad!=s->pad)return 0;
    for(unsigned i=0;i<SP_P6_SAVE_ROW_COUNT;++i) {
        SpP6RecordFileIdentityV552 *f=SP_P6_SAVE_ROW(i);if(!f->kind)continue;
        if(f->kind==SP_P6_RF_CACHE) {
            /* Cache rows are checked as a complete slot/FD/FILE set below. */
            continue;
        } else {
            if(f->state!=SP_P6_RF_CLOSED || f->close_raw)return 0;
            if(f->kind==SP_P6_RF_TEMP)temp++;
            if(f->kind==SP_P6_RF_PROJECT) { project++;if(f->calls!=(s->capture->project_write.write_count+1u+(s->capture->project_write.sync_raw==0)) || f->close_attempted!=3)return 0; }
            if(f->kind==SP_P6_RF_READER)readers++;
            if(f->kind==SP_P6_RF_DIRECTORY)directories++;
            if(f->kind==SP_P6_RF_PROJECT_READER) {
                project_readers++;
                if(f->fd==UINT32_MAX) {
                    if(f->file || f->calls || f->close_attempted)return 0;
                    missing++;
                } else if(f->fd<1 || f->fd>=1024 || !f->file ||
                          f->close_attempted!=3)return 0;
            }
        }
    }
    if(project!=expected_projects || temp!=1 ||
       readers!=(inflight?1u:2u) || project_readers!=expected_projects ||
       missing>1 || directories!=4u+missing ||
       !cache_rows_live(s,cache_rows,!remember))return 0;
    if(remember)s->cache=*cache_rows[0];
    return !memcmp(&s->cache,cache_rows[0],sizeof(s->cache));
}

static int project_complete(void) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    SpSynthProjectSaveV552 *g=&s->capture->project_write;
    return g->magic==UINT32_C(0x50534731) && g->last_token==s->token &&
        g->token==s->token && g->project==s->project && g->task==rd(UINT32_C(0x202ACD04)) &&
        !g->fault && !g->terminal &&
        g->alloc_count==2 && g->allocations[0] && g->allocations[1] && g->free_mask==3 &&
        g->write_count==64 && g->bytes==52000 && g->stat_seen==1 && g->close_attempted==1 &&
        g->fd==-1 && !g->file && g->open_raw>=1 && g->open_raw<1024 &&
        !g->stat_raw && !g->sync_raw && !g->close_raw && g->native_raw==1 &&
        g->size_low==52000 && !g->size_high;
}
/* Source-only admission for the same actual take's second native leg. */
SpSynthProjectSaveV552 *sp_p6_save_two_leg_v552_second(void) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    if(!exact() || s->state!=SP_P6_SAVE_WRITING || s->project_seen!=3 ||
       s->project_bytes!=52000 || s->capture->project_calls!=2 || s->capture->project_raw!=1 ||
       val(&s->capture->state)!=SP_TCAP_SAVING || !project_complete() ||
       !metadata() || !snapshot(0) || !journal(0,1,1))return NULL;
    return &s->capture->project_write;
}
/* No count promotion unless both source-owned native legs have completed. */
SpSynthCaptureTimedV552 *sp_p6_save_two_leg_v552_complete(void) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    unsigned legs=s->project_seen==6?1u:(s->project_seen==4?2u:0u);
    if(!legs || !exact() || s->state!=SP_P6_SAVE_WRITING ||
       s->project_bytes!=52000u*legs || s->capture->project_calls!=legs || s->capture->project_raw!=1 ||
       val(&s->capture->state)!=SP_TCAP_SAVING || !project_complete() ||
       !metadata() || !snapshot(0) || !journal(0,legs,0))return NULL;
    return s->capture;
}
uint32_t sp_p6_save_v552_project(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    uintptr_t caller=(uintptr_t)__builtin_return_address(0);
    if(caller==UINT32_C(0x8017F695)) {
        if(s->state!=SP_P6_SAVE_WRITING) {
            if(s->fault || (s->capture && s->token && val(&s->capture->token)==s->token))return UINT32_MAX;
            return native(0x800C1E98u,a,b,c,d);
        }
        if(!exact() || s->project_seen!=2 || s->project_bytes!=52000 ||
           s->capture->project_calls!=1 || s->capture->project_raw!=1 ||
           val(&s->capture->state)!=SP_TCAP_SAVING || !project_complete() ||
           !metadata() || !snapshot(0) || !journal(0,1,1) || b ||
           a!=*(volatile const uint16_t *)(uintptr_t)(OUTER+32)) {
            (void)fail(SP_P6_SAVE_IDENTITY);return UINT32_MAX;
        }
        /* The installed stock caller consumes this same actual query result.
         * Six is a completed unlimited leg; seven requires the second leg. */
        uint32_t result=native(0x800C1E98u,a,b,c,d);
        if(!exact() || !project_complete() || !metadata() || !snapshot(0) ||
           !journal(0,1,1) || (result!=UINT32_C(0xFFFE7960) && (int32_t)result<=0)) {
            (void)fail(SP_P6_SAVE_IDENTITY);return UINT32_MAX;
        }
        s->project_seen=result==UINT32_C(0xFFFE7960)?6u:7u;
        return result;
    }
    if(s->state!=SP_P6_SAVE_WRITING) {
        if(s->fault || (s->capture && s->token && val(&s->capture->token)==s->token))return 0;
        return native(0x800CF218u,a,b,c,d);
    }
    if(!exact() || a!=PARAM || (b!=s->project && b!=UINT32_MAX) ||
       val(&s->capture->state)!=SP_TCAP_SAVING) {
        (void)fail(SP_P6_SAVE_IDENTITY);return 0;
    }
    if(s->project_seen==0) {
        if(caller!=UINT32_C(0x8017F68D) || s->capture->project_calls ||
           s->project_bytes || !metadata()) {
            (void)fail(SP_P6_SAVE_IDENTITY);return 0;
        }
        snapshot(1);s->project_seen=1;s->capture->project_calls=1;
        s->capture->project_raw=sp_synth_project_save_v552_run(&s->capture->project_write,s->token,s->project);
        if(!exact() || s->capture->project_raw!=1 || !project_complete()) {
            (void)fail(SP_P6_SAVE_IO);return 0;
        }
        if(!metadata() || !snapshot(0) || !journal(1,1,1)) {
            (void)fail(SP_P6_SAVE_METADATA);return 0;
        }
        s->project_bytes=52000;s->project_seen=2;return 1;
    }
    if(s->project_seen==7) {
        if(caller!=UINT32_C(0x8017F72B) || s->capture->project_calls!=1 ||
           s->project_bytes!=52000 || s->capture->project_raw!=1 || !project_complete() ||
           !metadata() || !snapshot(0) || !journal(0,1,1)) {
            (void)fail(SP_P6_SAVE_IDENTITY);return 0;
        }
        s->project_seen=3;s->capture->project_calls=2;
        s->capture->project_raw=sp_synth_project_save_v552_run(&s->capture->project_write,s->token,s->project);
        if(!exact() || s->capture->project_raw!=1 || !project_complete()) {
            (void)fail(SP_P6_SAVE_IO);return 0;
        }
        if(!metadata() || !snapshot(0) || !journal(0,2,1)) {
            (void)fail(SP_P6_SAVE_METADATA);return 0;
        }
        s->project_bytes=104000;s->project_seen=4;return 1;
    }
    (void)fail(SP_P6_SAVE_IDENTITY);return 0;
}

int sp_p6_save_v552_write(SpSynthCaptureTimedV552 *c,uint32_t pad) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    if(!c || c!=s->capture || (s->state!=SP_P6_SAVE_IDLE && s->state!=SP_P6_SAVE_TRANSFERRED) ||
       s->fault || !smpl() || pad>=160 || val(&c->state)!=SP_TCAP_HELD || c->sample_rate_hz!=48000 ||
       !c->file_owned || c->window.accepted_frames<1000 || c->window.accepted_frames>(UINT32_MAX-512u)/4u ||
       val(&c->rx_active) || c->window.inflight || val(&c->rx_ack)!=val(&c->token) || !empty_pad(pad))return 0;
    if(!sp_p6_record_fullbar_v552_save_ready(c))return fail(SP_P6_SAVE_IDENTITY);
    uint32_t token=sp_p6_record_token_v552_actual_token();
    if(!token || token!=val(&c->token) || c->handle!=rd(OUTER+72) || c->handle>=1024 ||
       c->descriptor!=rd(TABLE+4*c->handle) || rd(NORMAL+432)!=c->handle ||
       rd(NORMAL+512)!=(uint32_t)c->window.accepted_frames || s->sequence==UINT32_MAX)return 0;
    s->token=token;s->generation=c->plan.start_generation;s->project=sp_p6_record_files_v552.project;s->pad=pad;
    s->frames=(uint32_t)c->window.accepted_frames;s->bytes=512+4*s->frames;
    s->project_seen=s->project_bytes=0;wr(OUTER+76,pad);s->state=SP_P6_SAVE_WRITING;
    int32_t result=sp_synth_capture_timed_v552_save_once(token);
    if(result || !exact() || val(&c->state)!=SP_TCAP_FINALIZED ||
       !((s->project_seen==6 && s->project_bytes==52000 && c->project_calls==1) ||
         (s->project_seen==4 && s->project_bytes==104000 && c->project_calls==2)) ||
       c->project_raw!=1)return fail(SP_P6_SAVE_IO);
    if(!metadata() || !journal(1,s->project_seen==6?1u:2u,0))return fail(SP_P6_SAVE_METADATA);
    snapshot(1);s->sequence++;s->wait_sequence=s->ack_sequence=0;s->state=SP_P6_SAVE_WAIT;
    (void)native(0x800D30A4u,RECORD,64,0,0);return 1;
}
void sp_p6_save_v552_before_wait(void *p) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    if((uintptr_t)p==RECORD && s->state==SP_P6_SAVE_WAIT && unmasked() &&
       !rd(0x202BBBF8u) && sp_p6_record_context_v552_current(2))s->wait_sequence=s->sequence;
}
void sp_p6_save_v552_record_return(uint32_t p,uint32_t action) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    if(p!=RECORD || action!=3 || s->state!=SP_P6_SAVE_WAIT || !unmasked() ||
       rd(0x202BBBF8u) || !sp_p6_record_context_v552_current(2))return;
    if(s->sequence && s->wait_sequence==s->sequence) { s->ack_sequence=s->sequence;
        (void)native(0x800D30A4u,0x202ACD00u,128,0,0); }
    else (void)native(0x800D30A4u,RECORD,64,0,0);
}
int sp_p6_save_v552_old_drain(void) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;SpSynthCaptureTimedV552 *c=s->capture;
    return c && s->state==SP_P6_SAVE_WAIT && !s->fault && unmasked() && !rd(0x202BBBF8u) &&
        sp_p6_record_context_v552_current(2) && sp_p6_record_token_v552_current() &&
        val(&c->state)==SP_TCAP_FINALIZED && val(&c->token)==s->token && !val(&c->fault) &&
        !val(&c->handoff_fault) && !val(&c->rx_active) && sp_p6_record_files_v552.active &&
        !sp_p6_record_files_v552.fault;
}
int sp_p6_save_v552_retirement_ready(SpSynthCaptureTimedV552 *c) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    return c==s->capture && s->state==SP_P6_SAVE_RETIRING && !s->fault &&
        s->sequence && s->wait_sequence==s->sequence && s->ack_sequence==s->sequence &&
        metadata() && snapshot(0) && journal(0,s->project_seen==6?1u:2u,0);
}
int sp_p6_save_v552_poll(SpSynthCaptureTimedV552 *c) {
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    if(!c || c!=s->capture || !smpl())return 0;
    if(s->state==SP_P6_SAVE_TRANSFERRED)return 1;
    if(s->state!=SP_P6_SAVE_WAIT)return s->fault?-1:0;
    if(!exact() || val(&c->state)!=SP_TCAP_FINALIZED || !metadata() || !snapshot(0) || !journal(0,s->project_seen==6?1u:2u,0))return fail(SP_P6_SAVE_IDENTITY);
    if(s->ack_sequence!=s->sequence)return 0;
    /* Queue exclusion remains a join gate. Refuse a pending native mutation. */
    if(rd(0x805917E0u)!=rd(0x805917E4u) || rd(0x805917A4u)!=rd(0x805917A8u))return 0;
    if(!sp_p6_record_producer_v552_save_release_ready(c))return fail(SP_P6_SAVE_CONTEXT);
    s->state=SP_P6_SAVE_RETIRING;
    (void)native(0x8017E5D0u,NORMAL+60,0,0,0);(void)native(0x800E9E30u,NORMAL,UINT32_MAX,0,0);
    wr(OUTER+72,UINT32_MAX);wr(OUTER+76,UINT32_MAX);wr(OUTER+592,0);wr(OUTER+604,0);
    *(volatile uint8_t *)(uintptr_t)(OUTER+57)=0;
    atomic_store_explicit(&c->state,SP_TCAP_RESERVING,memory_order_release);
    if(!sp_p6_record_token_v552_save_retired(c))return fail(SP_P6_SAVE_IDENTITY);
    if(!sp_p6_record_producer_v552_saved_released(c))return fail(SP_P6_SAVE_CONTEXT);
    s->state=SP_P6_SAVE_TRANSFERRED;return 1;
}
uint32_t sp_p6_save_v552_admission(void) { return 0; }
