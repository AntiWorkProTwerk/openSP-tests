#include "sp_p6_record_context_v552.h"
#include "guard.h"
#include "sp_synth_capture_timed_v552.h"
extern SpSynthCaptureTimedV552 *sp_p6_save_two_leg_v552_complete(void);
#include "sp_p6_capture_bridge.h"
#include "sp_p6_record_token_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_save_handover_v552.h"
#include "sp_p6_record_backend_v552.h"
#include "sp_p6_record_backend_join_v552.h"
#include "sp_p6_record_fullbar_v552.h"
#include "sp_p6_record_project_gate_v552.h"
#ifdef SP_SYNTH_NATIVE_BOUND_V552
#include "sp_synth_native_runtime_v552.h"
#endif
#ifdef SP_SYNTH_FULL_V552
#include "sp_synth_capture_tail_v552.h"
#include "sp_synth_take_save_v552.h"
#include "sp_synth_full_backend_v552.h"
#include "sp_synth_live_session_v552.h"
#endif
#include "sp_synth_memory_v552.h"
#include <stddef.h>
#include "sp_p6_transaction_ingress_v552.h"
#include <string.h>
#include "sp_p6_production_join.h"
#include "sp_p6_record_retirement_v552.h"
#include "sp_p6_record_audio_v552.h"
#include "sp_p6_session_binding_v552.h"

_Static_assert(sizeof(void *)==4,"Pinned ARM32 native ABI");
_Static_assert(ATOMIC_INT_LOCK_FREE==2 && ATOMIC_POINTER_LOCK_FREE==2,"Lock-free publication");
#define OUTER UINT32_C(0x82E0E71C)
#define NORMAL UINT32_C(0x82FE4F08)
#define SMPL UINT32_C(0x202ACD00)
#define RECORD UINT32_C(0x202ACFA0)
#define PANEL UINT32_C(0x8300A3E4)
#define LEASE 256u
#define PHASE(x) ((x)&255u)
typedef uint32_t (*Native)(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_tcapture_native_dispatch(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_tcapture_native_save(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_tcapture_native_consume(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_tcapture_native_append(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_tcapture_native_coalesce(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_tcapture_native_deferred(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_tcapture_native_post_drain(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_tcapture_native_post_save(uint32_t,uint32_t,uint32_t,uint32_t);
/* Resolved to the pinned live provider in a combined link. The component
 * fixture models this boundary and never claims actual page deletion. */
extern int sp_synth_live_session_v552_exit_request(uint32_t,uint32_t,uint32_t);
extern int sp_synth_live_session_v552_exit_ack(uint32_t);
static _Atomic(SpSynthCaptureTimedV552 *) owner;
/* Selected only by SMPL before BEGIN; immutable through native retirement. */
static atomic_uint p6_source,p6_pcm,p6_tx_task,p6_tx_token;
static uint32_t rd(uintptr_t a) { return *(volatile const uint32_t *)a; }
static uint8_t byte(uintptr_t a) { return *(volatile const uint8_t *)a; }
static void store(uintptr_t a,uint32_t v) { *(volatile uint32_t *)a=v; }
static uint32_t native(uintptr_t a,uint32_t r0,uint32_t r1,uint32_t r2,uint32_t r3) {
    return ((Native)(a|1u))(r0,r1,r2,r3);
}
static uint32_t context(void) {
    uint32_t ipsr,basepri;
    __asm__ volatile("mrs %0, ipsr":"=r"(ipsr));
    __asm__ volatile("mrs %0, basepri":"=r"(basepri));
    if(ipsr || basepri || (int32_t)rd(0x80245764)>0)return 0;
    uint32_t id=((uint32_t (*)(void))(uintptr_t)0x800D3163)();
    return id>=1 && id<=32?id:0;
}
static int task(uintptr_t object) { uint32_t id=context();return id && rd(object+4)==id; }
static int worker(void) { return task(SMPL) && !rd(0x202BBBF8); }
static int object(const void *p,size_t n) {
    uintptr_t a=(uintptr_t)p;
    return a && !(a&3u) && a<=UINTPTR_MAX-n &&
        (a+n<=SP_SYNTH_V552_POOL_BEGIN || a>=SP_SYNTH_V552_POOL_END);
}
/* Copied call inputs/outputs may live on an owned temporary stack in the
 * application pool. Only permanently published owners use object() above.
 * The caller still owns a valid, stable, nonaliasing span for this call. */
static int copy_span(const void *p,size_t n,size_t alignment) {
    uintptr_t a=(uintptr_t)p;
    return a && !(a&(alignment-1u)) && a<=UINTPTR_MAX-n;
}
static int disjoint(const void *a,size_t an,const void *b,size_t bn) {
    return (uintptr_t)a+an<=(uintptr_t)b || (uintptr_t)b+bn<=(uintptr_t)a;
}
static SpSynthCaptureTimedV552 *get(void) { return atomic_load_explicit(&owner,memory_order_acquire); }

/* SMPL writes this baseline only while BEGIN excludes active capture. The
 * serialized actual audio producer advances it after RUNNING publication.
 * It stores successful native64 source metadata, never a musical clock. */
static struct { uint32_t token,sequence,end; } manual_clock;
static int manual_profile(const SpSynthCaptureTimedV552 *o) {
    uint32_t seconds;
    memcpy(&seconds,&o->plan.plan.capture.seconds,sizeof(seconds));
    return o->plan.plan.capture.mode==0 && seconds==UINT32_C(0x42F00000) &&
        !o->plan.plan.capture.count_in_bars && !o->plan.plan.capture.include_release_tail &&
        o->sample_rate_hz==48000 && o->plan.plan.sample_rate_hz==48000;
}
static int manual_receipt(SpP6RecordAudioReceiptV552 *r) {
    const SpP6SessionBindingV552 *b=&sp_p6_session_binding_v552;
    const SpP6RecordAudioV552 *a=&sp_p6_record_audio_v552;
    return !atomic_load_explicit(&a->audio_active,memory_order_acquire) &&
        !(atomic_load_explicit(&a->revision,memory_order_acquire)&1u) &&
        sp_p6_record_audio_v552_session()==&sp_p6_production_session &&
        sp_p6_record_audio_v552_receipt(r) && r->visit && r->intent &&
        r->visit==b->visit && r->intent==b->sequence &&
        atomic_load_explicit(&b->pending,memory_order_acquire)==r->intent &&
        r->sequence && r->sequence!=UINT32_MAX && r->sample_end>=64 &&
        r->sample_end-r->sample_start==64 && r->sample_end<=UINT32_MAX-64u;
}
/* Called only after native setup/start returns, inside the short publication
 * mask. No file, native recorder, transport or musical clock operation runs. */
static int manual_baseline(SpSynthCaptureTimedV552 *o) {
    if(o->plan.plan.capture.mode!=0)return 1;
    SpP6RecordAudioReceiptV552 r;
    uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
    if(!manual_profile(o) || p6_source!=SP_P6_SOURCE_SYNTH_ONLY || !token ||
       token!=o->last_token || token!=o->plan.take_token || !o->plan.start_generation ||
       !manual_receipt(&r) || r.generation!=o->plan.start_generation)return 0;
    manual_clock.token=token;manual_clock.sequence=r.sequence;manual_clock.end=r.sample_end;
    return 1;
}
/* 0 retains the legacy idle/synchronized path; -1 refuses an owned manual
 * block through the existing fault/STOP path. Only the sole actual preview
 * success -> production PCM caller can provide the next source receipt. */
int sp_p6_capture_v552_manual_clock(const int16_t *pcm,uint32_t frames) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || p6_source!=SP_P6_SOURCE_SYNTH_ONLY)return 0;
    unsigned state=atomic_load_explicit(&o->state,memory_order_acquire);
    if(PHASE(state)!=SP_TCAP_RUNNING && PHASE(state)!=SP_TCAP_STOP_PENDING)return 0;
    if(o->plan.plan.capture.mode!=0)return 0;
    uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
    SpP6RecordAudioReceiptV552 r;
    if((state&SP_TCAP_UNSUPPORTED) || (state&~255u) || !manual_profile(o) ||
       !token || token!=o->last_token || token!=o->plan.take_token ||
       !o->plan.start_generation || manual_clock.token!=token ||
       atomic_load_explicit(&o->fault,memory_order_acquire) ||
       atomic_load_explicit(&o->handoff_fault,memory_order_acquire) ||
       atomic_load_explicit(&o->handoff_pending,memory_order_acquire) ||
       (uintptr_t)pcm!=p6_pcm || frames!=64 || context()!=p6_tx_task || p6_tx_token ||
       !manual_receipt(&r) || r.sequence!=manual_clock.sequence+1u ||
       r.sample_start!=manual_clock.end || r.sample_end!=manual_clock.end+64u ||
       atomic_load_explicit(&o->state,memory_order_acquire)!=state ||
       atomic_load_explicit(&o->token,memory_order_acquire)!=token)return -1;
    manual_clock.sequence=r.sequence;manual_clock.end=r.sample_end;
    return 1;
}
static void wake(void) { (void)native(0x800D30A4,SMPL,0x80,0,0); }
static void phase(SpSynthCaptureTimedV552 *o,unsigned next) {
    unsigned s=atomic_load_explicit(&o->state,memory_order_acquire);
    while(!atomic_compare_exchange_weak_explicit(&o->state,&s,(s&~255u)|next,
        memory_order_acq_rel,memory_order_acquire)){}
}
static void fault(SpSynthCaptureTimedV552 *o,int32_t why) {
    unsigned empty=0;
    (void)atomic_compare_exchange_strong_explicit(&o->fault,&empty,(uint32_t)why,memory_order_release,memory_order_relaxed);
    unsigned s=atomic_load_explicit(&o->state,memory_order_acquire);
    while(PHASE(s)==SP_TCAP_RUNNING || PHASE(s)==SP_TCAP_HELD) {
        unsigned next=PHASE(s)==SP_TCAP_RUNNING?SP_TCAP_STOP_PENDING:SP_TCAP_ERROR;
        if(atomic_compare_exchange_weak_explicit(&o->state,&s,(s&~255u)|next,
            memory_order_acq_rel,memory_order_acquire))break;
    }
}
static void handback_fault(SpSynthCaptureTimedV552 *o,int32_t why) {
    unsigned empty=0;
    (void)atomic_compare_exchange_strong_explicit(&o->handoff_fault,&empty,(uint32_t)why,
        memory_order_release,memory_order_relaxed);
    /* Sticky in the SAME word tested by admission/final retirement. In FREE,
     * preserve ordinary native behavior but permanently close new ownership.
     * A task gate is not IRQ exclusion. Never clear this bit or its provenance. */
    atomic_fetch_or_explicit(&o->state,SP_TCAP_UNSUPPORTED,memory_order_acq_rel);
}
static int enter(SpSynthCaptureTimedV552 *o,int drain,int audio) {
    unsigned s=atomic_load_explicit(&o->state,memory_order_acquire);
    for(;;) {
        unsigned p=PHASE(s);
        if(!audio && p!=SP_TCAP_FREE && !(drain && p==SP_TCAP_RUNNING))return 0;
        if(s>UINT32_MAX-LEASE) { fault(o,SP_TCAP_NATIVE_STATE);return 0; }
        if(atomic_compare_exchange_weak_explicit(&o->state,&s,s+LEASE,memory_order_acq_rel,memory_order_acquire))return 1;
    }
}
static void leave(SpSynthCaptureTimedV552 *o) {
    unsigned before=atomic_fetch_sub_explicit(&o->state,LEASE,memory_order_acq_rel);
    if((PHASE(before)==SP_TCAP_STOP_PENDING || PHASE(before)==SP_TCAP_DISCARD_BARRIER ||
        atomic_load_explicit(&o->handoff_pending,memory_order_acquire)) &&
       (before&~SP_TCAP_UNSUPPORTED)<2u*LEASE)wake();
}
static int same(SpSynthCaptureTimedV552 *o,uint32_t token) {
    return token && atomic_load_explicit(&o->token,memory_order_acquire)==token;
}
static int recorder(SpSynthCaptureTimedV552 *o) {
    return byte(OUTER+0x39)==2 && rd(OUTER+0x48)==o->handle &&
        (int32_t)o->handle>=0 && rd(OUTER+0x254)==NORMAL && rd(NORMAL)==0x8021E020 &&
        rd(NORMAL+0x1B0)==o->handle;
}
/* Authentic early source-owned BSS initialization must clear this receipt
 * before either native task starts. Isolated fixtures supply initial zero;
 * REC is its only publisher and late capture never resets or replays it. */
typedef struct {
    atomic_uint phase;
    uint32_t task;
    atomic_uint fault;
} SpP6RecordInitReceiptV552;
static SpP6RecordInitReceiptV552 p6_record_init_receipt;
_Static_assert(sizeof(SpP6RecordInitReceiptV552)==12,"Cold REC receipt budget");
extern const unsigned char sp_tcapture_record_init_entry[];
/* The installed common init-call patch reaches the preview wrapper first.
 * Its checked -Os BLX r1 is at +8 and returns at +10; the record entry then
 * tailbranches here without changing LR. An ABI change fails closed. */
static int p6_record_init_caller(uintptr_t caller) {
    uintptr_t entry=(uintptr_t)sp_synth_preview_native_v552_panel_init&~(uintptr_t)1;
    return caller==(entry+10u+1u) &&
        *(volatile const uint16_t *)(entry+8u)==0x4788u;
}
static uint32_t p6_record_init_task(void) {
    uint32_t i,p,b,f;
    __asm__ volatile("mrs %0,ipsr":"=r"(i));
    __asm__ volatile("mrs %0,primask":"=r"(p));
    __asm__ volatile("mrs %0,basepri":"=r"(b));
    __asm__ volatile("mrs %0,faultmask":"=r"(f));
    if(i || p || b || f || rd(0x202BBBF8) || rd(0x80245764))return 0;
    uint32_t t=native(0x800D3162,0,0,0,0);
    return t && t<=32 && rd(RECORD)==0x8021F380 && rd(RECORD+4)==t &&
        rd(0x8021F388)==((uintptr_t)sp_tcapture_record_init_entry|1u)?t:0;
}
static int p6_record_init_shape(uint32_t t) {
    return t && t<=32 && rd(RECORD)==0x8021F380 && rd(RECORD+4)==t &&
        rd(0x8021F388)==((uintptr_t)sp_tcapture_record_init_entry|1u) &&
        (rd(RECORD+12)&0x78u)==0x78u && rd(RECORD+60)==0 &&
        rd(RECORD+64)==1 && rd(RECORD+68)==2 && rd(RECORD+72)==3;
}
uint32_t sp_p6_record_start_rec_init_v552_current(void) {
    return atomic_load_explicit(&p6_record_init_receipt.phase,memory_order_acquire)==2 &&
        !atomic_load_explicit(&p6_record_init_receipt.fault,memory_order_acquire) &&
        p6_record_init_shape(p6_record_init_receipt.task);
}
static void p6_record_init_adopt(SpSynthCaptureTimedV552 *o) {
    if(o!=&sp_p6_production_capture || !sp_p6_record_start_rec_init_v552_current() ||
       !sp_p6_record_context_v552_registered() ||
       p6_record_init_receipt.task!=sp_p6_record_contexts_v552.record_task ||
       atomic_load_explicit(&o->state,memory_order_acquire)!=SP_TCAP_FREE || o->last_token ||
       atomic_load_explicit(&o->token,memory_order_acquire) || o->file_owned ||
       atomic_load_explicit(&o->rx_active,memory_order_acquire) ||
       atomic_load_explicit(&o->fault,memory_order_acquire) ||
       atomic_load_explicit(&o->handoff_fault,memory_order_acquire))return;
    unsigned expected=0;
    (void)atomic_compare_exchange_strong_explicit(&o->record_ready,&expected,1,
        memory_order_release,memory_order_relaxed);
}

int sp_synth_capture_timed_v552_init(SpSynthCaptureTimedV552 *o,uint32_t rate) {
    if(get() || !rate || !object(o,sizeof(*o)) || ((uintptr_t)o&(_Alignof(SpSynthCaptureTimedV552)-1u)))return 0;
    const unsigned char *b=(const unsigned char *)o;
    for(size_t i=0;i<sizeof(*o);++i)if(b[i])return 0;
    if(!sp_synth_project_save_v552_init(&o->project_write))return 0;
    atomic_init(&o->state,SP_TCAP_FREE);atomic_init(&o->token,0);atomic_init(&o->rx_ack,0);
    atomic_init(&o->fault,0);atomic_init(&o->permit,0);atomic_init(&o->audio_task,0);atomic_init(&o->backend,0);
    atomic_init(&o->native_save_count,0);atomic_init(&o->blocked_save_count,0);
    atomic_init(&o->record_ready,0);atomic_init(&o->barrier_token,0);atomic_init(&o->barrier_ack,0);
    atomic_init(&o->barrier_sequence,0);atomic_init(&o->wait_sequence,0);
    atomic_init(&o->handoff_pending,0);atomic_init(&o->handoff_fault,0);
    atomic_init(&o->exit_ticket,0);atomic_init(&o->released_ticket,0);
    o->sample_rate_hz=rate;
    atomic_init(&o->rx_active,0);atomic_init(&o->started_token,0);
    atomic_init(&o->tail_cut_reason,0);
    atomic_init(&o->cleanup_token,0);atomic_init(&o->notice_ready,0);atomic_init(&o->fence_phase,0);
#ifdef SP_SYNTH_NATIVE_BOUND_V552
    atomic_init(&o->pre_io_abort_token,0);
#endif
    if(!sp_p6_record_producer_v552_bind(o) || !sp_p6_record_token_v552_bind(o))return 0;
    if(!sp_p6_save_v552_bind(o))return 0;
    p6_record_init_adopt(o);
    atomic_store_explicit(&owner,o,memory_order_release);return 1;
}
int sp_synth_capture_timed_v552_publish(SpSynthSessionV552 *s) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !task(PANEL) || !object(s,sizeof(*s)) || !disjoint(o,sizeof(*o),s,sizeof(*s)) ||
       atomic_load_explicit(&s->ready,memory_order_acquire)!=1 ||
       atomic_load_explicit(&s->control_ready,memory_order_acquire)!=1 ||
       s->startup.ready!=1 || s->startup.memory.attached!=1)return 0;
    SpSynthBackendLink *empty=0;
    return atomic_compare_exchange_strong_explicit(&o->backend,&empty,&s->backend,
        memory_order_release,memory_order_relaxed);
}
int sp_synth_capture_timed_v552_kick(void) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !task(PANEL) || !atomic_load_explicit(&o->backend,memory_order_acquire))return 0;
    wake();return 1;
}
#ifdef SP_SYNTH_FULL_V552
int sp_synth_capture_timed_v552_kick_shutdown(void) {
    if(!get() || !task(PANEL) ||
       !atomic_load_explicit(&sp_synth_live_session_v552.terminal,memory_order_acquire))return 0;
    wake();return 1;
}
#endif
static int file(SpSynthCaptureTimedV552 *o) {
    return o->file_owned && o->handle>=1 && o->handle<1024 &&
        o->descriptor && rd(0x80B5F3B4+4*o->handle)==o->descriptor && rd(OUTER+0x48)==o->handle &&
        rd(OUTER+0x254)==NORMAL && rd(NORMAL)==0x8021E020 && rd(NORMAL+432)==o->handle;
}
static int release_gate(SpSynthCaptureTimedV552 *o) {
    if(native(0x800DECF8,0,0,0,0)==1 && !rd(0x202BBBF8))return 1;
    fault(o,SP_TCAP_CONTEXT);return 0;
}
static int command_number(unsigned n) {
    return sp_p6_mf_v552_command(n) || (n>=0x14 && n<=0x1A && n!=0x19) || n==0x416 || n==0x417 || n==0x41A || n==0x41D;
}
static int protected_command(uint32_t a) {
    if(!a || byte(a)!=0xA4)return 0;
    SpSynthCaptureTimedV552 *o=get();
    if(sp_p6_record_producer_v552.held || sp_p6_record_files_v552.active ||
       (o && PHASE(atomic_load_explicit(&o->state,memory_order_acquire))!=SP_TCAP_FREE))return 1;
    return command_number(byte(a+2)|((unsigned)byte(a+3)<<8));
}
/* Caller owns the checked non-nesting task gate and has zero prior leases.
 * Inspect finite native snapshots. Leave all stock payloads/indices intact. */
static int rings_clear(void) {
    unsigned w=rd(0x805917E0),r=rd(0x805917E4);
    if(w>=4096 || r>=4096)return 0;
    for(unsigned n=(w-r)&4095u;n;--n,r=(r+1)&4095u)
        if(protected_command(0x80B4C924+16*r))return 0;
    w=rd(0x805917A4);r=rd(0x805917A8);
    if(w>=128 || r>=128)return 0;
    for(unsigned n=(w-r)&127u;n;--n,r=(r+1)&127u) {
        uintptr_t p=0x80BAC434+16*r;
        if(byte(p)==0xA4 && command_number(byte(p+3)))return 0;
    }
    return 1;
}
static int idle(SpSynthCaptureTimedV552 *o) {
    return !o->file_owned && !atomic_load_explicit(&o->token,memory_order_acquire) &&
        !byte(OUTER+0x39) && !byte(OUTER+0x24E) && (int32_t)rd(OUTER+0x48)<0 && !rd(OUTER+0x250);
}
static int new_barrier(SpSynthCaptureTimedV552 *o) {
    unsigned previous=atomic_load_explicit(&o->barrier_sequence,memory_order_acquire);
    if(previous==UINT32_MAX) { handback_fault(o,SP_TCAP_EXHAUSTED);return 0; }
    atomic_store_explicit(&o->barrier_ack,0,memory_order_relaxed);
    atomic_store_explicit(&o->barrier_sequence,previous+1,memory_order_release);
    return 1;
}
/* Sole SMPL producer. Only the SMPL-consumed RX copy may supply counters.
 * Earlier takes can remain in observed_notice; never relabel them with the new
 * identity. Full control slots retain their payload until explicitly consumed. */
static void feedback(SpSynthCaptureTimedV552 *o,SpSynthBackendLink *b) {
    uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
    if(!b || !token || o->plan.take_token!=token || !o->plan.start_generation)return;
    SpSynthCaptureFeedback s={0};
    s.start_generation=o->plan.start_generation;s.take_token=token;
    s.recorder_phase=PHASE(atomic_load_explicit(&o->state,memory_order_acquire));
    s.fault=(int32_t)atomic_load_explicit(&o->fault,memory_order_acquire);
    if(!s.fault)s.fault=(int32_t)atomic_load_explicit(&o->handoff_fault,memory_order_acquire);
    s.sample_rate_hz=o->sample_rate_hz;
    s.count_in_frames=o->plan.plan.count_in_frames;s.duration_frames=o->plan.plan.duration_frames;
    const SpSynthCaptureTimedNotice *n=&o->observed_notice;
    if(n->token==token && n->generation==s.start_generation) {
        s.has_rx_notice=1;s.window_phase=n->phase;s.milestones=n->milestones;
        s.observed_frames=n->observed_frames;s.accepted_frames=n->accepted_frames;
        s.tail_cut_reason=n->tail_cut_reason;
    }
    (void)sp_synth_backend_link_capture_publish(b,&s);
}
#ifdef SP_SYNTH_NATIVE_BOUND_V552
static int start_unmasked(void) {
    uint32_t primask,faultmask;
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    return !primask && !faultmask;
}
/* Refusal can follow a task switch or an RX callback. The dispatch gate only
 * excludes task switches; mask IRQs for the finite proof and publication.
 * Do not inspect the RX-owned window until the state proves zero leases. */
static void abort_before_io(SpSynthCaptureTimedV552 *o,uint32_t token,unsigned previous,
    const SpSynthCaptureStartPlan *plan,int32_t setup_raw,uint32_t handle,uint32_t descriptor) {
    fault(o,SP_TCAP_BLOCKED);
    if(!start_unmasked() || !worker() || native(0x800DED08,0,0,0,0)!=1)return;
    if(rd(0x202BBBF8)!=2) { fault(o,SP_TCAP_CONTEXT);(void)release_gate(o);return; }
    uint32_t mask;
    __asm__ volatile("mrs %0, primask\n cpsid i":"=r"(mask)::"memory");
    unsigned expected=SP_TCAP_BEGIN;
    if((previous==SP_TCAP_FREE || previous==SP_TCAP_EXCLUSIVE_IDLE) && token &&
       atomic_load_explicit(&o->state,memory_order_acquire)==SP_TCAP_BEGIN &&
       atomic_load_explicit(&o->token,memory_order_acquire)==token && o->last_token==token &&
       !memcmp(&o->plan,plan,sizeof(*plan)) &&
       !atomic_load_explicit(&o->rx_active,memory_order_acquire) &&
       !atomic_load_explicit(&o->started_token,memory_order_acquire) &&
       !atomic_load_explicit(&o->rx_ack,memory_order_acquire) &&
       !atomic_load_explicit(&o->permit,memory_order_acquire) &&
       !atomic_load_explicit(&o->fence_phase,memory_order_acquire) &&
       !o->file_owned && !o->write_count && !o->override_mask && !o->discard_attempted &&
       !o->initial_write_raw && !o->close_raw && !o->unlink_raw && !o->setup_unlink_raw && !o->start_raw &&
       o->setup_raw==setup_raw && o->handle==handle && o->descriptor==descriptor &&
       !byte(OUTER+0x39) && !byte(OUTER+0x24E) && (int32_t)rd(OUTER+0x48)<0 && !rd(OUTER+0x250) &&
       o->window.start.take_token<token && o->window.last_token<token &&
       o->window.pending.token<token && !o->window.inflight &&
       atomic_load_explicit(&o->cleanup_token,memory_order_acquire)<token &&
       atomic_load_explicit(&o->pre_io_abort_token,memory_order_acquire)<token &&
       atomic_compare_exchange_strong_explicit(&o->state,&expected,SP_TCAP_RESERVING,
           memory_order_acq_rel,memory_order_acquire)) {
        /* last_token remains consumed. This receipt never authorizes RX
         * retirement or native file cleanup. Keep any published error. */
        atomic_store_explicit(&o->pre_io_abort_token,token,memory_order_release);
        atomic_store_explicit(&o->token,0,memory_order_release);
        atomic_store_explicit(&o->state,previous,memory_order_release);
    }
    __asm__ volatile("msr primask, %0"::"r"(mask):"memory");
    if(!release_gate(o))phase(o,SP_TCAP_ERROR);
}
#endif
int sp_synth_capture_timed_v552_begin(const SpAppRequest *request) {
    if(!sp_p6_production_admission())return 0;
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !worker() || o->last_token==UINT32_MAX ||
       atomic_load_explicit(&o->record_ready,memory_order_acquire)!=1 ||
       !copy_span(request,sizeof(*request),_Alignof(SpAppRequest)) || !disjoint(request,sizeof(*request),o,sizeof(*o)))return 0;
    SpSynthBackendLink *b=atomic_load_explicit(&o->backend,memory_order_acquire);
    if(!b || atomic_load_explicit(&b->responses.stopped,memory_order_acquire) ||
       !disjoint(request,sizeof(*request),(const char *)b - offsetof(SpSynthSessionV552,backend),sizeof(SpSynthSessionV552)))return 0;
    uint32_t token=o->last_token+1u;
    SpSynthCaptureStartPlan plan;
    if(!sp_synth_capture_plan_start(request,o->sample_rate_hz,o->last_token,token,&plan))return 0;
#ifdef SP_SYNTH_NATIVE_BOUND_V552
    if(!start_unmasked())return 0;
#endif
    /* The stock wrappers are non-nesting. worker() required a clear gate.
     * Keep only zero-lease admission and per-token publication inside it;
     * otherwise an action2 guard can publish a fault during the reset below.
     * This excludes task preemption, not ISRs or older suspended leases. */
    if(native(0x800DED08,0,0,0,0)!=1)return 0;
    if(rd(0x202BBBF8)!=2) { fault(o,SP_TCAP_CONTEXT);(void)release_gate(o);return 0; }
    unsigned expected=atomic_load_explicit(&o->state,memory_order_acquire);
    unsigned previous=expected;
    if(expected!=SP_TCAP_FREE && expected!=SP_TCAP_EXCLUSIVE_IDLE) { (void)release_gate(o);return 0; }
    if(!atomic_compare_exchange_strong_explicit(&o->state,&expected,SP_TCAP_RESERVING,
        memory_order_acq_rel,memory_order_acquire)) { (void)release_gate(o);return 0; }
    if(byte(OUTER+0x39) || byte(OUTER+0x24E) || (int32_t)rd(OUTER+0x48)>=0 || rd(OUTER+0x250) || !rings_clear()) {
        phase(o,previous);(void)release_gate(o);return 0;
    }
    o->last_token=token;atomic_store_explicit(&o->token,token,memory_order_relaxed);
    o->plan=plan;
    atomic_store_explicit(&o->started_token,0,memory_order_relaxed);
    atomic_store_explicit(&o->fence_phase,0,memory_order_relaxed);
    atomic_store_explicit(&o->rx_ack,0,memory_order_relaxed);
    atomic_store_explicit(&o->fault,0,memory_order_relaxed);
    atomic_store_explicit(&o->tail_cut_reason,0,memory_order_relaxed);
    atomic_store_explicit(&o->barrier_token,0,memory_order_relaxed);
    atomic_store_explicit(&o->barrier_ack,0,memory_order_relaxed);
    o->override_mask=0;o->write_count=0;o->discard_attempted=0;o->file_owned=0;
    o->initial_write_raw=0;o->close_raw=0;o->unlink_raw=0;o->setup_unlink_raw=0;o->start_raw=0;
#ifdef SP_SYNTH_NATIVE_BOUND_V552
    int32_t setup_before=o->setup_raw;
    uint32_t handle_before=o->handle,descriptor_before=o->descriptor;
#endif
    phase(o,SP_TCAP_BEGIN);
    if(!release_gate(o)) { phase(o,SP_TCAP_ERROR);return 0; }
#ifdef SP_SYNTH_NATIVE_BOUND_V552
    SpSynthNativeProviderV552 *provider=sp_synth_native_runtime_v552_provider();
    if(!provider || sp_synth_native_provider_v552_take_admitted(provider,token)!=1) {
        abort_before_io(o,token,previous,&plan,setup_before,handle_before,descriptor_before);
        return 0;
    }
#endif
    if(!sp_p6_record_project_gate_v552_prepare(o)) { fault(o,SP_TCAP_CONTEXT);phase(o,SP_TCAP_ERROR);return 0; }
    feedback(o,b); /* Preparation precedes first RX progress and START success. */
    if(!sp_p6_record_producer_v552_begin(o) || !sp_p6_record_token_v552_prepare(o)) { fault(o,SP_TCAP_CONTEXT);phase(o,SP_TCAP_ERROR);return 0; }
    o->setup_raw=(int32_t)native(0x8017F970,OUTER,0,0,0);
    o->handle=rd(OUTER+0x48);
    o->file_owned=o->handle>=1 && o->handle<1024 && rd(0x80B5F3B4+4*o->handle)!=0;
    o->descriptor=o->file_owned?rd(0x80B5F3B4+4*o->handle):0;
    if(o->write_count!=1 || o->initial_write_raw!=512)fault(o,SP_TCAP_INITIAL_WRITE);
    if(!file(o) || byte(OUTER+0x39)!=1 || byte(OUTER+0x24E) || byte(OUTER+0x3A) ||
       byte(OUTER+0x3B)!=1 || o->override_mask!=3 || rd(OUTER+0x250))fault(o,SP_TCAP_NATIVE_STATE);
    if(!atomic_load_explicit(&o->fault,memory_order_acquire)) {
        o->start_raw=(int32_t)native(0x8017F810,OUTER,0,0,0);
        if(!recorder(o) || byte(OUTER+0x24E)!=2 || rd(OUTER+0x250))fault(o,SP_TCAP_NATIVE_STATE);
    }
    store(OUTER+0x4C,UINT32_MAX);
    if(atomic_load_explicit(&o->fault,memory_order_acquire) ||
       atomic_load_explicit(&o->handoff_fault,memory_order_acquire)) { phase(o,SP_TCAP_STOP_PENDING);return 0; }
    /* No callback may fall between source baseline and RUNNING release. */
    uint32_t publication_mask;
    __asm__ volatile("mrs %0,primask\n cpsid i\n dmb":"=r"(publication_mask)::"memory");
    int manual_ready=manual_baseline(o);
    if(manual_ready)phase(o,SP_TCAP_RUNNING);
    else { fault(o,SP_TCAP_NATIVE_STATE);phase(o,SP_TCAP_STOP_PENDING); }
    __asm__ volatile("dmb\n msr primask,%0"::"r"(publication_mask):"memory");
    if(!manual_ready)return 0;
    if(atomic_load_explicit(&o->fault,memory_order_acquire)) { fault(o,SP_TCAP_NATIVE_STATE);return 0; }
    return 1;
}
int sp_synth_capture_timed_v552_cancel_start(uint32_t generation) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !worker() || !generation || !o->start_admitted || o->discard_attempted ||
       o->work.type!=SP_APP_REQUEST_CAPTURE_START || o->work.generation!=generation ||
       o->plan.start_generation!=generation || o->plan.take_token!=o->work_token ||
       !same(o,o->work_token) ||
       (atomic_load_explicit(&o->state,memory_order_acquire)&SP_TCAP_UNSUPPORTED) ||
       atomic_load_explicit(&o->handoff_pending,memory_order_acquire))return 0;
    SpSynthBackendLink *b=atomic_load_explicit(&o->backend,memory_order_acquire);
    if(!b || atomic_load_explicit(&b->responses.stopped,memory_order_acquire) ||
       atomic_load_explicit(&b->request_phase,memory_order_acquire)!=(o->working?2u:0u))return 0;
    if(!sp_synth_capture_timed_v552_stop(o->work_token))return 0;
    o->start_canceled=1;
    /* A published START completion belongs to the control inbox. Do not
     * rewrite it; a cancellation consumer must retire it before DISCARD.
     * Only an unpublished result remains ours to supersede. */
    if(o->working)o->response_ready=0;
    return 1;
}
int sp_synth_capture_timed_v552_cancel_result(uint32_t generation) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !worker() || !generation || !o->start_canceled || o->discard_attempted ||
       o->work.type!=SP_APP_REQUEST_CAPTURE_START || o->work.generation!=generation ||
       o->plan.start_generation!=generation || o->plan.take_token!=o->work_token ||
       !same(o,o->work_token))return 0;
    SpSynthBackendLink *b=atomic_load_explicit(&o->backend,memory_order_acquire);
    if(!b || atomic_load_explicit(&b->responses.stopped,memory_order_acquire))return -1;
    unsigned s=atomic_load_explicit(&o->state,memory_order_acquire);
    if((s&SP_TCAP_UNSUPPORTED) || PHASE(s)==SP_TCAP_ERROR ||
       atomic_load_explicit(&o->fault,memory_order_acquire) ||
       atomic_load_explicit(&o->handoff_fault,memory_order_acquire))return -1;
    if(s!=SP_TCAP_HELD || atomic_load_explicit(&o->rx_ack,memory_order_acquire)!=o->work_token ||
       atomic_load_explicit(&o->record_ready,memory_order_acquire)!=1 || byte(OUTER+0x24E) || !file(o))return 0;
    return 1;
}
int sp_synth_capture_timed_v552_tail_fence(uint32_t token,uint64_t frame) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !worker() || !same(o,token) || o->plan.take_token!=token ||
       !o->plan.plan.capture.include_release_tail ||
       PHASE(atomic_load_explicit(&o->state,memory_order_acquire))!=SP_TCAP_RUNNING ||
       atomic_load_explicit(&o->fence_phase,memory_order_acquire))return 0;
    o->fence_token=token;o->fence_frame=frame;o->fence_result=0;
    atomic_store_explicit(&o->fence_phase,1,memory_order_release);return 1;
}
int sp_synth_capture_timed_v552_fence_status(uint32_t token) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !worker() || !token || atomic_load_explicit(&o->fence_phase,memory_order_acquire)!=2 ||
       o->fence_token!=token)return 0;
    int result=o->fence_result;
    atomic_store_explicit(&o->fence_phase,0,memory_order_release);return result;
}
int sp_synth_capture_timed_v552_status(SpSynthCaptureTimedNotice *out) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !worker() || !copy_span(out,sizeof(*out),_Alignof(SpSynthCaptureTimedNotice)) ||
       !disjoint(out,sizeof(*out),o,sizeof(*o)) || !o->observed_notice.token)return 0;
    *out=o->observed_notice;return 1;
}
int sp_synth_capture_timed_v552_stop(uint32_t token) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !worker() || !same(o,token))return 0;
    unsigned s=atomic_load_explicit(&o->state,memory_order_acquire);
    while(PHASE(s)==SP_TCAP_RUNNING) {
        if(atomic_compare_exchange_weak_explicit(&o->state,&s,(s&~255u)|SP_TCAP_STOP_PENDING,
            memory_order_acq_rel,memory_order_acquire))return 1;
    }
    return PHASE(s)==SP_TCAP_STOP_PENDING || PHASE(s)==SP_TCAP_HELD || PHASE(s)==SP_TCAP_ERROR;
}
static void settle(SpSynthCaptureTimedV552 *o) {
    unsigned s=SP_TCAP_STOP_PENDING;
    if(atomic_load_explicit(&o->state,memory_order_acquire)!=s)return;
    uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
    if(!token || atomic_load_explicit(&o->rx_ack,memory_order_acquire)!=token)return;
    if(!recorder(o) || byte(OUTER+0x24E) || rd(OUTER+0x250))
        fault(o,rd(OUTER+0x250)?(int32_t)rd(OUTER+0x250):SP_TCAP_NATIVE_STATE);
    unsigned next=atomic_load_explicit(&o->fault,memory_order_acquire)?SP_TCAP_ERROR:SP_TCAP_HELD;
    (void)atomic_compare_exchange_strong_explicit(&o->state,&s,next,memory_order_acq_rel,memory_order_acquire);
}
int sp_synth_capture_timed_v552_discard(uint32_t token) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !worker() || !same(o,token) || o->discard_attempted ||
       atomic_load_explicit(&o->record_ready,memory_order_acquire)!=1 ||
       atomic_load_explicit(&o->rx_ack,memory_order_acquire)!=token || byte(OUTER+0x24E) || !file(o))return 0;
    unsigned expected=atomic_load_explicit(&o->state,memory_order_acquire);
    if(expected!=SP_TCAP_HELD && expected!=SP_TCAP_ERROR)return 0;
    if(atomic_load_explicit(&o->barrier_sequence,memory_order_acquire)==UINT32_MAX)return 0;
    if(!atomic_compare_exchange_strong_explicit(&o->state,&expected,SP_TCAP_DISCARD_BARRIER,
        memory_order_acq_rel,memory_order_acquire))return 0;
    o->discard_attempted=1;
    atomic_store_explicit(&o->barrier_token,token,memory_order_release);
    if(!new_barrier(o))return 0;
    (void)native(0x800D30A4,RECORD,0x40,0,0);
    return 1;
}
static void discarded(SpSynthCaptureTimedV552 *o) {
    uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
    unsigned sequence=atomic_load_explicit(&o->barrier_sequence,memory_order_acquire);
    if(!token || !sequence || atomic_load_explicit(&o->barrier_ack,memory_order_acquire)!=sequence ||
       atomic_load_explicit(&o->barrier_token,memory_order_acquire)!=token ||
       atomic_load_explicit(&o->rx_ack,memory_order_acquire)!=token)return;
    unsigned expected=SP_TCAP_DISCARD_BARRIER;
    if(!atomic_compare_exchange_strong_explicit(&o->state,&expected,SP_TCAP_DISCARDING,
        memory_order_acq_rel,memory_order_acquire))return;
    if(!file(o) || byte(OUTER+0x24E)) { fault(o,SP_TCAP_NATIVE_STATE);phase(o,SP_TCAP_ERROR);return; }
    /* DEBD8 includes the stock bounded close retries and releases its descriptor
     * slot even on failure. Never call it a second time for this token. */
    if(!sp_p6_record_token_v552_discard_enter(o)) { fault(o,SP_TCAP_CONTEXT);phase(o,SP_TCAP_ERROR);return; }
    o->close_raw=(int32_t)native(0x800DEBD8,o->handle,0,0,0);
    if(o->close_raw<0) { fault(o,SP_TCAP_CLOSE);phase(o,SP_TCAP_ERROR);return; }
    o->unlink_raw=(int32_t)native(0x800DECD8,OUTER+0x50,0,0,0);
    if(o->unlink_raw!=0) { fault(o,SP_TCAP_UNLINK);phase(o,SP_TCAP_ERROR);return; }
    (void)native(0x8017E5D0,NORMAL+60,0,0,0);
    (void)native(0x800E9E30,NORMAL,UINT32_MAX,0,0);
    store(OUTER+0x48,UINT32_MAX);store(OUTER+0x4C,UINT32_MAX);
    store(OUTER+0x250,0);store(OUTER+0x25C,0);
    *(volatile uint8_t *)(uintptr_t)(OUTER+0x39)=0;
    o->file_owned=0;
    /* This release follows the checked RX return, fresh RECORD batch and native
     * close/unlink/reset. Only RX may subsequently retire its window. */
    atomic_store_explicit(&o->cleanup_token,token,memory_order_release);
    atomic_store_explicit(&o->token,0,memory_order_release);
    phase(o,SP_TCAP_EXCLUSIVE_IDLE);
    if(!sp_p6_record_token_v552_discard_retired(o) || !sp_p6_record_producer_v552_released(o)) { fault(o,SP_TCAP_CONTEXT);phase(o,SP_TCAP_ERROR); }
}
int sp_synth_capture_timed_v552_exit_ready(uint32_t ticket) {
    SpSynthCaptureTimedV552 *o=get();
    return o && worker() && ticket && atomic_load_explicit(&o->exit_ticket,memory_order_acquire)==ticket &&
        atomic_load_explicit(&o->state,memory_order_acquire)==SP_TCAP_WAIT_DELETE && idle(o) &&
        !atomic_load_explicit(&o->handoff_fault,memory_order_acquire);
}
int sp_synth_capture_timed_v552_released(uint32_t ticket) {
    SpSynthCaptureTimedV552 *o=get();
    return o && worker() && ticket && atomic_load_explicit(&o->released_ticket,memory_order_acquire)==ticket;
}
static __attribute__((noinline)) int retire(SpSynthCaptureTimedV552 *o) {
    unsigned expected=SP_TCAP_RELEASE_BARRIER;
    return atomic_compare_exchange_strong_explicit(&o->state,&expected,SP_TCAP_FREE,
        memory_order_acq_rel,memory_order_acquire);
}
/* -1 retained failure, 0 pending, 1 recorder RELEASED. All provider calls are
 * from the sole SMPL backend owner while its copied LEAVE remains WORKING. */
static int handback(SpSynthCaptureTimedV552 *o) {
    if(o->work.token ||
       atomic_load_explicit(&o->handoff_fault,memory_order_acquire))return -1;
    unsigned s=atomic_load_explicit(&o->state,memory_order_acquire),p=PHASE(s);
    if(p==SP_TCAP_FREE || p==SP_TCAP_EXCLUSIVE_IDLE) {
        if(s!=p || !idle(o))return 0;
        if(atomic_load_explicit(&o->record_ready,memory_order_acquire)!=1 || o->last_ticket==UINT32_MAX)
            return -1;
        if(native(0x800DED08,0,0,0,0)!=1) { handback_fault(o,SP_TCAP_CONTEXT);return -1; }
        if(rd(0x202BBBF8)!=2) { handback_fault(o,SP_TCAP_CONTEXT);(void)release_gate(o);return -1; }
        unsigned expected=p;
        int clear=idle(o) && rings_clear();
        if(!clear || !atomic_compare_exchange_strong_explicit(&o->state,&expected,SP_TCAP_WAIT_DELETE,
            memory_order_acq_rel,memory_order_acquire)) { (void)release_gate(o);return 0; }
        ++o->last_ticket;o->exit_requested=0;
        atomic_store_explicit(&o->exit_ticket,o->last_ticket,memory_order_release);
        if(!release_gate(o)) { handback_fault(o,SP_TCAP_CONTEXT);return -1; }
        p=SP_TCAP_WAIT_DELETE;
    }
    uint32_t ticket=atomic_load_explicit(&o->exit_ticket,memory_order_acquire);
    if(p==SP_TCAP_WAIT_DELETE) {
        if(!o->exit_requested) {
            if(!sp_synth_capture_timed_v552_exit_ready(ticket))return 0;
            o->exit_requested=1;
            if(!sp_synth_live_session_v552_exit_request(ticket,o->work.generation,o->work.token)) {
                handback_fault(o,SP_TCAP_EXIT);return -1;
            }
        }
        if(!sp_synth_live_session_v552_exit_ack(ticket))return 0;
        if(atomic_load_explicit(&o->state,memory_order_acquire)!=SP_TCAP_WAIT_DELETE)return 0;
        if(native(0x800DED08,0,0,0,0)!=1) { handback_fault(o,SP_TCAP_CONTEXT);return -1; }
        if(rd(0x202BBBF8)!=2) { handback_fault(o,SP_TCAP_CONTEXT);(void)release_gate(o);return -1; }
        unsigned expected=SP_TCAP_WAIT_DELETE;
        if(!idle(o) || !rings_clear()) {
            handback_fault(o,SP_TCAP_CUTOFF);(void)release_gate(o);return -1;
        }
        if(!atomic_compare_exchange_strong_explicit(&o->state,&expected,SP_TCAP_RELEASE_BARRIER,
            memory_order_acq_rel,memory_order_acquire)) { (void)release_gate(o);return 0; }
        int armed=new_barrier(o);
        if(!release_gate(o)) { handback_fault(o,SP_TCAP_CONTEXT);return -1; }
        if(!armed)return -1;
        (void)native(0x800D30A4,RECORD,0x40,0,0);
        return 0;
    }
    if(p!=SP_TCAP_RELEASE_BARRIER)return -1;
    unsigned sequence=atomic_load_explicit(&o->barrier_sequence,memory_order_acquire);
    if(!sequence || atomic_load_explicit(&o->barrier_ack,memory_order_acquire)!=sequence || s!=p)return 0;
    if(!sp_synth_live_session_v552_exit_ack(ticket)) { handback_fault(o,SP_TCAP_EXIT);return -1; }
    if(native(0x800DED08,0,0,0,0)!=1) { handback_fault(o,SP_TCAP_CONTEXT);return -1; }
    if(rd(0x202BBBF8)!=2) { handback_fault(o,SP_TCAP_CONTEXT);(void)release_gate(o);return -1; }
    if(!idle(o) || !rings_clear()) {
        handback_fault(o,SP_TCAP_CUTOFF);(void)release_gate(o);return -1;
    }
    if(!release_gate(o)) { handback_fault(o,SP_TCAP_CONTEXT);return -1; }
    /* Mutation admission stays closed through successful unlock. A task or
     * unsupported IRQ entry between validation and this CAS changes the same
     * lease word, so it cannot disappear behind the final idle decision. */
    int done=retire(o);
    if(done)atomic_store_explicit(&o->released_ticket,ticket,memory_order_release);
    return done?1:0;
}
static void cancel_service(SpSynthCaptureTimedV552 *o,SpSynthBackendLink *b) {
    if(atomic_load_explicit(&b->responses.stopped,memory_order_acquire))return;
    unsigned phase=atomic_load_explicit(&b->capture_cancel_phase,memory_order_acquire);
    if(phase!=SP_CAPTURE_CANCEL_REQUEST && phase!=SP_CAPTURE_CANCEL_STOPPING)return;
    const SpSynthCaptureCancelRequest *r=&b->capture_cancel_request;
    int result=0;
    if(phase==SP_CAPTURE_CANCEL_REQUEST) {
        /* START may still be queued. Let the normal worker acquire/prepare it
         * once, then cancel against its admitted immutable identity below. */
        if(!o->working && atomic_load_explicit(&b->request_phase,memory_order_acquire)==1 &&
           b->request.type==SP_APP_REQUEST_CAPTURE_START && b->request.generation==r->start_generation)return;
        if((r->take_token && r->take_token!=o->plan.take_token) ||
           !sp_synth_capture_timed_v552_cancel_start(r->start_generation))result=-1;
        else atomic_store_explicit(&b->capture_cancel_phase,SP_CAPTURE_CANCEL_STOPPING,memory_order_release);
    }
    if(!result)result=sp_synth_capture_timed_v552_cancel_result(r->start_generation);
    if(!result)return;
    uint32_t token=o->plan.start_generation==r->start_generation && same(o,o->plan.take_token)?o->plan.take_token:0;
    b->capture_cancel_result=(SpSynthCaptureCancelResult){r->start_generation,token,r->audio_sequence,result};
    atomic_store_explicit(&b->capture_cancel_phase,SP_CAPTURE_CANCEL_RESULT,memory_order_release);
}
static void service(SpSynthCaptureTimedV552 *o) {
    if(!worker())return;
    if(atomic_load_explicit(&o->notice_ready,memory_order_acquire)) {
        o->observed_notice=o->notice;
        atomic_store_explicit(&o->notice_ready,0,memory_order_release);
    }
    settle(o);discarded(o);
    SpSynthBackendLink *b=atomic_load_explicit(&o->backend,memory_order_acquire);
    if(!b)return;
    if(o->working && !sp_p6_record_backend_v552_retained(o,b))return;
    cancel_service(o,b);
    feedback(o,b);
    if(!o->working) {
#ifdef SP_SYNTH_FULL_V552
        int available=sp_synth_full_backend_v552_before_request();
        if(available<0)sp_synth_live_session_v552_cancel();
        if(available!=1)return;
#endif
        const SpAppRequest *canonical=sp_p6_record_backend_v552_claim(o,b);
        if(!canonical) {
#ifdef SP_SYNTH_FULL_V552
            sp_synth_full_backend_v552_worker_idle();
#endif
            return;
        }
        o->work=*canonical;
        o->working=1;o->response_ready=0;o->closed_request=0;o->start_admitted=0;o->start_canceled=0;
        o->work_token=atomic_load_explicit(&o->token,memory_order_acquire);
        memset(&o->completion,0,sizeof(o->completion));
        o->completion.generation=o->work.generation;o->completion.token=o->work_token;
        if(o->work.type==SP_APP_REQUEST_CAPTURE_START) {
            SpAppRequest request=o->work;
            uint32_t previous=o->last_token;
            (void)sp_synth_capture_timed_v552_begin(&request);
            o->start_admitted=o->last_token!=previous;
#ifdef SP_SYNTH_NATIVE_BOUND_V552
            o->start_admitted=o->start_admitted && atomic_load_explicit(&o->token,memory_order_acquire)!=0;
#endif
            o->work_token=atomic_load_explicit(&o->token,memory_order_acquire);
            o->completion.token=o->work_token;
            if(!o->start_admitted) {
                o->completion.error=SP_UI_ERR_CAPTURE;
                o->completion.capture_active=byte(OUTER+0x24E)==2;o->response_ready=1;
            }
        } else if(o->work.type==SP_APP_REQUEST_TAKE_DISCARD) {
            if(!sp_synth_capture_timed_v552_discard(o->work.token)) {
                o->completion.error=SP_UI_ERR_CAPTURE;o->completion.capture_active=byte(OUTER+0x24E)==2;o->response_ready=1;
            }
        } else if(o->work.type==SP_APP_REQUEST_CAPTURE_STOP || o->work.type==SP_APP_REQUEST_GLOBAL_STOP) {
            int stopped=(o->work.token==o->work_token ||
                (o->work.type==SP_APP_REQUEST_GLOBAL_STOP && !o->work.token)) &&
                sp_synth_capture_timed_v552_stop(o->work_token);
            if(stopped && o->work.type==SP_APP_REQUEST_CAPTURE_STOP &&
               o->work.tail_cut_reason==SP_APP_TAIL_CUT_MANUAL) {
                unsigned empty=SP_APP_TAIL_CUT_NONE;
                (void)atomic_compare_exchange_strong_explicit(&o->tail_cut_reason,&empty,
                    SP_APP_TAIL_CUT_MANUAL,memory_order_release,memory_order_relaxed);
            }
            if(!stopped) {
                o->completion.error=SP_UI_ERR_CAPTURE;o->completion.capture_active=byte(OUTER+0x24E)==2;o->response_ready=1;
            }
        } else if(o->work.type==SP_APP_REQUEST_LEAVE) {
            atomic_store_explicit(&o->handoff_pending,1,memory_order_release);
#ifdef SP_SYNTH_FULL_V552
        } else if(o->work.type==SP_APP_REQUEST_DEST_QUERY || o->work.type==SP_APP_REQUEST_TAKE_WRITE ||
                  o->work.type==SP_APP_REQUEST_TAKE_RECOVER || o->work.type==SP_APP_REQUEST_LOAD_PATCH ||
                  o->work.type==SP_APP_REQUEST_PATCH_QUERY || o->work.type==SP_APP_REQUEST_PATCH_WRITE) {
            int result=sp_synth_full_backend_v552_begin(&o->work,&o->completion);
            o->closed_request=2;
            o->response_ready=result>0;
            if(result<0) {o->closed_request=1;o->completion.error=SP_UI_ERR_BACKEND;o->response_ready=1;}
#endif
        } else if(o->work.type==SP_APP_REQUEST_DEST_QUERY || o->work.type==SP_APP_REQUEST_TAKE_WRITE) {
            o->closed_request=3;
            int result=sp_p6_record_backend_v552_begin(o);
            o->response_ready=result>0;
            if(result<0) {o->completion.error=SP_UI_ERR_BACKEND;o->response_ready=1;}
        } else { o->completion.error=SP_UI_ERR_BACKEND;o->completion.capture_active=byte(OUTER+0x24E)==2;o->response_ready=1;o->closed_request=1; }
    }
    cancel_service(o,b);
    /* A result that has not entered the response inbox is still ours. An
     * observed failure/cancellation supersedes a backpressured START success.
     * RX may fault after this check: control must also consume retained status;
     * a START acknowledgment is not a promise that later recording cannot fail. */
    if(o->response_ready && o->start_admitted && o->work.type==SP_APP_REQUEST_CAPTURE_START &&
       o->completion.error==SP_UI_OK && (o->start_canceled ||
       atomic_load_explicit(&o->fault,memory_order_acquire) ||
       atomic_load_explicit(&o->handoff_fault,memory_order_acquire) ||
       PHASE(atomic_load_explicit(&o->state,memory_order_acquire))!=SP_TCAP_RUNNING))o->response_ready=0;
    if(!o->response_ready) {
        settle(o);discarded(o);
        unsigned p=PHASE(atomic_load_explicit(&o->state,memory_order_acquire));
#ifdef SP_SYNTH_FULL_V552
        if(o->closed_request==2) {
            o->response_ready=sp_synth_full_backend_v552_poll(&o->completion)>0;
        } else
#endif
        if(o->closed_request==3 || o->closed_request==4) {
            int result=sp_p6_record_backend_v552_poll(o);
            o->response_ready=result>0;
            if(result<0) {o->completion.error=SP_UI_ERR_STORAGE;
                o->completion.save_flags=SP_TAKE_SAVE_RECOVERY_REQUIRED;o->response_ready=1;}
        } else if(o->work.type==SP_APP_REQUEST_CAPTURE_START) {
            if(same(o,o->work_token) && (p==SP_TCAP_HELD || p==SP_TCAP_ERROR)) {
                o->completion.error=SP_UI_ERR_CAPTURE;o->completion.capture_active=0;o->response_ready=1;
            } else if(!o->start_canceled && !atomic_load_explicit(&o->fault,memory_order_acquire) &&
                same(o,o->work_token) && p==SP_TCAP_RUNNING &&
                atomic_load_explicit(&o->started_token,memory_order_acquire)==o->work_token) {
                o->completion.error=SP_UI_OK;o->completion.capture_active=1;o->response_ready=1;
            }
        } else if(o->work.type==SP_APP_REQUEST_LEAVE) {
            int result=handback(o);
            if(result) {
                o->completion.error=result>0?SP_UI_OK:SP_UI_ERR_CAPTURE;o->response_ready=1;
                if(result<0)atomic_store_explicit(&o->handoff_pending,0,memory_order_release);
            }
        } else if(o->work.type==SP_APP_REQUEST_TAKE_DISCARD &&
           ((p==SP_TCAP_EXCLUSIVE_IDLE && !atomic_load_explicit(&o->token,memory_order_acquire)) || p==SP_TCAP_ERROR)) {
            if(p==SP_TCAP_ERROR || sp_p6_record_backend_v552_discarded(o)) {
                o->completion.error=p==SP_TCAP_EXCLUSIVE_IDLE?SP_UI_OK:SP_UI_ERR_CAPTURE;o->response_ready=1;
            }
        } else if(same(o,o->work_token) && (p==SP_TCAP_HELD || p==SP_TCAP_ERROR)) {
            o->completion.error=p==SP_TCAP_HELD?SP_UI_OK:SP_UI_ERR_CAPTURE;o->response_ready=1;
        }
    }
    if(o->response_ready && (o->work.generation ||
       (!o->closed_request && o->completion.error==SP_UI_OK)) &&
       sp_synth_backend_link_finish(b,o->work.generation?&o->completion:0)) {
#ifdef SP_SYNTH_FULL_V552
        if(o->closed_request==2)sp_synth_full_backend_v552_finished(o->work.generation);
#endif
        if(o->work.type==SP_APP_REQUEST_LEAVE && o->completion.error==SP_UI_OK &&
           !sp_synth_live_session_v552_backend_released(
            atomic_load_explicit(&o->released_ticket,memory_order_acquire),
            sp_p6_record_retirement_v552.lifetime,o->work.generation,o->work.token))
            handback_fault(o,SP_TCAP_EXIT);
        if(!sp_p6_record_backend_v552_finished()) {handback_fault(o,SP_TCAP_CONTEXT);return;}
        o->working=0;atomic_store_explicit(&o->handoff_pending,0,memory_order_release);
    }
    feedback(o,b);
}
uint32_t sp_synth_capture_timed_v552_smpl(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    sp_p6_production_smpl();
    (void)sp_p6_tx_v552_service();
    (void)sp_p6_tx_v552_wake();
    uint32_t result=native(0x80194738,a,b,c,d);
    SpSynthCaptureTimedV552 *o=get();
    if(o && a==SMPL && b==4 && task(SMPL)) {
        service(o);
        (void)sp_p6_record_backend_v552_rearm();
    }
    else if(o && a==SMPL && task(SMPL) && atomic_load_explicit(&o->handoff_pending,memory_order_acquire))wake();
    return result;
}
#ifdef SP_SYNTH_FULL_V552
int sp_synth_capture_timed_v552_shutdown_ready(void) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !worker())return 0;
    unsigned s=atomic_load_explicit(&o->state,memory_order_acquire);
    return (s==SP_TCAP_FREE || s==SP_TCAP_EXCLUSIVE_IDLE) &&
        !atomic_load_explicit(&o->token,memory_order_acquire) &&
        !atomic_load_explicit(&o->rx_active,memory_order_acquire) &&
        !atomic_load_explicit(&o->handoff_fault,memory_order_acquire) && idle(o) && rings_clear();
}
#endif
void sp_synth_capture_timed_v552_before_wait(void *native_object) {
    SpSynthCaptureTimedV552 *o=get();
    sp_p6_save_v552_before_wait(native_object);
    if(!o || (uintptr_t)native_object!=RECORD)return;
    if(!task(RECORD) || rd(0x202BBBF8)) { handback_fault(o,SP_TCAP_CONTEXT);return; }
    atomic_store_explicit(&o->wait_sequence,
        atomic_load_explicit(&o->barrier_sequence,memory_order_acquire),memory_order_release);
#ifdef SP_SYNTH_FULL_V552
    sp_synth_take_save_v552_record_before_wait(native_object);
#endif
}
uint32_t sp_synth_capture_timed_v552_record(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || a!=RECORD)return native(0x800FBC38,a,b,c,d);
    if(!enter(o,0,1))return (uint32_t)SP_TCAP_BLOCKED;
    unsigned p=PHASE(atomic_load_explicit(&o->state,memory_order_acquire));
    int qualified=task(RECORD) && !rd(0x202BBBF8);
    if(!qualified) {
        handback_fault(o,SP_TCAP_CONTEXT);
        if(p!=SP_TCAP_FREE) { leave(o);return (uint32_t)SP_TCAP_BLOCKED; }
    }
    uint32_t result;
    if(b==1 && p!=SP_TCAP_FREE && p!=SP_TCAP_RUNNING &&
       !sp_p6_record_fullbar_v552_drain_ready(o))result=(uint32_t)SP_TCAP_BLOCKED;
    else result=native(0x800FBC38,a,b,c,d);
    if(b==1 && qualified && p!=SP_TCAP_FREE && rd(OUTER+592))
        fault(o,(int32_t)rd(OUTER+592));
    if(b==3 && qualified && atomic_load_explicit(&o->record_ready,memory_order_acquire)==1 &&
       (p==SP_TCAP_DISCARD_BARRIER || p==SP_TCAP_RELEASE_BARRIER)) {
        unsigned sequence=atomic_load_explicit(&o->barrier_sequence,memory_order_acquire);
        if(sequence && atomic_load_explicit(&o->wait_sequence,memory_order_acquire)==sequence) {
            uint32_t value=p==SP_TCAP_RELEASE_BARRIER?sequence:
                atomic_load_explicit(&o->barrier_token,memory_order_acquire);
            if(p==SP_TCAP_RELEASE_BARRIER || same(o,value)) {
                atomic_store_explicit(&o->barrier_ack,sequence,memory_order_release);wake();
            }
        } else {
            /* An older returned event mask cannot acknowledge this barrier.
             * Repost its no-op bit for a wait that begins under this sequence. */
            (void)native(0x800D30A4,RECORD,0x40,0,0);
        }
    }
#ifdef SP_SYNTH_FULL_V552
    if(qualified)sp_synth_take_save_v552_record_return(a,b);
#endif
    if(qualified)sp_p6_save_v552_record_return(a,b);
    leave(o);return result;
}
uint32_t sp_synth_capture_timed_v552_record_init(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    uint32_t t=p6_record_init_task();
    uintptr_t caller=(uintptr_t)__builtin_return_address(0);
    if(a==RECORD && atomic_load_explicit(&p6_record_init_receipt.phase,memory_order_acquire)) {
        atomic_fetch_or_explicit(&p6_record_init_receipt.fault,2,memory_order_release);
        SpSynthCaptureTimedV552 *o=get();
        if(o)handback_fault(o,SP_TCAP_CONTEXT);
        return (uint32_t)SP_TCAP_BLOCKED;
    }
    if(a!=RECORD || b!=0x800FBC69 || !t || !p6_record_init_caller(caller))
        return native(0x800FBC68,a,b,c,d);
    unsigned expected=0;
    if(!atomic_compare_exchange_strong_explicit(&p6_record_init_receipt.phase,&expected,1,
        memory_order_acq_rel,memory_order_acquire)) {
        atomic_fetch_or_explicit(&p6_record_init_receipt.fault,2,memory_order_release);
        SpSynthCaptureTimedV552 *o=get();
        if(o)handback_fault(o,SP_TCAP_CONTEXT);
        return (uint32_t)SP_TCAP_BLOCKED;
    }
    if(rd(RECORD+12)&0x78u) {
        atomic_fetch_or_explicit(&p6_record_init_receipt.fault,1,memory_order_release);
        SpSynthCaptureTimedV552 *o=get();
        if(o)handback_fault(o,SP_TCAP_CONTEXT);
        return (uint32_t)SP_TCAP_BLOCKED;
    }
    uint32_t result=native(0x800FBC68,a,b,c,d);
    if(p6_record_init_task()!=t || (rd(RECORD+12)&0x38u)!=0x38u ||
       rd(RECORD+60)!=0 || rd(RECORD+64)!=1 || rd(RECORD+68)!=2)goto failed;
    (void)native(0x800CC1E0,RECORD,64,3,0);
    if(p6_record_init_task()!=t || !p6_record_init_shape(t) ||
       atomic_load_explicit(&p6_record_init_receipt.fault,memory_order_acquire))goto failed;
    p6_record_init_receipt.task=t;
    atomic_store_explicit(&p6_record_init_receipt.phase,2,memory_order_release);
    p6_record_init_adopt(get());
    return result;
failed:
    atomic_fetch_or_explicit(&p6_record_init_receipt.fault,1,memory_order_release);
    SpSynthCaptureTimedV552 *o=get();
    if(o)handback_fault(o,SP_TCAP_CONTEXT);
    return result;
}

uint32_t sp_synth_capture_timed_v552_dispatch(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || !protected_command(a))return sp_tcapture_native_dispatch(a,b,c,d);
    if(!context())handback_fault(o,SP_TCAP_CONTEXT);
    if(!enter(o,0,0))return (uint32_t)SP_TCAP_BLOCKED;
    uint32_t result=sp_tcapture_native_dispatch(a,b,c,d);leave(o);return result;
}
uint32_t sp_synth_capture_timed_v552_save(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || a!=OUTER)return sp_tcapture_native_save(a,b,c,d);
    if(!context())handback_fault(o,SP_TCAP_CONTEXT);
    unsigned p=PHASE(atomic_load_explicit(&o->state,memory_order_acquire));
    if(p==SP_TCAP_FREE && enter(o,0,0)) {
        uint32_t result=sp_tcapture_native_save(a,b,c,d);leave(o);return result;
    }
    unsigned token=atomic_load_explicit(&o->token,memory_order_acquire);
    if(p==SP_TCAP_SAVING && worker() && token &&
       atomic_compare_exchange_strong_explicit(&o->permit,&token,0,memory_order_acq_rel,memory_order_acquire)) {
        atomic_fetch_add_explicit(&o->native_save_count,1,memory_order_relaxed);return sp_p6_record_files_v552_save(a,b,c,d);
    }
    atomic_fetch_add_explicit(&o->blocked_save_count,1,memory_order_relaxed);
    fault(o,rd(OUTER+0x250)?(int32_t)rd(OUTER+0x250):SP_TCAP_UNEXPECTED_SAVE);
    return (uint32_t)SP_TCAP_BLOCKED;
}
int32_t sp_synth_capture_timed_v552_save_once(uint32_t token) {
    SpSynthCaptureTimedV552 *o=get();
    uint32_t primask,faultmask;
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    if(!o || !worker() || !same(o,token) || !recorder(o) || byte(OUTER+0x24E) ||
       primask || faultmask || rd(OUTER+0x250) || rd(OUTER+0x4C)>=160 ||
       byte(OUTER+0x38) || o->project_write.terminal ||
       atomic_load_explicit(&o->state,memory_order_acquire)!=SP_TCAP_HELD ||
       atomic_load_explicit(&o->fault,memory_order_acquire))return SP_TCAP_BLOCKED;
    uint32_t project=native(0x800E1190,0,0,0,0);
    if(project>=128 || native(0x800D94D8,0x82E01144,132,0,0))return SP_TCAP_BLOCKED;
    unsigned expected=SP_TCAP_HELD;
    if(!atomic_compare_exchange_strong_explicit(&o->state,&expected,SP_TCAP_SAVING,memory_order_acq_rel,memory_order_acquire))return SP_TCAP_BLOCKED;
    o->save_project=project;o->project_calls=0;o->project_raw=INT32_MIN;
    atomic_store_explicit(&o->permit,token,memory_order_release);
    o->save_raw=(int32_t)native(0x8017ED78,OUTER,0,0,0);
    atomic_store_explicit(&o->permit,0,memory_order_release);
    if(rd(OUTER+0x250))fault(o,(int32_t)rd(OUTER+0x250));
    if(sp_p6_save_two_leg_v552_complete()!=o ||
       o->project_raw!=1)fault(o,SP_TCAP_PROJECT);
    phase(o,SP_TCAP_FINALIZED);
    int32_t error=(int32_t)atomic_load_explicit(&o->fault,memory_order_acquire);
    return error?error:o->save_raw;
}
uint32_t sp_synth_capture_timed_v552_project_save(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || PHASE(atomic_load_explicit(&o->state,memory_order_acquire))==SP_TCAP_FREE)
        return native(0x800CF218,a,b,c,d);
    uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
    if(!worker() || !token || a!=0x82E2CD08 || (b!=UINT32_MAX && b!=o->save_project) ||
       atomic_load_explicit(&o->state,memory_order_acquire)!=SP_TCAP_SAVING) {
        fault(o,SP_TCAP_PROJECT);return 0;
    }
    if(o->project_calls++) { fault(o,SP_TCAP_PROJECT);return 0; }
    o->project_raw=sp_synth_project_save_v552_run(&o->project_write,token,o->save_project);
    if(o->project_raw!=1)fault(o,SP_TCAP_PROJECT);
    return o->project_raw==1?1u:0u;
}
static int rx_window(SpSynthCaptureTimedV552 *o,uint32_t token) {
    SpSynthCaptureWindow *w=&o->window;
    if(w->start.take_token==token)return 1;
    if(o->plan.take_token!=token)return 0;
    if(w->last_token) {
        /* Cleanup is monotonic. An intervening take that failed before its
         * first RX block may leave the older window unretired. */
        if(atomic_load_explicit(&o->cleanup_token,memory_order_acquire)<w->last_token ||
           !sp_synth_capture_window_retire(w,w->last_token))return 0;
    }
    if(!sp_synth_capture_window_arm(w,&o->plan))return 0;
    if(o->plan.plan.capture.include_release_tail) {
        /* Bound captured tail PCM independently of control/worker progress.
         * A qualified natural-tail fence may shorten this maximum later. */
        uint64_t cap=(uint64_t)o->sample_rate_hz*5u;
        if(w->nominal_end>UINT64_MAX-cap ||
           !sp_synth_capture_window_stop_at(w,token,w->nominal_end+cap))return 0;
    }
    return 1;
}
static void rx_notice(SpSynthCaptureTimedV552 *o,uint32_t token) {
    const SpSynthCaptureWindow *w=&o->window;
    if(w->start.take_token!=token || atomic_load_explicit(&o->notice_ready,memory_order_acquire))return;
    SpSynthCaptureTimedNotice n={0};
    n.observed_frames=w->observed_frames;n.accepted_frames=w->accepted_frames;
    n.generation=w->start.start_generation;n.token=token;n.phase=w->phase;
    n.failed_accepted=w->failed_accepted;n.native_failed=w->native_failed;
    n.tail_cut_reason=atomic_load_explicit(&o->tail_cut_reason,memory_order_acquire);
    if(w->accepted_frames)n.milestones|=SP_TCAP_PCM_STARTED;
    if(w->accepted_frames>=w->start.plan.duration_frames)n.milestones|=SP_TCAP_NOMINAL_REACHED;
    if(w->phase==SP_CAPTURE_WINDOW_SEALED || w->phase==SP_CAPTURE_WINDOW_CANCELED ||
       w->phase==SP_CAPTURE_WINDOW_ERROR)n.milestones|=SP_TCAP_WINDOW_ENDED;
    o->notice=n;atomic_store_explicit(&o->notice_ready,1,memory_order_release);wake();
}
uint32_t sp_synth_capture_timed_v552_rx(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthCaptureTimedV552 *o=get();uint32_t token=0,id=0,qualified=0,entered=0;
    /* SYNTH_ONLY uses the real final-PCM TX envelope as sole producer.
     * Keep original RX extraction/backsampling live; normal-recorder
     * consume below refuses this source outside the TX envelope. */
    if(o && p6_source==SP_P6_SOURCE_SYNTH_ONLY &&
       atomic_load_explicit(&o->token,memory_order_acquire)) {
        uint32_t primask,faultmask;
        __asm__ volatile("mrs %0, primask":"=r"(primask));
        __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
        if(primask || faultmask || rd(0x202BBBF8) || context()!=p6_tx_task) {
            fault(o,SP_TCAP_CONTEXT);handback_fault(o,SP_TCAP_CONTEXT);
            return (uint32_t)SP_TCAP_BLOCKED;
        }
        if(!enter(o,0,1))return (uint32_t)SP_TCAP_BLOCKED;
        uint32_t result=native(0x1CA80,a,b,c,d);leave(o);return result;
    }
    if(o) {
        id=context();unsigned empty=0;
        if(id)(void)atomic_compare_exchange_strong_explicit(&o->audio_task,&empty,id,memory_order_release,memory_order_relaxed);
        qualified=id && atomic_load_explicit(&o->audio_task,memory_order_acquire)==id;
        if(!enter(o,0,1))return (uint32_t)SP_TCAP_BLOCKED;
        token=atomic_load_explicit(&o->token,memory_order_acquire);
        if(!qualified && PHASE(atomic_load_explicit(&o->state,memory_order_acquire))!=SP_TCAP_FREE) {
            fault(o,SP_TCAP_CONTEXT);
            handback_fault(o,SP_TCAP_CONTEXT);
        }
        if(qualified && token) {
            unsigned empty=0;
            if(!atomic_compare_exchange_strong_explicit(&o->rx_active,&empty,token,
                memory_order_acq_rel,memory_order_acquire)) {
                fault(o,SP_TCAP_CONTEXT);leave(o);return (uint32_t)SP_TCAP_BLOCKED;
            }
            entered=1;
        }
    }
    uint32_t result=native(0x1CA80,a,b,c,d);
    if(o) {
        unsigned p=PHASE(atomic_load_explicit(&o->state,memory_order_acquire));
        if(entered && same(o,token)) {
            SpSynthCaptureWindow *w=&o->window;
            if(p==SP_TCAP_STOP_PENDING && w->start.take_token==token &&
               (w->phase==SP_CAPTURE_WINDOW_COUNT_IN || w->phase==SP_CAPTURE_WINDOW_RECORD ||
                w->phase==SP_CAPTURE_WINDOW_TAIL))
                (void)sp_synth_capture_window_stop_at(w,token,w->observed_frames);
            rx_notice(o,token);
            atomic_store_explicit(&o->rx_active,0,memory_order_release);
        }
        if(qualified && p==SP_TCAP_STOP_PENDING && same(o,token)) {
            *(volatile uint8_t *)(uintptr_t)(OUTER+0x24E)=0;
            atomic_store_explicit(&o->rx_ack,token,memory_order_release);
        }
        leave(o);
    }
    return result;
}
uint32_t sp_synth_capture_timed_v552_consume(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthCaptureTimedV552 *o=get();
    if(o && a==OUTER) {
        unsigned p=PHASE(atomic_load_explicit(&o->state,memory_order_acquire));
        if(p!=SP_TCAP_FREE && p!=SP_TCAP_RUNNING && p!=SP_TCAP_STOP_PENDING)return a;
        if(p!=SP_TCAP_FREE) {
            uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
            if(p6_source==SP_P6_SOURCE_SYNTH_ONLY && p6_tx_token!=token)return a;
            if(p6_source==SP_P6_SOURCE_SYNTH_ONLY && (b!=p6_pcm || c!=64)) {
                fault(o,SP_TCAP_CONTEXT);return a;
            }
            uint32_t id=context();
            if(!token || !id || id!=atomic_load_explicit(&o->audio_task,memory_order_acquire) ||
               atomic_load_explicit(&o->rx_active,memory_order_acquire)!=token) {
                fault(o,SP_TCAP_CONTEXT);return a;
            }
            if(p==SP_TCAP_STOP_PENDING)return a;
            if(!rx_window(o,token)) { fault(o,SP_TCAP_NATIVE_STATE);return a; }
#ifdef SP_SYNTH_FULL_V552
            uint32_t at_limit=0;
            if(o->plan.plan.capture.include_release_tail &&
               !sp_synth_capture_tail_v552_step(&o->window,&at_limit)) {
                fault(o,SP_TCAP_CUTOFF);return a;
            }
#endif
            if(atomic_load_explicit(&o->fence_phase,memory_order_acquire)==1) {
                int ok=o->fence_token==token &&
                    sp_synth_capture_window_stop_at(&o->window,token,o->fence_frame);
                o->fence_result=ok?1:-1;
                atomic_store_explicit(&o->fence_phase,2,memory_order_release);
                if(!ok) { fault(o,SP_TCAP_CUTOFF);return a; }
            }
            int result=sp_synth_capture_window_v552_consume(&o->window,token,(const int16_t *)(uintptr_t)b,c);
            if(result!=1) { fault(o,SP_TCAP_NATIVE_STATE);return a; }
#ifdef SP_SYNTH_FULL_V552
            if(at_limit && o->window.phase==SP_CAPTURE_WINDOW_SEALED) {
                unsigned empty=SP_APP_TAIL_CUT_NONE;
                (void)atomic_compare_exchange_strong_explicit(&o->tail_cut_reason,&empty,
                    SP_APP_TAIL_CUT_LIMIT,memory_order_release,memory_order_relaxed);
            }
#endif
            if(o->window.accepted_frames && atomic_load_explicit(&o->started_token,memory_order_acquire)!=token) {
                atomic_store_explicit(&o->started_token,token,memory_order_release);wake();
            }
            return a;
        }
    }
    return sp_tcapture_native_consume(a,b,c,d);
}
static int beginning(SpSynthCaptureTimedV552 *o) {
    return o && worker() && PHASE(atomic_load_explicit(&o->state,memory_order_acquire))==SP_TCAP_BEGIN;
}
static uint32_t query(uintptr_t fn,unsigned bit,uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthCaptureTimedV552 *o=get();
    int qualify=beginning(o) && ((bit==1 && a==0x82E0EBBC && b==3) ||
        (bit==2 && a==0x82E01144 && b==39 && c==0));
    /* Mark the exact setup call while the original query executes. A nested
     * invocation retains native behavior and cannot claim this override. */
    int claim=qualify && !(o->override_mask&(bit|0x100u));
    if(claim)o->override_mask|=0x100u;
    uint32_t result=native(fn,a,b,c,d);
    if(claim) { o->override_mask=(o->override_mask&~0x100u)|bit;return 1; }
    return result;
}
uint32_t sp_synth_capture_timed_v552_stereo_query(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return query(0x800D56D8,1,a,b,c,d);
}
uint32_t sp_synth_capture_timed_v552_mode_query(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return query(0x800D94D8,2,a,b,c,d);
}
uint32_t sp_synth_capture_timed_v552_setup_unlink(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    uint32_t result=native(0x800DECD8,a,b,c,d);
    SpSynthCaptureTimedV552 *o=get();
    if(beginning(o) && a==OUTER+0x50)o->setup_unlink_raw=(int32_t)result;
    return result;
}
uint32_t sp_synth_capture_timed_v552_initial_write(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthCaptureTimedV552 *o=get();
    int qualify=beginning(o) && a==NORMAL;
    if(qualify && o->write_count) { fault(o,SP_TCAP_INITIAL_WRITE);return UINT32_MAX; }
    if(qualify)o->write_count=1;
    uint32_t result=native(0x1BC7C,a,b,c,d);
    if(qualify) {
        o->initial_write_raw=(int32_t)result;
        if(c!=512 || result!=512)fault(o,SP_TCAP_INITIAL_WRITE);
    }
    return result;
}
static uint32_t writer(Native fn,int deferred,uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o)return fn(a,b,c,d);
    if(!enter(o,0,1))return (uint32_t)SP_TCAP_BLOCKED;
    unsigned p=PHASE(atomic_load_explicit(&o->state,memory_order_acquire));
    if(!context()) {
        handback_fault(o,SP_TCAP_CONTEXT);
        if(p!=SP_TCAP_FREE) { leave(o);return (uint32_t)SP_TCAP_BLOCKED; }
    }
    int protected=deferred?(a && byte(a)==0xA4 && command_number(byte(a+3))):protected_command(a);
    uint32_t result=(p!=SP_TCAP_FREE && protected)?(uint32_t)SP_TCAP_BLOCKED:fn(a,b,c,d);
    leave(o);return result;
}
uint32_t sp_synth_capture_timed_v552_append(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return writer(sp_tcapture_native_append,0,a,b,c,d);
}
uint32_t sp_synth_capture_timed_v552_coalesce(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return writer(sp_tcapture_native_coalesce,0,a,b,c,d);
}
uint32_t sp_synth_capture_timed_v552_deferred(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return writer(sp_tcapture_native_deferred,1,a,b,c,d);
}
static uint32_t post(Native fn,uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o)return fn(a,b,c,d);
    if(!enter(o,0,1))return (uint32_t)SP_TCAP_BLOCKED;
    unsigned p=PHASE(atomic_load_explicit(&o->state,memory_order_acquire));
    if(!context()) {
        handback_fault(o,SP_TCAP_CONTEXT);
        if(p!=SP_TCAP_FREE) { leave(o);return (uint32_t)SP_TCAP_BLOCKED; }
    }
    uint32_t result=(p==SP_TCAP_FREE || p==SP_TCAP_RUNNING || p==SP_TCAP_STOP_PENDING ||
        (fn==sp_tcapture_native_post_drain && worker() &&
         sp_p6_record_fullbar_v552_post_ready(o)))?
        fn(a,b,c,d):(uint32_t)SP_TCAP_BLOCKED;
    leave(o);return result;
}
uint32_t sp_synth_capture_timed_v552_post_drain(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return post(sp_tcapture_native_post_drain,a,b,c,d);
}
uint32_t sp_synth_capture_timed_v552_post_save(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return post(sp_tcapture_native_post_save,a,b,c,d);
}

int sp_p6_capture_v552_source(uint32_t source,const int16_t *pcm,uint32_t audio_task) {
    SpSynthCaptureTimedV552 *o=get();uintptr_t pointer=(uintptr_t)pcm;
    uint32_t primask,faultmask;
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    if(primask || faultmask || !o || !worker() || p6_tx_token || audio_task<1 || audio_task>32 ||
       audio_task==rd(SMPL+4) || (source!=SP_P6_SOURCE_SYNTH_ONLY && source!=SP_P6_SOURCE_NATIVE_MIX) ||
       !pointer || (pointer&3u) || pointer>UINTPTR_MAX-256u ||
       !disjoint(pcm,256,o,sizeof(*o)) ||
       !disjoint(pcm,256,(const void *)OUTER,0x260) || !disjoint(pcm,256,(const void *)NORMAL,552) ||
       !disjoint(pcm,256,(const void *)SP_SYNTH_V552_POOL_BEGIN,SP_SYNTH_V552_POOL_END-SP_SYNTH_V552_POOL_BEGIN) ||
       atomic_load_explicit(&o->token,memory_order_acquire) ||
       atomic_load_explicit(&o->rx_active,memory_order_acquire) ||
       atomic_load_explicit(&o->fault,memory_order_acquire))return 0;
    unsigned state=atomic_load_explicit(&o->state,memory_order_acquire);
    if(state!=SP_TCAP_FREE && state!=SP_TCAP_EXCLUSIVE_IDLE)return 0;
    /* A completed earlier source is retired before changing the producer task.
     * FREE/EXCLUSIVE_IDLE excludes owned native callbacks; no file is touched. */
    p6_pcm=(uint32_t)pointer;p6_tx_task=audio_task;p6_source=source;
    atomic_store_explicit(&o->audio_task,0,memory_order_release);return 1;
}



/* Read by the two original native beat dispatchers. No separate click lease
 * or native REC mode is written. RUNNING is release-published after BEGIN;
 * started_token proves that the actual synth-only PCM feed has begun. STOP,
 * cancellation and fault leave this predicate through the existing owner. */
int sp_p6_capture_v552_metronome_active(void) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || atomic_load_explicit(&p6_source,memory_order_acquire)!=SP_P6_SOURCE_SYNTH_ONLY)
        return 0;
    uint32_t state=atomic_load_explicit(&o->state,memory_order_acquire);
    if((state&SP_TCAP_UNSUPPORTED) || PHASE(state)!=SP_TCAP_RUNNING ||
       atomic_load_explicit(&o->fault,memory_order_acquire) ||
       atomic_load_explicit(&o->handoff_fault,memory_order_acquire))return 0;
    uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
    return token && o->plan.take_token==token && o->plan.start_generation &&
        atomic_load_explicit(&o->started_token,memory_order_acquire)==token &&
        PHASE(atomic_load_explicit(&o->state,memory_order_acquire))==SP_TCAP_RUNNING &&
        atomic_load_explicit(&o->token,memory_order_acquire)==token;
}

int sp_p6_capture_v552_tx(const int16_t *pcm,uint32_t frames) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || p6_source!=SP_P6_SOURCE_SYNTH_ONLY)return 0;
    unsigned state=atomic_load_explicit(&o->state,memory_order_acquire);
    if(PHASE(state)==SP_TCAP_FREE || PHASE(state)==SP_TCAP_EXCLUSIVE_IDLE)return 0;
    uint32_t primask,faultmask;
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    if(primask || faultmask || rd(0x202BBBF8) ||
       (uintptr_t)pcm!=p6_pcm || frames!=64 || context()!=p6_tx_task || p6_tx_token) {
        fault(o,SP_TCAP_CONTEXT);return -1;
    }
    if(!enter(o,0,1))return -1;
    unsigned phase_now=PHASE(atomic_load_explicit(&o->state,memory_order_acquire));
    uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
    if(!token || (phase_now!=SP_TCAP_RUNNING && phase_now!=SP_TCAP_STOP_PENDING)) {
        leave(o);return 0;
    }
    unsigned empty=0;
    (void)atomic_compare_exchange_strong_explicit(&o->audio_task,&empty,p6_tx_task,
        memory_order_release,memory_order_relaxed);
    empty=0;
    if(atomic_load_explicit(&o->audio_task,memory_order_acquire)!=p6_tx_task ||
       !atomic_compare_exchange_strong_explicit(&o->rx_active,&empty,token,
           memory_order_acq_rel,memory_order_acquire)) {
        fault(o,SP_TCAP_CONTEXT);leave(o);return -1;
    }
    p6_tx_token=token;
    if(phase_now==SP_TCAP_RUNNING)
        (void)sp_synth_capture_timed_v552_consume(OUTER,p6_pcm,64,0);
    p6_tx_token=0;
    phase_now=PHASE(atomic_load_explicit(&o->state,memory_order_acquire));
    if(same(o,token)) {
        SpSynthCaptureWindow *w=&o->window;
        if(phase_now==SP_TCAP_STOP_PENDING && w->start.take_token==token &&
           (w->phase==SP_CAPTURE_WINDOW_COUNT_IN || w->phase==SP_CAPTURE_WINDOW_RECORD ||
            w->phase==SP_CAPTURE_WINDOW_TAIL))
            (void)sp_synth_capture_window_stop_at(w,token,w->observed_frames);
        rx_notice(o,token);
        atomic_store_explicit(&o->rx_active,0,memory_order_release);
        if(phase_now==SP_TCAP_STOP_PENDING) {
            *(volatile uint8_t *)(uintptr_t)(OUTER+0x24E)=0;
            atomic_store_explicit(&o->rx_ack,token,memory_order_release);
        }
    }
    leave(o);
    return atomic_load_explicit(&o->fault,memory_order_acquire)?-1:1;
}

int sp_p6_capture_v552_tx_fault(const int16_t *pcm,uint32_t frames) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || p6_source!=SP_P6_SOURCE_SYNTH_ONLY)return 0;
    unsigned state=atomic_load_explicit(&o->state,memory_order_acquire);
    if(PHASE(state)!=SP_TCAP_RUNNING && PHASE(state)!=SP_TCAP_STOP_PENDING)return 0;
    uint32_t primask,faultmask;
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    if(primask || faultmask || rd(0x202BBBF8) ||
       (uintptr_t)pcm!=p6_pcm || frames!=64 || context()!=p6_tx_task || p6_tx_token) {
        fault(o,SP_TCAP_CONTEXT);return -1;
    }
    fault(o,SP_TCAP_NATIVE_STATE);
    return sp_p6_capture_v552_tx(pcm,frames);
}

int sp_p6_capture_v552_tail_idle(const int16_t *pcm,uint32_t frames,uint32_t released) {
    SpSynthCaptureTimedV552 *o=get();
    if(!o || p6_source!=SP_P6_SOURCE_SYNTH_ONLY || !released)return 0;
    unsigned state=atomic_load_explicit(&o->state,memory_order_acquire);
    if(PHASE(state)!=SP_TCAP_RUNNING)return 0;
    uint32_t primask,faultmask;
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    if(released!=1 || primask || faultmask || rd(0x202BBBF8) ||
       (uintptr_t)pcm!=p6_pcm || frames!=64 || context()!=p6_tx_task || p6_tx_token) {
        fault(o,SP_TCAP_CONTEXT);return -1;
    }
    if(!enter(o,0,1))return -1;
    int result=0;
    SpSynthCaptureWindow *w=&o->window;
    uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
    if(token && w->start.take_token==token && w->phase==SP_CAPTURE_WINDOW_TAIL &&
       w->start.plan.capture.include_release_tail &&
       w->observed_frames<=UINT64_MAX-frames) {
        unsigned nonzero=0;for(unsigned i=0;i<128;++i)nonzero|=(uint16_t)pcm[i];
        if(!nonzero)result=sp_synth_capture_window_stop_at(w,token,w->observed_frames+frames);
    }
    leave(o);return result;
}

/* Read-only BEGIN precheck; no source rebinding or ownership reset. */
uint32_t sp_p6_record_start_capture_idle_v552(void) {
    return get()==&sp_p6_production_capture && worker() &&
        sp_p6_record_start_rec_init_v552_current() &&
        atomic_load_explicit(&p6_source,memory_order_acquire)==SP_P6_SOURCE_SYNTH_ONLY &&
        atomic_load_explicit(&p6_pcm,memory_order_acquire)==(uintptr_t)sp_synth_preview_native_v552.scratch.stereo &&
        atomic_load_explicit(&p6_tx_task,memory_order_acquire)==sp_synth_preview_native_v552.config.audio_task &&
        !atomic_load_explicit(&p6_tx_token,memory_order_acquire);
}

/* This one installed SAVE call normally reads the native automatic onset.
 * The manual Synth take instead retains its acknowledged REC timeline. The
 * original selected method still executes once for every call; all other
 * profiles and contexts return its result without changing native settings. */
uint64_t sp_p6_capture_manual_save_startpoint_v552(void *recorder_object) {
    uintptr_t caller=(uintptr_t)__builtin_return_address(0);
    uintptr_t object_address=(uintptr_t)recorder_object;
    uintptr_t vtable=rd(object_address);
    uint64_t original=((uint64_t (*)(void *))(uintptr_t)rd(vtable+0x50u))(recorder_object);
    uint32_t primask,faultmask;
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    SpSynthCaptureTimedV552 *o=get();
    const SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    const SpP6RecordFilesV552 *files=&sp_p6_record_files_v552;
    if(caller!=UINT32_C(0x8017EFCB) || object_address!=NORMAL ||
       !o || s->capture!=o || p6_source!=SP_P6_SOURCE_SYNTH_ONLY ||
       atomic_load_explicit(&o->state,memory_order_acquire)!=SP_TCAP_SAVING ||
       !manual_profile(o) || !worker() || primask || faultmask)return original;
    uint32_t token=atomic_load_explicit(&o->token,memory_order_acquire);
    if(s->state!=SP_P6_SAVE_WRITING || s->fault || !token || s->token!=token ||
       o->last_token!=token || o->plan.take_token!=token || manual_clock.token!=token ||
       !o->plan.start_generation || s->generation!=o->plan.start_generation ||
       atomic_load_explicit(&o->permit,memory_order_acquire) ||
       !atomic_load_explicit(&o->native_save_count,memory_order_acquire) ||
       atomic_load_explicit(&o->fault,memory_order_acquire) ||
       atomic_load_explicit(&o->handoff_fault,memory_order_acquire) ||
       atomic_load_explicit(&o->handoff_pending,memory_order_acquire) ||
       atomic_load_explicit(&o->rx_active,memory_order_acquire) ||
       atomic_load_explicit(&o->rx_ack,memory_order_acquire)!=token ||
       atomic_load_explicit(&o->started_token,memory_order_acquire)!=token ||
       o->window.phase!=SP_CAPTURE_WINDOW_SEALED || o->window.inflight ||
       o->window.start.take_token!=token ||
       o->window.start.start_generation!=o->plan.start_generation ||
       o->window.accepted_frames!=s->frames || s->frames<1000u ||
       s->frames>(UINT32_MAX-512u)/4u || s->bytes!=512u+4u*s->frames ||
       !o->file_owned || o->handle<1u || o->handle>=1024u ||
       o->descriptor<UINT32_C(0x80000000) || o->descriptor>=UINT32_C(0x84000000) ||
       (o->descriptor&3u) || rd(OUTER+72u)!=UINT32_MAX || rd(NORMAL+432u)!=o->handle ||
       byte(OUTER+56u) || byte(OUTER+590u) ||
       rd(OUTER+592u) || rd(OUTER+596u)!=NORMAL ||
       !files->active || !files->serial || files->fault ||
       files->project!=s->project || files->pad!=s->pad ||
       sp_p6_record_token_v552_actual_token()!=token ||
       files->record_operation || files->cache_depth || files->smpl_operation!=SP_P6_RF_SAVE ||
       rd(NORMAL+448u)!=512u || rd(NORMAL+452u) ||
       rd(NORMAL+456u)!=s->bytes || rd(NORMAL+460u) ||
       rd(NORMAL+512u)!=s->frames || rd(NORMAL+516u) ||
       atomic_load_explicit(&o->state,memory_order_acquire)!=SP_TCAP_SAVING ||
       atomic_load_explicit(&o->token,memory_order_acquire)!=token)return original;
    /* Native SAVE has already closed the original recording FILE and loaded
     * the destination header. A reused FD now belongs to its new reader.
     * The source journal, rather than that FD's current table entry, proves
     * successful retirement of the exact recorded temporary FILE. */
    uint32_t ctx=sp_p6_record_context_v552_current(1);
    unsigned temporary_rows=0;
    if(!ctx)return original;
    for(unsigned i=0;i<15u;i++) {
        const SpP6RecordFileIdentityV552 *f=&files->files[i];
        if(f->kind!=SP_P6_RF_TEMP)continue;
        temporary_rows++;
        if(f->state!=SP_P6_RF_CLOSED || f->fd!=o->handle || f->file!=o->descriptor ||
           f->context!=ctx || f->task!=rd(ctx) || f->operation!=SP_P6_RF_START ||
           f->close_attempted!=3u || f->close_raw || f->directory_context)return original;
    }
    if(temporary_rows!=1u || atomic_load_explicit(&o->state,memory_order_acquire)!=SP_TCAP_SAVING ||
       atomic_load_explicit(&o->token,memory_order_acquire)!=token)return original;
    return UINT64_C(512);
}
