#include "sp_p6_production_join.h"
#include "sp_p6_record_token_v552.h"
#include "sp_p6_record_retirement_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_files_v552.h"
#include <stddef.h>
#define OUTER 0x82E0E71Cu
#define NORMAL 0x82FE4F08u
typedef struct {
    SpSynthCaptureTimedV552 *capture;
    uint32_t state,token,generation,last_retired;
} SpP6RecordTokenV552;
static SpP6RecordTokenV552 token_owner;
_Static_assert(sizeof(SpP6RecordTokenV552)==20,"Source token binding budget");
static uint32_t rd(uint32_t p) { return *(volatile const uint32_t *)(uintptr_t)p; }
static uint8_t byte(uint32_t p) { return *(volatile const uint8_t *)(uintptr_t)p; }
static uint32_t value(const atomic_uint *a) { return atomic_load_explicit(a,memory_order_acquire); }
static int apart(uintptr_t a,size_t n,uintptr_t b,size_t m) { return a+n<=b || b+m<=a; }
static int object(SpSynthCaptureTimedV552 *c) {
    uintptr_t p=(uintptr_t)c;
    return p>=0x80000000u && p<=0x84000000u-sizeof(*c) && !(p&7u) &&
        apart(p,sizeof(*c),(uintptr_t)&sp_p6_record_files_v552,sizeof(sp_p6_record_files_v552)) &&
        apart(p,sizeof(*c),(uintptr_t)&sp_p6_record_contexts_v552,sizeof(sp_p6_record_contexts_v552));
}
int sp_p6_record_token_v552_bind(SpSynthCaptureTimedV552 *c) {
    if(token_owner.capture || !object(c) || !sp_p6_record_context_v552_registered() ||
       value(&c->state)!=SP_TCAP_FREE || value(&c->token) || c->last_token ||
       c->file_owned || value(&c->rx_active) || value(&c->cleanup_token) || !c->sample_rate_hz)return 0;
    token_owner.capture=c;token_owner.state=1;return 1;
}
static int same(void) {
    SpSynthCaptureTimedV552 *c=token_owner.capture;
    return c && token_owner.token && value(&c->token)==token_owner.token && c->last_token==token_owner.token &&
        c->plan.take_token==token_owner.token && c->plan.start_generation==token_owner.generation &&
        token_owner.generation && !value(&c->handoff_fault);
}
int sp_p6_record_token_v552_prepare(SpSynthCaptureTimedV552 *c) {
    if(c!=token_owner.capture || token_owner.state!=1 || !sp_p6_record_context_v552_current(1) ||
       sp_p6_record_files_v552.active || value(&c->state)!=SP_TCAP_BEGIN ||
       !value(&c->token) || value(&c->token)!=c->last_token || c->last_token<=token_owner.last_retired ||
       c->plan.take_token!=c->last_token || !c->plan.start_generation || value(&c->rx_active) ||
       c->file_owned || value(&c->rx_ack) || byte(OUTER+57) || byte(OUTER+590) || (int32_t)rd(OUTER+72)>=0)return 0;
    token_owner.token=c->last_token;token_owner.generation=c->plan.start_generation;token_owner.state=2;return 1;
}
int sp_p6_record_token_v552_native_begin(void) {
    if(!token_owner.capture)return 0;
    uint32_t phase=value(&token_owner.capture->state);
    if(token_owner.state==1 && !value(&token_owner.capture->token) &&
       (phase==SP_TCAP_FREE || phase==SP_TCAP_EXCLUSIVE_IDLE))return 0;
    if(token_owner.state!=2 || !same() || value(&token_owner.capture->state)!=SP_TCAP_BEGIN ||
       !sp_p6_record_context_v552_current(1))return -1;
    token_owner.state=3;return 1;
}
int sp_p6_record_token_v552_current(void) { return token_owner.state==3 && same(); }
uint32_t sp_p6_record_token_v552_actual_token(void) {
    if(!sp_p6_record_token_v552_current() || !sp_p6_record_files_v552.active ||
       sp_p6_record_files_v552.fault || !sp_p6_record_context_v552_current(1))return 0;
    uint32_t project=((uint32_t (*)(void))(uintptr_t)0x800E1191u)();
    uint32_t storage=((uint32_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(uintptr_t)0x800D94D9u)(0x82E01144u,132,0,0);
    return project<128 && project==sp_p6_record_files_v552.project && !storage?token_owner.token:0;
}
int sp_p6_record_token_v552_discard_enter(SpSynthCaptureTimedV552 *c) {
    uint32_t serial=c==token_owner.capture?value(&c->barrier_sequence):0;
    if(!serial || !sp_p6_record_token_v552_current() || !sp_p6_record_context_v552_current(1) ||
       value(&c->state)!=SP_TCAP_DISCARDING || value(&c->rx_active) || value(&c->rx_ack)!=token_owner.token ||
       value(&c->barrier_token)!=token_owner.token || value(&c->barrier_ack)!=serial || value(&c->wait_sequence)!=serial ||
       (sp_p6_record_files_v552.fault&~SP_P6_RF_IO) || !sp_p6_record_files_v552.active || sp_p6_record_files_v552.smpl_operation ||
       byte(OUTER+590) || !c->file_owned)return 0;
    if(sp_p6_record_files_v552.fault) {
        if(sp_p6_record_files_v552_outstanding()!=1)return 0;
        int exact=0;
        for(unsigned i=0;i<15;i++) {
            SpP6RecordFileIdentityV552 *f=&sp_p6_record_files_v552.files[i];
            if(f->kind==SP_P6_RF_TEMP && f->state==SP_P6_RF_LIVE && f->fd==c->handle &&
               f->file==c->descriptor && !f->close_attempted)exact=1;
        }
        if(!exact)return 0;
    }
    sp_p6_record_files_v552.smpl_operation=SP_P6_RF_DISCARD;return 1;
}
int sp_p6_record_token_v552_discard_retired(SpSynthCaptureTimedV552 *c) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    uint32_t serial=c==token_owner.capture?value(&c->barrier_sequence):0;
    if(!serial || token_owner.state!=3 || c!=token_owner.capture || !sp_p6_record_context_v552_current(1) ||
       value(&c->state)!=SP_TCAP_EXCLUSIVE_IDLE || value(&c->token) || value(&c->cleanup_token)!=token_owner.token ||
       value(&c->rx_active) || c->file_owned || c->window.inflight || value(&c->barrier_token)!=token_owner.token ||
       value(&c->barrier_ack)!=serial || value(&c->wait_sequence)!=serial || o->smpl_operation!=SP_P6_RF_DISCARD ||
       o->record_operation || (o->fault&~SP_P6_RF_IO) || sp_p6_record_files_v552_outstanding() ||
       c->close_raw || c->unlink_raw || !c->discard_attempted || byte(OUTER+57) || byte(OUTER+590) ||
       (int32_t)rd(OUTER+72)>=0 || rd(OUTER+592) || rd(OUTER+596)!=NORMAL || rd(NORMAL)!=0x8021E020u ||
       (int32_t)rd(NORMAL+432)>=0 || rd(NORMAL+420)>=30 || rd(NORMAL+424)>=30)return 0;
    for(unsigned i=0;i<30;i++)if(byte(NORMAL+60+12*i) || rd(NORMAL+64+12*i))return 0;
    /* Closed journal records may be recycled only after this actual cleanup
     * receipt. Permanent native contexts and lifetime counters are retained. */
    for(unsigned i=0;i<15;i++) {
        volatile uint32_t *words=(volatile uint32_t *)&o->files[i];
        for(unsigned k=0;k<sizeof(o->files[i])/4;k++)words[k]=0;
    }
    for(unsigned i=0;i<5;i++)for(unsigned k=0;k<64;k++)o->path[i][k]=0;
    o->smpl_operation=0;o->project=UINT32_MAX;o->pad=UINT32_MAX;o->cache_depth=0;o->fault=0;o->active=0;
    token_owner.last_retired=token_owner.token;token_owner.token=0;token_owner.generation=0;token_owner.state=1;return 1;
}

/* Included only in the checked local derivation of the frozen token provider. */
#include "sp_p6_save_handover_v552.h"
int sp_p6_record_token_v552_save_retired(SpSynthCaptureTimedV552 *c) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(c!=token_owner.capture || token_owner.state!=3 || !token_owner.token ||
       !sp_p6_record_context_v552_current(1) || !sp_p6_save_v552_retirement_ready(c) ||
       value(&c->state)!=SP_TCAP_RESERVING || value(&c->token)!=token_owner.token ||
       value(&c->cleanup_token)>=token_owner.token || !c->file_owned || value(&c->rx_active) ||
       c->window.inflight || byte(OUTER+57) || byte(OUTER+590) || rd(OUTER+592) ||
       (int32_t)rd(OUTER+72)>=0 || rd(OUTER+596)!=NORMAL || rd(NORMAL)!=0x8021E020u ||
       (int32_t)rd(NORMAL+432)>=0 || rd(NORMAL+420)>=30 || rd(NORMAL+424)>=30)return 0;
    for(unsigned i=0;i<30;i++)if(byte(NORMAL+60+12*i) || rd(NORMAL+64+12*i))return 0;
    /* Detach the live cache obligation into the provider receipt. Never close
     * its native FILE or label its journal record CLOSED. */
    for(unsigned i=0;i<15;i++) {
        volatile uint32_t *w=(volatile uint32_t *)&o->files[i];
        for(unsigned k=0;k<sizeof(o->files[i])/4;k++)w[k]=0;
    }
    for(unsigned i=0;i<5;i++)for(unsigned k=0;k<64;k++)o->path[i][k]=0;
    o->active=0;o->project=o->pad=UINT32_MAX;
    c->file_owned=0;atomic_store_explicit(&c->cleanup_token,token_owner.token,memory_order_release);
    atomic_store_explicit(&c->token,0,memory_order_release);
    atomic_store_explicit(&c->state,SP_TCAP_EXCLUSIVE_IDLE,memory_order_release);
    token_owner.last_retired=token_owner.token;token_owner.token=token_owner.generation=0;token_owner.state=1;return 1;
}

uint32_t sp_p6_record_retirement_v552_token_retired(void) {
    SpSynthCaptureTimedV552 *c=token_owner.capture;
    if(c!=&sp_p6_production_capture || token_owner.state!=1 || token_owner.token || token_owner.generation ||
       !token_owner.last_retired || atomic_load_explicit(&c->token,memory_order_acquire) ||
       atomic_load_explicit(&c->cleanup_token,memory_order_acquire)!=token_owner.last_retired ||
       c->last_token!=token_owner.last_retired)return 0;
    return token_owner.last_retired;
}

/* Actual native token provider vacancy, including its private prepared state. */
uint32_t sp_p6_record_start_token_idle_v552(void) {
    return sp_p6_record_context_v552_current(1) &&
        token_owner.capture==&sp_p6_production_capture && token_owner.state==1 &&
        !token_owner.token && !token_owner.generation &&
        token_owner.last_retired==sp_p6_production_capture.last_token;
}
