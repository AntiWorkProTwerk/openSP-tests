#include "sp_p6_record_ingress_alias_v552.h"
extern uint32_t sp_p6_mf_v552_import_coverage(void);
uint32_t sp_p6_ia_v552_hook_coverage(void){
if(*(volatile const uint32_t*)0x1CC5Cu!=0xF000F8DFu ||
*(volatile const uint32_t*)0x1CC60u!=((uint32_t)(uintptr_t)sp_p6_ia_v552_outer|1u))return 0;
if(*(volatile const uint32_t*)0x8017A320u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x8017A324u!=((uint32_t)(uintptr_t)sp_p6_ia_v552_inner|1u))return 0;
if(*(volatile const uint32_t*)0x801845F0u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x801845F4u!=((uint32_t)(uintptr_t)sp_p6_ia_v552_handler|1u))return 0;
if(*(volatile const uint16_t*)0x801845F8u!=0xBF00u)return 0;
if(*(volatile const uint32_t*)0x800100D0u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x800100D4u!=((uint32_t)(uintptr_t)sp_p6_ia_v552_lower_rename|1u))return 0;
if(*(volatile const uint32_t*)0x80021710u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x80021714u!=((uint32_t)(uintptr_t)sp_p6_ia_v552_lower_unlink|1u))return 0;
if(*(volatile const uint32_t*)0x800B30A8u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x800B30ACu!=((uint32_t)(uintptr_t)sp_p6_ia_v552_media|1u))return 0;
if(*(volatile const uint32_t*)0x80024EF0u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x80024EF4u!=((uint32_t)(uintptr_t)sp_p6_ia_v552_open|1u))return 0;
if(*(volatile const uint32_t*)0x800D9CC0u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x800D9CC4u!=((uint32_t)(uintptr_t)sp_p6_ia_v552_alternate_open|1u))return 0;
if(*(volatile const uint32_t*)0x800DD0B8u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x800DD0BCu!=((uint32_t)(uintptr_t)sp_p6_ia_v552_rename|1u))return 0;
if(*(volatile const uint32_t*)0x800DECD8u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x800DECDCu!=((uint32_t)(uintptr_t)sp_p6_ia_v552_unlink|1u))return 0;
if(*(volatile const uint32_t*)0x8017E098u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x8017E09Cu!=((uint32_t)(uintptr_t)sp_p6_ia_v552_copy|1u))return 0;
if(*(volatile const uint32_t*)0x8021D054u!=((uint32_t)(uintptr_t)sp_p6_ia_v552_callback|1u))return 0;
return sp_p6_mf_v552_import_coverage();}
