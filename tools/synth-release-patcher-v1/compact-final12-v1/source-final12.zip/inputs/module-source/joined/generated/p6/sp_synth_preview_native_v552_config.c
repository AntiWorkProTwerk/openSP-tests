#include "sp_synth_preview_native_v552.h"
static const SpPreviewNativeConfigV552 trial={
    .trial_policy=UINT32_C(0x50544E31), .sample_rate=48000, .pair_index=2,
    .audio_task=1, .control_lease_frames=48000
};
const SpPreviewNativeConfigV552 *const sp_synth_preview_native_v552_config=&trial;
