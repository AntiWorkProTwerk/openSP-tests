#ifndef SP_SYNTH_UI_RENDER_H
#define SP_SYNTH_UI_RENDER_H
#include <stdint.h>

/* Semantic view of the saved Penpot design. A stock presenter must clip text
 * using measured bitmap-font metrics; this is not an OLED framebuffer. */
typedef struct sp_ui_view {
    char header[32], hero[32], footer[48];
    char error[24];
    char rows[4][32], labels[3][16], values[3][16];
    uint8_t row_count, selected, focused, controls, busy, dirty, take_held;
    uint8_t pickup_visible, pickup_knob;
    int8_t pickup_direction;
    uint32_t elapsed_ms;
    uint8_t row_selection, show_focus;
    uint8_t plot_valid; /* Exactly 1 enables a supplied plot; former tail padding. */
} sp_ui_view;
#endif
