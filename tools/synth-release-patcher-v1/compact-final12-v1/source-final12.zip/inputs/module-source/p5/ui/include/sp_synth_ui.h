#ifndef SP_SYNTH_UI_H
#define SP_SYNTH_UI_H

#include <stdint.h>
#include "sp_synth_ui_render.h"

/* Original portable control model. Stock control IDs, pad pitch order, storage,
 * timing and thread ownership must be supplied by a verified host adapter. */
#define SP_UI_COMMAND_CAPACITY 20u
#define SP_UI_PAGE_COUNT 12u
#define SP_UI_BANK_CAPACITY 8u
#define SP_UI_VALUE_MAX 16383u
#define SP_UI_NAME_CAPACITY 25u

typedef enum sp_ui_page {
    SP_UI_PLAY, SP_UI_OSC, SP_UI_FILTER, SP_UI_AMP, SP_UI_MOD, SP_UI_VOICE,
    SP_UI_LFO, SP_UI_ENV2, SP_UI_KEYS, SP_UI_MACROS, SP_UI_CAPTURE_READY,
    SP_UI_BROWSER, SP_UI_RECORDING, SP_UI_DESTINATION, SP_UI_OVERWRITE,
    SP_UI_SAVE_ERROR, SP_UI_SAVED, SP_UI_NEW_CONFIRM, SP_UI_LEAVE_CONFIRM,
    SP_UI_INIT_CONFIRM, SP_UI_STORE, SP_UI_PATCH_REPLACE, SP_UI_PATCH_ERROR,
    SP_UI_CAPTURE_ERROR, SP_UI_INACTIVE
} sp_ui_page;

typedef enum sp_ui_event_type {
    SP_UI_PAD_DOWN, SP_UI_PAD_UP, SP_UI_SHIFT_DOWN, SP_UI_SHIFT_UP,
    SP_UI_VALUE_PRESS, SP_UI_VALUE_TURN, SP_UI_CTRL_MOVE, SP_UI_REC_PRESS,
    SP_UI_EXIT_PRESS, SP_UI_MIDI_DOWN, SP_UI_MIDI_UP, SP_UI_MIDI_SUSTAIN,
    SP_UI_SYNTH_PANIC, SP_UI_COMPLETE, SP_UI_NOTICE_EXPIRED,
    SP_UI_CAPTURE_PROGRESS, SP_UI_SET_METADATA
} sp_ui_event_type;

typedef enum sp_ui_command_type {
    SP_UI_CMD_PAD_ON, SP_UI_CMD_PAD_OFF, SP_UI_CMD_MIDI_ON, SP_UI_CMD_MIDI_OFF,
    SP_UI_CMD_SUSTAIN, SP_UI_CMD_RELEASE_PADS, SP_UI_CMD_PANIC,
    SP_UI_CMD_PARAM_SET, SP_UI_CMD_OCTAVE, SP_UI_CMD_GLOBAL_STOP,
    SP_UI_CMD_BROWSE_BEGIN, SP_UI_CMD_BROWSE_AUDITION,
    SP_UI_CMD_BROWSE_RESTORE, SP_UI_CMD_BROWSE_COMMIT, SP_UI_CMD_INITIALIZE,
    SP_UI_CMD_CAPTURE_START, SP_UI_CMD_CAPTURE_STOP, SP_UI_CMD_TAKE_DISCARD,
    SP_UI_CMD_DEST_QUERY, SP_UI_CMD_TAKE_WRITE, SP_UI_CMD_PATCH_QUERY,
    SP_UI_CMD_PATCH_WRITE, SP_UI_CMD_LEAVE, SP_UI_CMD_PATCH_METADATA,
    SP_UI_CMD_PREVIEW_LEVEL
} sp_ui_command_type;

typedef enum sp_ui_error {
    SP_UI_OK, SP_UI_ERR_STORAGE, SP_UI_ERR_CARD, SP_UI_ERR_FULL,
    SP_UI_ERR_READ_ONLY, SP_UI_ERR_CAPTURE, SP_UI_ERR_BACKEND,
    SP_UI_ERR_GENERATION_EXHAUSTED
} sp_ui_error;

typedef struct sp_ui_patch {
    uint32_t token;
    char name[SP_UI_NAME_CAPACITY];
    uint8_t family, favorite, factory;
} sp_ui_patch;

typedef struct sp_ui_binding {
    uint16_t parameter_id; /* Adapter maps this ID and normalized range to DSP. */
    uint16_t value;
    char label[16], display[16];
    uint16_t step; /* VALUE increment in normalized units; zero means one. */
} sp_ui_binding;

typedef struct sp_ui_event {
    sp_ui_event_type type;
    int32_t value; /* Turn delta, 0..16383 CTRL, MIDI velocity, progress ms. */
    uint32_t generation;
    uint32_t token; /* Successful captured take handle, or restored patch token. */
    uint16_t index; /* Pad 1..16, CTRL 0..2, MIDI note 0..127. */
    uint8_t channel; /* MIDI channel 0..15. */
    uint8_t occupied, factory;
    uint8_t capture_active; /* On capture failure: backend still owns a live session. */
    sp_ui_error error;
    char name[SP_UI_NAME_CAPACITY]; /* Query result or metadata; always bounded. */
} sp_ui_event;

typedef struct sp_ui_command {
    sp_ui_command_type type;
    uint32_t generation; /* Zero for immediate commands; nonzero for completion. */
    uint32_t token;
    uint32_t revision;
    int32_t value;
    uint16_t index;
    uint8_t channel, bank, replace;
    char name[SP_UI_NAME_CAPACITY];
} sp_ui_command;

typedef struct sp_ui_commands {
    sp_ui_command items[SP_UI_COMMAND_CAPACITY];
    uint8_t count;
} sp_ui_commands;

typedef struct sp_ui {
    sp_ui_page page, return_page;
    sp_ui_command_type pending;
    uint32_t generation, revision, browse_revision, take_token, elapsed_ms;
    uint32_t stale_completions;
    sp_ui_patch patch, browse_original;
    const sp_ui_patch *catalog; /* Immutable until replaced or UI stopped. */
    uint16_t catalog_count, browse_index, active_pads, physical_pads;
    sp_ui_binding bindings[SP_UI_PAGE_COUNT][SP_UI_BANK_CAPACITY][3];
    uint8_t bank_count[SP_UI_PAGE_COUNT], banks[SP_UI_PAGE_COUNT];
    uint16_t knob_position[3];
    uint8_t knob_known[3], picked_up[3];
    uint8_t shift, map, focused, selection, dirty, browse_dirty, initialized;
    uint8_t take_held, dest_bank, dest_pad, dest_known, dest_occupied;
    uint8_t store_slot, store_known, store_occupied, store_factory;
    uint8_t busy, browse_snapshot, browse_family, browse_favorites;
    uint8_t pickup_visible, pickup_knob, discard_leaves;
    int8_t octave, pickup_direction;
    sp_ui_error error;
    char destination_name[SP_UI_NAME_CAPACITY], slot_name[SP_UI_NAME_CAPACITY];
} sp_ui;

/* Bindings must be installed before a page can issue parameter commands.
 * Refreshing only formatted display text preserves knob focus/pickup. Changed
 * assignments or values reset pickup on the current bank. Catalog names are
 * bounded to 24 visible bytes; caller retains ownership of immutable catalog.
 * Input calls are single-owner and synchronous. Each dispatch returns a fresh
 * bounded command batch; consume it before dispatching another event. There is
 * no internal lossy queue. MIDI releases, pad releases and panic bypass busy. */
void sp_ui_init(sp_ui *ui, const sp_ui_patch *patch,
                const sp_ui_patch *catalog, uint16_t catalog_count);
/* Explicit fresh input-ownership boundary, never an ordinary input event.
 * Caller must finish LEAVE/panic, quiesce capture/backend work and discard old
 * queued input before calling. Only inactive, idle UI with no take may enter.
 * A matching current generation is consumed once; exhaustion rejects.
 * Returns to Play without resetting the patch, edits, bindings or catalog.
 * Installs fresh physical pads/SHIFT (0 or 1); held pads stay silent until release.
 * Resets transient map/pickup history. Retained stock releases remain owned by
 * the outer input owner and must still be delivered there.
 * Rejection leaves UI unchanged. Single UI owner only. */
int sp_ui_reenter(sp_ui *ui,uint32_t generation,uint16_t physical_pads,uint8_t shift);
/* Replace immutable metadata only when idle and outside the browser. No sound,
 * page, edited patch or take changes. Up to256 unique nonzero tokens. Caller
 * keeps new storage immutable until replaced/stopped; single UI owner only.
 * Rejects malformed metadata without changing UI. Empty catalog is allowed. */
int sp_ui_set_catalog(sp_ui *ui,const sp_ui_patch *catalog,uint16_t count);
void sp_ui_set_bank(sp_ui *ui, sp_ui_page page, uint8_t bank,
                    uint8_t bank_count, const sp_ui_binding controls[3]);
void sp_ui_dispatch(sp_ui *ui, const sp_ui_event *event, sp_ui_commands *commands);
void sp_ui_make_view(const sp_ui *ui, sp_ui_view *view);

#endif
