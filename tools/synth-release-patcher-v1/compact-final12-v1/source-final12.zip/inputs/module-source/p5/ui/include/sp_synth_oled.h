#ifndef SP_SYNTH_OLED_H
#define SP_SYNTH_OLED_H
#include "sp_synth_ui_render.h"

/* Original portable renderer. 128x64, row-major, 16 bytes/row, MSB first.
 * This is NOT the stock panel's transport format. Call outside audio processing.
 * Input/output must be disjoint. Text reads stop at each fixed field capacity.
 * Optional plot is 120 caller-owned values in 0..255, top to bottom. It is
 * drawn only when view->plot_valid is exactly 1 and plot is non-NULL.
 * Fonts are original provisional uppercase bitmaps. */
typedef struct sp_oled_frame { uint8_t bytes[1024]; } sp_oled_frame;
void sp_synth_oled_render(const sp_ui_view *view, const uint8_t plot[120],
                          sp_oled_frame *frame);
#endif
