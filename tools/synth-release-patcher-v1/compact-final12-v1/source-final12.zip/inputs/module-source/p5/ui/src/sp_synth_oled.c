#include "sp_synth_oled.h"
#include "sp_synth_oled_font.h"
#include <stddef.h>
#include <string.h>

static void pixel(sp_oled_frame *f,int x,int y,int white) {
    if((unsigned)x>=128 || (unsigned)y>=64)return;
    unsigned at=(unsigned)y*16+(unsigned)x/8;
    uint8_t mask=(uint8_t)(0x80u>>((unsigned)x&7));
    if(white)f->bytes[at]|=mask;else f->bytes[at]&=(uint8_t)~mask;
}
static void box(sp_oled_frame *f,int x,int y,int w,int h,int white) {
    for(int j=0;j<h;++j)for(int i=0;i<w;++i)pixel(f,x+i,y+j,white);
}
static unsigned glyph(unsigned char c) {
    if(c>='a' && c<='z')c=(unsigned char)(c-'a'+'A');
    if(c<32 || c>90)c='?';
    return c-32;
}
static size_t length(const char *s,size_t capacity) {
    size_t n=0;while(n<capacity && s[n])++n;return n;
}
/* Long strings reduce to the compact face before showing an explicit ellipsis.
 * Unsupported bytes produce '?'; no UTF-8 or locale-dependent calls. */
static void text(sp_oled_frame *f,int x,int y,int width,const char *s,
                 size_t capacity,int large,int white) {
    size_t n=length(s,capacity);if(!n)return;
    if(large && n*6-1>(size_t)width)large=0;
    unsigned advance=large?6:4,height=large?7:5,gwidth=advance-1;
    unsigned fit=(unsigned)(width+1)/advance;
    if(!fit)return;
    unsigned visible=n<fit?(unsigned)n:fit;
    for(unsigned i=0;i<visible;++i) {
        unsigned c=glyph((unsigned char)s[i]);
        if(n>fit && i+3>=fit)c=glyph('.');
        for(unsigned yy=0;yy<height;++yy) {
            uint8_t row=large?sp_oled_font_large[c][yy]:sp_oled_font_small[c][yy];
            for(unsigned xx=0;xx<gwidth;++xx)
                if(row&(1u<<(gwidth-1-xx)))pixel(f,x+(int)(i*advance+xx),y+(int)yy,white);
        }
    }
}
void sp_synth_oled_render(const sp_ui_view *v,const uint8_t plot[120],sp_oled_frame *f) {
    if(!f)return;
    memset(f,0,sizeof(*f));if(!v)return;
    text(f,3,1,122,v->header,sizeof(v->header),1,1);
    box(f,0,9,128,1,1);box(f,0,55,128,1,1);
    text(f,3,58,122,v->footer,sizeof(v->footer),0,1);
    text(f,3,13,122,v->hero,sizeof(v->hero),1,1);
    unsigned rows=v->row_count>4?4:v->row_count;
    unsigned start=v->hero[0]?28:14,step=rows>=3?9:12;
    for(unsigned i=0;i<rows;++i) {
        unsigned y=start+i*step;
        if(y+7>55 || (v->controls && y+7>36))break;
        int selected=v->row_selection && v->selected==i;
        if(selected)box(f,1,(int)y-1,126,9,1);
        text(f,3,(int)y,122,v->rows[i],sizeof(v->rows[i]),1,!selected);
    }
    if(plot && v->plot_valid==1 && !rows && !v->error[0]) {
        unsigned top=v->hero[0]?26:14,height=v->hero[0]?9:21;
        for(unsigned i=0;i<120;++i)
            pixel(f,4+(int)i,(int)(top+((unsigned)plot[i]*(height-1)+127)/255),1);
    }
    if(v->controls)for(unsigned i=0;i<3;++i) {
        int x=3+(int)i*43;
        text(f,x,36,39,v->labels[i],sizeof(v->labels[i]),0,1);
        int pickup=v->pickup_visible && v->pickup_knob==i;
        text(f,x,45,pickup?32:39,v->values[i],sizeof(v->values[i]),1,1);
        if(v->show_focus && v->focused==i)box(f,x,43,35,1,1);
    }
    if(v->pickup_visible && v->pickup_knob<3 && v->controls) {
        /* Keep the label intact; a direction chevron sits beside the value. */
        int x=38+(int)v->pickup_knob*43;
        for(int i=0;i<3;++i){int y=v->pickup_direction<0?47+i:49-i;
            pixel(f,x-i,y,1);pixel(f,x+i,y,1);}
    }
    if(v->error[0]) {
        box(f,0,25,128,10,1);
        text(f,3,27,122,v->error,sizeof(v->error),0,0);
    }
}
