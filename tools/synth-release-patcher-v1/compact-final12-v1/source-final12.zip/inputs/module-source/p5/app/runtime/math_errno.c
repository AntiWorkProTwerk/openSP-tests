/* Module-local Newlib errno storage, without RTOS TLS. Calls that can reach
 * __errno belong to one serialized panel/control owner. Audio may use audited
 * errno-free math leaves. Recheck the final ELF and indirect dispatch whenever
 * math or callback paths change; a direct-call graph alone is insufficient.
 * Do not expose this cell to stock callers or interrupt handlers. The platform
 * must initialize this BSS before any module entry. */
static int synth_math_errno;

int *__errno(void) {
    return &synth_math_errno;
}
