#ifndef SP_SYNTH_APP_H
#define SP_SYNTH_APP_H

#include "sp_synth_engine.h"
#include "sp_synth_presets.h"
#include "sp_synth_ui.h"

/* Original portable composition; every call belongs to ONE serialized owner.
 * No atomic/thread/ISR contract. Platform messages must be copied to that owner
 * before these calls. Rendering never invokes storage, display or callbacks. */
#define SP_APP_REQUEST_CAPACITY 4u
#define SP_APP_KEY_CAPACITY SP_SYNTH_MAX_NOTES
#define SP_APP_BINDING_BASE 256u

typedef enum {
    SP_APP_CHROMATIC, SP_APP_MAJOR, SP_APP_MINOR, SP_APP_DORIAN,
    SP_APP_MIXOLYDIAN, SP_APP_PENTATONIC, SP_APP_MINOR_PENTATONIC,
    SP_APP_SCALE_COUNT
} SpAppScale;

typedef enum {
    SP_APP_REQUEST_LOAD_PATCH, SP_APP_REQUEST_CAPTURE_START,
    SP_APP_REQUEST_CAPTURE_STOP, SP_APP_REQUEST_TAKE_DISCARD,
    SP_APP_REQUEST_DEST_QUERY, SP_APP_REQUEST_TAKE_WRITE,
    SP_APP_REQUEST_PATCH_QUERY, SP_APP_REQUEST_PATCH_WRITE,
    SP_APP_REQUEST_GLOBAL_STOP, SP_APP_REQUEST_LEAVE
} SpAppRequestType;

typedef struct {
    uint32_t mode;             /* 0=fixed seconds, 1=bars; 4 beats/bar */
    float seconds, bars, tempo_bpm;
    uint32_t count_in_bars, include_release_tail;
} SpAppCapture;

/* Portable RX observations. These do not prove START/STOP/save completion,
 * note release, a tail boundary or file persistence. Original START identity
 * survives later UI generations. Plan/rate are immutable once observed. */
typedef struct {
    uint32_t start_generation,take_token,sample_rate_hz,has_rx_notice;
    int32_t fault;
    uint32_t sealed; /* RX accepted its final slice; not native STOP/HELD. */
    uint64_t observed_frames,accepted_frames,count_in_frames,duration_frames;
} SpAppCaptureProgress;
typedef struct {
    uint32_t start_generation,take_token,audio_sequence;
    int32_t result; /* 1: held for checked discard; -1: retained failure. */
} SpAppCaptureCancelCompletion;
enum { SP_APP_CANCEL_NONE,SP_APP_CANCEL_AUDIO,SP_APP_CANCEL_READY,
       SP_APP_CANCEL_REQUESTED,SP_APP_CANCEL_DISCARD,SP_APP_CANCEL_FAILED };
enum { SP_APP_CAPTURE_FAIL_PREPARE,SP_APP_CAPTURE_FAIL_CANCEL,SP_APP_CAPTURE_FAIL_DISCARD };
enum { SP_APP_TAIL_NONE,SP_APP_TAIL_AUDIO,SP_APP_TAIL_RELEASING,SP_APP_TAIL_QUIET };

typedef struct {
    SpAppRequestType type;
    uint32_t generation, token, revision;
    uint16_t index;
    uint8_t bank, replace;
    SpAppCapture capture;
    SpPreset preset;           /* Immutable copy for PATCH_WRITE only. */
} SpAppRequest;

typedef struct {
    uint32_t generation, token;
    sp_ui_error error;
    uint8_t occupied, factory;
    uint8_t capture_active;
    char name[SP_UI_NAME_CAPACITY];
    const SpPreset *preset;    /* Required for successful external LOAD_PATCH. */
} SpAppCompletion;

typedef struct {
    uint32_t tag;
    uint32_t identity;
    uint8_t active, held, source, channel, note;
    float velocity,pressure;
} SpAppKey;

typedef struct {
    SpSynthEngine engine;
    sp_ui ui;
    SpPreset edited, browse_snapshot;
    SpAppKey keys[SP_APP_KEY_CAPACITY];
    SpSynthEvent events[SP_SYNTH_MAX_EVENTS];
    SpAppRequest requests[SP_APP_REQUEST_CAPACITY];
    SpAppCapture capture;
    uint32_t next_tag, event_count, request_count, event_faults, request_faults;
    uint32_t stale_completions, pending_load_generation, pending_load_token;
    uint32_t pending_revision, edit_serial, save_serial;
    uint8_t root, scale, pad_channel, sustain[16], snapshot_valid, batch_failed;
    float bend[16], pressure[16], wheel[16], preview_level;
    uint32_t voice_limit;
    uint32_t request_issued_generation;
    uint32_t refresh_count;
    uint8_t bindings_dirty;
    /* Optional deferred audio mode; see sp_synth_audio_batch.h. The embedded
     * engine becomes an unused handoff snapshot after transfer. */
    struct SpAppAudioBatch *audio_batch;
    uint32_t audio_sequence;
    uint8_t audio_deferred, audio_pending, audio_faulted;
    SpAppCaptureProgress capture_progress;
    SpAppCapture capture_plan; /* Immutable app-side START settings for display. */
    uint32_t capture_cancel_state,capture_cancel_sequence;
    uint8_t capture_failure_stage,capture_failure_details;
    uint32_t capture_tail_state,capture_tail_sequence;
    uint32_t capture_quiet_sequence,capture_quiet_sample;
} SpSynthApp;

/* Catalog is immutable caller-owned metadata and must outlive app. Factory
 * tokens are served internally; all other tokens require an explicit load
 * completion. Initial patch is copied. MIDI pitch is never root-transposed. */
int sp_synth_app_init(SpSynthApp *app, const SpPreset *initial,
                      const sp_ui_patch *catalog, uint16_t catalog_count,
                      float sample_rate, uint32_t voice_limit, uint32_t seed);
typedef struct {
    uint32_t generation;       /* Current UI generation; consumed on success. */
    uint32_t audio_sequence;   /* Current acknowledged sequence, or 0 if serialized. */
    uint16_t physical_pads;    /* Fresh held snapshot; silent until released. */
    uint8_t shift;             /* Fresh physical SHIFT state, exactly 0 or 1. */
    uint8_t fresh_input;       /* New ownership/cutoff established; old input discarded. */
    uint8_t leave_complete;    /* Platform LEAVE finished after panic audio acknowledgment. */
    uint8_t backend_quiescent; /* No acquired work, responses, capture or retained take. */
} SpAppReentryBoundary;
/* Control owner only, after leaving and before fresh input is admitted.
 * Requires all three boundary attestations exactly 1. App checks its observable
 * work/keys/faults; caller owns facts in backend/mailbox/native capture/input.
 * Physical pads and SHIFT come from the fresh ownership boundary. Keep stock
 * release ownership in the outer input owner; reentry does not clear it.
 * Deferred mode must be between successfully acknowledged audio batches,
 * with no batch open and an unexhausted sequence. Serialized panic must have executed.
 * Preserves engine and edited patch, root/scale/octave, dirty/revision, macros,
 * catalog and sequence counters. UI generation advances without wrap.
 * Exhausted note identities reject; reentry never resets or wraps their counter.
 * Does not initialize the engine, transfer audio, render or reanchor clocks.
 * Returns 0 without changing app on any rejected boundary. */
int sp_synth_app_reenter(SpSynthApp *app,const SpAppReentryBoundary *boundary);
int sp_synth_app_pad_note(const SpSynthApp *app, uint16_t pad, uint8_t *note);
/* Dispatch UI events between renders, before timestamped input. Immediate
 * note commands affect offset0 of the next render. All commands are consumed
 * synchronously; async work is exposed only through bounded requests. */
int sp_synth_app_dispatch(SpSynthApp *app, const sp_ui_event *event);
/* Inputs must arrive in nondecreasing offset order and belong to the NEXT
 * render. MIDI channels/pitches stay unchanged. Repeated note-offs are FIFO;
 * callers may provide nonzero parameter tags for explicit source identity.
 * Pressure, bend, wheel, sustain and tempo use the engine's native contract.
 * Overflow, invalid input or unsorted offsets release every key and discard
 * the whole pending batch. No callback occurs from render. */
int sp_synth_app_input(SpSynthApp *app, const SpSynthEvent *event);
/* Pure event-shape/range check shared by timestamped input admission.
 * Does not validate app state, ordering, key capacity or a particular block. */
int sp_synth_app_event_valid(const SpSynthEvent *event);
int sp_synth_app_render(SpSynthApp *app, float *stereo, uint32_t frames);
void sp_synth_app_panic(SpSynthApp *app);
/* Outside rendering, host dequeues one request and later explicitly reports
 * its generation. Successful writes are never inferred from dequeueing. */
int sp_synth_app_request(SpSynthApp *app, SpAppRequest *request);
int sp_synth_app_complete(SpSynthApp *app, const SpAppCompletion *completion);
/* Same control phase as completion, before panel/MIDI input. Copies matching
 * observations only; wrong identity, changed plan, regressing counters and
 * invalid shape leave app untouched. A first nonzero fault remains latched.
 * Updates the recording timer from accepted RX frames, with saturation.
 * A sealed, nonfaulted take issues ordinary STOP once START has completed.
 * That request still waits for its control batch's audio acknowledgment;
 * sealing never implies native STOP/HELD. Does not touch the engine.
 * Retire on successful discard/save or qualified reentry; new START replaces
 * the expectation. Caller input must be immutable and disjoint from app. */
int sp_synth_app_capture_progress(SpSynthApp *app,const SpAppCaptureProgress *progress);
/* Control owner, after the exact successful audio completion and before the
 * next batch. Copies end-of-render quiescence only; sample is a wrapping
 * software render cursor, NOT an RX/DAC fence. Never reads the audio engine.
 * No STOP is implied; the native RX route must separately qualify its fence. */
int sp_synth_app_capture_tail_observe(SpSynthApp *app,uint32_t sequence,
    uint32_t quiescent,uint32_t sample);
/* True while an otherwise idle controller should publish an empty batch to
 * obtain another ordered audio observation. No allocation or engine access. */
int sp_synth_app_capture_tail_poll(const SpSynthApp *app);
/* Serialized control transaction, after START's ordinary response is consumed.
 * Returns1 when the matching cancellation receipt was consumed (including
 * failure),0 to retain it. HELD queues tokened DISCARD; it never returns to setup
 * before that request completes. A positive sequence in deferred mode must match
 * the successfully acknowledged panic batch recorded by the app. */
int sp_synth_app_cancel_complete(SpSynthApp *app,uint32_t generation,uint32_t token,
    uint32_t audio_sequence,int32_t result);
/* Semantic rendering of the saved capture states; no engine/native access.
 * Returns1 when a capture-phase view replaced the normal UI view. */
int sp_synth_app_capture_view(const SpSynthApp *app,sp_ui_view *view);
/* Metadata is editable, bounded and persisted in the preset wrapper. Macro
 * assignments use native units; gain/recursive assignments are invalid. */
int sp_synth_app_set_metadata(SpSynthApp *app, const char *name,
                             uint8_t category, uint8_t favorite);
int sp_synth_app_set_macro_label(SpSynthApp *app, uint32_t macro, const char *label);
void sp_synth_app_refresh(SpSynthApp *app);
/* Same serialized control-phase rule as metadata edits. The catalog remains
 * caller-owned and immutable; busy/browser states defer replacement. */
int sp_synth_app_set_catalog(SpSynthApp *app,const sp_ui_patch *catalog,uint16_t count);

#endif
