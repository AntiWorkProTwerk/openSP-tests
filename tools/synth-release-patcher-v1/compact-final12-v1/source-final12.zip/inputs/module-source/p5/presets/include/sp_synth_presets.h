#ifndef SP_SYNTH_PRESETS_H
#define SP_SYNTH_PRESETS_H

#include <stddef.h>
#include <stdint.h>
#include "sp_synth_engine.h"

#define SP_PRESET_COUNT 128u
#define SP_PRESET_NAME_CAPACITY 25u
#define SP_PRESET_INTENT_CAPACITY 96u
#define SP_PRESET_VERSION 1u
#define SP_PRESET_MACRO_LABEL_CAPACITY 12u

typedef enum {
    SP_PRESET_BASS = 1, SP_PRESET_LEAD, SP_PRESET_PAD, SP_PRESET_KEYS,
    SP_PRESET_PLUCK, SP_PRESET_BRASS, SP_PRESET_PERCUSSION, SP_PRESET_TEXTURE
} SpPresetCategory;

typedef struct {
    char label[SP_PRESET_MACRO_LABEL_CAPACITY];
    uint32_t parameter, logarithmic;
    float minimum, maximum;
} SpPresetMacro;

typedef struct {
    uint32_t id;
    uint8_t category, favorite;
    char name[SP_PRESET_NAME_CAPACITY];
    char intent[SP_PRESET_INTENT_CAPACITY];
    SpPresetMacro macro_controls[3];
    SpSynthPatch patch;
} SpPreset;

typedef enum {
    SP_PRESET_OK = 0, SP_PRESET_ARGUMENT, SP_PRESET_CAPACITY,
    SP_PRESET_TRUNCATED, SP_PRESET_OVERSIZED, SP_PRESET_MAGIC,
    SP_PRESET_UNSUPPORTED, SP_PRESET_CRC, SP_PRESET_INVALID
} SpPresetStatus;

/* The array and all returned factory pointers are immutable. Copy a patch into
 * caller-owned editing state. User saves require a separate storage namespace;
 * these functions perform no file, card, flash or device operation. */
extern const SpPreset sp_synth_factory_presets[SP_PRESET_COUNT];
const SpPreset *sp_synth_preset_at(size_t index);
const SpPreset *sp_synth_preset_find(uint32_t id);
const char *sp_synth_preset_category_name(uint8_t category);
int sp_synth_preset_is_factory(uint32_t id);
/* Resolve an assigned macro to one native parameter; no I/O or patch mutation.
 * Master gain and recursive macro targets are excluded from assignments. */
int sp_synth_preset_macro_value(const SpPreset *preset, uint32_t macro,
                                 float normalized, SpSynthParam *parameter, float *value);

/* Wire version 1 uses fixed-length little-endian integers and IEEE binary32
 * fields, bounded zero-padded ASCII strings, and CRC32 over header/payload.
 * Native structure layout is never persisted. Exact length is required.
 * Encode rejects invalid data before writing; decode commits only on success.
 * Input/output must not alias. Call outside rendering with exclusive ownership.
 * Atomic filesystem replacement, persistence and storage errors belong to the
 * platform adapter and are not established by this in-memory codec. */
size_t sp_synth_preset_record_size(void);
int sp_synth_preset_valid(const SpPreset *preset);
SpPresetStatus sp_synth_preset_encode(const SpPreset *preset, uint8_t *bytes,
                                     size_t capacity, size_t *written);
SpPresetStatus sp_synth_preset_decode(const uint8_t *bytes, size_t length,
                                     SpPreset *preset);

#endif
