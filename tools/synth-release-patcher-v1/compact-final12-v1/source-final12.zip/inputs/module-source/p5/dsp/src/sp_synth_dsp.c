#include "sp_synth_dsp.h"
#include <math.h>
#include <float.h>
#include "sp_synth_tables.h"

_Static_assert(sizeof(float)==4 && FLT_RADIX==2 && FLT_MANT_DIG==24,
               "Synth tables require binary32 float");

static float bounded(float x, float lo, float hi, float fallback) {
    if (!isfinite(x)) return fallback;
    return x < lo ? lo : (x > hi ? hi : x);
}
static float clean(float x) { return fabsf(x) < 1e-20f ? 0.0f : x; }
static float table(const float *values, float position, unsigned last) {
    /* Binary32 subtraction can round a fraction just below one up to one.
     * Handle the endpoint before fetching i+1, including exp2 near zero. */
    if (position >= (float)last) return values[last];
    if (!(position > 0.0f)) return values[0];
    unsigned i = (unsigned)position;
    float t = position - (float)i;
    return values[i] + t * (values[i + 1] - values[i]);
}
static float wrap(float p) {
    /* Normal oscillator/LFO phases need no library rounding operation.
     * The old subtraction canonicalizes negative zero to positive zero. */
    if (p >= 0.0f && p < 1.0f) return p == 0.0f ? 0.0f : p;
    p -= floorf(p);
    return p >= 1.0f ? 0.0f : p;
}

float sp_synth_exp2(float octaves) {
    float x = bounded(octaves, -24.0f, 24.0f, 0.0f);
    /* bounded() guarantees finite [-24,24], so truncation cannot overflow. */
    int n = (int)x;
    if (x < (float)n) --n;
    union { uint32_t bits; float value; } scale;
    scale.bits = (uint32_t)(n + 127) << 23;
    return table(sp_exp2_table, (x - (float)n) * 256.0f, 256) * scale.value;
}

float sp_synth_sine(float phase) {
    if (!isfinite(phase)) return 0.0f;
    return table(sp_sine_table, wrap(phase) * 512.0f, 512);
}

static float blep(float t, float dt) {
    if (t < dt) {
        float x = t / dt;
        return x + x - x*x - 1.0f;
    }
    if (t > 1.0f - dt) {
        float x = (t - 1.0f) / dt;
        return x*x + x + x + 1.0f;
    }
    return 0.0f;
}

static float triangle(float phase, float dt) {
    /* Every chosen band stays below 0.45 cycles/sample. Adjacent-band
     * interpolation is continuous at band boundaries and never uses a band
     * with a highest harmonic above that limit. */
    static const unsigned harmonics[7] = {1, 3, 7, 15, 31, 63, 127};
    /* At tiny positive increments, the richest table is already sufficient.
     * Cap before division so subnormals cannot overflow the band selector. */
    float limit = dt < 0.45f/255.0f ? 255.0f : 0.45f/dt;
    unsigned band = 0;
    while (band < 6 && (float)harmonics[band + 1] <= limit) ++band;
    float high = table(sp_triangle_table[band], phase * 512.0f, 512);
    if (!band) return high;
    float next = (float)(band == 6 ? 255 : harmonics[band + 1]);
    float mix = bounded((limit - (float)harmonics[band]) /
                        (next - (float)harmonics[band]), 0.0f, 1.0f, 0.0f);
    float low = table(sp_triangle_table[band - 1], phase * 512.0f, 512);
    return low + mix * (high - low);
}

float sp_synth_osc(SpOsc *osc, SpWave wave, float increment, float pulse_width) {
    if (!osc) return 0.0f;
    float dt = bounded(increment, 0.0f, 0.45f, 0.0f);
    if (dt == 0.0f) return 0.0f;
    float phase = isfinite(osc->phase) ? wrap(osc->phase) : 0.0f;
    float out;
    switch (wave) {
        case SP_WAVE_SINE: out = table(sp_sine_table, phase * 512.0f, 512); break;
        case SP_WAVE_TRIANGLE: out = triangle(phase, dt); break;
        case SP_WAVE_SAW: out = 2.0f*phase - 1.0f - blep(phase, dt); break;
        case SP_WAVE_PULSE: {
            float width = bounded(pulse_width, 0.01f, 0.99f, 0.5f);
            float edge = phase - width;
            if (edge < 0.0f) edge += 1.0f;
            out = (phase < width ? 1.0f : -1.0f) + blep(phase, dt) - blep(edge, dt);
            break;
        }
        default: out = 0.0f; break;
    }
    phase += dt;
    osc->phase = phase >= 1.0f ? phase - 1.0f : phase;
    return out;
}

void sp_synth_noise_seed(SpNoise *noise, uint32_t seed) {
    if (noise) noise->state = seed ? seed : UINT32_C(0x9e3779b9);
}
float sp_synth_noise(SpNoise *noise) {
    if (!noise) return 0.0f;
    uint32_t x = noise->state ? noise->state : UINT32_C(0x9e3779b9);
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    noise->state = x;
    return (float)(x >> 8) * (1.0f / 8388608.0f) - 1.0f;
}

static uint32_t duration(float seconds, float rate) {
    float samples = seconds * rate;
    return samples < 1.0f ? 1u : (uint32_t)ceilf(samples);
}
void sp_synth_env_init(SpEnvelope *env, float sample_rate, const SpEnvConfig *config) {
    if (!env) return;
    SpEnvConfig c = config ? *config : (SpEnvConfig){0.005f,0.2f,0.7f,0.3f,0.0f};
    c.attack = bounded(c.attack,0.0f,60.0f,0.005f);
    c.decay = bounded(c.decay,0.0f,60.0f,0.2f);
    c.sustain = bounded(c.sustain,0.0f,1.0f,0.7f);
    c.release = bounded(c.release,0.0f,60.0f,0.3f);
    c.curve = bounded(c.curve,-0.95f,0.95f,0.0f);
    *env = (SpEnvelope){0};
    env->config = c;
    env->sample_rate = bounded(sample_rate,8000.0f,192000.0f,48000.0f);
}
void sp_synth_env_on(SpEnvelope *env, int reset_phase) {
    if (!env) return;
    if (reset_phase) env->value = 0.0f;
    env->gate = 1;
    env->stage = SP_ENV_ATTACK;
    env->start = env->value;
    env->remaining = duration(env->config.attack,env->sample_rate);
    env->step = 1.0f/(float)env->remaining;
}
void sp_synth_env_off(SpEnvelope *env) {
    if (!env) return;
    env->gate = 0;
    if (env->stage == SP_ENV_IDLE) return;
    env->stage = SP_ENV_RELEASE;
    env->start = env->value;
    env->remaining = duration(env->config.release,env->sample_rate);
    env->step = 1.0f/(float)env->remaining;
}
float sp_synth_env_tick(SpEnvelope *env) {
    if (!env) return 0.0f;
    float progress;
    switch (env->stage) {
        case SP_ENV_ATTACK:
            if (env->remaining) --env->remaining;
            progress=1.0f-(float)env->remaining*env->step;
            progress *= 1.0f+env->config.curve*(1.0f-progress);
            env->value=env->start+(1.0f-env->start)*progress;
            if (!env->remaining) {
                env->value=1.0f; env->stage=SP_ENV_DECAY;
                env->remaining=duration(env->config.decay,env->sample_rate);
                env->step=1.0f/(float)env->remaining;
            }
            break;
        case SP_ENV_DECAY:
            if (env->remaining) --env->remaining;
            progress=1.0f-(float)env->remaining*env->step;
            progress *= 1.0f+env->config.curve*(1.0f-progress);
            env->value=1.0f+(env->config.sustain-1.0f)*progress;
            if (!env->remaining) {
                env->value=env->config.sustain; env->stage=SP_ENV_SUSTAIN;
                if (env->loop && env->gate) sp_synth_env_on(env,0);
            }
            break;
        case SP_ENV_SUSTAIN: env->value=env->config.sustain; break;
        case SP_ENV_RELEASE:
            if (env->remaining) --env->remaining;
            progress=1.0f-(float)env->remaining*env->step;
            progress *= 1.0f+env->config.curve*(1.0f-progress);
            env->value=env->start*(1.0f-progress);
            if (!env->remaining) { env->value=0.0f; env->stage=SP_ENV_IDLE; }
            break;
        default: env->value=0.0f; env->stage=SP_ENV_IDLE; break;
    }
    return env->value;
}

void sp_synth_filter_set(SpFilter *filter, float sample_rate, float cutoff, float resonance) {
    if (!filter) return;
    float rate=bounded(sample_rate,8000.0f,192000.0f,48000.0f);
    float hz=bounded(cutoff,5.0f,rate*0.45f,1000.0f);
    float pos=hz/rate*(256.0f/0.45f);
    /* table() handles the exact endpoint before fetching the next element. */
    filter->target_g=table(sp_tan_table,pos,256);
    filter->target_k=2.0f-1.96f*bounded(resonance,0.0f,1.0f,0.0f);
}
void sp_synth_filter_init(SpFilter *filter, SpFilterMode mode,
                          float sample_rate, float cutoff, float resonance) {
    if (!filter) return;
    *filter=(SpFilter){0};
    filter->mode=(unsigned)mode<=SP_FILTER_NOTCH?(uint32_t)mode:SP_FILTER_LP12;
    sp_synth_filter_set(filter,sample_rate,cutoff,resonance);
    filter->g=filter->target_g; filter->k=filter->target_k;
}
static float svf(SpSvf *state,float x,float g,float k,uint32_t mode) {
    float a1=1.0f/(1.0f+g*(g+k)),a2=g*a1,a3=g*a2;
    float v3=x-state->ic2;
    float bp=a1*state->ic1+a2*v3;
    float lp=state->ic2+a2*state->ic1+a3*v3;
    state->ic1=clean(2.0f*bp-state->ic1);
    state->ic2=clean(2.0f*lp-state->ic2);
    if (mode==SP_FILTER_HP12) return x-k*bp-lp;
    if (mode==SP_FILTER_BP12) return bp;
    if (mode==SP_FILTER_NOTCH) return x-k*bp;
    return lp;
}
float sp_synth_filter_tick(SpFilter *filter, float input) {
    if (!filter) return 0.0f;
    float x=bounded(input,-16.0f,16.0f,0.0f);
    filter->g += 0.005f*(filter->target_g-filter->g);
    filter->k += 0.005f*(filter->target_k-filter->k);
    float y=svf(&filter->stage[0],x,filter->g,filter->k,filter->mode);
    if (filter->mode==SP_FILTER_LP24)
        y=svf(&filter->stage[1],y,filter->g,1.41421356f,SP_FILTER_LP12);
    if (!isfinite(y) || !isfinite(filter->stage[0].ic1) ||
        !isfinite(filter->stage[0].ic2) || !isfinite(filter->stage[1].ic1) ||
        !isfinite(filter->stage[1].ic2)) {
        filter->stage[0]=(SpSvf){0}; filter->stage[1]=(SpSvf){0};
        ++filter->faults;
        return 0.0f;
    }
    return y;
}

static float saturate(float x) {
    if (x>=1.0f) return 1.0f;
    if (x<=-1.0f) return -1.0f;
    return x*(1.5f-0.5f*x*x);
}
static float primitive(float x) {
    float a=fabsf(x);
    if (a>=1.0f) return a-0.375f;
    float x2=x*x;
    return x2*(0.75f-0.125f*x2);
}
float sp_synth_drive_tick(SpDrive *drive, float input, float amount) {
    if (!drive) return 0.0f;
    float dry=bounded(input,-16.0f,16.0f,0.0f);
    float wet=bounded(amount,0.0f,1.0f,0.0f);
    float x=dry*(1.0f+15.0f*wet),delta=x-drive->previous;
    float y;
    if (!drive->primed) y=saturate(x);
    else if (x>=1.0f && drive->previous>=1.0f) y=1.0f;
    else if (x<=-1.0f && drive->previous<=-1.0f) y=-1.0f;
    else if (fabsf(x)<=1.0f && fabsf(drive->previous)<=1.0f)
        /* Factored divided difference avoids cancellation for close inputs. */
        y=(x+drive->previous)*(0.75f-0.125f*(x*x+drive->previous*drive->previous));
    else if (fabsf(delta)<0.001f) y=saturate(0.5f*(x+drive->previous));
    else y=(primitive(x)-primitive(drive->previous))/delta;
    drive->previous=x; drive->primed=1;
    y=bounded(y,-1.0f,1.0f,0.0f);
    return dry+wet*(y-dry);
}
