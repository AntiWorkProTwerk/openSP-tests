#include "sp_synth_canvas_v552.h"
#include <stdint.h>

_Static_assert(sizeof(void *)==4,"v5.52 canvas ABI requires 32-bit pointers");
typedef void (*colors_fn)(void *,int32_t *);
typedef void (*restore_fn)(void *,const int32_t *);
typedef void (*pair_fn)(void *,int32_t,int32_t);
typedef void (*rect_fn)(void *,int,int,int,int);
typedef void (*line_fn)(void *,int,int,int);

int sp_synth_canvas_v552_present(void *canvas,const sp_oled_frame *frame) {
    if(!canvas || !frame)return 0;
    void *backend=*(void **)canvas;
    if(!backend)return 0;
    const uintptr_t *ops=*(const uintptr_t **)backend;
    if(!ops)return 0;
    int32_t previous[2];
    ((colors_fn)ops[0x24/4])(backend,previous);
    ((pair_fn)(uintptr_t)0x800D8019)(canvas,0x0100000f,0x01000000);
    ((rect_fn)(uintptr_t)0x800C2C91)(canvas,0,0,127,63);
    for(unsigned y=0;y<64;++y) {
        unsigned x=0;
        while(x<128) {
            while(x<128 && !(frame->bytes[y*16+x/8]&(0x80u>>(x&7))))++x;
            unsigned left=x;
            while(x<128 && (frame->bytes[y*16+x/8]&(0x80u>>(x&7))))++x;
            if(left<x)((line_fn)(uintptr_t)0x800D7FE9)(canvas,(int)left,(int)y,(int)x-1);
        }
    }
    ((restore_fn)ops[0x1c/4])(backend,previous);
    return 1;
}
