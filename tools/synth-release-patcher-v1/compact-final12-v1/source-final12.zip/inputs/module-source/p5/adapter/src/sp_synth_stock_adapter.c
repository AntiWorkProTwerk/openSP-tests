#include "sp_synth_stock_adapter.h"
#include <limits.h>

SpSynthStockResult sp_synth_stock_mix_block(
    const SpSynthStockBlock *block, SpSynthStockScratch *scratch,
    SpSynthStockRender render, void *context)
{
    size_t required;
    uintptr_t work_begin, work_end, scratch_begin, scratch_end;
    uint32_t frame;
    if (!block || !scratch || !render ||
        block->frames > SP_SYNTH_STOCK_MAX_FRAMES ||
        block->pair_index >= SP_SYNTH_STOCK_PAIR_COUNT)
        return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    if (block->frames == 0)
        return SP_SYNTH_STOCK_OK;
    if (!block->words)
        return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    required = (size_t)block->frames * SP_SYNTH_STOCK_STRIDE_WORDS;
    if (block->word_count < required)
        return SP_SYNTH_STOCK_INSUFFICIENT_BUFFER;
    work_begin = (uintptr_t)block->words;
    scratch_begin = (uintptr_t)scratch;
    if (work_begin > UINTPTR_MAX - required * sizeof(int32_t) ||
        scratch_begin > UINTPTR_MAX - sizeof(*scratch))
        return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    work_end = work_begin + required * sizeof(int32_t);
    scratch_end = scratch_begin + sizeof(*scratch);
    if (work_begin < scratch_end && scratch_begin < work_end)
        return SP_SYNTH_STOCK_INVALID_ARGUMENT;
    if (!render(context, scratch->stereo, block->frames))
        return SP_SYNTH_STOCK_RENDER_FAILED;
    for (frame = 0; frame < block->frames; ++frame) {
        size_t at = (size_t)frame * SP_SYNTH_STOCK_STRIDE_WORDS +
                    (size_t)block->pair_index * 2;
        uint32_t channel;
        for (channel = 0; channel < 2; ++channel) {
            int64_t sum = (int64_t)block->words[at + channel] +
                          scratch->stereo[frame * 2 + channel];
            if (sum < INT32_MIN || sum > INT32_MAX)
                return SP_SYNTH_STOCK_NO_HEADROOM;
        }
    }
    for (frame = 0; frame < block->frames; ++frame) {
        size_t at = (size_t)frame * SP_SYNTH_STOCK_STRIDE_WORDS +
                    (size_t)block->pair_index * 2;
        block->words[at] += scratch->stereo[frame * 2];
        block->words[at + 1] += scratch->stereo[frame * 2 + 1];
    }
    return SP_SYNTH_STOCK_OK;
}
