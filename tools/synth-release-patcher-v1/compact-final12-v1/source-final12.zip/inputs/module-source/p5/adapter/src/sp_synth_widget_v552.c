#include "sp_synth_widget_v552.h"
#include "sp_synth_canvas_v552.h"
#include <stddef.h>
#include <stdint.h>

struct sp_synth_widget_v552 {
    uint32_t base[39];             /* 156-byte stock base object */
    uint32_t prefix[2];            /* observed zero vtable prefix */
    uintptr_t methods[35];         /* slots 0x00..0x88 */
    sp_oled_frame frame;
    sp_synth_widget_v552 **owner;
};
_Static_assert(sizeof(void *)==4,"v5.52 widget ABI requires 32-bit pointers");
_Static_assert(offsetof(struct sp_synth_widget_v552,frame)==304,"widget layout");
_Static_assert(sizeof(struct sp_synth_widget_v552)==1332,"owned widget bytes");
typedef void (*object_fn)(void *);
typedef void *(*factory_fn)(void *,void *);
typedef void *(*append_fn)(void *,int,factory_fn,const char *,...);
static int last(const sp_synth_widget_v552 *w) {
    const uint32_t *parent=(const uint32_t *)(uintptr_t)w->base[27];
    if(!parent)return 0;
    uint32_t count=parent[3];
    return count>0 && count<=512 && parent[231+count-1]==(uintptr_t)w;
}
static void detach_owner(sp_synth_widget_v552 *w) {
    if(w->owner && *w->owner==w)*w->owner=0;
    w->owner=0;
}
static void destroy(void *object) {
    sp_synth_widget_v552 *w=object;
    detach_owner(w);
    ((object_fn)(uintptr_t)0x800E11CB)(w);
}
static void draw(sp_synth_widget_v552 *w) {
    if(last(w))sp_synth_canvas_v552_present((void *)(uintptr_t)w->base[33],&w->frame);
    w->base[33]=0; /* Canvas belongs to the current draw, not to this object. */
}
static void *factory(void *existing,void *parent) {
    if(existing){destroy(existing);return 0;}
    sp_synth_widget_v552 *w=((void *(*)(unsigned))(uintptr_t)0x800D8B15)(sizeof(*w));
    if(!w)return 0;
    uint32_t *words=(uint32_t *)w;
    for(unsigned i=0;i<sizeof(*w)/4;++i)words[i]=0;
    ((void *(*)(void *,void *))(uintptr_t)0x800C2A61)(w,parent);
    const uintptr_t *base=(const uintptr_t *)(uintptr_t)0x8021D0A8;
    for(unsigned i=0;i<35;++i)w->methods[i]=base[i];
    /* The base's deleting-destructor slot is a trap; own our allocation. */
    w->methods[1]=(uintptr_t)destroy;
    w->methods[0x60/4]=(uintptr_t)draw;
    w->base[0]=(uintptr_t)w->methods;
    w->base[1]=0;w->base[2]=0;w->base[3]=127;w->base[4]=63;
    w->base[33]=0;
    return w;
}
sp_synth_widget_v552 *sp_synth_widget_v552_add(void *parent) {
    if(!parent || ((const uint32_t *)parent)[3]>=512)return 0;
    return ((append_fn)(uintptr_t)0x800C4A19)(parent,0,factory,"");
}
sp_synth_widget_v552 *sp_synth_widget_v552_add_owned(void *parent,sp_synth_widget_v552 **owner) {
    if(!owner || *owner)return 0;
    sp_synth_widget_v552 *w=sp_synth_widget_v552_add(parent);
    if(w){w->owner=owner;*owner=w;}
    return w;
}
int sp_synth_widget_v552_update(sp_synth_widget_v552 *w,const sp_oled_frame *frame) {
    if(!w || !frame || ((const uint8_t *)w)[61] || !last(w))return 0;
    unsigned changed=0;
    for(unsigned i=0;i<1024;++i)changed|=w->frame.bytes[i]^frame->bytes[i];
    if(!changed)return 1;
    for(unsigned i=0;i<1024;++i)w->frame.bytes[i]=frame->bytes[i];
    ((object_fn)(uintptr_t)0x800D0019)(w);
    return 2;
}
void sp_synth_widget_v552_remove(sp_synth_widget_v552 **handle) {
    if(!handle || !*handle)return;
    sp_synth_widget_v552 *w=*handle;
    detach_owner(w);
    *handle=0;
    ((object_fn)(uintptr_t)0x80074151)(w);
}
