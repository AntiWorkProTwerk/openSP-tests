#include "sp_synth_generator_route_v552.h"
#include "sp_synth_memory_v552.h"
#include <stddef.h>

_Static_assert(sizeof(void *) == 4, "Pinned v5.52 route requires ARM32");
_Static_assert(ATOMIC_INT_LOCK_FREE == 2, "Audio route requires lock-free atomics");
_Static_assert(_Alignof(SpSynthGeneratorRouteV552) == 8, "Discard alignment");
#define ROUTE_INITIALIZED UINT32_C(0x47525431)
typedef uint32_t (*NativeMixer)(void *, int32_t *, int32_t, int32_t);

int sp_synth_generator_route_v552_init(SpSynthGeneratorRouteV552 *owner) {
    uintptr_t begin = (uintptr_t)owner;
    const size_t bytes = sizeof(*owner);
    if (begin < UINT32_C(0x80000000) || begin % _Alignof(*owner) ||
        begin > UINT32_C(0x84000000) - bytes) return 0;
    uintptr_t end = begin + bytes;
    if (begin < SP_SYNTH_V552_POOL_END && end > SP_SYNTH_V552_POOL_BEGIN) return 0;
    const unsigned char *p = (const unsigned char *)owner;
    for (size_t i = 0; i < bytes; ++i) if (p[i]) return 0;
    atomic_init(&owner->requested, 0);
    atomic_init(&owner->acknowledged, 0);
    atomic_init(&owner->fault, 0);
    owner->initialized = ROUTE_INITIALIZED;
    return 1;
}

uint32_t sp_synth_generator_route_v552_request(SpSynthGeneratorRouteV552 *owner,
    SpSynthGeneratorRouteModeV552 mode) {
    if (!owner || owner->initialized != ROUTE_INITIALIZED ||
        (mode != SP_SYNTH_GENERATOR_NATIVE && mode != SP_SYNTH_GENERATOR_DISCARD) ||
        atomic_load_explicit(&owner->fault, memory_order_acquire)) return 0;
    uint32_t request = atomic_load_explicit(&owner->requested, memory_order_relaxed);
    uint32_t ack = atomic_load_explicit(&owner->acknowledged, memory_order_acquire);
    if (request != ack || (request >> 1) == UINT32_C(0x7FFFFFFF)) return 0;
    uint32_t next = (((request >> 1) + 1u) << 1) | (uint32_t)mode;
    atomic_store_explicit(&owner->requested, next, memory_order_release);
    return next;
}

uint32_t sp_synth_generator_route_v552_ack(const SpSynthGeneratorRouteV552 *owner) {
    if (!owner || owner->initialized != ROUTE_INITIALIZED) return 0;
    return atomic_load_explicit(&owner->acknowledged, memory_order_acquire);
}

uint32_t sp_synth_generator_route_v552_dispatch(SpSynthGeneratorRouteV552 *owner,
    void *state, int32_t *work, int32_t frames, int32_t stride) {
    NativeMixer native = (NativeMixer)(uintptr_t)UINT32_C(0x1CB85);
    if (!owner || owner->initialized != ROUTE_INITIALIZED)
        return native(state, work, frames, stride);
    if ((uintptr_t)state != UINT32_C(0x80249800) ||
        (uintptr_t)work != UINT32_C(0x202AD3A0) || frames != 64 || stride != 14) {
        atomic_store_explicit(&owner->fault, SP_SYNTH_GENERATOR_ROUTE_BAD_TUPLE,
            memory_order_release);
        return native(state, work, frames, stride);
    }
    uint32_t request = atomic_load_explicit(&owner->requested, memory_order_acquire);
    int32_t *destination = work;
    if (request & 1u) {
        for (unsigned i = 0; i < SP_SYNTH_GENERATOR_ROUTE_WORDS; ++i)
            owner->discard[i] = work[i];
        destination = owner->discard;
    }
    uint32_t result = native(state, destination, frames, stride);
    atomic_store_explicit(&owner->acknowledged, request, memory_order_release);
    return result;
}
