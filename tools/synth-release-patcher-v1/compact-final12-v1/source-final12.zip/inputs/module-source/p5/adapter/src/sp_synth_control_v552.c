#include "sp_synth_control_v552.h"
#include <string.h>

int sp_synth_control_v552_ctrl(int32_t index,int32_t value,sp_ui_event *out) {
    if(!out || index<1 || index>3 || value<0 || value>127)return 0;
    memset(out,0,sizeof(*out));
    out->type=SP_UI_CTRL_MOVE;out->index=(uint16_t)(index-1);
    out->value=value*129; /* 127*129 == 16383, including both endpoints. */
    return 1;
}
int sp_synth_control_v552_encoder(int32_t index,int32_t delta,sp_ui_event *out) {
    if(!out || index!=0 || !delta)return 0;
    memset(out,0,sizeof(*out));out->type=SP_UI_VALUE_TURN;
    out->value=delta<0?-1:1;
    return 1;
}
int sp_synth_control_v552_pad(int32_t index,int32_t velocity,int down,sp_ui_event *out) {
    if(!out || index<0 || index>15 || (down!=0 && down!=1) ||
       (down && (velocity<0 || velocity>127)))return 0;
    memset(out,0,sizeof(*out));out->type=down?SP_UI_PAD_DOWN:SP_UI_PAD_UP;
    out->index=(uint16_t)(index+1);out->value=down?velocity:0;
    return 1;
}
int sp_synth_control_v552_button(int32_t id,int down,sp_ui_event *out) {
    if(!out || (down!=0 && down!=1))return 0;
    sp_ui_event_type type;
    if(id==42)type=down?SP_UI_SHIFT_DOWN:SP_UI_SHIFT_UP;
    else if(!down)return 0;
    else if(id==49)type=SP_UI_VALUE_PRESS;
    else if(id==27)type=SP_UI_REC_PRESS;
    else if(id==34)type=SP_UI_EXIT_PRESS;
    else return 0;
    memset(out,0,sizeof(*out));out->type=type;return 1;
}
static int32_t signed16(const uint8_t *p) {
    int32_t value=(int32_t)p[0]+((int32_t)p[1]<<8);
    return value>=32768?value-65536:value;
}
int sp_synth_control_v552_event(const void *record,size_t bytes,sp_ui_event *out) {
    if(!record || !out || bytes<6)return 0;
    const uint8_t *p=record;
    unsigned type=(unsigned)p[0]+((unsigned)p[1]<<8);
    int32_t index=signed16(p+2),value=signed16(p+4);
    switch(type) {
    case 5:case 6:return sp_synth_control_v552_button(index,type==5,out);
    case 7:return sp_synth_control_v552_encoder(index,value,out);
    case 9:return sp_synth_control_v552_ctrl(index,value,out);
    case 16:case 17:return sp_synth_control_v552_pad(index,value,type==16,out);
    default:return 0;
    }
}
