#ifndef SP_SYNTH_RUNTIME_STORAGE_H
#define SP_SYNTH_RUNTIME_STORAGE_H
#include "sp_synth_control_queue.h"
#include "sp_synth_input_clock.h"
#include "sp_synth_page_v552.h"

/* Storage schema only. No target address, allocator, initialization, attachment
 * or task ownership is implied. Publish individual members only after their
 * established initialization contracts; never copy/reset this aggregate live.
 * Widget storage is separately allocated by stock and is not included here. */
typedef struct {
    SpSynthApp controller;
    SpAppAudioState audio;
    SpSynthAudioMailbox mailbox;
    SpSynthAppMixScratch audio_scratch;
    SpSynthControlQueue controls;
    SpSynthMidiQueue midi;
    SpSynthInputClock clock;
    sp_synth_input_owner input;
    sp_synth_input_batch input_batch;
    sp_synth_page_v552 page;
    sp_ui_view view;
    uint8_t plot[120];
} SpSynthRuntimeStorage;
#endif
