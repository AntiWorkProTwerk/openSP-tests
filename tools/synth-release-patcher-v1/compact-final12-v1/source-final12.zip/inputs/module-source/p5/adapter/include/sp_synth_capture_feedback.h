#ifndef SP_SYNTH_CAPTURE_FEEDBACK_H
#define SP_SYNTH_CAPTURE_FEEDBACK_H
#include <stdint.h>

/* Copied recorder observations, not a backend completion. The original START
 * generation identifies the take even after STOP uses another UI generation.
 * recorder_phase is SP_TCAP_*; window_phase is SP_CAPTURE_WINDOW_* and is valid
 * only when has_rx_notice is1. Never read the RX-owned window from control.
 * A recorder fault takes precedence over older progress. Native phase/fault are
 * sampled separately; this does not claim an atomic hardware-state snapshot.
 * Counters cover accepted RX PCM, not rendered TX, written file bytes or a DAC
 * boundary. Rate/route qualification remains the platform's responsibility. */
typedef struct {
    uint32_t start_generation,take_token,recorder_phase,window_phase;
    uint32_t sample_rate_hz,milestones;
    int32_t fault;
    uint32_t has_rx_notice;
    uint64_t observed_frames,accepted_frames,count_in_frames,duration_frames;
} SpSynthCaptureFeedback;

typedef enum {
    SP_CAPTURE_FEEDBACK_WAITING,
    SP_CAPTURE_FEEDBACK_READY,
    SP_CAPTURE_FEEDBACK_STALE
} SpCaptureFeedbackDelivery;
#endif
