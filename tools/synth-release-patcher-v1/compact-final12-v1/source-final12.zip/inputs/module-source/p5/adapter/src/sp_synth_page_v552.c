#include "sp_synth_page_v552.h"
#include <stddef.h>

_Static_assert(sizeof(sp_synth_page_v552)==1032,"v5.52 page owner layout");

int sp_synth_page_v552_publish(sp_synth_page_v552 *owner,void *page,
                              const sp_ui_view *view,const uint8_t plot[120]) {
    if(!owner || !page || !view || !owner->widget || owner->page!=page)return 0;
    sp_synth_oled_render(view,plot,&owner->scratch);
    return sp_synth_widget_v552_update(owner->widget,&owner->scratch);
}

int sp_synth_page_v552_after_entry(sp_synth_page_v552 *owner,void *page,
                                  const sp_ui_view *view,const uint8_t plot[120]) {
    if(!owner || !page || !view)return 0;
    if(owner->widget && owner->page!=page)return 0;
    if(!owner->widget) {
        owner->page=0;
        if(!sp_synth_widget_v552_add_owned((uint8_t *)page+56,&owner->widget))return 0;
        owner->page=page;
    }
    return sp_synth_page_v552_publish(owner,page,view,plot);
}

void sp_synth_page_v552_detach(sp_synth_page_v552 *owner) {
    if(!owner)return;
    sp_synth_widget_v552_remove(&owner->widget);
    owner->page=0;
}
