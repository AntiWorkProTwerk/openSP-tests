#include "sp_synth_input_owner.h"
#include <string.h>

static void emit(sp_synth_input_batch *out,sp_ui_event_type type,uint16_t index,int32_t value) {
    sp_ui_event *event=&out->events[out->count++];
    memset(event,0,sizeof(*event));event->type=type;event->index=index;event->value=value;
}
void sp_synth_input_init(sp_synth_input_owner *owner,uint16_t held_pads,int shift) {
    if(!owner)return;
    owner->physical=held_pads;owner->captured=0;owner->delivered=0;
    owner->enabled=0;owner->shift=(uint8_t)(shift!=0);
}
int sp_synth_input_enable(sp_synth_input_owner *owner,int enabled,int shift,sp_synth_input_batch *out) {
    if(!out)return 0;
    out->count=0;
    if(!owner || (enabled!=0 && enabled!=1) || (shift!=0 && shift!=1))return 0;
    if(owner->enabled && !enabled) {
        for(unsigned p=0;p<16;++p)if(owner->delivered&(1u<<p))emit(out,SP_UI_PAD_UP,(uint16_t)(p+1),0);
        owner->delivered=0;emit(out,SP_UI_SHIFT_UP,0,0);
    } else if(enabled && (!owner->enabled || owner->shift!=shift)) {
        emit(out,shift?SP_UI_SHIFT_DOWN:SP_UI_SHIFT_UP,0,0);
    }
    owner->enabled=(uint8_t)enabled;owner->shift=(uint8_t)shift;
    return 1;
}
int sp_synth_input_route(sp_synth_input_owner *owner,const sp_ui_event *event,sp_synth_input_batch *out) {
    if(!out)return 0;
    out->count=0;if(!owner || !event)return 0;
    if(event->type==SP_UI_SHIFT_DOWN || event->type==SP_UI_SHIFT_UP) {
        unsigned shift=event->type==SP_UI_SHIFT_DOWN;
        if(owner->enabled && owner->shift!=shift)emit(out,event->type,0,0);
        owner->shift=(uint8_t)shift;return 0;
    }
    if(event->type==SP_UI_PAD_DOWN || event->type==SP_UI_PAD_UP) {
        if(event->index<1 || event->index>16 ||
           (event->type==SP_UI_PAD_DOWN && (event->value<0 || event->value>127)))return 0;
        uint16_t bit=(uint16_t)(1u<<(event->index-1));
        if(event->type==SP_UI_PAD_DOWN) {
            if(owner->physical&bit)return (owner->captured&bit)!=0;
            owner->physical|=bit;
            if(!owner->enabled)return 0;
            owner->captured|=bit;owner->delivered|=bit;
            emit(out,SP_UI_PAD_DOWN,event->index,event->value);return 1;
        }
        owner->physical&=(uint16_t)~bit;
        if(!(owner->captured&bit))return 0;
        owner->captured&=(uint16_t)~bit;
        if(owner->delivered&bit)emit(out,SP_UI_PAD_UP,event->index,0);
        owner->delivered&=(uint16_t)~bit;return 1;
    }
    if(!owner->enabled)return 0;
    switch(event->type) {
    case SP_UI_VALUE_PRESS:case SP_UI_REC_PRESS:case SP_UI_EXIT_PRESS:
        emit(out,event->type,0,0);return 1;
    case SP_UI_VALUE_TURN:
        if(!event->value)return 0;
        emit(out,event->type,0,event->value);return 1;
    case SP_UI_CTRL_MOVE:
        if(event->index>2 || event->value<0 || (uint32_t)event->value>SP_UI_VALUE_MAX)return 0;
        emit(out,event->type,event->index,event->value);return 1;
    default:return 0;
    }
}
