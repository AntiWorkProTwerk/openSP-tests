#ifndef SP_SYNTH_ENTRY_OWNER_V552_LIVE_H
#define SP_SYNTH_ENTRY_OWNER_V552_LIVE_H
#include "sp_synth_entry_owner_v552.h"
/* Separate source variant for the live-session composition. Link it instead
 * of the accepted entry-owner C file, never alongside that file. All existing
 * entry functions and owner layout retain their original implementation.
 *
 * Trusted selected-page callback after native generic routing. Offer only the
 * current copied kind5 REC/EXIT/VALUE, kind7 VALUE or kind9 CTRL record. Button
 * payload beyond kind/index is undefined and is not compared. Other controls
 * compare the signed16 native value too. A fresh matching frame is offered
 * once; old-prefix, duplicate, stale, disabled and foreign offers return0.
 * A successful offer reserves source ownership, not musical admission: the
 * caller must still run its native derived child/modal decisions once. */
int sp_synth_entry_owner_v552_control_offer(void *panel,uint32_t kind,
    int32_t index,int32_t value);
#endif
