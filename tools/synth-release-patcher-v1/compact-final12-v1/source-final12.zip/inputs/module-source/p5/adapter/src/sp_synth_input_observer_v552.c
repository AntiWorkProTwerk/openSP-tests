#include "sp_synth_input_observer_v552.h"
#include "sp_synth_memory_v552.h"
#include <stddef.h>

_Static_assert(sizeof(void *)==4,"Pinned native observer requires ARM32");
_Static_assert(sizeof(SpSynthInputObserverV552)==28,"Source-copy owner ABI");
_Static_assert(offsetof(SpSynthInputObserverV552,loss)==8,"Guard loss offset");
SpSynthInputObserverV552 sp_synth_input_observer_v552
    __attribute__((section(".bss.sp_synth_input_observer_v552")));
extern volatile uint32_t sp404_stock_input_native_v552_scratch[3];

#define W ((volatile uint32_t *)(uintptr_t)UINT32_C(0x805919B0))
#define R ((volatile uint32_t *)(uintptr_t)UINT32_C(0x805919B4))
#define RING ((volatile uint32_t *)(uintptr_t)UINT32_C(0x80B5E7A4))
static uint32_t enter(void) {
    uint32_t mask;
    __asm__ volatile("mrs %0, primask\n\tcpsid i\n\tdmb sy":"=r"(mask)::"memory");
    return mask;
}
static void leave(uint32_t mask) {
    __asm__ volatile("dmb sy\n\tmsr primask, %0"::"r"(mask):"memory");
}
static uint32_t task(void) {
    return ((uint32_t (*)(void))(uintptr_t)UINT32_C(0x800D3163))();
}
static int object(const void *p,size_t n,size_t a) {
    uintptr_t v=(uintptr_t)p;
    return v && v%a==0 && v<=UINTPTR_MAX-n;
}
static int overlap(uintptr_t a,size_t an,uintptr_t b,size_t bn) {
    return a<b+bn && b<a+an;
}
static int cursors(SpSynthInputObserverV552 *o,uint32_t *r,uint32_t *w) {
    *r=*R;*w=*W;
    if(*r>255 || *w>255 || sp404_stock_input_native_v552_scratch[2]) {
        o->loss|=SP_INPUT_OBSERVER_CURSOR;return 0;
    }
    return 1;
}
static void observe(SpSynthInputObserverV552 *o,const uint32_t record[3]) {
    uint32_t kind=record[0]&65535u,index=record[0]>>16;
    if(kind==16 && index<16)o->held_pads|=1u<<index;
    if(kind==17 && index<16)o->held_pads&=~(1u<<index);
    if((kind==5 || kind==6) && index==42)o->shift=kind==5;
    if(o->records==UINT32_MAX)o->loss|=SP_INPUT_OBSERVER_EXHAUSTED;
    else ++o->records;
}
static void dispatch(SpSynthInputObserverV552 *o,const uint32_t record[3]) {
    uint32_t mask=enter();
    SpSynthSessionV552 *s=o->session;
    uint32_t owner_task=o->task_id;
    leave(mask);
    uint32_t kind=record[0]&65535u,index=record[0]>>16;
    if(s && task()!=owner_task) {
        mask=enter();o->loss|=SP_INPUT_OBSERVER_FOREIGN;leave(mask);
        /* Stop publication is atomic; mutable input stays with its task. */
        sp_synth_session_v552_stop(s);
    } else if(s && atomic_load_explicit(&s->ready,memory_order_acquire)==1 &&
              atomic_load_explicit(&s->control_ready,memory_order_acquire)==1) {
        sp_synth_input_owner *input=&s->startup.memory.storage->input;
        if(kind==16 && index<16) {
            /* This revision keeps every new down stock-owned, even if a
             * future integrator has enabled the portable input owner. */
            input->physical|=(uint16_t)(1u<<index);
        } else if(kind==17 && index<16) {
            int captured=(input->captured&(1u<<index))!=0;
            sp_ui_event event={.type=SP_UI_PAD_UP,.index=(uint16_t)(index+1)};
            (void)sp_synth_session_v552_route(s,&event);
            if(captured) {
                (void)((uint32_t (*)(uintptr_t))(uintptr_t)UINT32_C(0x800D4961))(
                    UINT32_C(0x80591B24));
                return;
            }
        } else if((kind==5 || kind==6) && index==42) {
            sp_ui_event event={.type=kind==5?SP_UI_SHIFT_DOWN:SP_UI_SHIFT_UP};
            (void)sp_synth_session_v552_route(s,&event);
        }
    }
    /* The router's result is ignored by native drain too. In particular,
     * SHIFT still reaches native bitmap/modal/alias bookkeeping once. */
    (void)((uint32_t (*)(const void *))(uintptr_t)UINT32_C(0x8003B531))(record);
}
uint64_t sp_synth_input_observer_v552_drain(void) {
    SpSynthInputObserverV552 *o=&sp_synth_input_observer_v552;
    uint32_t mask=enter(),r,w;
    if(o->depth==UINT32_MAX) {
        o->loss|=SP_INPUT_OBSERVER_EXHAUSTED;
        r=*R;w=*W;leave(mask);return (uint64_t)w<<32|r;
    }
    ++o->depth;
    for(;;) {
        if(!cursors(o,&r,&w) || r==w)break;
        uint32_t record[3]={RING[3*r],RING[3*r+1],RING[3*r+2]};
        *R=(r+1)&255u;
        observe(o,record);
        leave(mask);
        dispatch(o,record);
        mask=enter();
    }
    --o->depth;
    leave(mask);
    return (uint64_t)w<<32|r;
}
int sp_synth_input_observer_v552_panel_cutoff(SpSynthPanelRingCutoffV552 *out) {
    uintptr_t p=(uintptr_t)out;
    if(!object(out,sizeof(*out),_Alignof(SpSynthPanelRingCutoffV552)) ||
       overlap(p,sizeof(*out),UINT32_C(0x8003B3C8),40) ||
       overlap(p,sizeof(*out),UINT32_C(0x805919B0),8) ||
       overlap(p,sizeof(*out),UINT32_C(0x80B5E7A4),3072))return 0;
    SpSynthInputObserverV552 *o=&sp_synth_input_observer_v552;
    uint32_t mask=enter(),r,w;
    int ok=cursors(o,&r,&w) && r==w && !o->depth && !o->loss;
    if(ok) {
        SpSynthPanelRingCutoffV552 value={o->held_pads,o->shift,
            *(volatile const uint32_t *)(uintptr_t)UINT32_C(0xE0001004),o->records,0};
        *out=value;
    }
    leave(mask);return ok;
}
int sp_synth_input_observer_v552_bind(SpSynthSessionV552 *s,void *panel) {
    if((uintptr_t)panel!=UINT32_C(0x8300A3E4) ||
       !object(s,sizeof(*s),_Alignof(SpSynthSessionV552)))return 0;
    uintptr_t p=(uintptr_t)s;
    if(overlap(p,sizeof(*s),SP_SYNTH_V552_POOL_BEGIN,
        SP_SYNTH_V552_POOL_END-SP_SYNTH_V552_POOL_BEGIN) ||
       overlap(p,sizeof(*s),UINT32_C(0x8003B3C8),40))return 0;
    uint32_t id=task();
    if(id<1 || id>32 || atomic_load_explicit(&s->ready,memory_order_acquire)!=1 ||
       atomic_load_explicit(&s->control_ready,memory_order_acquire)!=1 ||
       atomic_load_explicit(&s->terminal,memory_order_acquire) ||
       s->startup.ready!=1 || s->startup.memory.attached!=1)return 0;
    const SpSynthStorageV552 *m=&s->startup.memory;
    const size_t a=_Alignof(SpSynthRuntimeStorage),n=sizeof(SpSynthRuntimeStorage)+a-1;
    uintptr_t raw=(uintptr_t)m->allocation;
    if(m->pool_id<1 || m->pool_id>8 || raw<SP_SYNTH_V552_POOL_BEGIN ||
       raw>SP_SYNTH_V552_POOL_END-n ||
       (uintptr_t)m->storage!=((raw+a-1)&~(uintptr_t)(a-1)))return 0;
    SpSynthInputObserverV552 *o=&sp_synth_input_observer_v552;
    const sp_synth_input_owner *input=&m->storage->input;
    uint32_t mask=enter(),r,w;
    int ok=cursors(o,&r,&w) && r==w && !o->depth && !o->loss && !o->session &&
        !o->task_id && !input->enabled && !input->captured && !input->delivered &&
        input->physical==o->held_pads && input->shift==o->shift;
    if(ok){o->session=s;o->task_id=id;}
    leave(mask);return ok;
}
