#include "sp_p6_record_mutation_closure_v552.h"
extern uint32_t sp_p6_clock_project_reset(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_clock_project_initialize(uint32_t,uint32_t,uint32_t,uint32_t);
int sp_p6_mc_v552_hook_coverage(void){
if(*(volatile const uint32_t*)0x8005AFA0u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x8005AFA4u!=((uint32_t)(uintptr_t)sp_p6_clock_project_reset|1u) ||
*(volatile const uint16_t*)0x8005AFA8u!=0xBF00u)return 0;
if(*(volatile const uint32_t*)0x8010F0B0u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x8010F0B4u!=((uint32_t)(uintptr_t)sp_p6_clock_project_initialize|1u) ||
*(volatile const uint16_t*)0x8010F0B8u!=0xBF00u)return 0;
return 1;}
