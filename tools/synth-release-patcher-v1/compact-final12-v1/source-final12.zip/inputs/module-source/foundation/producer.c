#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_project_gate_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_record_token_v552.h"
#include <stddef.h>
#include "sp_p6_record_ingress_alias_v552.h"

#define PARAM 0x8300A4D8u
#define QUEUE 0x82E0D624u
#define SERVICE 0x82E0E5F8u
#define METHOD 0x8021D054u
#define DISPATCH 0x80183F90u
SpP6RecordProducerV552 sp_p6_record_producer_v552;
_Static_assert(sizeof(SpP6RecordProducerV552)==52,"Permanent producer observer budget");
static uint32_t rd(uint32_t a) { return *(volatile const uint32_t *)(uintptr_t)a; }
static uint16_t half(uint32_t a) { return *(volatile const uint16_t *)(uintptr_t)a; }
static uint32_t value(const atomic_uint *a) { return atomic_load_explicit(a,memory_order_acquire); }
static uint32_t native(uint32_t a,uint32_t b,uint32_t c,uint32_t d,uint32_t e) {
    return ((uint32_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(uintptr_t)(a|1u))(b,c,d,e);
}
static uint32_t lock(void) { uint32_t p;__asm__ volatile("mrs %0, primask\n cpsid i":"=r"(p)::"memory");return p; }
static void unlock(uint32_t p) { __asm__ volatile("dmb\n msr primask, %0"::"r"(p):"memory"); }
static uint32_t task(void) {
    uint32_t ip,pm,bp,fm;
    __asm__ volatile("mrs %0, ipsr":"=r"(ip));__asm__ volatile("mrs %0, primask":"=r"(pm));
    __asm__ volatile("mrs %0, basepri":"=r"(bp));__asm__ volatile("mrs %0, faultmask":"=r"(fm));
    if(ip || pm || bp || fm || rd(0x202BBBF8u) || rd(0x80245764u))return 0;
    return native(0x800D3162u,0,0,0,0);
}
static int installed(void) {
    return rd(METHOD)==((uint32_t)(uintptr_t)sp_p6_ia_v552_callback|1u) &&
        rd(DISPATCH)==0xF000F8DFu && rd(DISPATCH+4)==((uint32_t)(uintptr_t)sp_p6_record_producer_v552_dispatch|1u) &&
        half(DISPATCH+8)==0xBF00u;
}
static int identity(const SpP6RecordProducerV552 *o) {
    return o->task && o->task<=32 && rd(PARAM)==0x8021D034u && rd(PARAM+4)==o->task &&
        rd(QUEUE+48)==o->task && rd(QUEUE+52)==0x80064E39u;
}
static int adopt(void) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    uint32_t t=rd(PARAM+4),p=lock();
    if(!o->task && t && t<=32 && rd(PARAM)==0x8021D034u && rd(QUEUE+48)==t && rd(QUEUE+52)==0x80064E39u)o->task=t;
    int result=identity(o);unlock(p);return result;
}
static int queues(void) {
    return rd(SERVICE+4)<=8 && rd(SERVICE+8)<=8 &&
        half(QUEUE+20)<=half(QUEUE+22) && half(QUEUE+44)<=half(QUEUE+46) &&
        half(QUEUE+22)==128 && half(QUEUE+46)==128;
}
static int outer_waiting(void) { return half(QUEUE+20) || half(QUEUE+44); }
static int waiting(void) {
    return sp_p6_record_project_gate_v552_pending_locked() || outer_waiting() || sp_p6_record_ingress_alias_v552.outer_count || (sp_p6_record_producer_v552.drain_requested && (rd(SERVICE+4)!=rd(SERVICE+8) || sp_p6_record_ingress_alias_v552.inner_size));
}
int sp_p6_record_producer_v552_bind(SpSynthCaptureTimedV552 *c) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    uintptr_t a=(uintptr_t)c;
    if(o->capture || a<0x80000000u || a>0x84000000u-sizeof(*c) || (a&7u) ||
       !sp_p6_record_context_v552_current(1) || value(&c->state)!=SP_TCAP_FREE || value(&c->token) ||
       c->last_token || c->file_owned || sp_p6_record_files_v552.active || !installed())return 0;
    if(!adopt() || !queues() || o->task==sp_p6_record_contexts_v552.smpl_task ||
       o->task==sp_p6_record_contexts_v552.record_task || o->task==sp_p6_record_contexts_v552.fileif_task)return 0;
    uint32_t p=lock();
    if(!sp_p6_ia_v552_quiescent() || !sp_p6_record_project_gate_v552_bind_locked() || o->capture || o->fault || o->active || o->held || !identity(o) || !queues() || !installed()) { unlock(p);return 0; }
    o->capture=c;unlock(p);return 1;
}
int sp_p6_record_producer_v552_begin(SpSynthCaptureTimedV552 *c) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    if(c!=o->capture || !c || !sp_p6_record_context_v552_current(1) || !installed() ||
       !identity(o) || !queues() || value(&c->state)!=SP_TCAP_BEGIN || !value(&c->token) ||
       value(&c->token)!=c->last_token || c->plan.take_token!=c->last_token ||
       c->last_token<=o->last_retired || !c->plan.start_generation || c->file_owned || value(&c->rx_active) ||
       sp_p6_record_files_v552.active)return 0;
    uint32_t p=lock();
    if(!sp_p6_ia_v552_quiescent() || !sp_p6_record_project_gate_v552_begin_locked(c) || o->fault || o->held || o->active || !identity(o) || !queues() || !installed()) { unlock(p);return 0; }
    o->token=c->last_token;o->held=1;unlock(p);return 1;
}
int sp_p6_record_producer_v552_wake(void) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    if(!o->capture || !sp_p6_record_context_v552_current(1))return 0;
    uint32_t p=lock();
    int ready=!o->fault && !o->held && !o->active && o->pending && identity(o) && installed();
    if(ready)o->wakes++;
    unlock(p);
    if(!ready)return 0;
    /* Unknown or failed signal results do not acknowledge a drained command. */
    (void)native(0x80064E38u,0,0,0,0);return 1;
}
int sp_p6_record_producer_v552_released(SpSynthCaptureTimedV552 *c) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    if(!c || c!=o->capture || !sp_p6_record_context_v552_current(1) || !installed() || !identity(o) ||
       !queues() || value(&c->state)!=SP_TCAP_EXCLUSIVE_IDLE || value(&c->token) ||
       value(&c->cleanup_token)!=o->token || !o->token || c->file_owned || value(&c->rx_active) ||
       c->window.inflight || sp_p6_record_token_v552_current() || sp_p6_record_files_v552.active ||
       sp_p6_record_files_v552_outstanding() || c->close_raw || c->unlink_raw || !c->discard_attempted ||
       !value(&c->barrier_sequence) || value(&c->barrier_token)!=o->token ||
       value(&c->barrier_ack)!=value(&c->barrier_sequence) || value(&c->wait_sequence)!=value(&c->barrier_sequence))return 0;
    uint32_t p=lock();
    if(o->fault || !o->held || o->active) { unlock(p);return 0; }
    o->last_retired=o->token;o->token=0;o->held=0;if(waiting())o->pending=1;unlock(p);
    (void)sp_p6_record_producer_v552_wake();return 1;
}
static int enter(uint32_t current,int callback) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    if(!adopt())return 0;
    uint32_t p=lock();
    if(!identity(o) || !queues() || current!=o->task || !installed() || o->active==UINT32_MAX) {
        o->fault|=1;o->pending|=(uint32_t)waiting();unlock(p);return 0;
    }
    if(o->held || o->fault) {
        if(!callback && rd(SERVICE+4)!=rd(SERVICE+8))o->drain_requested=1;
        if(waiting())o->pending=1;
        unlock(p);return 0;
    }
    /* A nested service dispatch on the same native ParamTask remains within
     * the callback ticket. SMPL BEGIN sees active until both frames return. */
    o->active++;if(callback)o->callbacks++;else o->dispatches++;unlock(p);return 1;
}
static void leave(uint32_t current) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    uint32_t p=lock();
    if(!o->active || current!=o->task || !identity(o) || !queues() || o->held || !installed())o->fault|=2;
    else { o->active--;o->pending=(uint32_t)waiting(); }
    unlock(p);
}
uint32_t sp_p6_record_producer_v552_dispatch(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    if(a!=SERVICE) { if(o->held || o->active) { o->fault|=4;return 1; }
        return sp_p6_rp_dispatch_original_v552(a,b,c,d); }
    if(!enter(task(),0))return 1; /* Stock empty drain return; no response sent. */
    uint32_t r=sp_p6_rp_dispatch_original_v552(a,b,c,d);
    if(rd(SERVICE+4)==rd(SERVICE+8))o->drain_requested=0;
    leave(task());return r;
}
uint32_t sp_p6_record_producer_v552_callback(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    if(b)return native(0x80073008u,a,b,c,d);
    if(a!=PARAM || !enter(task(),1))return 0;
    if(!sp_p6_record_project_gate_v552_replay()) { leave(task());return 0; }
    /* A request may already have been copied into the inner queue before the
     * hold. Its outer envelope can be gone; drain the retained copy first. */
    if(o->drain_requested && rd(SERVICE+4)!=rd(SERVICE+8)) {
        o->replays++;(void)sp_p6_record_producer_v552_dispatch(SERVICE,0,0,0);
    }
    uint32_t r=native(0x80073008u,a,b,c,d);leave(task());return r;
}

/* Separate SAVE receipt. No DISCARD fields are fabricated for this release. */
#include "sp_p6_save_handover_v552.h"
int sp_p6_record_producer_v552_save_release_ready(SpSynthCaptureTimedV552 *c) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    if(!c || c!=o->capture || c!=s->capture || !sp_p6_record_context_v552_current(1) ||
       !installed() || !identity(o) || !queues() || s->state!=SP_P6_SAVE_WAIT || s->fault ||
       !o->token || s->token!=o->token || value(&c->token)!=o->token ||
       value(&c->state)!=SP_TCAP_FINALIZED || !c->file_owned || value(&c->rx_active) ||
       c->window.inflight || !sp_p6_record_token_v552_current())return 0;
    uint32_t p=lock();int ready=!o->fault && o->held && !o->active;unlock(p);return ready;
}
int sp_p6_record_producer_v552_saved_released(SpSynthCaptureTimedV552 *c) {
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    SpP6SaveHandoverV552 *s=&sp_p6_save_handover_v552;
    if(!c || c!=o->capture || c!=s->capture || !sp_p6_record_context_v552_current(1) ||
       !installed() || !identity(o) || !queues() || s->state!=SP_P6_SAVE_RETIRING || s->fault ||
       s->token!=o->token || !s->sequence || s->wait_sequence!=s->sequence || s->ack_sequence!=s->sequence ||
       value(&c->state)!=SP_TCAP_EXCLUSIVE_IDLE || value(&c->token) || value(&c->cleanup_token)!=o->token ||
       !o->token || c->file_owned || value(&c->rx_active) || c->window.inflight ||
       sp_p6_record_token_v552_current() || sp_p6_record_files_v552.active ||
       sp_p6_record_files_v552_outstanding())return 0;
    uint32_t p=lock();
    if(o->fault || !o->held || o->active) { unlock(p);return 0; }
    o->last_retired=o->token;o->token=0;o->held=0;if(waiting())o->pending=1;unlock(p);
    (void)sp_p6_record_producer_v552_wake();return 1;
}
