#include "sp_p6_record_files_v552.h"
#include "sp_p6_save_handover_v552.h"
#include "sp_p6_record_context_v552.h"
#ifndef SP_P6_RF_DIAGNOSTIC
#include "sp_p6_record_token_v552.h"
#endif
#include <stddef.h>

#define OUTER 0x82E0E71Cu
#define NORMAL 0x82FE4F08u
#define TABLE 0x80B5F3B4u
#define RECORD 0x202ACFA0u
typedef uint32_t (*Native)(uint32_t,uint32_t,uint32_t,uint32_t);
#define ORIGINAL(n) extern uint32_t sp_p6_rf_##n##_original_v552(uint32_t,uint32_t,uint32_t,uint32_t)
ORIGINAL(start);ORIGINAL(save);ORIGINAL(discard);ORIGINAL(record);ORIGINAL(open);
ORIGINAL(read);ORIGINAL(write);ORIGINAL(close);ORIGINAL(sync);
ORIGINAL(lower_close);
ORIGINAL(directory_open);ORIGINAL(directory_close);
ORIGINAL(directory_read);
ORIGINAL(cache);
ORIGINAL(rename);ORIGINAL(unlink);
ORIGINAL(alternate_open);ORIGINAL(copy);ORIGINAL(bulk_close);ORIGINAL(bulk_close_external);ORIGINAL(cache_clear);
SpP6RecordFilesV552 sp_p6_record_files_v552;
_Static_assert(sizeof(SpP6RecordFilesV552)==1024,"Bounded independent FILE/DIR journal");
static uint32_t rd(uint32_t p) { return *(volatile const uint32_t *)(uintptr_t)p; }
static uint8_t byte(uint32_t p) { return *(volatile const uint8_t *)(uintptr_t)p; }
static uint32_t native(uint32_t p,uint32_t a,uint32_t b,uint32_t c,uint32_t d) { return ((Native)(uintptr_t)(p|1u))(a,b,c,d); }
static uint32_t mask(void) { uint32_t p;__asm__ volatile("mrs %0, primask\n cpsid i":"=r"(p)::"memory");return p; }
static void unmask(uint32_t p) { __asm__ volatile("msr primask, %0"::"r"(p):"memory"); }
static void fault(uint32_t f) { uint32_t p=mask();sp_p6_record_files_v552.fault|=f;unmask(p); }
static int span(uint32_t p,uint32_t n) { return p>=0x80000000u && p<=0x84000000u-n && !(p&3u); }
static char fold(char c) {
    if(c>='a' && c<='z')return (char)(c-'a'+'A');
    return c=='\\'?'/':c;
}
static int same(const char *a,const char *b) {
    for(unsigned i=0;i<64;i++) { if(fold(a[i])!=fold(b[i]))return 0;if(!a[i])return 1; }return 0;
}
static int text(const char *p) { for(unsigned i=0;i<64;i++)if(!p[i])return i>=3;return 0; }
static int prefix(const char *a,const char *b) {
    for(unsigned i=0;i<64;i++) { if(!a[i])return b[i]=='/' || !b[i];if(a[i]!=b[i])return 0; }return 0;
}
static uint32_t scope(uint32_t *ctx) {
#ifndef SP_P6_RF_DIAGNOSTIC
    if(!sp_p6_record_token_v552_current()) { *ctx=0;return 0; }
#endif
    uint32_t c=sp_p6_record_context_v552_current(1);
    if(c) { *ctx=c;return sp_p6_record_files_v552.smpl_operation; }
    c=sp_p6_record_context_v552_current(2);
    if(c) { *ctx=c;return sp_p6_record_files_v552.record_operation; }
    *ctx=0;return 0;
}
static int live(const SpP6RecordFileIdentityV552 *f) {
    if(f->state!=SP_P6_RF_LIVE || !span(f->file,36) || !(rd(f->file)&1u))return 0;
    return f->kind==SP_P6_RF_DIRECTORY?f->directory_context && rd(f->file+4)==f->directory_context:
        f->fd>=1 && f->fd<1024 && rd(TABLE+4*f->fd)==f->file;
}
static SpP6RecordFileIdentityV552 *identity(uint32_t a,uint32_t is_file) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    for(unsigned i=0;i<15;i++) {
        SpP6RecordFileIdentityV552 *f=&o->files[i];
        if(f->kind && f->state!=SP_P6_RF_CLOSED && (is_file?f->file:f->fd)==a)return f;
    }
    return NULL;
}
static SpP6RecordFileIdentityV552 *reserve(uint32_t kind,uint32_t ctx,uint32_t operation) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    uint32_t p=mask();
    for(unsigned i=0;i<15;i++)if(!o->files[i].kind) {
        SpP6RecordFileIdentityV552 *f=&o->files[i];f->kind=kind;f->fd=UINT32_MAX;
        f->context=ctx;f->task=rd(ctx);f->operation=operation;f->close_raw=INT32_MIN;
        unmask(p);return f;
    }
    unmask(p);fault(SP_P6_RF_FULL);return NULL;
}
static int permits(SpP6RecordFileIdentityV552 *f,uint32_t write) {
    uint32_t ctx=0,op=scope(&ctx);
    if(!op || !ctx || !live(f) || f->close_attempted ||
       (f->kind!=SP_P6_RF_TEMP && (f->context!=ctx || f->task!=rd(ctx)))) {
        fault(SP_P6_RF_IDENTITY);return 0;
    }
    if(f->kind==SP_P6_RF_TEMP) {
        if(op!=SP_P6_RF_RECORD && (f->context!=ctx || f->task!=rd(ctx)))return 0;
        if(write)return op==SP_P6_RF_START || op==SP_P6_RF_RECORD || op==SP_P6_RF_SAVE;
        return op==SP_P6_RF_SAVE || op==SP_P6_RF_DISCARD;
    }
    if(op!=SP_P6_RF_SAVE)return 0;
    return write?f->kind==SP_P6_RF_PROJECT:f->kind==SP_P6_RF_READER || f->kind==SP_P6_RF_CACHE ||
        f->kind==SP_P6_RF_DIRECTORY || f->kind==SP_P6_RF_PROJECT || f->kind==SP_P6_RF_PROJECT_READER;
}
static int temporary(SpP6RecordFilesV552 *o) {
    SpP6RecordFileIdentityV552 *f=identity(rd(OUTER+72),0);
    return f && f->kind==SP_P6_RF_TEMP && live(f) && rd(OUTER+596)==NORMAL &&
        rd(NORMAL)==0x8021E020u && rd(NORMAL+432)==f->fd && same(o->path[0],(const char *)(uintptr_t)(OUTER+80));
}
static int discard_io_fault(void) {
    return sp_p6_record_files_v552.fault==SP_P6_RF_IO &&
        sp_p6_record_files_v552.smpl_operation==SP_P6_RF_DISCARD &&
        sp_p6_record_context_v552_current(1)!=0;
}
static int smpl_scope(uint32_t operation) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(!sp_p6_record_context_v552_current(1) || o->smpl_operation || o->fault) { fault(SP_P6_RF_SCOPE);return 0; }
    o->smpl_operation=operation;return 1;
}
uint32_t sp_p6_record_files_v552_start(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(a!=OUTER || b || !sp_p6_record_context_v552_registered())return sp_p6_rf_start_original_v552(a,b,c,d);
#ifndef SP_P6_RF_DIAGNOSTIC
    if(!o->active) {
        int claim=sp_p6_record_token_v552_native_begin();
        if(!claim)return sp_p6_rf_start_original_v552(a,b,c,d);
        if(claim<0) { fault(SP_P6_RF_SCOPE);o->refusals++;return UINT32_MAX; }
    }
#endif
    if(o->active || o->serial==UINT32_MAX || byte(OUTER+57) || !smpl_scope(SP_P6_RF_START)) {
        fault(SP_P6_RF_SCOPE);o->refusals++;return UINT32_MAX;
    }
    o->active=1;o->serial++;o->project=native(0x800E1190u,0,0,0,0);o->pad=UINT32_MAX;
    const char *name="B:/_rec.bin";for(unsigned i=0;i<sizeof("B:/_rec.bin");i++)o->path[0][i]=name[i];
    uint32_t result=sp_p6_rf_start_original_v552(a,b,c,d);o->native_calls++;
    if(!sp_p6_record_context_v552_current(1) || !temporary(o) || byte(OUTER+57)!=1)fault(SP_P6_RF_IDENTITY);
    o->smpl_operation=0;return result;
}
uint32_t sp_p6_record_files_v552_record(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(!o->active || a!=RECORD || b!=1)return sp_p6_rf_record_original_v552(a,b,c,d);
    if(sp_p6_save_v552_old_drain())return sp_p6_rf_record_original_v552(a,b,c,d);
    if(o->fault || o->record_operation || !sp_p6_record_context_v552_current(2) || !temporary(o)) {
        fault(SP_P6_RF_SCOPE);o->refusals++;return UINT32_MAX;
    }
    o->record_operation=SP_P6_RF_RECORD;
    uint32_t r=sp_p6_rf_record_original_v552(a,b,c,d);o->native_calls++;
    if(!sp_p6_record_context_v552_current(2) || !temporary(o))fault(SP_P6_RF_IDENTITY);
    o->record_operation=0;return r;
}
static int save_paths(SpP6RecordFilesV552 *o) {
    o->pad=rd(OUTER+76);
    if(o->pad>=160 || o->project>=128 || native(0x800E1190u,0,0,0,0)!=o->project ||
       native(0x800D94D8u,0x82E01144u,132,0,0) ||
       native(0x800DC6B8u,0x82E2CD08u,101,o->pad,0))return 0;
    for(unsigned i=0;i<3;i++) {
        native(0x800D60C8u,(uint32_t)(uintptr_t)o->path[1+i],o->pad,i,o->project);
        if(!text(o->path[1+i]))return 0;
    }
    unsigned i=0;
    while(i<64 && o->path[1][i]) {
        if(i+5<64 && o->path[1][i]=='/' && o->path[1][i+1]=='S' && o->path[1][i+2]=='M' &&
           o->path[1][i+3]=='P' && o->path[1][i+4]=='L' && o->path[1][i+5]=='/')break;
        o->path[4][i]=o->path[1][i];i++;
    }
    if(i>51 || i==64)return 0;
    const char *tail="/PADCONF.BIN";for(unsigned k=0;k<sizeof("/PADCONF.BIN");k++)o->path[4][i+k]=tail[k];
    return text(o->path[4]);
}
static uint32_t be32(const uint8_t *p) { return (uint32_t)p[0]<<24 | (uint32_t)p[1]<<16 | (uint32_t)p[2]<<8 | p[3]; }
static int checked_reader(const char *path) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    uint32_t frames=rd(NORMAL+512),status[7];uint8_t header[512];
    for(unsigned i=0;i<7;i++)*(volatile uint32_t *)&status[i]=0;
    if(o->fault || o->smpl_operation!=SP_P6_RF_SAVE || !sp_p6_record_context_v552_current(1) ||
       frames>(UINT32_MAX-512u)/4u || !frames || byte(OUTER+58))return 0;
    uint32_t size=512+4*frames;
    uint32_t fd=native(0x800DEC60u,(uint32_t)(uintptr_t)path,0,0,0);
    if((int32_t)fd<0)return 0;
    SpP6RecordFileIdentityV552 *f=identity(fd,0);
    if(!f || f->kind!=SP_P6_RF_READER || !live(f)) { fault(SP_P6_RF_IDENTITY);return 0; }
    int ok=!native(0x800D1130u,fd,(uint32_t)(uintptr_t)status,0,0) && status[2]==size && !status[3] &&
        native(0x800DEC48u,fd,(uint32_t)(uintptr_t)header,512,0)==512 &&
        header[0]=='R' && header[1]=='F' && header[2]=='W' && header[3]=='V' &&
        be32(header+4)==size-8 && be32(header+8)==48000 && be32(header+12)==2 && be32(header+16)==16;
    /* A changed identity/context remains held. A semantic header failure still
     * retires its exact readable FILE once before the transaction faults. */
    if(o->fault || !live(f) || !sp_p6_record_context_v552_current(1))return 0;
    if(native(0x800DEBD8u,fd,0,0,0) || f->state!=SP_P6_RF_CLOSED)return 0;
    return ok;
}
uint32_t sp_p6_record_files_v552_save(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(!o->active || a!=OUTER)return sp_p6_rf_save_original_v552(a,b,c,d);
    if(!smpl_scope(SP_P6_RF_SAVE) || !temporary(o) || !save_paths(o)) {
        fault(SP_P6_RF_SCOPE);o->refusals++;o->smpl_operation=0;return UINT32_MAX;
    }
    uint32_t r=sp_p6_rf_save_original_v552(a,b,c,d);o->native_calls++;
    if(!sp_p6_record_context_v552_current(1))fault(SP_P6_RF_CONTEXT);
    if(!r && !o->fault && !checked_reader(o->path[1]))fault(SP_P6_RF_IO);
    o->smpl_operation=0;return o->fault?UINT32_MAX:r;
}
uint32_t sp_p6_record_files_v552_discard(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(!o->active || a!=OUTER)return sp_p6_rf_discard_original_v552(a,b,c,d);
    if(!smpl_scope(SP_P6_RF_DISCARD)) { o->refusals++;return UINT32_MAX; }
    uint32_t r=sp_p6_rf_discard_original_v552(a,b,c,d);o->native_calls++;
    if(!sp_p6_record_context_v552_current(1))fault(SP_P6_RF_CONTEXT);
    o->smpl_operation=0;return r;
}
uint32_t sp_p6_record_files_v552_open(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(!o->active)return sp_p6_rf_open_original_v552(a,b,c,d);
    const char *path=(const char *)(uintptr_t)b;unsigned which=5;
    if(b)for(unsigned i=0;i<5;i++)if(o->path[i][0] && same(path,o->path[i])) { which=i;break; }
    if(which==5)return sp_p6_rf_open_original_v552(a,b,c,d);
    uint32_t ctx=0,op=scope(&ctx),kind=which==4?(c?SP_P6_RF_PROJECT:SP_P6_RF_PROJECT_READER):
        which?(o->cache_depth?SP_P6_RF_CACHE:SP_P6_RF_READER):SP_P6_RF_TEMP;
    if(!which && !c)kind=SP_P6_RF_READER;
    if(o->fault || a!=TABLE || !ctx || (op!=SP_P6_RF_START && op!=SP_P6_RF_SAVE) ||
       (op==SP_P6_RF_START && (which || c!=1537)) || (which==4 && c && c!=1537) ||
       (which>0 && which<4 && c)) { fault(SP_P6_RF_SCOPE);o->refusals++;return UINT32_MAX; }
    SpP6RecordFileIdentityV552 *f=reserve(kind,ctx,op);if(!f)return UINT32_MAX;
    uint32_t r=sp_p6_rf_open_original_v552(a,b,c,d);o->native_calls++;
    if((int32_t)r<0) { f->state=SP_P6_RF_CLOSED;f->close_raw=0;return r; }
    f->fd=r;f->file=r<1024?rd(TABLE+4*r):0;f->state=SP_P6_RF_LIVE;
    if(!live(f) || !sp_p6_record_context_v552_current(1))fault(SP_P6_RF_IDENTITY);
    return r;
}
static uint32_t io(Native chain,uint32_t kind,uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    SpP6RecordFileIdentityV552 *f=identity(a,kind==3);
    if(!o->active || !f)return chain(a,b,c,d);
    int cleanup=kind==4 && f->kind==SP_P6_RF_TEMP && discard_io_fault();
    if((o->fault && !cleanup) || !permits(f,kind==2)) { o->refusals++;return kind==1 || kind==2?0:UINT32_MAX; }
    f->calls++;
    if(kind==4)f->close_attempted=1;
    uint32_t r=chain(a,b,c,d);o->native_calls++;
    if(kind==4) {
        f->close_raw=(int32_t)r;
        f->state=r==0 && rd(TABLE+4*f->fd)==0 && !(rd(f->file)&1u)?SP_P6_RF_CLOSED:SP_P6_RF_UNCERTAIN;
        if(f->state==SP_P6_RF_CLOSED)o->retirements++;else fault(SP_P6_RF_IO);
        if(f->state==SP_P6_RF_CLOSED && f->kind==SP_P6_RF_TEMP &&
           o->smpl_operation==SP_P6_RF_SAVE && !checked_reader(o->path[0]))fault(SP_P6_RF_IO);
    } else if(!live(f) || ((kind==1 || kind==2) && r!=c) || (kind==3 && r))fault(SP_P6_RF_IO);
    return r;
}
uint32_t sp_p6_record_files_v552_read(uint32_t a,uint32_t b,uint32_t c,uint32_t d) { return io(sp_p6_rf_read_original_v552,1,a,b,c,d); }
uint32_t sp_p6_record_files_v552_write(uint32_t a,uint32_t b,uint32_t c,uint32_t d) { return io(sp_p6_rf_write_original_v552,2,a,b,c,d); }
uint32_t sp_p6_record_files_v552_sync(uint32_t a,uint32_t b,uint32_t c,uint32_t d) { return io(sp_p6_rf_sync_original_v552,3,a,b,c,d); }
uint32_t sp_p6_record_files_v552_close(uint32_t a,uint32_t b,uint32_t c,uint32_t d) { return io(sp_p6_rf_close_original_v552,4,a,b,c,d); }
uint32_t sp_p6_record_files_v552_lower_close(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    SpP6RecordFileIdentityV552 *f=identity(a,1);
    if(!o->active || !f)return sp_p6_rf_lower_close_original_v552(a,b,c,d);
    uint32_t ctx=0,op=scope(&ctx);
    if((o->fault && !(f->kind==SP_P6_RF_TEMP && discard_io_fault())) || !live(f) || f->kind==SP_P6_RF_DIRECTORY || f->close_attempted!=1 ||
       f->context!=ctx || f->task!=rd(ctx) || (op!=SP_P6_RF_SAVE && op!=SP_P6_RF_DISCARD)) {
        o->refusals++;return UINT32_MAX;
    }
    /* Native public CLOSE retries this entry. Consume the exact FILE before
     * the first lower call; a returned error retains the journal identity. */
    f->close_attempted=3;
    uint32_t r=sp_p6_rf_lower_close_original_v552(a,b,c,d);o->native_calls++;
    if(!sp_p6_record_context_v552_current(1))fault(SP_P6_RF_CONTEXT);
    return r;
}
uint32_t sp_p6_record_files_v552_directory_open(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(!o->active || !o->path[1][0] || !a || !prefix((const char *)(uintptr_t)a,o->path[1]))return sp_p6_rf_directory_open_original_v552(a,b,c,d);
    uint32_t ctx=0,op=scope(&ctx);
    if(o->fault || op!=SP_P6_RF_SAVE || !ctx) { fault(SP_P6_RF_SCOPE);o->refusals++;return 0; }
    SpP6RecordFileIdentityV552 *f=reserve(SP_P6_RF_DIRECTORY,ctx,op);if(!f)return 0;
    uint32_t r=sp_p6_rf_directory_open_original_v552(a,b,c,d);o->native_calls++;
    if(!r) { f->state=SP_P6_RF_CLOSED;f->close_raw=0;return r; }
    f->file=r;f->state=SP_P6_RF_LIVE;
    if(span(r,8))f->directory_context=rd(r+4);
    if(!live(f) || !sp_p6_record_context_v552_current(1))fault(SP_P6_RF_IDENTITY);
    return r;
}
uint32_t sp_p6_record_files_v552_directory_close(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;SpP6RecordFileIdentityV552 *f=identity(a,1);
    if(!o->active || !f)return sp_p6_rf_directory_close_original_v552(a,b,c,d);
    if(o->fault || f->kind!=SP_P6_RF_DIRECTORY || !permits(f,0)) { o->refusals++;return UINT32_MAX; }
    f->calls++;f->close_attempted=1;uint32_t r=sp_p6_rf_directory_close_original_v552(a,b,c,d);o->native_calls++;
    f->close_raw=(int32_t)r;f->state=!r && rd(a+4)==f->directory_context && !(rd(a)&1u)?SP_P6_RF_CLOSED:SP_P6_RF_UNCERTAIN;
    if(f->state==SP_P6_RF_CLOSED)o->retirements++;else fault(SP_P6_RF_IO);return r;
}
uint32_t sp_p6_record_files_v552_directory_read(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;SpP6RecordFileIdentityV552 *f=identity(a,1);
    if(!o->active || !f)return sp_p6_rf_directory_read_original_v552(a,b,c,d);
    if(o->fault || f->kind!=SP_P6_RF_DIRECTORY || !permits(f,0)) { o->refusals++;return 0; }
    f->calls++;uint32_t r=sp_p6_rf_directory_read_original_v552(a,b,c,d);o->native_calls++;
    if(!live(f) || !sp_p6_record_context_v552_current(1))fault(SP_P6_RF_IDENTITY);
    return r;
}
uint32_t sp_p6_record_files_v552_cache(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(!o->active || a!=0x82E111C8u || b!=o->pad)return sp_p6_rf_cache_original_v552(a,b,c,d);
    uint32_t ctx=0,op=scope(&ctx);
    if(o->fault || op!=SP_P6_RF_SAVE || !ctx || o->cache_depth) { fault(SP_P6_RF_SCOPE);o->refusals++;return UINT32_MAX; }
    o->cache_depth=1;uint32_t r=sp_p6_rf_cache_original_v552(a,b,c,d);o->native_calls++;o->cache_depth=0;
    if((int32_t)r>=0) {
        SpP6RecordFileIdentityV552 *f=identity(r,0);
        if(!f || f->kind!=SP_P6_RF_CACHE || !live(f) || !sp_p6_record_context_v552_current(1))fault(SP_P6_RF_IDENTITY);
    }
    return r;
}
static unsigned protected_path(uint32_t p) {
    if(!p)return 5;
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    for(unsigned i=0;i<5;i++)if(o->path[i][0] && same((const char *)(uintptr_t)p,o->path[i]))return i;
    return 5;
}
static int alternate_path(uint32_t p) {
    if(protected_path(p)!=5)return 1;
    if(!p)return 0;
    const char *path=(const char *)(uintptr_t)p;
    const char *remote=(const char *)(uintptr_t)0x8023D04Eu;
    for(unsigned i=0;i<14;i++)if(path[i]!=remote[i])return 0;
    char translated[64];translated[0]='B';translated[1]=':';translated[2]='/';
    for(unsigned i=0;i<61;i++) {
        translated[i+3]=path[i+14];
        if(!path[i+14])return protected_path((uint32_t)(uintptr_t)translated)!=5;
    }
    return 0;
}
static uint32_t blocking_task(void) {
    uint32_t ipsr,basepri,primask,faultmask;
    __asm__ volatile("mrs %0, ipsr":"=r"(ipsr));
    __asm__ volatile("mrs %0, basepri":"=r"(basepri));
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    if(ipsr || basepri || primask || faultmask || rd(0x202BBBF8u) || (int32_t)rd(0x80245764u)>0)return 0;
    uint32_t task=native(0x800D3162u,0,0,0,0);
    return task>=1 && task<=32?task:0;
}
uint32_t sp_p6_record_files_v552_alternate_open(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(o->active && alternate_path(a)) { o->refusals++;return UINT32_MAX; }
    /* Once the real normal allocator has initialized its native pair, use
     * that same semaphore/mutex around the whole alternate publication.
     * Startup work before that initialization still needs producer retirement
     * and cannot supply complete admission. READ does not take this gate. */
    if(!sp_p6_record_context_v552_registered() || byte(TABLE+0x140C)!=1)
        return sp_p6_rf_alternate_open_original_v552(a,b,c,d);
    uint32_t task=blocking_task(),sem=rd(TABLE+0x1404),mutex=rd(TABLE+0x1408);
    if(!task || !sem || sem>32 || !mutex || mutex>8) { o->refusals++;return UINT32_MAX; }
    if(native(0x800D3252u,sem,1,UINT32_MAX,0)) { o->refusals++;return UINT32_MAX; }
    if(native(0x800D3112u,mutex,UINT32_MAX,0,0)) {
        native(0x800D3248u,sem,1,0,0);o->refusals++;return UINT32_MAX;
    }
    uint32_t result=UINT32_MAX;
    /* Either wait can yield to a newer take; recheck the actual task, pair
     * and namespace after acquisition, before the unlocked stock scan. */
    if(blocking_task()==task && byte(TABLE+0x140C)==1 && rd(TABLE+0x1404)==sem && rd(TABLE+0x1408)==mutex &&
       (!o->active || !alternate_path(a)))result=sp_p6_rf_alternate_open_original_v552(a,b,c,d);
    else o->refusals++;
    native(0x800D3108u,mutex,0,0,0);native(0x800D3248u,sem,1,0,0);return result;
}
uint32_t sp_p6_record_files_v552_copy(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(!o->active || (!alternate_path(b) && !alternate_path(c)))return sp_p6_rf_copy_original_v552(a,b,c,d);
    o->refusals++;return UINT32_MAX;
}
uint32_t sp_p6_record_files_v552_bulk_close(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    if(sp_p6_record_files_v552.active && sp_p6_record_files_v552_outstanding()) {
        sp_p6_record_files_v552.refusals++;return UINT32_MAX;
    }
    return sp_p6_rf_bulk_close_original_v552(a,b,c,d);
}
uint32_t sp_p6_record_files_v552_bulk_close_external(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    if(sp_p6_record_files_v552.active && sp_p6_record_files_v552_outstanding()) {
        sp_p6_record_files_v552.refusals++;return UINT32_MAX;
    }
    return sp_p6_rf_bulk_close_external_original_v552(a,b,c,d);
}
uint32_t sp_p6_record_files_v552_cache_clear(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(!o->active || a!=0x82E111C8u || b!=o->pad)return sp_p6_rf_cache_clear_original_v552(a,b,c,d);
    uint32_t ctx=0,op=scope(&ctx);
    if(!o->fault && ctx && op==SP_P6_RF_SAVE) {
        int held=0;
        for(unsigned i=0;i<15;i++)if(o->files[i].kind==SP_P6_RF_CACHE && o->files[i].state!=SP_P6_RF_CLOSED)held=1;
        if(!held)return sp_p6_rf_cache_clear_original_v552(a,b,c,d);
    }
    o->refusals++;return UINT32_MAX;
}
uint32_t sp_p6_record_files_v552_rename(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;
    if(!o->active || (protected_path(a)==5 && protected_path(b)==5))return sp_p6_rf_rename_original_v552(a,b,c,d);
    uint32_t ctx=0,op=scope(&ctx);
    if(o->fault || op!=SP_P6_RF_SAVE || !ctx || protected_path(a)!=0 || protected_path(b)!=1) {
        o->refusals++;return UINT32_MAX;
    }
    uint32_t r=sp_p6_rf_rename_original_v552(a,b,c,d);o->native_calls++;
    if(r || !sp_p6_record_context_v552_current(1))fault(SP_P6_RF_IO);
    return r;
}
uint32_t sp_p6_record_files_v552_unlink(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    SpP6RecordFilesV552 *o=&sp_p6_record_files_v552;unsigned path=protected_path(a);
    if(!o->active || path==5)return sp_p6_rf_unlink_original_v552(a,b,c,d);
    uint32_t ctx=0,op=scope(&ctx);
    int cleanup=0;
    if(!path && op==SP_P6_RF_DISCARD && discard_io_fault()) {
        for(unsigned i=0;i<15;i++) {
            SpP6RecordFileIdentityV552 *f=&o->files[i];
            if(f->kind==SP_P6_RF_TEMP && f->fd==rd(OUTER+72) && f->state==SP_P6_RF_CLOSED &&
               f->close_attempted==3 && !f->close_raw && f->context==ctx && rd(TABLE+4*f->fd)==0 && !(rd(f->file)&1u))cleanup=1;
        }
    }
    if((o->fault && !cleanup) || !ctx || (op!=SP_P6_RF_START && op!=SP_P6_RF_SAVE && op!=SP_P6_RF_DISCARD)) {
        o->refusals++;return UINT32_MAX;
    }
    /* SAVE is admitted only for the empty native destination observed before
     * metadata clear. Preserve unlisted files: native rename must reject them. */
    if(op==SP_P6_RF_SAVE && path>=1 && path<=3)return 0;
    if(path) { o->refusals++;return UINT32_MAX; }
    uint32_t r=sp_p6_rf_unlink_original_v552(a,b,c,d);o->native_calls++;
    if(!sp_p6_record_context_v552_current(1))fault(SP_P6_RF_CONTEXT);
    return r;
}
uint32_t sp_p6_record_files_v552_outstanding(void) {
    uint32_t n=0;
    for(unsigned i=0;i<15;i++) {
        if(sp_p6_record_files_v552.files[i].kind && sp_p6_record_files_v552.files[i].state!=SP_P6_RF_CLOSED)n++;
    }
    return n;
}
uint32_t sp_p6_record_files_v552_admission(void) { return 0; }
