#include "sp_p6_pattern_clock_v552.h"
#include <stdint.h>
#include "sp_p6_transaction_ingress_v552.h"
#include "sp_p6_record_mutation_closure_v552.h"
typedef uint32_t (*Call)(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_clock_initialize_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_initialize(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(0,b);
 uint32_t result=sp_p6_clock_initialize_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_sync_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_sync(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(1,b);
 uint32_t result=sp_p6_clock_sync_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_start_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_start(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(2,b);
 uint32_t result=sp_p6_clock_start_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_continue_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_continue(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(3,b);
 uint32_t result=sp_p6_clock_continue_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_stop_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_stop(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(4,b);
 uint32_t result=sp_p6_clock_stop_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_song_seek_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_song_seek(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(5,b);
 uint32_t result=sp_p6_clock_song_seek_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_start_at_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_start_at(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(6,b);
 uint32_t result=sp_p6_clock_start_at_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_reset_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_reset(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(7,b);
 uint32_t result=sp_p6_clock_reset_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_reschedule_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_reschedule(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(8,b);
 uint32_t result=sp_p6_clock_reschedule_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_seek_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_seek(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(9,b);
 uint32_t result=sp_p6_clock_seek_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_coarse_seek_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_coarse_seek(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(10,b);
 uint32_t result=sp_p6_clock_coarse_seek_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_tempo_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_tempo(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(11,b);
 uint32_t result=sp_p6_clock_tempo_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_meter_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_meter(uint32_t a,uint32_t b,uint32_t d,uint32_t e){
 uint32_t watched=sp_p6_clock_v552_mutation_enter(12,b);
 uint32_t result=sp_p6_clock_meter_original(a,b,d,e);
 sp_p6_clock_v552_mutation_leave(watched);return result;}
extern uint32_t sp_p6_clock_project_original(uint32_t,uint32_t,uint32_t,uint32_t);
extern uint32_t sp_p6_record_project_gate_v552_setter(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_project(uint32_t a,uint32_t b,uint32_t d,uint32_t e){return sp_p6_record_project_gate_v552_setter(a,b,d,e);}
extern uint32_t sp_p6_clock_project_reset_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_project_reset(uint32_t a,uint32_t b,uint32_t d,uint32_t e){uint32_t link;__asm__ volatile("mov %0, lr":"=r"(link));(void)a;(void)b;(void)d;(void)e;return sp_p6_record_project_gate_v552.active?sp_p6_tx_v552_nested(SP_P6_MC_RESET,link):sp_p6_mc_v552_reset();}
extern uint32_t sp_p6_clock_project_initialize_original(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_clock_project_initialize(uint32_t a,uint32_t b,uint32_t d,uint32_t e){uint32_t link;__asm__ volatile("mov %0, lr":"=r"(link));(void)a;(void)b;(void)d;(void)e;return sp_p6_record_project_gate_v552.active?sp_p6_tx_v552_nested(SP_P6_MC_INITIALIZE,link):sp_p6_mc_v552_initialize();}
uint32_t sp_p6_clock_v552_hook_coverage(void){
 if(*(volatile const uint32_t*)0x800036F8u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x800036FCu!=((uint32_t)(uintptr_t)sp_p6_clock_initialize|1u))return 0;
 if(*(volatile const uint32_t*)0x80008050u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x80008054u!=((uint32_t)(uintptr_t)sp_p6_clock_sync|1u))return 0;
 if(*(volatile const uint32_t*)0x80009F18u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x80009F1Cu!=((uint32_t)(uintptr_t)sp_p6_clock_start|1u))return 0;
 if(*(volatile const uint32_t*)0x8000A088u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x8000A08Cu!=((uint32_t)(uintptr_t)sp_p6_clock_continue|1u))return 0;
 if(*(volatile const uint32_t*)0x8000A0C8u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x8000A0CCu!=((uint32_t)(uintptr_t)sp_p6_clock_stop|1u))return 0;
 if(*(volatile const uint32_t*)0x80009D80u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x80009D84u!=((uint32_t)(uintptr_t)sp_p6_clock_song_seek|1u))return 0;
 if(*(volatile const uint32_t*)0x8000D9C8u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x8000D9CCu!=((uint32_t)(uintptr_t)sp_p6_clock_start_at|1u))return 0;
 if(*(volatile const uint32_t*)0x800A3950u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x800A3954u!=((uint32_t)(uintptr_t)sp_p6_clock_reset|1u))return 0;
 if(*(volatile const uint32_t*)0x8000D978u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x8000D97Cu!=((uint32_t)(uintptr_t)sp_p6_clock_reschedule|1u))return 0;
 if(*(volatile const uint32_t*)0x80051CF8u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x80051CFCu!=((uint32_t)(uintptr_t)sp_p6_clock_seek|1u))return 0;
 if(*(volatile const uint32_t*)0x80016318u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x8001631Cu!=((uint32_t)(uintptr_t)sp_p6_clock_coarse_seek|1u))return 0;
 if(*(volatile const uint32_t*)0x80011B48u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x80011B4Cu!=((uint32_t)(uintptr_t)sp_p6_clock_tempo|1u))return 0;
 if(*(volatile const uint32_t*)0x80010328u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x8001032Cu!=((uint32_t)(uintptr_t)sp_p6_clock_meter|1u))return 0;
 if(*(volatile const uint32_t*)0x800DED18u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x800DED1Cu!=((uint32_t)(uintptr_t)sp_p6_clock_project|1u))return 0;
 if(*(volatile const uint32_t*)0x8005AFA0u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x8005AFA4u!=((uint32_t)(uintptr_t)sp_p6_clock_project_reset|1u))return 0;
 if(*(volatile const uint32_t*)0x8010F0B0u!=0xF000F8DFu ||
    *(volatile const uint32_t*)0x8010F0B4u!=((uint32_t)(uintptr_t)sp_p6_clock_project_initialize|1u))return 0;
 return 1;}

uint32_t sp_p6_pg_setter_original_v552(uint32_t a,uint32_t b,uint32_t c,uint32_t d){uint32_t watched=sp_p6_clock_v552_mutation_enter(13,b);uint32_t r=sp_p6_clock_project_original(a,b,c,d);sp_p6_clock_v552_mutation_leave(watched);return r;}
