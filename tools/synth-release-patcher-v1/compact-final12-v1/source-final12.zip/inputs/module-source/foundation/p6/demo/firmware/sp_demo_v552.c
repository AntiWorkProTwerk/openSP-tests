#include "sp_demo_v552.h"
#include "sp_synth_preview_native_v552.h"
#include <stddef.h>

SpDemo sp_demo_v552;
static atomic_uint transport_fault;
static atomic_uint adapter_ready;
static uint8_t read8(uintptr_t a){return *(volatile uint8_t *)a;}
static uint32_t read32(uintptr_t a){return *(volatile uint32_t *)a;}
static int on_ui(void){
    const SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    return atomic_load_explicit(&m->ready,memory_order_acquire)==1 &&
        ((uint32_t (*)(void))(uintptr_t)0x800D3163)()==m->task_id;
}
/* RTOS get-time800D3194 jumps to TCM3FFA. TCM476E stores high word first.
 * Keep its units raw: no measured or verified frequency is supplied. */
uint64_t sp_demo_v552_ticks(void){
    uint32_t time[2]={0,0};
    if(((int (*)(uint32_t *))(uintptr_t)0x800D3195)(time))return 0;
    return ((uint64_t)time[0]<<32)|time[1];
}
void sp_demo_v552_init(void){
    if(!atomic_load_explicit(&adapter_ready,memory_order_acquire) && on_ui()){
        atomic_init(&transport_fault,0);sp_demo_init(&sp_demo_v552,0);
        atomic_store_explicit(&adapter_ready,1,memory_order_release);
    }
}
static int connected(void){
    /*833B70B4 transport+32 CDC context: configured44, DTR-open46, config47.
     *118C8 SET_CONTROL_LINE_STATE0x22 dispatches42830 case11. */
    return read32(0x833B9030u)==0x833B70B4u && read32(0x833B7178u)==2048 &&
        read8(0x833B7100u)==1 && read8(0x833B7103u)==1 &&
        read8(0x833B7102u)==1;
}
void sp_demo_v552_poll(void){
    if(!atomic_load_explicit(&adapter_ready,memory_order_acquire) || !on_ui())return;
    if(atomic_load_explicit(&sp_demo_v552.enabled,memory_order_acquire) ||
       atomic_load_explicit(&sp_demo_v552.connected,memory_order_acquire))
        (void)((int (*)(void *))(uintptr_t)0x8001E121)((void *)0x80D4C5B0u);
}
void sp_demo_v552_enable(int enabled){
    if(!on_ui())return;
    sp_demo_v552_init();sp_demo_enable(&sp_demo_v552,enabled);sp_demo_v552_poll();
}
void sp_demo_v552_event(uint16_t control,uint8_t kind,int32_t value,uint32_t aux){
    if(!on_ui())return;
    sp_demo_v552_init();sp_demo_event(&sp_demo_v552,sp_demo_v552_ticks(),control,kind,value,aux);
}
void sp_demo_v552_capture(const uint8_t bitmap[1024],const SpDemoMeta *meta){
    if(!on_ui())return;
    sp_demo_v552_init();(void)sp_demo_capture(&sp_demo_v552,sp_demo_v552_ticks(),bitmap,meta);
}
void sp_demo_v552_state(const SpDemoMeta *meta){
    if(!on_ui())return;
    sp_demo_v552_init();sp_demo_publish_state(&sp_demo_v552,sp_demo_v552_ticks(),meta);
}
/* The existing serialized TX worker is the only telemetry sender. The call to
 * stock68038 finishes native serialization/flush before the raw packet enqueue.
 * Native437D8 copies a complete record while PRIMASK is protected. Its error
 * after starting06590 can leave admitted bytes in the ring: inspect the write
 * cursor and never duplicate those bytes on a later retry. */
int sp_demo_v552_worker(void *object){
    int result=((int (*)(void *))(uintptr_t)0x80068039)(object);
    if((uintptr_t)object!=0x80D4C5B0u || !atomic_load_explicit(&adapter_ready,memory_order_acquire))return result;
    if(((uint32_t (*)(void))(uintptr_t)0x800D3163)()!=read32(0x80D4C5B8u))return result;
    int ready=connected();
    if(!ready)atomic_store_explicit(&transport_fault,0,memory_order_release);
    ready=ready && !atomic_load_explicit(&transport_fault,memory_order_acquire);
    const uint8_t *data;uint32_t size;
    if(!sp_demo_next(&sp_demo_v552,ready,sp_demo_v552_ticks(),&data,&size))return result;
    uint32_t irq;
    /* Keep cursor observations in the same native critical section as copy.
     * Other stock task/IRQ writers must not mimic telemetry admission. */
    __asm volatile("mrs %0, primask\n\tcpsid i":"=r"(irq)::"memory");
    uint32_t before=read32(0x833B717Cu);
    int sent=((int (*)(const uint8_t *,uint32_t))(uintptr_t)0x800437D9)(data,size);
    uint32_t after=read32(0x833B717Cu);
    __asm volatile("msr primask, %0"::"r"(irq):"memory");
    if(sent==(int)size)sp_demo_accepted(&sp_demo_v552);
    else if(after!=before){
        sp_demo_accepted(&sp_demo_v552);
        atomic_store_explicit(&transport_fault,1,memory_order_release);
    }
    return result;
}
uint32_t sp_demo_v552_status(void){
    return atomic_load_explicit(&adapter_ready,memory_order_acquire)?sp_demo_status(&sp_demo_v552):0;
}
