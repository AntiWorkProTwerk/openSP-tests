#include "sp_synth_preview_visual.h"
#include <limits.h>
#include <math.h>
#include <stddef.h>
#define VISUAL_INITIALIZED UINT32_C(0x50565331)
#define READER_INITIALIZED UINT32_C(0x50565231)
#define DIRTY UINT32_C(4)
_Static_assert(sizeof(SpPreviewVisualSnapshot)==SP_PREVIEW_VISUAL_BYTES,"P6 visual snapshot ABI2");
_Static_assert(offsetof(SpPreviewVisualSnapshot,applied_preset)==30 &&
    offsetof(SpPreviewVisualSnapshot,applied_mono)==31 &&
    offsetof(SpPreviewVisualSnapshot,minimum)==32 &&
    offsetof(SpPreviewVisualSnapshot,envelope_stage)==224 &&
    offsetof(SpPreviewVisualSnapshot,envelope_progress)==228,"P6 retained prefix and extension offsets");
_Static_assert(sizeof(SpPreviewVisualReader)==16,"Visual reader ABI");
_Static_assert(ATOMIC_INT_LOCK_FREE==2,"Nonblocking visual middle exchange");
static int overlaps(uintptr_t a,size_t n,uintptr_t b,size_t m) {
    return a>UINTPTR_MAX-n || b>UINTPTR_MAX-m || (a<b+m && b<a+n);
}
static void blank(SpPreviewVisualSnapshot *s) {
    unsigned char *p=(void *)s;for(size_t i=0;i<sizeof(*s);++i)p[i]=0;
    s->active_pad=16;s->flags=SP_VISUAL_SILENT;
}
static int8_t quantize_min(int value) {
    int scaled=value*127;
    return (int8_t)(scaled>=0?scaled/SP_PREVIEW_VISUAL_PEAK:
        -((-scaled+SP_PREVIEW_VISUAL_PEAK-1)/SP_PREVIEW_VISUAL_PEAK));
}
static int8_t quantize_max(int value) {
    int scaled=value*127;
    return (int8_t)(scaled>=0?(scaled+SP_PREVIEW_VISUAL_PEAK-1)/SP_PREVIEW_VISUAL_PEAK:
        -((-scaled)/SP_PREVIEW_VISUAL_PEAK));
}
void sp_preview_visual_init(SpPreviewVisualState *s,uint32_t rate) {
    s->rate=rate;s->cadence_frames=(rate+29u)/30u;
    s->back_index=0;s->samples_per_column=1;s->hint_samples_per_column=1;
    for(unsigned i=0;i<3;++i)blank(&s->buffers[i]);
    atomic_init(&s->middle,2);s->initialized=VISUAL_INITIALIZED;
    s->pending=1;sp_preview_visual_commit(s);
}
void sp_preview_visual_hint(SpPreviewVisualState *s,float increment) {
    unsigned bin=1;
    if(isfinite(increment) && increment>0.0f) {
        float width=1.0f/(48.0f*increment);
        if(width>=128.0f)bin=128;
        else if(width>1.0f){bin=(unsigned)width;if((float)bin<width)++bin;}
    }
    s->hint_samples_per_column=(uint16_t)bin;
}
void sp_preview_visual_reset_capture(SpPreviewVisualState *s) {
    s->pending=0;s->capturing=0;s->column=0;s->samples_in_column=0;
    s->wait_frames=0;s->quiet_frames=0;s->trigger_armed=0;
    s->window_samples=0;s->window_peak=0;s->window_clipped=0;
}
static void begin(SpPreviewVisualState *s,unsigned flags) {
    s->capturing=1;s->column=0;s->samples_in_column=0;s->window_samples=0;
    s->window_peak=0;s->window_clipped=0;s->window_flags=(uint8_t)flags;
    s->samples_per_column=s->hint_samples_per_column;
    s->bin_minimum=INT16_MAX;s->bin_maximum=INT16_MIN;
}
int sp_preview_visual_capture(SpPreviewVisualState *s,int16_t sample,int clipped,uint32_t command_ticket) {
    ++s->frame_sequence;if(s->elapsed<UINT32_MAX)++s->elapsed;
    if(s->pending)return 0;
    s->last_clear_reason=0;
    unsigned magnitude=(unsigned)(sample<0?-(int)sample:sample);
    if(magnitude<=1){if(s->quiet_frames<UINT32_MAX)++s->quiet_frames;}else s->quiet_frames=0;
    if(s->quiet_frames>=s->cadence_frames && s->elapsed>=s->cadence_frames) {
        SpPreviewVisualSnapshot *out=&s->buffers[s->back_index];blank(out);
        out->frame_sequence=s->frame_sequence;out->command_ticket=command_ticket;out->flags|=SP_VISUAL_FALLBACK;
        s->pending=1;s->capturing=0;return 1;
    }
    if(!s->capturing) {
        if(s->wait_frames<UINT32_MAX)++s->wait_frames;
        if(sample<=-32)s->trigger_armed=1;
        if(s->trigger_armed && sample>=32)begin(s,SP_VISUAL_TRIGGERED);
        else if(s->wait_frames>=s->cadence_frames)begin(s,SP_VISUAL_FALLBACK);
        else return 0;
        s->window_command_ticket=command_ticket;
    }
    if(command_ticket!=s->window_command_ticket)s->window_flags|=SP_VISUAL_MIXED;
    if(sample<s->bin_minimum)s->bin_minimum=sample;
    if(sample>s->bin_maximum)s->bin_maximum=sample;
    if(magnitude>s->window_peak)s->window_peak=magnitude;
    if(clipped && s->window_clipped<UINT16_MAX)++s->window_clipped;
    ++s->window_samples;
    if(++s->samples_in_column<s->samples_per_column)return 0;
    SpPreviewVisualSnapshot *out=&s->buffers[s->back_index];
    out->minimum[s->column]=quantize_min(s->bin_minimum);
    out->maximum[s->column]=quantize_max(s->bin_maximum);
    s->samples_in_column=0;s->bin_minimum=INT16_MAX;s->bin_maximum=INT16_MIN;
    if(++s->column<SP_PREVIEW_VISUAL_COLUMNS)return 0;
    s->capturing=0;s->wait_frames=0;s->trigger_armed=0;
    if(s->elapsed<s->cadence_frames)return 0;
    out->frame_sequence=s->frame_sequence;out->span_frames=(uint16_t)s->window_samples;
    out->command_ticket=s->window_command_ticket;
    out->peak_i16=(uint16_t)s->window_peak;out->clipped_samples=(uint16_t)s->window_clipped;
    out->flags=s->window_flags;if(s->window_peak<=1)out->flags|=SP_VISUAL_SILENT;
    s->pending=1;return 1;
}
SpPreviewVisualSnapshot *sp_preview_visual_pending(SpPreviewVisualState *s) {
    return s->pending?&s->buffers[s->back_index]:0;
}
void sp_preview_visual_commit(SpPreviewVisualState *s) {
    if(!s->pending)return;
    s->buffers[s->back_index].sequence=s->sequence+1u;
    uint32_t old=atomic_load_explicit(&s->middle,memory_order_acquire);
    if(!atomic_compare_exchange_weak_explicit(&s->middle,&old,s->back_index|DIRTY,
        memory_order_acq_rel,memory_order_acquire))return;
    ++s->sequence;s->back_index=old&3u;s->pending=0;s->elapsed=0;
}
int sp_preview_visual_clear_prepare(SpPreviewVisualState *s,uint32_t frame_end,int terminal) {
    uint32_t reason=terminal?2u:1u;
    s->frame_sequence=frame_end;
    if(s->last_clear_reason==reason)return 0;
    sp_preview_visual_reset_capture(s);s->last_clear_reason=reason;
    SpPreviewVisualSnapshot *out=&s->buffers[s->back_index];blank(out);
    out->frame_sequence=frame_end;if(terminal)out->flags|=SP_VISUAL_TERMINAL;
    s->pending=1;return 1;
}
int sp_synth_preview_visual_reader_init(SpPreviewVisualReader *r) {
    if(!r || (uintptr_t)r%_Alignof(SpPreviewVisualReader))return 0;
    const unsigned char *p=(const void *)r;
    for(size_t i=0;i<sizeof(*r);++i)if(p[i])return 0;
    r->initialized=READER_INITIALIZED;r->front_index=1;return 1;
}
SpPreviewVisualResult sp_preview_visual_read(const SpPreviewVisualState *s,
    SpPreviewVisualReader *r,SpPreviewVisualSnapshot *out) {
    if(!s || !r || !out || (uintptr_t)s%_Alignof(SpPreviewVisualState) ||
       (uintptr_t)r%_Alignof(SpPreviewVisualReader) || (uintptr_t)out%_Alignof(SpPreviewVisualSnapshot) ||
       s->initialized!=VISUAL_INITIALIZED || r->initialized!=READER_INITIALIZED || r->front_index>=3 ||
       overlaps((uintptr_t)out,sizeof(*out),(uintptr_t)s,sizeof(*s)) ||
       overlaps((uintptr_t)out,sizeof(*out),(uintptr_t)r,sizeof(*r)) ||
       overlaps((uintptr_t)r,sizeof(*r),(uintptr_t)s,sizeof(*s)))return SP_VISUAL_INVALID;
    uint32_t middle=atomic_load_explicit(&s->middle,memory_order_acquire);
    if((middle&3u)>=3 || (middle&~7u))return SP_VISUAL_INVALID;
    SpPreviewVisualResult result=SP_VISUAL_CACHED;
    if(middle&DIRTY) {
        if(atomic_compare_exchange_weak_explicit((_Atomic uint32_t *)&s->middle,&middle,r->front_index,
            memory_order_acq_rel,memory_order_acquire)) {
            r->front_index=middle&3u;r->has_snapshot=1;result=SP_VISUAL_NEW;
        }
    }
    const unsigned char *src=(const void *)&s->buffers[r->front_index];unsigned char *dst=(void *)out;
    for(size_t i=0;i<sizeof(*out);++i)dst[i]=src[i];
    r->sequence=out->sequence;return result;
}
