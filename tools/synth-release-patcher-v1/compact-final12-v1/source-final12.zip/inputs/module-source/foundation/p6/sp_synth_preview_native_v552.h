#ifndef SP_SYNTH_PREVIEW_NATIVE_V552_H
#define SP_SYNTH_PREVIEW_NATIVE_V552_H
#include "sp_synth_preview_voice.h"
#include "sp_p4_controls.h"
#include "sp_synth_entry_owner_v552_live.h"
#include "sp_synth_generator_route_v552.h"
#include "sp_synth_stock_adapter.h"

enum {
    SP_PREVIEW_NATIVE_PREPARED=0, SP_PREVIEW_NATIVE_HOLD,
    SP_PREVIEW_NATIVE_CHOOSER, SP_PREVIEW_NATIVE_WAIT_ROUTE,
    SP_PREVIEW_NATIVE_WAIT_AUDIO, SP_PREVIEW_NATIVE_ACTIVE,
    SP_PREVIEW_NATIVE_STOPPING, SP_PREVIEW_NATIVE_WAIT_NATIVE,
    SP_PREVIEW_NATIVE_GENERATOR, SP_PREVIEW_NATIVE_LEFT, SP_PREVIEW_NATIVE_FAULT
};
enum { SP_PREVIEW_CHOICE_SYNTH=0, SP_PREVIEW_CHOICE_GENERATOR=1 };
enum { SP_PREVIEW_SELECT_SYNTH=1, SP_PREVIEW_SELECT_GENERATOR,
       SP_PREVIEW_CONFIRM, SP_PREVIEW_EXIT, SP_PREVIEW_PANIC };
enum { SP_PREVIEW_NATIVE_CONFIG=1u, SP_PREVIEW_NATIVE_CONTEXT=2u,
       SP_PREVIEW_NATIVE_ENTRY=4u, SP_PREVIEW_NATIVE_ROUTE=8u,
       SP_PREVIEW_NATIVE_AUDIO=16u, SP_PREVIEW_NATIVE_LIFETIME=32u, SP_PREVIEW_NATIVE_DISPLAY=64u };
enum { SP_PREVIEW_NATIVE_QUALIFIED=31u };

/* Experimental pad-test policy, not a hardware qualification mask.
 * Numeric rate, pair, task and lease are explicit unmeasured assumptions.
 * P6R adds ordered normal quiesce. Terminal stop and bounds stay latched. */
typedef struct {
    uint32_t trial_policy,sample_rate,pair_index,audio_task,control_lease_frames;
} SpPreviewNativeConfigV552;
/* A copy made only by the selected serialized control task. No audio-owned
 * DSP fields are inspected. ACTIVE requires both route and permission receipts.
 * GENERATOR requires a matching NATIVE-route receipt before restoring tables. */
typedef struct {
    uint32_t state,fault,choice,held_pads,route_ticket,route_ack;
    uint32_t permission_ticket,permission_ack,stop_ack;
    SpP4ControlView controls;
} SpPreviewNativeView;
typedef struct {
    SpSynthGeneratorRouteV552 generator;
    SpSynthPreviewVoice voice;
    SpP4Controls controls;
    SpSynthStockScratch scratch;
    SpSynthEntryOwnerV552 entry;
    uint32_t primary[88],secondary[7];
    SpPreviewNativeConfigV552 config;
    _Atomic uint32_t ready,terminal,phase;
    uint32_t initialized,attempted,task_id,choice,command,route_ticket;
    uint32_t permission_ticket,stop_action,voice_used,exit_requested,normal_stop_ticket;
    _Atomic(void *) active_page;
    _Atomic(void *) retired_page;
} SpPreviewNativeV552;

extern SpPreviewNativeV552 sp_synth_preview_native_v552;
extern const SpPreviewNativeConfigV552 *const sp_synth_preview_native_v552_config;
uint64_t sp_synth_preview_native_v552_pool(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_preview_native_v552_panel_init(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_preview_native_v552_factory(const uint16_t *);
void sp_synth_preview_native_v552_service(void *panel);
void sp_synth_preview_native_v552_before_control(void *panel,uint32_t);
uint32_t sp_synth_preview_native_v552_audio(void *,int32_t *,int32_t,int32_t);
uint32_t sp_synth_preview_native_v552_audio_thunk(void);
uint32_t sp_synth_preview_native_v552_wait(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_preview_native_v552_control(uint32_t,uint32_t,uint32_t,uint32_t);
void sp_synth_preview_native_v552_cancel(void);
uint32_t sp_synth_preview_native_v552_shutdown_initialize(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_synth_preview_native_v552_shutdown_callback(uint32_t,uint32_t,uint32_t,uint32_t);
/* Control-only intent. Refuses a second outstanding command or an invalid state.
 * No render hook needs to issue side effects. Service performs route changes
 * outside the native dispatch/sample frame and waits for actual audio receipts. */
int sp_synth_preview_native_v552_select(void *panel,uint32_t command);
int sp_synth_preview_native_v552_snapshot(void *panel,SpPreviewNativeView *out);
/* Root UI supplies strong definitions. present runs after the original native
 * tick; detach precedes native destruction or table restoration. */
int sp_synth_preview_native_v552_present(void *page,const SpPreviewNativeView *);
void sp_synth_preview_native_v552_detach(void *page);
/* Selected control owner forgets handles after foreign native destruction.
 * It must not dereference/free the retired page or native children. */
void sp_synth_preview_native_v552_retire(void *page);
#endif
