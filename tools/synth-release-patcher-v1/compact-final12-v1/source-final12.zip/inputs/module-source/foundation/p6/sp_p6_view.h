#ifndef SP_P6_VIEW_H
#define SP_P6_VIEW_H
#include "sp_synth_preview_native_v552.h"
#include "sp_synth_preview_visual.h"
#include "sp_p6_menu.h"
#include <stdint.h>
/* Pure row-major MSB-first rasterizer. Invalid inputs leave all 1024 bytes
 * untouched. NULL telemetry means WAIT; menu must be a UI-owned copy. */
int sp_p6_view_render(const SpPreviewNativeView *,const SpPreviewVisualSnapshot *,
                      const SpP6MenuView *,uint8_t frame[1024]);
#endif
