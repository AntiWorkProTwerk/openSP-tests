#include "sp_synth_preview_view_v552.h"
#include "sp_synth_preview_native_v552.h"
#include <stddef.h>
#include <string.h>

static void copy(char *out, size_t capacity, const char *text) {
    size_t i = 0;
    while (i + 1 < capacity && text[i]) { out[i] = text[i]; ++i; }
    out[i] = 0;
}

int sp_synth_preview_view_v552_build(uint32_t state, uint32_t choice,
                                    uint32_t fault, sp_ui_view *out) {
    if (!out) return 0;
    memset(out, 0, sizeof(*out));
    if (state == SP_PREVIEW_NATIVE_PREPARED ||
        state == SP_PREVIEW_NATIVE_GENERATOR || state == SP_PREVIEW_NATIVE_LEFT)
        return 0;
    copy(out->header, sizeof(out->header), "SYNTH P6 TEST");
    copy(out->footer, sizeof(out->footer), "NOTES PAUSED");
    out->row_count = 2;
    switch (state) {
    case SP_PREVIEW_NATIVE_CHOOSER:
        copy(out->header, sizeof(out->header), "SOUND GENERATOR");
        copy(out->rows[0], sizeof(out->rows[0]), "SYNTH P6");
        copy(out->rows[1], sizeof(out->rows[1]), "ORIGINAL GENERATOR");
        copy(out->footer, sizeof(out->footer), "VALUE:CHOOSE / PRESS");
        out->row_selection = 1;
        out->selected = choice == SP_PREVIEW_CHOICE_GENERATOR ? 1 : 0;
        break;
    case SP_PREVIEW_NATIVE_HOLD:
        copy(out->hero, sizeof(out->hero), "TAP SHIFT");
        copy(out->rows[0], sizeof(out->rows[0]), "RELEASE, THEN PRESS");
        copy(out->rows[1], sizeof(out->rows[1]), "NOTES PAUSED");
        copy(out->footer, sizeof(out->footer), "EXIT:SAMPLER");
        break;
    case SP_PREVIEW_NATIVE_WAIT_ROUTE:
    case SP_PREVIEW_NATIVE_WAIT_AUDIO:
        copy(out->hero, sizeof(out->hero), "STARTING SYNTH");
        copy(out->rows[0], sizeof(out->rows[0]), "PLEASE WAIT");
        copy(out->rows[1], sizeof(out->rows[1]), "NOTES PAUSED");
        copy(out->footer, sizeof(out->footer), "EXIT:SAMPLER");
        out->busy = 1;
        break;
    case SP_PREVIEW_NATIVE_ACTIVE:
        copy(out->hero, sizeof(out->hero), "SINE / MONO");
        copy(out->rows[0], sizeof(out->rows[0]), "PAD 1-16: C3-D#4");
        copy(out->rows[1], sizeof(out->rows[1]), "ONE VOICE");
        copy(out->footer, sizeof(out->footer), "PADS:PLAY EXIT:BACK");
        break;
    case SP_PREVIEW_NATIVE_STOPPING:
        copy(out->hero, sizeof(out->hero), "STOPPING VOICE");
        copy(out->rows[0], sizeof(out->rows[0]), "PLEASE WAIT");
        out->busy = 1;
        break;
    case SP_PREVIEW_NATIVE_WAIT_NATIVE:
        copy(out->hero, sizeof(out->hero), "RETURNING...");
        copy(out->rows[0], sizeof(out->rows[0]), "PLEASE WAIT");
        copy(out->rows[1], sizeof(out->rows[1]), "NOTES PAUSED");
        out->busy = 1;
        break;
    case SP_PREVIEW_NATIVE_FAULT: {
        static const char hex[] = "0123456789ABCDEF";
        copy(out->hero, sizeof(out->hero), "SYNTH STOPPED");
        copy(out->rows[0], sizeof(out->rows[0]), "NOTES PAUSED");
        copy(out->rows[1], sizeof(out->rows[1]), "ERROR 00000000");
        for (unsigned i = 0; i < 8; ++i)
            out->rows[1][6 + i] = hex[(fault >> ((7 - i) * 4)) & 15u];
        copy(out->footer, sizeof(out->footer), "EXIT:RETURN");
        break;
    }
    default:
        copy(out->hero, sizeof(out->hero), "SYNTH STOPPED");
        copy(out->rows[0], sizeof(out->rows[0]), "UNKNOWN STATE");
        copy(out->rows[1], sizeof(out->rows[1]), "NOTES PAUSED");
        break;
    }
    return 1;
}
