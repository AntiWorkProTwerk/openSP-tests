#ifndef SP_P6_MENU_H
#define SP_P6_MENU_H
#include "sp_p4_controls.h"
#include <stdint.h>
enum { SP_P6_PLAY=0, SP_P6_MENU, SP_P6_SOUND, SP_P6_VOICE,
       SP_P6_RECORD, SP_P6_DEMO };
/* Serialized UI owner only. The renderer receives a complete copied view.
 * Selection is intent; controls and PCM receipts establish requested/applied. */
typedef struct {
    uint32_t page,selection,preset,mono,demo_status;
} SpP6MenuView;
typedef struct { SpP6MenuView view; } SpP6Menu;
extern SpP6Menu sp_p6_menu;
void sp_p6_menu_init(void);
int sp_p6_menu_snapshot(SpP6MenuView *);
int sp_p6_menu_press(SpP4Controls *,SpSynthPreviewVoice *,int shift);
int sp_p6_menu_turn(SpP4Controls *,SpSynthPreviewVoice *,int32_t delta,int shift);
/* Returns one when consumed. PLAY returns zero for the native sampler exit. */
int sp_p6_menu_exit(void);
#endif
