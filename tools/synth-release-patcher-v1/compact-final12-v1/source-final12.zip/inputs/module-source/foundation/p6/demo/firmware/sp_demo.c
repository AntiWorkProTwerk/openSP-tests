#include "sp_demo.h"
#include <limits.h>
#include <string.h>

#define DIRTY 4u
#define FAIR_EVENTS 1u
#define FAIR_FRAME 2u
#define FAIR_CLOCK 4u
static void u16(uint8_t *p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
static void u32(uint8_t *p,uint32_t v){for(unsigned i=0;i<4;++i)p[i]=(uint8_t)(v>>(8*i));}
static void u64(uint8_t *p,uint64_t v){u32(p,(uint32_t)v);u32(p+4,(uint32_t)(v>>32));}
uint32_t sp_demo_crc32(const uint8_t *p,uint32_t n){
    uint32_t crc=UINT32_MAX;
    for(uint32_t i=0;i<n;++i){crc^=p[i];for(unsigned b=0;b<8;++b)crc=(crc>>1)^(0xEDB88320u & (0u-(crc&1u)));}
    return ~crc;
}
static void meta_encode(uint8_t *p,const SpDemoMeta *m){
    u64(p,m->capture_ticks);u32(p+8,m->frame_sequence);u32(p+12,m->pcm_end_frame);
    u32(p+16,m->command_ticket);u32(p+20,m->command_ack);u32(p+24,m->held_pad_mask);
    u32(p+28,m->control_valid_mask);p[32]=m->preset;p[33]=m->page;
    p[34]=m->requested_mono;p[35]=m->applied_preset;p[36]=m->applied_mono;
    p[37]=m->active_voices;p[38]=m->visual_flags;p[39]=(uint8_t)m->octave;
    for(unsigned i=0;i<4;++i)u16(p+40+2*i,m->envelope[i]);
    for(unsigned i=0;i<3;++i)u16(p+48+2*i,m->ctrl[i]);
    p[54]=m->value_down;p[55]=m->shift;u32(p+56,(uint32_t)m->value_total);
    u32(p+60,m->state_revision);
    for(unsigned i=0;i<4;++i){p[64+i]=m->envelope_stage[i];p[68+i]=m->envelope_progress[i];}
}
static void event_encode(uint8_t *p,const SpDemoEvent *e){
    u32(p,e->sequence);u64(p+4,e->ticks);u16(p+12,e->control);
    p[14]=e->kind;p[15]=e->flags;u32(p+16,(uint32_t)e->value);u32(p+20,e->aux);
}
void sp_demo_init(SpDemo *d,uint32_t hz){
    memset(d,0,sizeof(*d));atomic_init(&d->initialized,0);d->clock_hz=hz;
    d->frame_back=d->state_back=0;d->frame_front=d->state_front=2;
    atomic_init(&d->frame_middle,1);atomic_init(&d->state_middle,1);
    atomic_init(&d->event_read,0);atomic_init(&d->event_write,0);
    atomic_init(&d->enabled,0);atomic_init(&d->connected,0);atomic_init(&d->dropped_frames,0);
    atomic_init(&d->dropped_events,0);atomic_init(&d->event_sequence,0);
    atomic_store_explicit(&d->initialized,1,memory_order_release);
}
void sp_demo_enable(SpDemo *d,int enable){if(d && d->initialized)atomic_store_explicit(&d->enabled,!!enable,memory_order_release);}
static void publish(atomic_uint *middle,unsigned *back){
    unsigned old=atomic_exchange_explicit(middle,*back|DIRTY,memory_order_acq_rel);
    *back=old&3u;
}
static int acquire(atomic_uint *middle,unsigned *front){
    unsigned old=atomic_load_explicit(middle,memory_order_acquire);
    if(!(old&DIRTY))return 0;
    if(!atomic_compare_exchange_strong_explicit(middle,&old,*front,memory_order_acq_rel,memory_order_acquire))return 0;
    *front=old&3u;return 1;
}
static void physical_into(SpDemo *d,SpDemoMeta *out,const SpDemoMeta *in,uint64_t ticks){
    *out=*in;out->capture_ticks=ticks;out->held_pad_mask=d->physical.held_pad_mask;
    out->control_valid_mask=d->physical.control_valid_mask;
    for(unsigned i=0;i<3;++i)out->ctrl[i]=d->physical.ctrl[i];
    out->value_down=d->physical.value_down;out->shift=d->physical.shift;
    out->value_total=d->physical.value_total;out->state_revision=d->physical.state_revision;
}
void sp_demo_publish_state(SpDemo *d,uint64_t ticks,const SpDemoMeta *m){
    if(!d || !d->initialized || !m)return;
    physical_into(d,&d->states[d->state_back],m,ticks);
    d->physical=d->states[d->state_back];
    publish(&d->state_middle,&d->state_back);
}
int sp_demo_capture(SpDemo *d,uint64_t ticks,const uint8_t bitmap[1024],const SpDemoMeta *m){
    if(!d || !d->initialized || !bitmap || !m)return 0;
    sp_demo_publish_state(d,ticks,m);
    if(!atomic_load_explicit(&d->enabled,memory_order_acquire))return 0;
    SpDemoFrame *f=&d->frames[d->frame_back];physical_into(d,&f->meta,m,ticks);
    memcpy(f->bitmap,bitmap,1024);
    unsigned old=atomic_exchange_explicit(&d->frame_middle,d->frame_back|DIRTY,memory_order_acq_rel);
    d->frame_back=old&3u;
    if(old&DIRTY)atomic_fetch_add_explicit(&d->dropped_frames,1,memory_order_relaxed);
    return 1;
}
void sp_demo_event(SpDemo *d,uint64_t ticks,uint16_t control,uint8_t kind,int32_t value,uint32_t aux){
    if(!d || !d->initialized || control<1 || control>22 || kind<1 || kind>4)return;
    if((control<=16 || control==21 || control==22) && kind!=SP_DEMO_DOWN && kind!=SP_DEMO_UP)return;
    if(control>=17 && control<=19 && (kind!=SP_DEMO_ABSOLUTE || value<0 || value>127))return;
    if(control==20 && kind!=SP_DEMO_RELATIVE)return;
    d->physical.control_valid_mask|=1u<<(control-1u);
    if(control<=16){uint32_t bit=1u<<(control-1u);if(kind==1)d->physical.held_pad_mask|=bit;else d->physical.held_pad_mask&=~bit;}
    else if(control<=19)d->physical.ctrl[control-17u]=(uint16_t)value;
    else if(control==20){
        int64_t sum=(int64_t)d->physical.value_total+value;
        d->physical.value_total=sum>INT32_MAX?INT32_MAX:sum<INT32_MIN?INT32_MIN:(int32_t)sum;
    }else if(control==21)d->physical.value_down=(uint8_t)(kind==1);
    else d->physical.shift=(uint8_t)(kind==1);
    ++d->physical.state_revision;
    sp_demo_publish_state(d,ticks,&d->physical);
    if(!atomic_load_explicit(&d->enabled,memory_order_acquire))return;
    uint32_t seq=atomic_load_explicit(&d->event_sequence,memory_order_relaxed);
    if(seq==UINT32_MAX){atomic_fetch_add_explicit(&d->dropped_events,1,memory_order_relaxed);return;}
    atomic_store_explicit(&d->event_sequence,seq+1u,memory_order_relaxed);
    unsigned w=atomic_load_explicit(&d->event_write,memory_order_relaxed);
    unsigned r=atomic_load_explicit(&d->event_read,memory_order_acquire);
    if(w-r>=SP_DEMO_EVENT_CAPACITY){atomic_fetch_add_explicit(&d->dropped_events,1,memory_order_relaxed);return;}
    d->events[w&(SP_DEMO_EVENT_CAPACITY-1u)]=(SpDemoEvent){seq+1u,ticks,control,kind,0,value,aux};
    atomic_store_explicit(&d->event_write,w+1u,memory_order_release);
}
static int finish(SpDemo *d,uint8_t kind,unsigned n,uint64_t ticks){
    if(d->sequence==UINT32_MAX){d->exhausted=1;d->connected=0;return 0;}
    uint8_t *p=d->tx;p[0]='S';p[1]='P';p[2]='T';p[3]='6';p[4]=1;p[5]=kind;
    u16(p+6,0);u16(p+8,(uint16_t)n);u16(p+10,32);u32(p+12,d->session);
    u32(p+16,d->sequence+1u);u64(p+20,ticks);u32(p+28,d->clock_hz);
    u32(p+32+n,sp_demo_crc32(p,32+n));d->tx_size=36+n;d->pending_kind=kind;return 1;
}
int sp_demo_next(SpDemo *d,int ready,uint64_t ticks,const uint8_t **data,uint32_t *size){
    if(!d || !d->initialized || !data || !size)return 0;
    ready=ready && atomic_load_explicit(&d->enabled,memory_order_acquire) && !d->exhausted;
    if(!ready){d->connected=0;d->tx_size=0;d->pending_kind=0;return 0;}
    if(!d->connected){
        if(d->session==UINT32_MAX){d->exhausted=1;return 0;}
        if(d->session)++d->reconnects;
        ++d->session;d->connected=1;d->sequence=0;d->hello=1;
        d->gap=d->reconnects?SP_DEMO_GAP_RECONNECT:0;d->state_due=1;d->frame_due=1;
        d->clock_due=1;d->tx_size=0;d->pending_kind=0;
        d->fair_remaining=0;d->wake_count=0;
        atomic_store_explicit(&d->event_read,atomic_load_explicit(&d->event_write,memory_order_acquire),memory_order_release);
    }
    if(d->tx_size){*data=d->tx;*size=d->tx_size;return 1;}
    /* Count fresh scheduling opportunities even while data is busy. Pending
     * rejected bytes return above and remain immutable until accepted. */
    if(d->wake_count<30)++d->wake_count;
    if(d->wake_count>=30)d->clock_due=1;
    (void)acquire(&d->state_middle,&d->state_front);
    unsigned old_front=d->frame_front;
    if(acquire(&d->frame_middle,&d->frame_front)){
        if(d->frame_due && d->frames[old_front].meta.frame_sequence)
            atomic_fetch_add_explicit(&d->dropped_frames,1,memory_order_relaxed);
        d->frame_due=1;
    }
    uint32_t df=atomic_load_explicit(&d->dropped_frames,memory_order_relaxed);
    uint32_t de=atomic_load_explicit(&d->dropped_events,memory_order_relaxed);
    if(df!=d->reported_frames)d->gap|=SP_DEMO_GAP_FRAMES;
    if(de!=d->reported_events){d->gap|=SP_DEMO_GAP_EVENTS;if(!d->state_due)d->state_due=1;}
    unsigned r=atomic_load_explicit(&d->event_read,memory_order_relaxed);
    unsigned w=atomic_load_explicit(&d->event_write,memory_order_acquire);
    unsigned count=w-r;if(count>16)count=16;
    const int frame=d->frame_due && d->frames[d->frame_front].meta.frame_sequence;
    uint8_t *p=d->tx+32;unsigned n=0,kind=0;
    /* A GAP resynchronizes with STATE before any other record. Each accepted
     * STATE then reserves bounded data turns, even if another gap accumulated
     * while it was sent. Skip credits for data absent at this opportunity. */
    if(!d->hello && d->state_due!=2 && d->fair_remaining){
        if((d->fair_remaining&FAIR_EVENTS) && !count)d->fair_remaining&=~FAIR_EVENTS;
        if((d->fair_remaining&FAIR_FRAME) && !frame)d->fair_remaining&=~FAIR_FRAME;
        if((d->fair_remaining&FAIR_CLOCK) && !d->clock_due)d->fair_remaining&=~FAIR_CLOCK;
        if(d->fair_remaining&FAIR_EVENTS)kind=SP_DEMO_EVENTS;
        else if(d->fair_remaining&FAIR_FRAME)kind=SP_DEMO_FRAME;
        else if(d->fair_remaining&FAIR_CLOCK)kind=SP_DEMO_CLOCK;
    }
    if(d->hello){kind=1;n=32;memset(p,0,n);u32(p,7);u32(p+4,1);u32(p+8,d->clock_hz);
        u32(p+12,SP_DEMO_MAX_RECORD);u32(p+16,64);u32(p+20,d->reconnects);u32(p+24,0x50364431u);
    }else{
        if(d->state_due==2)kind=SP_DEMO_STATE;
        else if(!kind){
            if(d->gap)kind=SP_DEMO_GAP;
            else if(d->state_due)kind=SP_DEMO_STATE;
            else if(d->clock_due)kind=SP_DEMO_CLOCK;
            else if(count)kind=SP_DEMO_EVENTS;
            else if(frame)kind=SP_DEMO_FRAME;
        }
    }
    if(kind==SP_DEMO_GAP){n=16;u32(p,df);u32(p+4,de);u32(p+8,d->reconnects);u32(p+12,d->gap);
        d->pending_frame_drops=df;d->pending_event_drops=de;
    }else if(kind==SP_DEMO_STATE){n=SP_DEMO_META_BYTES;meta_encode(p,&d->states[d->state_front]);
    }else if(kind==SP_DEMO_EVENTS){n=16+24*count;u32(p,count);u32(p+4,de);
            u32(p+8,atomic_load_explicit(&d->event_sequence,memory_order_relaxed));
            u32(p+12,d->states[d->state_front].state_revision);
            for(unsigned i=0;i<count;++i)event_encode(p+16+24*i,&d->events[(r+i)&63u]);
            d->pending_events=count;
    }else if(kind==SP_DEMO_FRAME){n=SP_DEMO_MAX_PAYLOAD;meta_encode(p,&d->frames[d->frame_front].meta);
            memcpy(p+SP_DEMO_META_BYTES,d->frames[d->frame_front].bitmap,1024);
    }else if(kind==SP_DEMO_CLOCK){n=24;u64(p,d->states[d->state_front].capture_ticks);u64(p+8,ticks);
            u32(p+16,d->states[d->state_front].pcm_end_frame);u32(p+20,0);
    }
    if(!kind || !finish(d,(uint8_t)kind,n,ticks))return 0;
    *data=d->tx;*size=d->tx_size;return 1;
}
void sp_demo_accepted(SpDemo *d){
    if(!d || !d->tx_size)return;
    ++d->sequence;
    switch(d->pending_kind){
        case 1:d->hello=0;break;
        case 2:d->frame_due=0;d->fair_remaining&=~FAIR_FRAME;break;
        case 3:atomic_fetch_add_explicit(&d->event_read,d->pending_events,memory_order_release);d->fair_remaining&=~FAIR_EVENTS;break;
        case 4:d->state_due=0;d->last_state_revision=d->states[d->state_front].state_revision;
            d->fair_remaining=FAIR_EVENTS|FAIR_FRAME|FAIR_CLOCK;break;
        case 5:d->clock_due=0;d->wake_count=0;d->state_due=1;d->fair_remaining&=~FAIR_CLOCK;break;
        case 6:d->reported_frames=d->pending_frame_drops;d->reported_events=d->pending_event_drops;d->gap=0;d->state_due=2;break;
        default:break;
    }
    d->tx_size=0;d->pending_kind=0;
}
uint32_t sp_demo_status(const SpDemo *d){
    if(!d || !d->initialized || !atomic_load_explicit(&d->enabled,memory_order_acquire))return 0;
    return d->connected?2u:1u;
}
