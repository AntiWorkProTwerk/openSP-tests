#include "sp_p6_menu.h"
#include "sp_demo_v552.h"
#include <stddef.h>

SpP6Menu sp_p6_menu;
void sp_p6_menu_init(void) {sp_p6_menu.view=(SpP6MenuView){0};}
int sp_p6_menu_snapshot(SpP6MenuView *out) {
    if(!out)return 0;
    *out=sp_p6_menu.view;out->demo_status=sp_demo_v552_status();return 1;
}
static int valid(const SpP4Controls *s,const SpSynthPreviewVoice *voice,int shift) {
    return s && s->initialized==1 && voice && (shift==0 || shift==1) &&
        s->view.page<SP_P4_PAGES && s->view.preset<SP_PREVIEW_PRESETS && s->view.mono<=1;
}
static int load(SpP4Controls *s,SpSynthPreviewVoice *voice,unsigned preset) {
    if(s->view.preset==preset)return 1;
    if(!sp_synth_preview_voice_preset(voice,preset))return 0;
    /* One queued program, then one shadow update. This preserves the P4 knob
     * binding behavior without queuing each intervening program. */
    SpP4ControlView *v=&s->view;
    v->preset=preset;v->modified=0;
    v->mono=sp_synth_preview_preset_mono(preset);
    v->octave=sp_synth_preview_preset_octave(preset);
    for(unsigned i=0;i<SP_PREVIEW_PARAMETERS;++i)v->values[i]=sp_synth_preview_preset_value(preset,i);
    v->pickup_mask=0;v->baseline_mask=7u&~v->known_mask;
    for(unsigned k=0;k<SP_P4_KNOBS;++k){
        s->anchor_knobs[k]=v->knobs[k];s->anchor_values[k]=v->values[v->page*3+k];
    }
    return 1;
}
int sp_p6_menu_press(SpP4Controls *s,SpSynthPreviewVoice *voice,int shift) {
    if(!valid(s,voice,shift))return 0;
    SpP6MenuView *m=&sp_p6_menu.view;
    if(shift){m->page=m->page==SP_P6_PLAY?SP_P6_MENU:SP_P6_PLAY;m->selection=0;return 1;}
    switch(m->page){
    case SP_P6_PLAY:return sp_p4_controls_press(s,voice,0);
    case SP_P6_MENU:
        if(m->selection>3)return 0;
        m->page=SP_P6_SOUND+m->selection;
        m->preset=s->view.preset;m->mono=s->view.mono;
        /* Entering the explicit USB DEMO view opts into read-only export. */
        if(m->page==SP_P6_DEMO)sp_demo_v552_enable(1);
        return 1;
    case SP_P6_SOUND:return m->preset<SP_PREVIEW_PRESETS?load(s,voice,m->preset):0;
    case SP_P6_VOICE:return m->mono<=1?sp_p4_controls_mode(s,voice,(int)m->mono):0;
    case SP_P6_RECORD:return 1; /* No production capture/save ownership yet. */
    case SP_P6_DEMO:sp_demo_v552_enable(sp_demo_v552_status()==0);return 1;
    default:return 0;
    }
}
int sp_p6_menu_turn(SpP4Controls *s,SpSynthPreviewVoice *voice,int32_t delta,int shift) {
    if(!valid(s,voice,shift) || !delta)return 0;
    SpP6MenuView *m=&sp_p6_menu.view;
    if(m->page==SP_P6_PLAY)return sp_p4_controls_turn(s,voice,delta,shift);
    uint32_t *selection;unsigned limit;
    if(m->page==SP_P6_MENU){selection=&m->selection;limit=3;}
    else if(m->page==SP_P6_SOUND){selection=&m->preset;limit=SP_PREVIEW_PRESETS-1;}
    else if(m->page==SP_P6_VOICE){selection=&m->mono;limit=1;}
    else return m->page==SP_P6_RECORD || m->page==SP_P6_DEMO;
    if(*selection>limit)return 0;
    if(delta<0){if(*selection)--*selection;}else if(*selection<limit)++*selection;
    return 1;
}
int sp_p6_menu_exit(void) {
    SpP6MenuView *m=&sp_p6_menu.view;
    if(m->page==SP_P6_PLAY)return 0;
    m->page=m->page==SP_P6_MENU?SP_P6_PLAY:SP_P6_MENU;return 1;
}
