#ifndef SP_DEMO_H
#define SP_DEMO_H
#include "../protocol/sp_demo_protocol.h"
#include <stdatomic.h>

typedef struct { SpDemoMeta meta; uint8_t bitmap[SP_DEMO_FRAME_BYTES]; } SpDemoFrame;
typedef struct {
    SpDemoFrame frames[3];
    SpDemoMeta states[3],physical;
    SpDemoEvent events[SP_DEMO_EVENT_CAPACITY];
    atomic_uint frame_middle,state_middle,event_write,event_read,enabled,connected;
    atomic_uint dropped_frames,dropped_events,event_sequence,initialized;
    unsigned frame_back,frame_front,state_back,state_front;
    uint32_t session,reconnects,sequence,clock_hz;
    uint32_t hello,gap,state_due,frame_due,clock_due;
    uint32_t reported_frames,reported_events,last_state_revision;
    uint32_t pending_kind,pending_events,pending_frame_drops,pending_event_drops;
    uint32_t wake_count,exhausted;
    /* Consumer-owned credit after resync: one event batch, newest frame and
     * due clock before another GAP/STATE cycle. No wire format change. */
    uint32_t fair_remaining;
    uint8_t tx[SP_DEMO_MAX_RECORD];
    uint32_t tx_size;
} SpDemo;

/* One serialized UI/control producer; one native CDC-task consumer. None of
 * these functions belongs in an audio callback. No heap or retry loop. */
void sp_demo_init(SpDemo *,uint32_t nominal_clock_hz);
void sp_demo_enable(SpDemo *,int);
void sp_demo_event(SpDemo *,uint64_t ticks,uint16_t control,uint8_t kind,
                   int32_t value,uint32_t auxiliary);
int sp_demo_capture(SpDemo *,uint64_t ticks,const uint8_t bitmap[1024],
                    const SpDemoMeta *);
/* UI must call publish_state after its controls/meta change even without a
 * frame, so overflow/reconnect gets the current physical state. */
void sp_demo_publish_state(SpDemo *,uint64_t ticks,const SpDemoMeta *);
/* At most one complete record. Pointer remains stable until accepted or a
 * connection transition. A rejected stock enqueue calls this again later. */
int sp_demo_next(SpDemo *,int transport_ready,uint64_t ticks,
                 const uint8_t **data,uint32_t *size);
void sp_demo_accepted(SpDemo *);
uint32_t sp_demo_crc32(const uint8_t *,uint32_t);
uint32_t sp_demo_status(const SpDemo *); /* off0/wait1/connected2 */
#endif
