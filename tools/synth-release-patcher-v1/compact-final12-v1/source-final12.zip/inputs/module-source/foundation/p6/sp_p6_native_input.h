#ifndef SP_P6_NATIVE_INPUT_H
#define SP_P6_NATIVE_INPUT_H
#include <stdint.h>
/* Actual fresh, sequenced native drain record only; no enable/disable edges. */
void sp_p6_native_input_record(const uint32_t record[3]);
#endif
