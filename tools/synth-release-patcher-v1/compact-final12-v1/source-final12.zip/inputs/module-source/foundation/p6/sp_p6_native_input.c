#include "sp_p6_native_input.h"
#include "sp_demo_v552.h"
#include "sp_synth_preview_native_v552.h"
void sp_p6_native_input_record(const uint32_t record[3]){
    SpPreviewNativeV552 *m=&sp_synth_preview_native_v552;
    if(!record || atomic_load_explicit(&m->ready,memory_order_acquire)!=1 ||
       ((uint32_t (*)(void))(uintptr_t)0x800D3163)()!=m->task_id)return;
    uint32_t kind=record[0]&65535u,id=record[0]>>16;
    if((kind==5 || kind==6) && id==42)
        sp_demo_v552_event(SP_DEMO_SHIFT,kind==5?SP_DEMO_DOWN:SP_DEMO_UP,kind==5,0);
    else if(kind==6 && id==49)
        sp_demo_v552_event(SP_DEMO_VALUE_PRESS,SP_DEMO_UP,0,0);
    else if(kind==17 && id<16 && (sp_demo_v552.physical.held_pad_mask&(1u<<id)))
        sp_demo_v552_event((uint16_t)(id+1),SP_DEMO_UP,0,m->voice.control_ids[id]);
}
