#ifndef SP_DEMO_V552_H
#define SP_DEMO_V552_H
#include "sp_demo.h"
extern SpDemo sp_demo_v552;
void sp_demo_v552_init(void); /* serialized control owner after BSS clear */
void sp_demo_v552_enable(int enabled);
void sp_demo_v552_poll(void); /* bounded wake only; service/tick, never audio */
void sp_demo_v552_event(uint16_t control,uint8_t kind,int32_t value,uint32_t aux);
void sp_demo_v552_capture(const uint8_t bitmap[1024],const SpDemoMeta *);
void sp_demo_v552_state(const SpDemoMeta *);
int sp_demo_v552_worker(void *); /* replacement8021CA74, stock call first */
uint64_t sp_demo_v552_ticks(void);
uint32_t sp_demo_v552_status(void);
#endif
