#include "sp_synth_preview_voice.h"
#include <limits.h>
#include <math.h>

_Static_assert(UINT_MAX==UINT32_MAX && ATOMIC_INT_LOCK_FREE==2,
               "Preview requires lock-free 32-bit unsigned atomics");
_Static_assert((SP_PREVIEW_QUEUE & (SP_PREVIEW_QUEUE-1))==0,"Power of two queue");
_Static_assert(sizeof(SpPreviewEvent)==8,"Event layout");
_Static_assert(sizeof(SpSynthPreviewVoice)<=4096,"P5 voice storage budget");
#define PREVIEW_INITIALIZED UINT32_C(0x50563531)
enum { ENABLE=1,DISABLE,DOWN,UP,PARAMETER,PRESET,MONO,OCTAVE,QUIESCE };
typedef struct {
    char name[14]; uint16_t values[SP_PREVIEW_PARAMETERS];
    uint8_t wave_a,wave_b,mono; int8_t octave;
    uint8_t sub,noise,sustain,filter_mode;
} Preset;
/* Cutoff/resonance/env, mix/detune/pulse, A/D/R, LFO rate/depth/glide.
 * Immutable program data; names are short enough for the physical OLED. */
static const Preset presets[SP_PREVIEW_PRESETS]={
 {"Soft Sine", {3940,0,0,0,0,2048,450,0,700,1000,0,0},0,0,0,0,0,0,255,0},
 {"Warm Triangle",{2780,320,500,1150,450,2048,620,1450,1600,1000,100,0},1,1,0,0,20,0,200,0},
 {"Round Bass", {1700,950,2400,1100,160,2048,150,800,900,600,0,0},2,1,1,-1,90,0,170,1},
 {"Acid Pulse", {1650,3050,3350,700,40,900,70,650,400,900,0,800},3,2,1,-1,20,0,150,0},
 {"Wide Saw", {3250,900,950,2100,1400,2048,550,1700,1750,1100,160,0},2,2,0,0,10,0,210,1},
 {"Pluck", {2300,1150,3600,1700,250,2048,20,1000,650,800,0,0},2,1,0,0,0,0,12,0},
 {"Slow Pad", {2500,700,700,2200,1800,2048,2600,2400,3000,1200,350,0},2,1,0,0,15,0,220,1},
 {"Hollow Lead", {3050,650,1700,1400,550,1024,350,1550,1200,1700,650,1400},3,1,1,0,0,0,220,0},
 {"Dust Keys", {2400,900,2200,900,180,2048,250,1100,1850,1000,80,0},1,2,0,0,0,18,130,1},
 {"Sub Bass", {1200,300,1800,450,60,2048,350,1050,950,600,0,1000},0,1,1,-1,180,0,220,1},
 {"Buzzy Brass", {3100,1600,1600,2300,700,1600,1150,1350,1050,1200,220,0},2,3,0,0,15,0,190,0},
 {"Pure Fifth", {3450,200,450,2000,4095,2048,650,1200,1900,1400,200,0},0,1,0,0,0,0,225,0},
 {"Air Noise", {2700,1850,2700,2000,300,2048,1750,2100,2650,700,80,0},1,3,0,0,0,100,170,1},
 {"Soft Organ", {3300,250,250,2450,0,2048,280,900,950,800,0,0},0,3,0,0,85,0,255,0},
 {"Vibrato Lead",{3150,1100,1200,2050,950,2048,450,1450,1700,2200,1250,1500},2,3,1,0,10,0,200,0},
 {"Pulse Chord", {2850,1350,1450,2150,950,3100,850,1750,2150,1300,250,0},3,3,0,0,25,0,210,1}
};
const char *sp_synth_preview_preset_name(unsigned p){return p<SP_PREVIEW_PRESETS?presets[p].name:0;}
uint16_t sp_synth_preview_preset_value(unsigned p,unsigned k){
    return p<SP_PREVIEW_PRESETS && k<SP_PREVIEW_PARAMETERS?presets[p].values[k]:0;
}
unsigned sp_synth_preview_preset_mono(unsigned p){return p<SP_PREVIEW_PRESETS?presets[p].mono:0;}
int sp_synth_preview_preset_octave(unsigned p){return p<SP_PREVIEW_PRESETS?presets[p].octave:0;}
int sp_synth_preview_preset_info(unsigned p,SpPreviewPresetInfo *out) {
    if(p>=SP_PREVIEW_PRESETS || !out)return 0;
    const Preset *s=&presets[p];
    *out=(SpPreviewPresetInfo){s->wave_a,s->wave_b,s->sub,s->noise,s->sustain,s->filter_mode};
    return 1;
}

static int valid(const SpSynthPreviewVoice *v) {
    return v && (uintptr_t)v%_Alignof(SpSynthPreviewVoice)==0 &&
           v->initialized==PREVIEW_INITIALIZED;
}
static void latch(SpSynthPreviewVoice *v,uint32_t reason) {
    atomic_fetch_or_explicit(&v->terminal,reason,memory_order_release);
}
static float unit(uint16_t x){return (float)x*(1.0f/4095.0f);}
static void derive(SpSynthPreviewVoice *v) {
    SpPreviewPatch *p=&v->patch; const Preset *s=&presets[v->preset];
    p->cutoff=40.0f*sp_synth_exp2(8.2f*unit(v->parameters[0]));
    p->resonance=0.82f*unit(v->parameters[1]);
    p->env_amount=6.0f*unit(v->parameters[2]);
    p->mix=unit(v->parameters[3]);
    /* Highest detune position is a fifth, the middle remains a narrow chorus.
     * This permits the compact Pure Fifth preset without an extra parameter. */
    float x=unit(v->parameters[4]);
    p->detune=sp_synth_exp2(x<0.95f?x*0.02f:((x-0.95f)*11.6666667f));
    p->width=0.1f+0.8f*unit(v->parameters[5]);
    p->pulse_mean=2.0f*p->width-1.0f;
    p->pulse_scale=1.0f/(1.0f+fabsf(p->pulse_mean));
    x=unit(v->parameters[6]);p->attack=0.001f+3.0f*x*x*x;
    x=unit(v->parameters[7]);p->decay=0.015f+2.0f*x*x;
    x=unit(v->parameters[8]);p->release=0.020f+4.0f*x*x*x;
    p->lfo_increment=(0.1f+9.9f*unit(v->parameters[9]))/v->sample_rate;
    p->lfo_depth=unit(v->parameters[10])*(1.0f/12.0f);
    x=unit(v->parameters[11]);p->glide_coefficient=1.0f/(1.0f+v->sample_rate*x*x);
    p->sub=(float)s->sub*(1.0f/255.0f)*0.65f;
    p->noise=(float)s->noise*(1.0f/255.0f)*0.65f;
    p->sustain=(float)s->sustain*(1.0f/255.0f);
    p->filter_decay=p->decay;
    p->wave_a=s->wave_a;p->wave_b=s->wave_b;p->filter_mode=s->filter_mode;
    v->transpose=sp_synth_exp2((float)((int)v->octave-2));
    for(unsigned i=0;i<SP_PREVIEW_VOICES;++i) {
        SpPreviewPolyVoice *u=&v->voices[i];
        u->envelope.config=(SpEnvConfig){p->attack,p->decay,p->sustain,p->release,0};
        u->filter_envelope.config=(SpEnvConfig){p->attack,p->filter_decay,0,p->release,0};
        u->filter.mode=p->filter_mode; /* audio owner only; retain history */
    }
    v->modulation_countdown=0;
}
static void load_preset(SpSynthPreviewVoice *v,unsigned program) {
    v->preset=program;v->mono=presets[program].mono;
    v->octave=(unsigned)(presets[program].octave+2);
    for(unsigned i=0;i<SP_PREVIEW_PARAMETERS;++i)v->parameters[i]=presets[program].values[i];
    derive(v);
}
int sp_synth_preview_voice_init(SpSynthPreviewVoice *v,uint32_t rate) {
    if(!v || (uintptr_t)v%_Alignof(SpSynthPreviewVoice) || rate<8000 || rate>192000)return 0;
    const unsigned char *p=(const void *)v;
    for(size_t i=0;i<sizeof(*v);++i)if(p[i])return 0;
    atomic_init(&v->write_index,0);atomic_init(&v->read_index,0);atomic_init(&v->terminal,0);
    atomic_init(&v->permission_ack,0);atomic_init(&v->stop_ack,0);atomic_init(&v->heartbeat,0);
    atomic_init(&v->idle_ack,0);atomic_init(&v->command_ack,0);v->sample_rate=(float)rate;
    v->transition_frames=rate/500u; /* 2 ms, bounded16..384 frames. */
    for(unsigned i=0;i<SP_PREVIEW_PADS;++i)
        v->increments[i]=440.0f*sp_synth_exp2(((float)i-21.0f)/12.0f)/(float)rate;
    const SpEnvConfig c={0.005f,0.0f,1.0f,0.040f,0.0f};
    for(unsigned i=0;i<SP_PREVIEW_VOICES;++i) {
        SpPreviewPolyVoice *u=&v->voices[i];u->pad=SP_PREVIEW_PADS;
        sp_synth_env_init(&u->envelope,(float)rate,&c);
        sp_synth_env_init(&u->filter_envelope,(float)rate,&c);
        sp_synth_filter_init(&u->filter,SP_FILTER_LP12,(float)rate,8000.0f,0);
        sp_synth_noise_seed(&u->noise,UINT32_C(0x7182d8a3)+i*UINT32_C(0x9239ac71));
    }
    load_preset(v,0);v->active_pad=SP_PREVIEW_PADS;
    sp_preview_visual_init(&v->visual,rate);v->initialized=PREVIEW_INITIALIZED;
    return 1;
}
uint32_t sp_synth_preview_voice_faults(const SpSynthPreviewVoice *v) {
    return valid(v)?atomic_load_explicit(&v->terminal,memory_order_acquire):0;
}
void sp_synth_preview_voice_stop(SpSynthPreviewVoice *v) {if(valid(v))latch(v,SP_PREVIEW_STOP);}
static int publish(SpSynthPreviewVoice *v,unsigned kind,unsigned pad,uint32_t ticket,uint16_t value) {
    if(!valid(v) || atomic_load_explicit(&v->terminal,memory_order_acquire))return 0;
    uint32_t w=atomic_load_explicit(&v->write_index,memory_order_relaxed);
    uint32_t r=atomic_load_explicit(&v->read_index,memory_order_acquire);
    uint32_t distance=w-r;
    if(distance>=SP_PREVIEW_QUEUE) {
        latch(v,distance==SP_PREVIEW_QUEUE?SP_PREVIEW_OVERFLOW:SP_PREVIEW_QUEUE_FAULT);return 0;
    }
    v->queue[w & (SP_PREVIEW_QUEUE-1)]=(SpPreviewEvent){ticket,(uint8_t)kind,(uint8_t)pad,value};
    atomic_store_explicit(&v->write_index,w+1,memory_order_release);return 1;
}
int sp_synth_preview_voice_admit(SpSynthPreviewVoice *v,int admitted) {
    if(!valid(v) || (admitted!=0 && admitted!=1) || sp_synth_preview_voice_faults(v))return 0;
    if(v->control_admitted==(unsigned)admitted)return 1;
    if(v->permission_ticket==UINT32_MAX){latch(v,SP_PREVIEW_EXHAUSTED);return 0;}
    uint32_t ticket=v->permission_ticket+1;
    if(!publish(v,admitted?ENABLE:DISABLE,0,ticket,0))return 0;
    v->permission_ticket=ticket;v->control_admitted=(unsigned)admitted;
    if(!admitted)for(unsigned p=0;p<SP_PREVIEW_PADS;++p)v->control_ids[p]=0;
    return 1;
}
uint32_t sp_synth_preview_voice_quiesce(SpSynthPreviewVoice *v) {
    if(!valid(v) || sp_synth_preview_voice_faults(v))return 0;
    if(v->permission_ticket==UINT32_MAX){latch(v,SP_PREVIEW_EXHAUSTED);return 0;}
    uint32_t ticket=v->permission_ticket+1;
    if(!publish(v,QUIESCE,0,ticket,0))return 0;
    v->permission_ticket=ticket;v->control_admitted=0;
    for(unsigned p=0;p<SP_PREVIEW_PADS;++p)v->control_ids[p]=0;
    return ticket;
}
uint32_t sp_synth_preview_voice_idle_ack(const SpSynthPreviewVoice *v) {
    return valid(v)?atomic_load_explicit(&v->idle_ack,memory_order_acquire):0;
}
uint32_t sp_synth_preview_voice_permission(const SpSynthPreviewVoice *v){return valid(v)?v->permission_ticket:0;}
uint32_t sp_synth_preview_voice_permission_ack(const SpSynthPreviewVoice *v){
    return valid(v)?atomic_load_explicit(&v->permission_ack,memory_order_acquire):0;
}
uint32_t sp_synth_preview_voice_stop_ack(const SpSynthPreviewVoice *v){
    return valid(v)?atomic_load_explicit(&v->stop_ack,memory_order_acquire):0;
}
int sp_synth_preview_voice_lease(SpSynthPreviewVoice *v,uint32_t frames) {
    if(!valid(v) || !frames || frames>INT32_MAX || v->lease_frames ||
       v->permission_ticket || sp_synth_preview_voice_faults(v))return 0;
    v->lease_frames=frames;return 1;
}
int sp_synth_preview_voice_pulse(SpSynthPreviewVoice *v) {
    if(!valid(v) || !v->lease_frames || sp_synth_preview_voice_faults(v))return 0;
    uint32_t value=atomic_load_explicit(&v->heartbeat,memory_order_relaxed);
    if(value==UINT32_MAX){latch(v,SP_PREVIEW_EXHAUSTED);return 0;}
    atomic_store_explicit(&v->heartbeat,value+1,memory_order_release);return 1;
}
uint32_t sp_synth_preview_voice_down(SpSynthPreviewVoice *v,unsigned pad) {
    if(!valid(v) || pad>=SP_PREVIEW_PADS || !v->control_admitted ||
       v->control_ids[pad] || sp_synth_preview_voice_faults(v))return 0;
    if(v->next_ticket==UINT32_MAX){latch(v,SP_PREVIEW_EXHAUSTED);return 0;}
    uint32_t ticket=v->next_ticket+1;
    if(!publish(v,DOWN,pad,ticket,0))return 0;
    v->next_ticket=ticket;v->control_ids[pad]=ticket;return ticket;
}
int sp_synth_preview_voice_up(SpSynthPreviewVoice *v,unsigned pad,uint32_t ticket) {
    if(!valid(v) || pad>=SP_PREVIEW_PADS || !ticket || !v->control_admitted ||
       v->control_ids[pad]!=ticket)return 0;
    if(!publish(v,UP,pad,ticket,0))return 0;
    v->control_ids[pad]=0;return 1;
}
static int command(SpSynthPreviewVoice *v,unsigned kind,unsigned param,uint16_t value) {
    if(!valid(v) || !v->control_admitted || sp_synth_preview_voice_faults(v))return 0;
    if(v->control_command_ticket==UINT32_MAX){latch(v,SP_PREVIEW_EXHAUSTED);return 0;}
    uint32_t ticket=v->control_command_ticket+1;
    if(!publish(v,kind,param,ticket,value))return 0;
    v->control_command_ticket=ticket;return 1;
}
int sp_synth_preview_voice_parameter(SpSynthPreviewVoice *v,unsigned k,uint32_t x){
    return k<SP_PREVIEW_PARAMETERS && x<=4095?command(v,PARAMETER,k,(uint16_t)x):0;
}
int sp_synth_preview_voice_preset(SpSynthPreviewVoice *v,unsigned p){
    return p<SP_PREVIEW_PRESETS?command(v,PRESET,0,(uint16_t)p):0;
}
int sp_synth_preview_voice_mono(SpSynthPreviewVoice *v,int x){
    return x==0 || x==1?command(v,MONO,0,(uint16_t)x):0;
}
int sp_synth_preview_voice_octave(SpSynthPreviewVoice *v,int x){
    return x>=-2 && x<=2?command(v,OCTAVE,0,(uint16_t)(x+2)):0;
}
uint32_t sp_synth_preview_voice_command(const SpSynthPreviewVoice *v){return valid(v)?v->control_command_ticket:0;}
uint32_t sp_synth_preview_voice_command_ack(const SpSynthPreviewVoice *v){
    return valid(v)?atomic_load_explicit(&v->command_ack,memory_order_acquire):0;
}
static void clear_unit(SpPreviewPolyVoice *u) {
    u->pad=SP_PREVIEW_PADS;u->ticket=0;u->age=0;u->increment=0;
    for(unsigned i=0;i<3;++i)u->oscillator[i].phase=0;
    u->envelope.value=0;u->envelope.gate=0;u->envelope.stage=SP_ENV_IDLE;u->envelope.remaining=0;
    u->filter_envelope.value=0;u->filter_envelope.gate=0;
    u->filter_envelope.stage=SP_ENV_IDLE;u->filter_envelope.remaining=0;
    for(unsigned i=0;i<2;++i)u->filter.stage[i]=(SpSvf){0};
}
static void silence(SpSynthPreviewVoice *v) {
    for(unsigned p=0;p<SP_PREVIEW_PADS;++p)v->audio_ids[p]=0;
    for(unsigned i=0;i<SP_PREVIEW_VOICES;++i)clear_unit(&v->voices[i]);
    v->audio_admitted=0;v->active_pad=SP_PREVIEW_PADS;
    v->lfo_phase=0;v->modulation_countdown=0;v->age=0;
    v->last_sample=0;v->transition_offset=0;
    v->transition_remaining=0;v->transition_pending=0;
}
static unsigned latest(const SpSynthPreviewVoice *v) {
    uint32_t id=0;unsigned selected=SP_PREVIEW_PADS;
    for(unsigned p=0;p<SP_PREVIEW_PADS;++p)if(v->audio_ids[p]>id){id=v->audio_ids[p];selected=p;}
    return selected;
}
static void start_unit(SpSynthPreviewVoice *v,SpPreviewPolyVoice *u,unsigned pad,int legato) {
    if(!legato){
        if(u->envelope.stage!=SP_ENV_IDLE)v->transition_pending=1;
        clear_unit(u);u->increment=v->increments[pad]*v->transpose;
        sp_synth_filter_set(&u->filter,v->sample_rate,v->patch.cutoff,v->patch.resonance);
        u->filter.g=u->filter.target_g;u->filter.k=u->filter.target_k;
        v->modulation_countdown=0;
    }
    u->pad=pad;u->ticket=v->audio_ids[pad];u->age=u->ticket;
    if(!legato){sp_synth_env_on(&u->envelope,1);sp_synth_env_on(&u->filter_envelope,1);}
}
static void rebuild(SpSynthPreviewVoice *v) {
    for(unsigned i=0;i<SP_PREVIEW_VOICES;++i)clear_unit(&v->voices[i]);
    v->active_pad=latest(v);
    if(v->active_pad>=SP_PREVIEW_PADS)return;
    if(v->mono){start_unit(v,&v->voices[0],v->active_pad,0);return;}
    uint32_t ceiling=UINT32_MAX;
    for(unsigned i=0;i<SP_PREVIEW_VOICES;++i) {
        uint32_t best=0;unsigned selected=SP_PREVIEW_PADS;
        for(unsigned p=0;p<SP_PREVIEW_PADS;++p)
            if(v->audio_ids[p]>best && v->audio_ids[p]<=ceiling){best=v->audio_ids[p];selected=p;}
        if(selected==SP_PREVIEW_PADS)break;
        start_unit(v,&v->voices[i],selected,0);ceiling=best-1;
    }
}
static int apply(SpSynthPreviewVoice *v,SpPreviewEvent e) {
    if(e.kind<ENABLE || e.kind>QUIESCE || (e.kind<=UP && e.reserved))return 0;
    if(e.kind==ENABLE || e.kind==DISABLE || e.kind==QUIESCE) {
        if(!e.ticket || e.ticket!=v->audio_permission_ticket+1 || e.pad || (e.kind==QUIESCE && e.reserved) ||
           (e.kind==ENABLE && v->audio_admitted) || (e.kind==DISABLE && !v->audio_admitted))return 0;
        sp_preview_visual_reset_capture(&v->visual);
        silence(v);v->audio_admitted=e.kind==ENABLE;v->audio_permission_ticket=e.ticket;
        v->audio_heartbeat=atomic_load_explicit(&v->heartbeat,memory_order_acquire);
        v->lease_remaining=v->lease_frames;
        atomic_store_explicit(&v->permission_ack,e.ticket,memory_order_release);return 1;
    }
    if(!v->audio_admitted || !e.ticket)return 0;
    if(e.kind>=PARAMETER) {
        if(e.ticket!=v->audio_command_ticket+1)return 0;
        if(e.kind==PARAMETER) {
            if(e.pad>=SP_PREVIEW_PARAMETERS || e.reserved>4095)return 0;
            v->parameters[e.pad]=e.reserved;derive(v);
        } else {
            if(e.pad)return 0;
            if(e.kind==PRESET) {
                if(e.reserved>=SP_PREVIEW_PRESETS)return 0;
                v->transition_pending=1;
                uint32_t mono=v->mono;load_preset(v,e.reserved);
                if(v->mono!=mono)rebuild(v);
            } else if(e.kind==MONO) {
                if(e.reserved>1)return 0;
                if(v->mono!=e.reserved){v->transition_pending=1;v->mono=e.reserved;rebuild(v);}
            } else {
                if(e.reserved>4)return 0;
                v->octave=e.reserved;derive(v);
            }
        }
        v->audio_command_ticket=e.ticket;
        atomic_store_explicit(&v->command_ack,e.ticket,memory_order_release);return 1;
    }
    if(e.pad>=SP_PREVIEW_PADS)return 0;
    if(e.kind==DOWN) {
        if(v->audio_ids[e.pad])return 0;
        v->audio_ids[e.pad]=e.ticket;v->active_pad=e.pad;
        if(v->mono) {
            SpPreviewPolyVoice *u=&v->voices[0];
            start_unit(v,u,e.pad,u->envelope.gate && u->pad<SP_PREVIEW_PADS);
        } else {
            unsigned selected=0,releasing=SP_PREVIEW_VOICES;uint32_t oldest=UINT32_MAX;
            int idle=0;
            for(unsigned i=0;i<SP_PREVIEW_VOICES;++i) {
                SpPreviewPolyVoice *u=&v->voices[i];
                if(u->envelope.stage==SP_ENV_IDLE){selected=i;idle=1;break;}
                if(!u->envelope.gate && (releasing==SP_PREVIEW_VOICES ||
                   u->envelope.value<v->voices[releasing].envelope.value))releasing=i;
                if(u->age<oldest){oldest=u->age;selected=i;}
            }
            /* Preserve release tails whenever an unused voice exists. If all
             * slots are busy, retire the quietest release before a held note. */
            if(!idle && releasing<SP_PREVIEW_VOICES)selected=releasing;
            start_unit(v,&v->voices[selected],e.pad,0);
        }
    } else {
        if(v->audio_ids[e.pad]!=e.ticket)return 0;
        v->audio_ids[e.pad]=0;v->active_pad=latest(v);
        if(v->mono) {
            SpPreviewPolyVoice *u=&v->voices[0];
            if(u->pad==e.pad && u->ticket==e.ticket) {
                if(v->active_pad<SP_PREVIEW_PADS)start_unit(v,u,v->active_pad,1);
                else {sp_synth_env_off(&u->envelope);sp_synth_env_off(&u->filter_envelope);}
            }
        } else for(unsigned i=0;i<SP_PREVIEW_VOICES;++i) {
            SpPreviewPolyVoice *u=&v->voices[i];
            if(u->pad==e.pad && u->ticket==e.ticket){sp_synth_env_off(&u->envelope);sp_synth_env_off(&u->filter_envelope);}
        }
    }
    return 1;
}
static float tick(SpSynthPreviewVoice *v) {
    SpPreviewPatch *p=&v->patch;float sum=0;
    /* Shared vibrato and filter targets at one sample in16. TPT targets still
     * smooth every sample. Bounded modulation work, no transcendental library. */
    int update=v->modulation_countdown==0;
    if(update){v->modulation=sp_synth_exp2(sp_synth_sine(v->lfo_phase)*p->lfo_depth);v->modulation_countdown=16;}
    --v->modulation_countdown;v->lfo_phase+=p->lfo_increment;
    if(v->lfo_phase>=1)v->lfo_phase-=1;
    for(unsigned i=0;i<SP_PREVIEW_VOICES;++i) {
        SpPreviewPolyVoice *u=&v->voices[i];
        if(u->pad>=SP_PREVIEW_PADS || u->envelope.stage==SP_ENV_IDLE)continue;
        uint32_t amp_stage=u->envelope.stage;
        float amp=sp_synth_env_tick(&u->envelope);
        if(amp_stage==SP_ENV_ATTACK) {
            /* A cubic knee keeps the selected attack duration and zero slope
             * at both endpoints. Store the audible value so an early UP's
             * release starts at that value rather than the linear progress. */
            amp=amp*amp*(3.0f-2.0f*amp);u->envelope.value=amp;
        }
        float env=sp_synth_env_tick(&u->filter_envelope);
        float target=v->increments[u->pad]*v->transpose;
        u->increment+=(target-u->increment)*(v->mono?p->glide_coefficient:1.0f);
        float increment=u->increment*v->modulation;
        float a=sp_synth_osc(&u->oscillator[0],(SpWave)p->wave_a,increment,p->width);
        float b=sp_synth_osc(&u->oscillator[1],(SpWave)p->wave_b,increment*p->detune,p->width);
        /* A pulse's mean is2*width-1. Remove it before the amp envelope so
         * unequal widths do not turn note gates into a DC thump. Normalize
         * the resulting asymmetric pulse to retain the original peak bound. */
        if(p->wave_a==SP_WAVE_PULSE)a=(a-p->pulse_mean)*p->pulse_scale;
        if(p->wave_b==SP_WAVE_PULSE)b=(b-p->pulse_mean)*p->pulse_scale;
        float x=a+(b-a)*p->mix;
        if(p->sub>0)x+=p->sub*sp_synth_osc(&u->oscillator[2],SP_WAVE_SINE,increment*0.5f,0.5f);
        if(p->noise>0)x+=p->noise*sp_synth_noise(&u->noise);
        if(update)sp_synth_filter_set(&u->filter,v->sample_rate,
            p->cutoff*sp_synth_exp2(p->env_amount*env),p->resonance);
        float filtered=sp_synth_filter_tick(&u->filter,x*(1.0f/(1.0f+p->sub+p->noise)));
        if(!isfinite(filtered) || u->filter.faults || !isfinite(amp) || !isfinite(u->increment)) {
            latch(v,SP_PREVIEW_RENDER_FAULT);return 0;
        }
        sum+=0.12f*amp*filtered;
        if(u->envelope.stage==SP_ENV_IDLE)clear_unit(u);
    }
    return sum;
}
static float transition(SpSynthPreviewVoice *v,float sample) {
    if(v->transition_pending) {
        /* The first replacement sample equals the last audible sample.
         * A2 ms cubic residual reaches zero with zero endpoint slope. Only
         * audio owns these fields; repeated edits restart from actual output. */
        v->transition_offset=v->last_sample-sample;
        v->transition_remaining=v->transition_frames;
        v->transition_pending=0;
    }
    if(v->transition_remaining) {
        float t=1.0f-(float)v->transition_remaining/(float)v->transition_frames;
        sample+=v->transition_offset*(1.0f-t*t*(3.0f-2.0f*t));
        --v->transition_remaining;
    }
    return sample;
}
static unsigned visual_pad(const SpSynthPreviewVoice *v) {
    if(v->active_pad<SP_PREVIEW_PADS)return v->active_pad;
    unsigned pad=SP_PREVIEW_PADS;uint32_t age=0;
    for(unsigned i=0;i<SP_PREVIEW_VOICES;++i) {
        const SpPreviewPolyVoice *u=&v->voices[i];
        if(u->envelope.stage!=SP_ENV_IDLE && u->age>=age){age=u->age;pad=u->pad;}
    }
    return pad;
}
static void visual_hint(SpSynthPreviewVoice *v) {
    unsigned pad=visual_pad(v);
    sp_preview_visual_hint(&v->visual,pad<SP_PREVIEW_PADS?v->increments[pad]*v->transpose:0);
}
static void visual_metadata(const SpSynthPreviewVoice *v,SpPreviewVisualSnapshot *s) {
    if(!s->span_frames)s->command_ticket=v->audio_command_ticket;
    s->held_pad_mask=0;s->active_voices=0;
    s->active_pad=(uint8_t)visual_pad(v);
    s->applied_preset=(uint8_t)v->preset;s->applied_mono=(uint8_t)v->mono;
    if(v->audio_admitted)s->flags|=SP_VISUAL_ADMITTED;
    for(unsigned i=0;i<SP_PREVIEW_PADS;++i)if(v->audio_ids[i])s->held_pad_mask|=1u<<i;
    for(unsigned i=0;i<SP_PREVIEW_VOICES;++i) {
        const SpEnvelope *e=&v->voices[i].envelope;
        if(e->stage!=SP_ENV_IDLE)++s->active_voices;
        s->envelope[i]=(uint8_t)(e->value<=0?0:e->value>=1?255:e->value*255.0f);
        s->envelope_stage[i]=(uint8_t)e->stage;
        float progress=e->stage==SP_ENV_IDLE?0.0f:e->stage==SP_ENV_SUSTAIN?1.0f:
            1.0f-(float)e->remaining*e->step;
        s->envelope_progress[i]=(uint8_t)(progress<=0?0:progress>=1?255:progress*255.0f);
    }
    s->lfo=(int8_t)(sp_synth_sine(v->lfo_phase)*127.0f);
}
SpPreviewVisualResult sp_synth_preview_voice_visual_read(const SpSynthPreviewVoice *v,
    SpPreviewVisualReader *r,SpPreviewVisualSnapshot *s) {
    uintptr_t owner=(uintptr_t)v,out=(uintptr_t)s,reader=(uintptr_t)r;
    if(!valid(v) || !r || !s || out>UINTPTR_MAX-sizeof(*s) ||
       reader>UINTPTR_MAX-sizeof(*r) || owner>UINTPTR_MAX-sizeof(*v) ||
       (out<owner+sizeof(*v) && owner<out+sizeof(*s)) ||
       (reader<owner+sizeof(*v) && owner<reader+sizeof(*r)))return SP_VISUAL_INVALID;
    return sp_preview_visual_read(&v->visual,r,s);
}
SpPreviewRenderResult sp_synth_preview_voice_render(SpSynthPreviewVoice *v,
    int16_t *out,size_t capacity,uint32_t frames) {
    if(!valid(v))return SP_PREVIEW_INVALID;
    size_t bytes=(size_t)frames*2*sizeof(int16_t);uintptr_t first=(uintptr_t)out,owner=(uintptr_t)v;
    if(frames>SP_PREVIEW_FRAMES || capacity<(size_t)frames*2 ||
       (frames && (!out || first%_Alignof(int16_t) || first>UINTPTR_MAX-bytes ||
        owner>UINTPTR_MAX-sizeof(*v) || (first<owner+sizeof(*v) && owner<first+bytes)))) {
        latch(v,SP_PREVIEW_RENDER_FAULT);return SP_PREVIEW_INVALID;
    }
    uint32_t visual_frame_end=v->visual.frame_sequence+frames;
    for(unsigned i=0;i<frames*2;++i)out[i]=0;
    uint32_t r=atomic_load_explicit(&v->read_index,memory_order_relaxed);
    uint32_t end=atomic_load_explicit(&v->write_index,memory_order_acquire);
    if(end-r>SP_PREVIEW_QUEUE)latch(v,SP_PREVIEW_QUEUE_FAULT);
    for(unsigned i=0;i<frames;++i) {
        if(atomic_load_explicit(&v->terminal,memory_order_acquire))break;
        if(r!=end) {
            SpPreviewEvent event=v->queue[r & (SP_PREVIEW_QUEUE-1)];
            if(!apply(v,event)){latch(v,SP_PREVIEW_IDENTITY_FAULT);break;}
            visual_hint(v);
            atomic_store_explicit(&v->read_index,++r,memory_order_release);
        }
        int clipped=0;
        if(v->audio_admitted) {
            float sample=transition(v,tick(v));
            if(!isfinite(sample)){latch(v,SP_PREVIEW_RENDER_FAULT);break;}
            if(sample>0.45f){sample=0.45f;clipped=1;}
            if(sample< -0.45f){sample=-0.45f;clipped=1;}
            v->last_sample=sample;
            int16_t value=(int16_t)(sample*32767.0f);out[2*i]=value;out[2*i+1]=value;
        }
        if(v->audio_admitted) {
            if(sp_preview_visual_capture(&v->visual,out[2*i],clipped,v->audio_command_ticket))
                visual_metadata(v,sp_preview_visual_pending(&v->visual));
        } else ++v->visual.frame_sequence;
        if(v->audio_admitted && v->lease_frames) {
            uint32_t pulse=atomic_load_explicit(&v->heartbeat,memory_order_acquire);
            if(pulse!=v->audio_heartbeat){v->audio_heartbeat=pulse;v->lease_remaining=v->lease_frames;}
            if(!v->lease_remaining){latch(v,SP_PREVIEW_CONTROL_STALL);break;}
            --v->lease_remaining;
        }
    }
    if(atomic_load_explicit(&v->terminal,memory_order_acquire)) {
        silence(v);for(unsigned i=0;i<frames*2;++i)out[i]=0;
        if(frames) {
            if(sp_preview_visual_clear_prepare(&v->visual,visual_frame_end,1))
                visual_metadata(v,sp_preview_visual_pending(&v->visual));
            sp_preview_visual_commit(&v->visual);
        }
        if(frames)atomic_store_explicit(&v->stop_ack,1,memory_order_release);
        return SP_PREVIEW_TERMINAL;
    }
    if(frames && !v->audio_admitted && sp_preview_visual_clear_prepare(&v->visual,visual_frame_end,0))
        visual_metadata(v,sp_preview_visual_pending(&v->visual));
    sp_preview_visual_commit(&v->visual);
    if(frames && !v->audio_admitted && r==end &&
       atomic_load_explicit(&v->idle_ack,memory_order_relaxed)!=v->audio_permission_ticket) {
        unsigned silent=1;
        for(unsigned i=0;i<frames*2;++i)if(out[i]){silent=0;break;}
        if(silent)atomic_store_explicit(&v->idle_ack,v->audio_permission_ticket,memory_order_release);
    }
    return SP_PREVIEW_OK;
}
