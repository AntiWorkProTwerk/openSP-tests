#include "sp_synth_entry_owner_v552_live.h"
#include "sp_synth_input_observer_v552.h"
#include "sp_synth_control_v552.h"
#include "sp_p6_native_input.h"
#include <stddef.h>
#include <stdint.h>

_Static_assert(sizeof(void *)==4,"Native ARM32 contract");
_Static_assert(ATOMIC_POINTER_LOCK_FREE==2 && ATOMIC_INT_LOCK_FREE==2,"Lock-free publication");
static _Atomic(SpSynthEntryOwnerV552 *) registered;
extern volatile uint32_t sp404_stock_input_native_v552_scratch[3];
#define W (*(volatile uint32_t *)(uintptr_t)0x805919B0)
#define R (*(volatile uint32_t *)(uintptr_t)0x805919B4)
#define RING ((volatile uint32_t *)(uintptr_t)0x80B5E7A4)
typedef struct Frame { uint32_t record[3],old,offered;struct Frame *previous; } Frame;
static uint32_t lock(void) { uint32_t v;__asm__ volatile("mrs %0, primask\n\tcpsid i\n\tdmb sy":"=r"(v)::"memory");return v; }
static void unlock(uint32_t v) { __asm__ volatile("dmb sy\n\tmsr primask, %0"::"r"(v):"memory"); }
static uint32_t task(void) { return ((uint32_t (*)(void))(uintptr_t)0x800D3163)(); }
static void fault(SpSynthEntryOwnerV552 *o,uint32_t reason) {
    atomic_fetch_or_explicit(&o->fault,reason,memory_order_release);o->stop(o->context);
}
static int owner(SpSynthEntryOwnerV552 *o) {
    if(!o)return 0;
    if(task()==o->task_id)return 1;
    fault(o,SP_ENTRY_FOREIGN);return 0;
}
static int cursors(void) {
    return R<256 && W<256 && !sp404_stock_input_native_v552_scratch[2];
}
static int emit(SpSynthEntryOwnerV552 *o,const sp_synth_input_batch *b) {
    if(!b->count)return 1;
    if(o->publish(o->context,b))return 1;
    fault(o,SP_ENTRY_PUBLISH);return 0;
}
/* Keep the 17-event portable batch out of native dispatch/page frames. */
__attribute__((noinline)) static int route(SpSynthEntryOwnerV552 *o,const sp_ui_event *e) {
    sp_synth_input_batch b;
    int consumed=sp_synth_input_route(&o->input,e,&b);
    (void)emit(o,&b);return consumed;
}
int sp_synth_entry_owner_v552_install(SpSynthEntryOwnerV552 *o,void *panel,
    SpSynthEntryPublishV552 publish,SpSynthEntryStopV552 stop,void *context) {
    if(!o || (uintptr_t)o%_Alignof(SpSynthEntryOwnerV552) || !publish || !stop ||
       (uintptr_t)panel!=0x8300A3E4 || atomic_load_explicit(&registered,memory_order_acquire))return 0;
    uint32_t id=task();if(id<1 || id>32)return 0;
    const unsigned char *p=(const void *)o;
    for(size_t i=0;i<sizeof(*o);++i)if(p[i])return 0;
    uint32_t mask=lock();
    if(!cursors() || sp_synth_input_observer_v552.loss ||
       sp_synth_input_observer_v552.depth || sp_synth_input_observer_v552.session) {
        unlock(mask);return 0;
    }
    o->task_id=id;o->publish=publish;o->stop=stop;o->context=context;
    o->expected_read=R;
    sp_synth_input_init(&o->input,UINT16_MAX,0);
    atomic_store_explicit(&registered,o,memory_order_release);
    unlock(mask);return 1;
}
int sp_synth_entry_owner_v552_enter(SpSynthEntryBoundaryV552 *out) {
    SpSynthEntryOwnerV552 *o=atomic_load_explicit(&registered,memory_order_acquire);
    if(!out || !owner(o))return 0;
    uint32_t mask=lock();
    if(atomic_load_explicit(&o->fault,memory_order_acquire) || !cursors() ||
       sp_synth_input_observer_v552.loss ||
       o->sample_depth || o->dispatch_depth || !o->shift_seen || o->input.enabled ||
       o->epoch==UINT32_MAX || R!=o->expected_read) {unlock(mask);return 0;}
    o->old_remaining=(W-R)&255u;
    o->quarantine=(o->active | ~o->seen)&65535u;
    o->input.physical=(uint16_t)(o->quarantine | o->input.captured);
    ++o->epoch;
    SpSynthEntryBoundaryV552 result={o->input.physical,o->shift,o->epoch,o->old_remaining};
    sp_synth_input_batch batch;
    (void)sp_synth_input_enable(&o->input,1,(int)o->shift,&batch);
    unlock(mask);
    if(!emit(o,&batch))return 0;
    *out=result;return 1;
}
int sp_synth_entry_owner_v552_exit(void) {
    SpSynthEntryOwnerV552 *o=atomic_load_explicit(&registered,memory_order_acquire);
    if(!owner(o))return 0;
    sp_synth_input_batch b;
    (void)sp_synth_input_enable(&o->input,0,(int)o->shift,&b);
    return emit(o,&b);
}
void sp_synth_entry_owner_v552_cancel(void) {
    SpSynthEntryOwnerV552 *o=atomic_load_explicit(&registered,memory_order_acquire);
    if(o)fault(o,SP_ENTRY_EXTERNAL);
}
uint32_t sp_synth_entry_owner_v552_sample(uint32_t raw,uint32_t id,uint32_t r2,uint32_t r3) {
    SpSynthEntryOwnerV552 *o=atomic_load_explicit(&registered,memory_order_acquire);
    uint32_t mask=lock();
    int tracked=o && id<16 && o->sample_depth!=UINT32_MAX;
    if(tracked)++o->sample_depth;
    unlock(mask);
    uint32_t result=((uint32_t (*)(uint32_t,uint32_t,uint32_t,uint32_t))(uintptr_t)0x8008E681)(raw,id,r2,r3);
    if(tracked) {
        mask=lock();
        const volatile uint16_t *samples=(const void *)(uintptr_t)(0x833C1CE8+4*id);
        const volatile uint8_t *latch=(const void *)(uintptr_t)(0x833C1DAC+id);
        uint32_t bit=1u<<id;
        o->seen|=bit;
        if(samples[0] || samples[1] || *latch)o->active|=bit;
        else o->active&=~bit;
        --o->sample_depth;unlock(mask);
        /* Mutable note ownership belongs only to the selected task. */
        if(owner(o) && !(o->active&bit) && (o->quarantine&bit)) {
            o->quarantine&=~bit;
            if(!(o->input.captured&bit))o->input.physical&=(uint16_t)~bit;
        }
    } else if(o && id<16)fault(o,SP_ENTRY_EXHAUSTED);
    return result;
}
int sp_synth_entry_owner_v552_page(void *panel,const void *record) {
    SpSynthEntryOwnerV552 *o=atomic_load_explicit(&registered,memory_order_acquire);
    if((uintptr_t)panel!=0x8300A3E4 || !record || !owner(o) ||
       atomic_load_explicit(&o->fault,memory_order_acquire))return 0;
    Frame *f=o->dispatch;
    if(!f || f->old || f->offered || !o->input.enabled)return 0;
    const uint8_t *a=record,*b=(const void *)f->record;
    for(unsigned i=0;i<6;++i)if(a[i]!=b[i])return 0;
    if((f->record[0]&65535u)!=16)return 0;
    sp_ui_event event;
    if(!sp_synth_control_v552_event(record,6,&event))return 0;
    f->offered=1;
    return route(o,&event);
}
int sp_synth_entry_owner_v552_control_offer(void *panel,uint32_t kind,
    int32_t index,int32_t value) {
    SpSynthEntryOwnerV552 *o=atomic_load_explicit(&registered,memory_order_acquire);
    int recovery=kind==5 && (index==34 || index==49);
    if((uintptr_t)panel!=0x8300A3E4 || !owner(o) ||
       (atomic_load_explicit(&o->fault,memory_order_acquire) && !recovery))return 0;
    Frame *f=o->dispatch;
    if(!f || f->old || f->offered || (!o->input.enabled && !recovery))return 0;
    if((f->record[0]&65535u)!=kind || (int16_t)(f->record[0]>>16)!=index)return 0;
    if(kind!=5 && (int16_t)(f->record[1]&65535u)!=value)return 0;
    /* Native-only PATTERN SELECT has no Synth UI event translation. */
    if(kind==5 && index==20){f->offered=1;return 1;}
    sp_ui_event event;
    if(!((kind==5 && index!=42) || kind==7 || kind==9) ||
       !sp_synth_control_v552_event(f->record,6,&event))return 0;
    f->offered=1;return 1;
}
int sp_p6_session_binding_v552_record_offered(void) {
    SpSynthEntryOwnerV552 *o=atomic_load_explicit(&registered,memory_order_acquire);
    if(!owner(o) || atomic_load_explicit(&o->fault,memory_order_acquire) ||
       !o->input.enabled || o->sample_depth)return 0;
    Frame *f=o->dispatch;
    return f && !f->old && f->offered==1 &&
        (f->record[0]&65535u)==5 && ((int16_t)(f->record[0]>>16)==49 || (int16_t)(f->record[0]>>16)==27);
}
extern void sp_p6_record_direct_edge(void);
extern void sp_p6_pattern_transport_v552_edge(void);
static void dispatch(SpSynthEntryOwnerV552 *o,Frame *f,int valid) {
    uint32_t kind=f->record[0]&65535u,id=f->record[0]>>16;
    if(valid) {
        f->previous=o->dispatch;o->dispatch=f;
        sp_p6_record_direct_edge();
        sp_p6_pattern_transport_v552_edge();
        if(!f->old)sp_p6_native_input_record(f->record);
        if((kind==5 || kind==6) && id==42) {
            sp_ui_event e={.type=kind==5?SP_UI_SHIFT_DOWN:SP_UI_SHIFT_UP};
            (void)route(o,&e);
        }
        if(kind==17 && id<16) {
            sp_ui_event e={.type=SP_UI_PAD_UP,.index=(uint16_t)(id+1)};
            int captured=route(o,&e);
            o->quarantine&=~(1u<<id);
            if(captured) {
                (void)((uint32_t (*)(uintptr_t))(uintptr_t)0x800D4961)(0x80591B24);
                o->dispatch=f->previous;return;
            }
        }
    }
    (void)((uint32_t (*)(const void *))(uintptr_t)0x8003B531)(f->record);
    if(valid) {
        /* A down rejected by native modal/gate/page remains stock-owned. */
        if(kind==16 && id<16)o->input.physical|=(uint16_t)(1u<<id);
        o->dispatch=f->previous;
    }
}
uint64_t sp_synth_entry_owner_v552_drain(void) {
    SpSynthEntryOwnerV552 *o=atomic_load_explicit(&registered,memory_order_acquire);
    int valid=owner(o);
    uint32_t mask=lock(),r=R,w=W;
    SpSynthInputObserverV552 *v=&sp_synth_input_observer_v552;
    /* A competing/nested nonempty drain can finish a later event before the
     * current native page callback. Cancel admission rather than reverse it.
     * Native routing and captured-release retirement still run. */
    if(valid && o->dispatch_depth && r!=w && o->input.enabled) {
        unlock(mask);fault(o,SP_ENTRY_SEQUENCE);mask=lock();
    }
    if(v->depth==UINT32_MAX || (valid && o->dispatch_depth==UINT32_MAX)) {
        unlock(mask);if(o)fault(o,SP_ENTRY_EXHAUSTED);return (uint64_t)w<<32|r;
    }
    ++v->depth;if(valid)++o->dispatch_depth;
    for(;;) {
        r=R;w=W;
        if(!cursors()) {unlock(mask);if(o)fault(o,SP_ENTRY_LOSS);mask=lock();break;}
        if(o && v->loss) {unlock(mask);fault(o,SP_ENTRY_LOSS);mask=lock();}
        if(r==w)break;
        Frame f={{RING[3*r],RING[3*r+1],RING[3*r+2]},0,0,0};
        R=(r+1)&255u;
        uint32_t kind=f.record[0]&65535u,id=f.record[0]>>16;
        if(kind==16 && id<16)v->held_pads|=1u<<id;
        if(kind==17 && id<16)v->held_pads&=~(1u<<id);
        if((kind==5 || kind==6) && id==42)v->shift=kind==5;
        if(v->records==UINT32_MAX) {
            v->loss|=SP_INPUT_OBSERVER_EXHAUSTED;
            unlock(mask);if(o)fault(o,SP_ENTRY_EXHAUSTED);mask=lock();
        } else ++v->records;
        if(valid) {
            if(r!=o->expected_read) {
                unlock(mask);fault(o,SP_ENTRY_SEQUENCE);mask=lock();
            }
            o->expected_read=R;
            f.old=o->old_remaining!=0;
            if(f.old)--o->old_remaining;
            if((kind==5 || kind==6) && id==42){o->shift_seen=1;o->shift=kind==5;}
        }
        unlock(mask);dispatch(o,&f,valid);mask=lock();
    }
    --v->depth;if(valid)--o->dispatch_depth;
    unlock(mask);return (uint64_t)w<<32|r;
}
