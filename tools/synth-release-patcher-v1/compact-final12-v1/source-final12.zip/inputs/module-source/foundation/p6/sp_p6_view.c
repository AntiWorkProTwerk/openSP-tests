#include "sp_p6_view.h"
#include "sp_synth_oled_font.h"
#include <stddef.h>
#include <string.h>

static void pixel(uint8_t *f,int x,int y) {
    if((unsigned)x<128 && (unsigned)y<64)f[(unsigned)y*16+(unsigned)x/8]|=(uint8_t)(0x80u>>(x&7));
}
static void horizontal(uint8_t *f,int x,int y,int length) {for(int i=0;i<length;++i)pixel(f,x+i,y);}
static void vertical(uint8_t *f,int x,int a,int b) {
    if(a>b){int t=a;a=b;b=t;}for(int y=a;y<=b;++y)pixel(f,x,y);
}
static void line(uint8_t *f,int x0,int y0,int x1,int y1) {
    int dx=x1-x0,dy=y1-y0;
    if(dx<0)dx=-dx;
    int sign=dy<0?-1:1;if(dy<0)dy=-dy;
    if(dx>=dy){for(int i=0;i<=dx;++i)pixel(f,x0+i,y0+(dx?sign*(dy*i+dx/2)/dx:0));}
    else for(int i=0;i<=dy;++i)pixel(f,x0+(dy?(dx*i+dy/2)/dy:0),y0+sign*i);
}
static void text(uint8_t *f,int x,int y,const char *s,int large,int limit) {
    const int width=large?5:3,height=large?7:5,advance=width+1;
    while(*s && x+width<=limit){
        unsigned ch=(unsigned char)*s++;
        if(ch>='a' && ch<='z')ch-='a'-'A';
        if(ch<32 || ch>90)ch='?';
        const uint8_t *rows=large?sp_oled_font_large[ch-32]:sp_oled_font_small[ch-32];
        for(int row=0;row<height;++row)for(int col=0;col<width;++col)
            if(rows[row]&(1u<<(width-1-col)))pixel(f,x+col,y+row);
        x+=advance;
    }
}
static void number(uint8_t *f,int x,int y,unsigned n,int large,int limit) {
    char s[4];unsigned len=0;
    if(n>=100)s[len++]='1';
    if(n>=10)s[len++]=(char)('0'+(n/10)%10);
    s[len++]=(char)('0'+n%10);s[len]=0;text(f,x,y,s,large,limit);
}
static const char *page_name(const SpP4ControlView *c,const SpP6MenuView *m) {
    static const char *const names[]={"","MENU","SOUND","VOICE","RECORD","USB DEMO"};
    return m->page?names[m->page]:sp_p4_controls_page_name(c->page);
}
static int pending(const SpP4ControlView *c,const SpPreviewVisualSnapshot *s) {
    return c->command_ticket!=c->command_ack || (s &&
        (s->command_ticket!=c->command_ticket || (s->flags&SP_VISUAL_MIXED) ||
         s->applied_mono!=c->mono || s->applied_preset!=c->preset));
}
static void header(uint8_t *f,const SpP4ControlView *c,const SpPreviewVisualSnapshot *s,const SpP6MenuView *m) {
    text(f,3,1,page_name(c,m),0,46);
    text(f,48,1,!s?"WAIT":s->applied_mono?"MONO":"POLY4",0,78);
    if(s)number(f,88,1,s->active_voices,0,92);else text(f,88,1,"-",0,92);
    text(f,92,1,"/4",0,108);
    for(unsigned i=0;i<4;++i){
        int x=112+(int)i*3;
        horizontal(f,x,6,2);
        if(s && i<s->active_voices){vertical(f,x,2,6);vertical(f,x+1,2,6);}
    }
    horizontal(f,3,9,122);
}
static int sample_y(int value,int center,int amplitude) {
    value*=3;if(value<-127)value=-127;if(value>127)value=127;
    return center-value*amplitude/127;
}
static void pcm(uint8_t *f,const SpPreviewVisualSnapshot *s,int center,int amplitude) {
    if(!s){horizontal(f,3,center,96);return;}
    int previous=sample_y((s->minimum[0]+s->maximum[0])/2,center,amplitude);
    for(unsigned i=0;i<96;++i){
        int value=sample_y((s->minimum[i]+s->maximum[i])/2,center,amplitude);
        vertical(f,3+(int)i,sample_y(s->maximum[i],center,amplitude),sample_y(s->minimum[i],center,amplitude));
        if(i)vertical(f,3+(int)i,previous,value);
        previous=value;
    }
}
static void footer(uint8_t *f,const char *s) {horizontal(f,3,55,122);text(f,3,58,s,0,125);}
static void preset_row(uint8_t *f,int x,int y,unsigned preset,int large,int limit) {
    char n[4]={(char)('0'+(preset+1)/10),(char)('0'+(preset+1)%10),' ',0};
    text(f,x,y,n,large,limit);text(f,x+(large?18:12),y,sp_synth_preview_preset_name(preset),large,limit);
}
static void select_row(uint8_t *f,int y) {pixel(f,3,y+1);horizontal(f,3,y+2,3);pixel(f,3,y+3);}
static void menu(uint8_t *f,const SpP4ControlView *c,const SpPreviewVisualSnapshot *s,const SpP6MenuView *m) {
    const char *hint="VAL:ENTER EXIT:PLAY";
    switch(m->page){
    case SP_P6_MENU:
        text(f,10,12,"SOUND",0,34);preset_row(f,38,12,c->preset,0,125);
        text(f,10,21,"VOICE",0,34);text(f,38,21,c->mono?"MONO":"POLY4",0,125);
        text(f,10,30,"RECORD",0,38);text(f,42,30,"UNAVAILABLE",0,125);
        text(f,10,39,"USB DEMO",0,46);
        text(f,50,39,m->demo_status==0?"OFF":m->demo_status==1?"WAIT PC":"CONNECTED",0,125);
        select_row(f,12+(int)m->selection*9);break;
    case SP_P6_SOUND: {
        unsigned first=m->preset>1?m->preset-1:0;if(first>12)first=12;
        for(unsigned i=0;i<4;++i){
            unsigned p=first+i;int y=12+(int)i*9;
            preset_row(f,10,y,p,0,117);
            if(p==m->preset)select_row(f,y);
            if(p==c->preset)text(f,121,y,"*",0,125);
        }
        hint="VAL:LOAD EXIT:BACK";break;
    }
    case SP_P6_VOICE:
        text(f,10,12,"MONO  1 VOICE",0,125);text(f,10,21,"POLY4  4 VOICES",0,125);
        select_row(f,m->mono?12:21);
        text(f,10,30,"APPLIED:",0,42);text(f,46,30,!s?"WAIT":s->applied_mono?"MONO":"POLY4",0,125);
        text(f,10,39,pending(c,s)?"UPDATE PENDING":"PADS: PLAY",0,125);
        hint="VAL:SET EXIT:BACK";break;
    case SP_P6_RECORD:
        text(f,10,14,"PATTERN RECORD",0,125);text(f,10,25,"UNAVAILABLE",1,125);
        text(f,10,39,"PLAYING TRIAL",0,125);hint="EXIT:BACK PADS:PLAY";break;
    case SP_P6_DEMO:
        text(f,10,14,m->demo_status==0?"EXPORT OFF":m->demo_status==1?"WAIT FOR PC":"PC CONNECTED",1,125);
        text(f,10,29,"SYNTH SCREEN+CTRL",0,125);text(f,10,39,"AUDIO: PC INPUT",0,125);
        hint=m->demo_status==0?"VAL:ON EXIT:BACK":"VAL:OFF EXIT:BACK";break;
    default:break;
    }
    pcm(f,s,50,2);text(f,104,48,!s?"WAIT":pending(c,s)?"UPD":"PCM",0,125);footer(f,hint);
}
static unsigned duration_ms(unsigned v,unsigned base,unsigned span,unsigned power) {
    uint64_t numerator=(uint64_t)v*v;uint64_t denominator=(uint64_t)4095*4095;
    if(power==3){numerator*=v;denominator*=4095;}
    return base+(unsigned)((numerator*span+denominator/2)/denominator);
}
static void marker(uint8_t *f,int x,int y) {horizontal(f,x-1,y,3);vertical(f,x,y-1,y+1);}
static void envelope(uint8_t *f,const SpP4ControlView *c,const SpPreviewVisualSnapshot *s) {
    unsigned a=duration_ms(c->values[6],1,3000,3),d=duration_ms(c->values[7],15,2000,2),r=duration_ms(c->values[8],20,4000,3);
    unsigned sum=a+d+r;int aw=8+(int)(58*a/sum),dw=8+(int)(58*d/sum),rw=95-13-aw-dw;
    SpPreviewPresetInfo info;sp_synth_preview_preset_info(c->preset,&info);
    int sustain=43-(int)((info.sustain*8u+127u)/255u);
    for(int x=0;x<=aw;++x)pixel(f,3+x,43-(8*x*x*(3*aw-2*x))/(aw*aw*aw));
    line(f,3+aw,35,3+aw+dw,sustain);horizontal(f,3+aw+dw,sustain,14);
    line(f,3+aw+dw+13,sustain,98,43);
    text(f,104,36,"ADSR",0,125);
    if(!s)return;
    /* Highest captured envelope, stable lowest-index tie. This is a single
     * representative voice; the PCM and activity remain the complete mix. */
    unsigned voice=0;for(unsigned i=1;i<4;++i)if(s->envelope[i]>s->envelope[voice])voice=i;
    unsigned stage=s->envelope_stage[voice],p=s->envelope_progress[voice];int x,y;
    switch(stage){
    case 1:x=3+(int)(aw*p/255);y=43-(int)(8*p*p*(765-2*p)/(255u*255u*255u));break;
    case 2:x=3+aw+(int)(dw*p/255);y=35+(int)((sustain-35)*p/255);break;
    case 3:x=3+aw+dw+6;y=sustain;break;
    case 4:x=3+aw+dw+13+(int)(rw*p/255);y=sustain+(int)((43-sustain)*p/255);break;
    default:return;
    }
    /* Keep the marker wholly within the 96x9 schematic region. */
    if(x<4)x=4;
    if(x>97)x=97;
    if(y<36)y=36;
    if(y>42)y=42;
    marker(f,x,y);
}
static void filter(uint8_t *f,const SpP4ControlView *c) {
    int knee=10+(int)(c->values[0]*75u/4095u),peak=(int)(c->values[1]*4u/4095u),env=(int)(c->values[2]*10u/4095u);
    SpPreviewPresetInfo info;sp_synth_preview_preset_info(c->preset,&info);
    int highpass=info.filter_mode==SP_FILTER_HP12;
    int start=highpass?43:39,end=highpass?39:43;
    horizontal(f,3,start,knee-3);line(f,knee,start,knee+3,39-peak);
    line(f,knee+3,39-peak,knee+10,end);horizontal(f,knee+10,end,99-knee-10);
    for(int x=knee+env+3;x<knee+env+11 && x<99;x+=2)pixel(f,x,35);
    text(f,104,36,"FILT",0,125);
}
static void pulse(uint8_t *f,const SpP4ControlView *c) {
    int width=10+(int)(c->values[5]*76u/4095u),height=2+(int)(c->values[3]*2u/4095u),shift=1+(int)(c->values[4]*6u/4095u);
    horizontal(f,3,39-height,width);vertical(f,3+width,39-height,39+height);horizontal(f,3+width,39+height,96-width);
    for(int x=3;x<99;x+=3){int relative=x-3-shift;pixel(f,x,relative>=0 && relative<width?35:43);}
    text(f,104,36,"PULSE",0,125);
}
static void modulation(uint8_t *f,const SpP4ControlView *c,const SpPreviewVisualSnapshot *s) {
    /* A small integer sine stands for bipolar modulation. Rate changes the
     * period, depth the span; glide has its own ramp. The captured LFO value
     * moves the right marker vertically; it does not claim an elapsed phase. */
    static const int8_t sine[32]={0,25,49,71,90,106,117,125,127,125,117,106,90,71,49,25,0,-25,-49,-71,-90,-106,-117,-125,-127,-125,-117,-106,-90,-71,-49,-25};
    int period=76-(int)(c->values[9]*60u/4095u),amp=1+(int)(c->values[10]*3u/4095u);
    for(int x=0;x<76;++x)pixel(f,3+x,39-sine[(x*32/period)%32]*amp/127);
    int glide=2+(int)(c->values[11]*13u/4095u);line(f,81,43,81+glide,35);horizontal(f,81+glide,35,18-glide);
    if(s){int value=s->lfo;if(value<-127)value=-127;marker(f,97,39-value*3/127);}
    text(f,104,36,"LFO",0,125);
}
int sp_p6_view_render(const SpPreviewNativeView *v,const SpPreviewVisualSnapshot *s,const SpP6MenuView *m,uint8_t frame[1024]) {
    if(!v || !m || !frame || v->state!=SP_PREVIEW_NATIVE_ACTIVE)return 0;
    const SpP4ControlView *c=&v->controls;
    if(c->page>=4 || c->preset>=16 || c->mono>1 || c->octave<-2 || c->octave>2 ||
       (c->known_mask|c->pickup_mask|c->baseline_mask)>7 || m->page>SP_P6_DEMO ||
       m->selection>3 || m->preset>=16 || m->mono>1 || m->demo_status>2)return 0;
    for(unsigned i=0;i<12;++i)if(c->values[i]>4095)return 0;
    for(unsigned i=0;i<3;++i)if(c->knobs[i]>4095)return 0;
    if(s){
        if(!s->sequence || s->active_voices>4 || s->active_pad>16 || s->held_pad_mask>65535 ||
           s->flags>63 || s->applied_preset>=16 || s->applied_mono>1 || s->peak_i16>14745)return 0;
        for(unsigned i=0;i<96;++i)if(s->minimum[i]>s->maximum[i])return 0;
        for(unsigned i=0;i<4;++i)if(s->envelope_stage[i]>4)return 0;
    }
    memset(frame,0,1024);header(frame,c,s,m);
    if(m->page){menu(frame,c,s,m);return 1;}
    preset_row(frame,3,11,c->preset,1,c->modified?93:98);
    if(c->modified)text(frame,93,11,"*",1,98);
    char octave[7]={'O','C','T',' ',c->octave<0?'-':'+',(char)('0'+(c->octave<0?-c->octave:c->octave)),0};
    text(frame,101,11,octave,0,125);
    pcm(frame,s,26,7);
    const char *status=!s?"WAIT":pending(c,s)?"UPD":(s->flags&(SP_VISUAL_TERMINAL|SP_VISUAL_SILENT))?"IDLE":s->held_pad_mask?"PLAY":s->active_voices?"REL":"IDLE";
    text(frame,104,21,status,0,125);
    int crop=0;if(s)for(unsigned i=0;i<96;++i)if(s->minimum[i]<-42 || s->maximum[i]>42)crop=1;
    text(frame,104,28,s && s->clipped_samples?"CLP":crop?"Z!":"Z3",0,125);
    switch(c->page){case 0:filter(frame,c);break;case 1:pulse(frame,c);break;case 2:envelope(frame,c,s);break;case 3:modulation(frame,c,s);break;}
    for(unsigned j=0;j<3;++j){
        unsigned p=c->page*3+j,x=3+j*42,value=(c->values[p]*100u+2047u)/4095u;
        const char *label=p==11?"GLD":sp_p4_controls_parameter_name(p);
        text(frame,(int)x,45,label,0,(int)x+23);
        unsigned digits=value>=100?3:value>=10?2:1;number(frame,(int)x+40-(int)digits*4,45,value,0,(int)x+40);
        horizontal(frame,(int)x,53,39);horizontal(frame,(int)x,52,(int)((c->values[p]*38u+2047u)/4095u));
    }
    footer(frame,"VAL:SND/PAGE SHIFT:MENU");return 1;
}
