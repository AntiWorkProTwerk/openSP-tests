#include "sp_p4_controls.h"
#include <stddef.h>

_Static_assert(SP_PREVIEW_PARAMETERS==SP_P4_PAGES*SP_P4_KNOBS,"P5 page mapping");
_Static_assert(SP_PREVIEW_PRESETS==16,"P5 preset bank");
_Static_assert(sizeof(SpP4ControlView)==72,"Preserved copied P4 view ABI");

static uint32_t normalize(uint32_t value) {return (value*4095u+63u)/127u;}
static void anchor(SpP4Controls *s) {
    SpP4ControlView *v=&s->view;
    v->pickup_mask=0;v->baseline_mask=7u&~v->known_mask;
    for(unsigned knob=0;knob<3;++knob) {
        s->anchor_knobs[knob]=v->knobs[knob];
        s->anchor_values[knob]=v->values[v->page*3+knob];
    }
}
static void preset_shadow(SpP4Controls *s,unsigned preset) {
    SpP4ControlView *v=&s->view;
    v->preset=preset;v->modified=0;
    v->mono=sp_synth_preview_preset_mono(preset);
    v->octave=sp_synth_preview_preset_octave(preset);
    for(unsigned p=0;p<SP_PREVIEW_PARAMETERS;++p)
        v->values[p]=sp_synth_preview_preset_value(preset,p);
    anchor(s);
}
int sp_p4_controls_init(SpP4Controls *s) {
    if(!s || s->initialized)return 0;
    s->view=(SpP4ControlView){0};preset_shadow(s,0);
    s->initialized=1;return 1;
}
int sp_p4_controls_snapshot(const SpP4Controls *s,SpP4ControlView *out) {
    if(!s || s->initialized!=1 || !out)return 0;
    *out=s->view;return 1;
}
int sp_p4_controls_seed(SpP4Controls *s,int32_t index,int32_t value) {
    if(!s || s->initialized!=1 || index<1 || index>3 || value<0 || value>127 ||
       s->view.page>=SP_P4_PAGES)return 0;
    unsigned knob=(unsigned)index-1;uint32_t bit=1u<<knob;
    uint16_t current=(uint16_t)normalize((uint32_t)value);
    s->view.knobs[knob]=current;s->view.known_mask|=bit;
    s->view.baseline_mask&=~bit;s->view.pickup_mask&=~bit;
    s->anchor_knobs[knob]=current;
    s->anchor_values[knob]=s->view.values[s->view.page*3+knob];
    return 1;
}
int sp_p4_controls_forget(SpP4Controls *s,int32_t index) {
    if(!s || s->initialized!=1 || index<1 || index>3)return 0;
    uint32_t bit=1u<<((unsigned)index-1);
    s->view.known_mask&=~bit;s->view.baseline_mask|=bit;return 1;
}
int sp_p4_controls_ctrl(SpP4Controls *s,SpSynthPreviewVoice *voice,int32_t index,int32_t value) {
    if(!s || s->initialized!=1 || !voice || index<1 || index>3 || value<0 || value>127)return 0;
    SpP4ControlView *v=&s->view;
    if(v->page>=SP_P4_PAGES)return 0;
    unsigned knob=(unsigned)index-1,parameter=v->page*3+knob;
    uint32_t bit=1u<<knob,current=normalize((uint32_t)value);
    if(!(v->known_mask&bit) || (v->baseline_mask&bit))
        return sp_p4_controls_seed(s,index,value);
    uint32_t x=s->anchor_knobs[knob],y=s->anchor_values[knob],target;
    if(current==x)target=y;
    else if(current>x) {
        uint32_t span=4095u-x;
        target=y+((4095u-y)*(current-x)+span/2u)/span;
    } else {
        target=y-(y*(x-current)+x/2u)/x;
    }
    /* A rejected queue still leaves the observed physical position available
     * for the screen. The parameter and fixed binding anchors stay unchanged. */
    v->knobs[knob]=(uint16_t)current;
    if(target!=v->values[parameter] &&
       !sp_synth_preview_voice_parameter(voice,parameter,target))return 0;
    if(target!=v->values[parameter]) {v->values[parameter]=(uint16_t)target;v->modified=1;}
    if(current!=x && (current==0 || current==4095)) {
        s->anchor_knobs[knob]=(uint16_t)current;
        s->anchor_values[knob]=(uint16_t)target;
    }
    return 1;
}
int sp_p4_controls_turn(SpP4Controls *s,SpSynthPreviewVoice *voice,int32_t delta,int shift) {
    if(!s || s->initialized!=1 || !voice || !delta || (shift!=0 && shift!=1))return 0;
    SpP4ControlView *v=&s->view;int step=delta<0?-1:1;
    if(shift) {
        int target=v->octave+step;
        if(target<-2 || target>2)return 1;
        if(!sp_synth_preview_voice_octave(voice,target))return 0;
        v->octave=target;v->modified=1;return 1;
    }
    int target=(int)v->preset+step;
    if(target<0 || target>=SP_PREVIEW_PRESETS)return 1;
    if(!sp_synth_preview_voice_preset(voice,(unsigned)target))return 0;
    preset_shadow(s,(unsigned)target);return 1;
}
int sp_p4_controls_press(SpP4Controls *s,SpSynthPreviewVoice *voice,int shift) {
    if(!s || s->initialized!=1 || !voice || (shift!=0 && shift!=1))return 0;
    SpP4ControlView *v=&s->view;
    if(shift) {
        uint32_t mono=!v->mono;
        if(!sp_synth_preview_voice_mono(voice,(int)mono))return 0;
        v->mono=mono;v->modified=1;return 1;
    }
    v->page=(v->page+1)%SP_P4_PAGES;anchor(s);return 1;
}
int sp_p4_controls_mode(SpP4Controls *s,SpSynthPreviewVoice *voice,int mono) {
    if(!s || s->initialized!=1 || !voice || (mono!=0 && mono!=1))return 0;
    if(s->view.mono==(uint32_t)mono)return 1;
    if(!sp_synth_preview_voice_mono(voice,mono))return 0;
    s->view.mono=(uint32_t)mono;s->view.modified=1;return 1;
}
const char *sp_p4_controls_page_name(unsigned page) {
    static const char *const names[SP_P4_PAGES]={"TONE","OSC","AMP","MOD"};
    return page<SP_P4_PAGES?names[page]:"?";
}
const char *sp_p4_controls_parameter_name(unsigned parameter) {
    static const char *const names[SP_PREVIEW_PARAMETERS]={
        "CUT","RES","ENV","MIX","DET","PW","ATK","DEC","REL","RATE","DEP","GLIDE"
    };
    return parameter<SP_PREVIEW_PARAMETERS?names[parameter]:"?";
}
