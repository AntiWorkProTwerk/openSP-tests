#ifndef SP_DEMO_PROTOCOL_H
#define SP_DEMO_PROTOCOL_H
#include <stdint.h>

enum { SP_DEMO_VERSION=1, SP_DEMO_HEADER=32, SP_DEMO_FRAME_BYTES=1024,
       SP_DEMO_META_BYTES=72, SP_DEMO_MAX_PAYLOAD=1096,
       SP_DEMO_MAX_RECORD=1132, SP_DEMO_EVENT_BYTES=24,
       SP_DEMO_EVENT_CAPACITY=64, SP_DEMO_EVENT_BATCH=16 };
enum { SP_DEMO_SESSION=1, SP_DEMO_FRAME=2, SP_DEMO_EVENTS=3,
       SP_DEMO_STATE=4, SP_DEMO_CLOCK=5, SP_DEMO_GAP=6 };
enum { SP_DEMO_PAD1=1, SP_DEMO_CTRL1=17, SP_DEMO_CTRL2=18,
       SP_DEMO_CTRL3=19, SP_DEMO_VALUE_TURN=20,
       SP_DEMO_VALUE_PRESS=21, SP_DEMO_SHIFT=22 };
enum { SP_DEMO_DOWN=1, SP_DEMO_UP=2, SP_DEMO_ABSOLUTE=3,
       SP_DEMO_RELATIVE=4 };
enum { SP_DEMO_SYNTH_SCREEN=1, SP_DEMO_NAMED_CONTROLS=2,
       SP_DEMO_PASSIVE_CLOCK=4, SP_DEMO_GLOBAL_SCREEN=8 };
enum { SP_DEMO_GAP_RECONNECT=1, SP_DEMO_GAP_EVENTS=2,
       SP_DEMO_GAP_FRAMES=4, SP_DEMO_GAP_EXHAUSTED=8 };

/* Encoders write fields explicitly. No native struct layout is a wire ABI.
 * META/STATE offsets: capture_ticks64@0, frame_sequence32@8,
 * pcm_end_frame32@12, command_ticket32@16, command_ack32@20,
 * held_pad_mask32@24, control_valid_mask32@28,
 * preset/page/requested_mono/applied_preset/applied_mono/active_voices/
 * visual_flags/octave_i8 @32..39, envelope4*u16@40,
 * CTRL1..3 u16@48, VALUE_down/SHIFT u8@54..55,
 * VALUE cumulative i32@56, state_revision32@60,
 * envelope_stage4*u8@64, envelope_progress4*u8@68.
 * Metadata corresponds to the bitmap capture. PCM fields and applied mode
 * come from the same completed visual window; requested mode is UI shadow.
 */
typedef struct {
    uint64_t capture_ticks;
    uint32_t frame_sequence,pcm_end_frame,command_ticket,command_ack;
    uint32_t held_pad_mask,control_valid_mask;
    uint8_t preset,page,requested_mono,applied_preset,applied_mono;
    uint8_t active_voices,visual_flags;
    int8_t octave;
    uint16_t envelope[4],ctrl[3];
    uint8_t value_down,shift;
    int32_t value_total;
    uint32_t state_revision;
    uint8_t envelope_stage[4],envelope_progress[4];
} SpDemoMeta;
typedef struct {
    uint32_t sequence;
    uint64_t ticks;
    uint16_t control;
    uint8_t kind,flags;
    int32_t value;
    uint32_t aux;
} SpDemoEvent;
#endif
