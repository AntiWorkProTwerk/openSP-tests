#include "sp_p6_record_project_gate_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_record_token_v552.h"
#include "sp_p6_record_context_v552.h"
#include <stddef.h>
#include "sp_p6_transaction_ingress_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_ingress_alias_v552.h"
#include "sp_p6_record_mutation_closure_v552.h"
extern uint32_t sp_p6_clock_project(uint32_t,uint32_t,uint32_t,uint32_t);

#define SETTER 0x800DED18u
#define OBJECT 0x82E009D0u
SpP6RecordProjectGateV552 sp_p6_record_project_gate_v552;
_Static_assert(sizeof(SpP6RecordProjectGateV552)==236,"Project gate permanent owner budget");
static uint32_t rd(uint32_t a) { return *(volatile const uint32_t *)(uintptr_t)a; }
static uint32_t lock(void) { uint32_t p;__asm__ volatile("mrs %0, primask\n cpsid i":"=r"(p)::"memory");return p; }
static void unlock(uint32_t p) { __asm__ volatile("dmb\n msr primask, %0"::"r"(p):"memory"); }
static uint32_t task(void) {
    uint32_t ip,pm,bp,fm;
    __asm__ volatile("mrs %0, ipsr":"=r"(ip));__asm__ volatile("mrs %0, primask":"=r"(pm));
    __asm__ volatile("mrs %0, basepri":"=r"(bp));__asm__ volatile("mrs %0, faultmask":"=r"(fm));
    if(ip || pm || bp || fm || rd(0x202BBBF8u) || rd(0x80245764u))return 0;
    uint32_t t=((uint32_t (*)(void))(uintptr_t)0x800D3163u)();
    return t && t<=32?t:0;
}
static int installed(void) {
    return sp_p6_tx_v552_coverage() && sp_p6_mc_v552_hook_coverage() && rd(SETTER)==0xF000F8DFu && rd(SETTER+4)==((uint32_t)(uintptr_t)sp_p6_clock_project|1u) &&
        *(volatile const uint16_t *)(uintptr_t)(SETTER+8)==0xBF00u;
}
static int clear(void) {
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    return installed() && !g->active && !g->count && !g->fault && g->generation<UINT32_MAX;
}
int sp_p6_record_project_gate_v552_bind_locked(void) { return clear(); }
int sp_p6_record_project_gate_v552_prepare(SpSynthCaptureTimedV552 *c) {
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    uint32_t current=task(),context=sp_p6_record_context_v552_current(1),p=lock();
    if(!c || c!=o->capture || !context || current!=sp_p6_record_contexts_v552.smpl_task || !clear() || o->held || o->active || o->fault ||
       atomic_load_explicit(&c->state,memory_order_acquire)!=SP_TCAP_BEGIN || !c->last_token ||
       atomic_load_explicit(&c->token,memory_order_acquire)!=c->last_token || c->plan.take_token!=c->last_token ||
       rd(0x805923FCu)>=128) { unlock(p);return 0; }
    g->prepared_generation=g->generation;g->prepared_token=c->last_token;g->prepared_project=rd(0x805923FCu);
    unlock(p);return 1;
}
int sp_p6_record_project_gate_v552_begin_locked(SpSynthCaptureTimedV552 *c) {
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    return c && c==sp_p6_record_producer_v552.capture && clear() &&
        g->prepared_token==c->last_token && g->prepared_generation==g->generation &&
        g->prepared_project==rd(0x805923FCu);
}
int sp_p6_record_project_gate_v552_pending_locked(void) { return sp_p6_record_project_gate_v552.count!=0; }
uint32_t sp_p6_record_project_gate_v552_generation(void) {
    uint32_t p=lock();
    uint32_t r=clear()?sp_p6_record_project_gate_v552.generation:0;
    unlock(p);return r;
}
static uint32_t execute(SpP6ProjectCommandV552 command) {
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    uint32_t result=sp_p6_tx_v552_command(command)?
        sp_p6_tx_v552_original(command):sp_p6_mc_v552_original(command);
    uint32_t current=command.task?task():0,p=lock();
    if(g->active!=1 || g->task!=current || current!=command.task || !installed())g->fault|=8;
    g->active=0;g->task=0;unlock(p);return result;
}
uint32_t sp_p6_record_project_gate_v552_setter(uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    if(b!=132)return sp_p6_pg_setter_original_v552(a,b,c,d);
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    uint32_t current=task(),p=lock();
    /* Every direct and virtual call to this entry is admitted before the
     * original validator, configuration store D3B68 and cache reset D8A80. */
    if(!installed() || !current || a!=OBJECT || g->active || g->fault || g->generation==UINT32_MAX) {
        g->fault|=1;unlock(p);return SP_P6_PROJECT_DEFERRED;
    }
    if(o->held || g->count) {
        uint32_t token=o->held?o->token:g->commands[g->head].token;
        if(!o->capture || !token || (o->held && token<=o->last_retired) || c>=128 ||
           g->count>=SP_P6_PROJECT_QUEUE_CAPACITY || g->retained==UINT32_MAX) {
            g->fault|=2;unlock(p);return SP_P6_PROJECT_DEFERRED;
        }
        uint32_t i=(g->head+g->count)%SP_P6_PROJECT_QUEUE_CAPACITY;
        g->commands[i]=(SpP6ProjectCommandV552){a,b,c,d,current,token};
        g->count++;g->retained++;o->pending=1;unlock(p);return SP_P6_PROJECT_DEFERRED;
    }
    /* A queued deferred setter cannot be overtaken by a fresh direct setter.
     * Any token/journal mismatch also refuses; no ordinary fallback runs. */
    if(o->fault || sp_p6_record_files_v552.active || sp_p6_record_token_v552_current()) {
        g->fault|=4;unlock(p);return SP_P6_PROJECT_DEFERRED;
    }
    g->generation++;g->active=1;g->task=current;
    unlock(p);return execute((SpP6ProjectCommandV552){a,b,c,d,current,0});
}
int sp_p6_record_project_gate_v552_replay(void) {
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    uint32_t current=task(),p=lock();
    if(!g->count) { unlock(p);return 1; }
    if(g->fault || g->active || !installed() || current!=o->task || !o->active ||
       o->held || o->fault || !o->capture || sp_p6_record_files_v552.active || sp_p6_record_token_v552_current()) {
        unlock(p);return 0;
    }
    /* One callback replays at most eight retained calls. New BEGIN remains
     * excluded by producer.active and count until all native returns finish. */
    uint32_t remaining=g->count;unlock(p);
    while(remaining--) {
        p=lock();
        if(!g->count || g->fault || g->active || o->held || !o->active || current!=o->task ||
           g->generation==UINT32_MAX || g->replayed==UINT32_MAX) { unlock(p);return 0; }
        SpP6ProjectCommandV552 command=g->commands[g->head];
        if(!command.token || command.token>o->last_retired) { unlock(p);return 0; }
        if(sp_p6_tx_v552_command(command)) { unlock(p);return 0; }
        command.task=current;g->generation++;g->active=1;g->task=current;unlock(p);
        (void)execute(command);p=lock();
        if(g->fault) { unlock(p);return 0; }
        g->head=(g->head+1)%SP_P6_PROJECT_QUEUE_CAPACITY;g->count--;g->replayed++;
        unlock(p);
    }
    return 1;
}

/* Appended only to the checked local project-gate derivation. The shared epoch,
 * active scope and eight-record FIFO preserve the existing prepare/BEGIN proof. */
static uint32_t direct_mutation(uint32_t operation) {
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    uint32_t ip,current=0;
    __asm__ volatile("mrs %0, ipsr":"=r"(ip));
    /* Native startup can precede the task registry and run with PRIMASK set.
     * Only an unbound producer uses this cold path; binding checks g->active. */
    if(o->capture)current=task();
    uint32_t p=lock();
    /* The stock initialized branch is bounded and nonblocking. Execute it
     * under the mask so a no-op cannot race a flag change into initialization. */
    if(operation==SP_P6_MC_INITIALIZE && installed() && !g->active &&
       *(volatile const uint8_t *)(uintptr_t)0x805923F8u) {
        uint32_t result=sp_p6_mc_v552_initialize_original();unlock(p);return result;
    }
    if(!installed() || ip || (o->capture && !current) || g->active || g->fault ||
       g->generation==UINT32_MAX || (o->active && current!=o->task)) {
        g->fault|=16;unlock(p);return SP_P6_PROJECT_DEFERRED;
    }
    if(o->held || g->count) {
        uint32_t token=o->held?o->token:g->commands[g->head].token;
        if(!o->capture || !token || (o->held && token<=o->last_retired) ||
           g->count>=SP_P6_PROJECT_QUEUE_CAPACITY || g->retained==UINT32_MAX) {
            g->fault|=32;unlock(p);return SP_P6_PROJECT_DEFERRED;
        }
        uint32_t index=(g->head+g->count)%SP_P6_PROJECT_QUEUE_CAPACITY;
        g->commands[index]=(SpP6ProjectCommandV552){0,operation,0,0,current,token};
        g->count++;g->retained++;o->pending=1;unlock(p);return SP_P6_PROJECT_DEFERRED;
    }
    if(o->fault || sp_p6_record_files_v552.active || sp_p6_record_token_v552_current()) {
        g->fault|=64;unlock(p);return SP_P6_PROJECT_DEFERRED;
    }
    g->generation++;g->active=1;g->task=current;
    unlock(p);return execute((SpP6ProjectCommandV552){0,operation,0,0,current,0});
}
uint32_t sp_p6_mc_v552_reset(void) { return direct_mutation(SP_P6_MC_RESET); }
uint32_t sp_p6_mc_v552_initialize(void) { return direct_mutation(SP_P6_MC_INITIALIZE); }

uint32_t sp_p6_tx_gate_request(SpP6ProjectCommandV552 command){
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    uint32_t ip,current=0;__asm__ volatile("mrs %0, ipsr":"=r"(ip));
    if(o->capture)current=task();
    uint32_t p=lock();
    if(ip || !sp_p6_tx_v552_command(command) || !installed() || g->active || g->fault || g->generation==UINT32_MAX ||
       (o->capture && (!current || current!=sp_p6_record_contexts_v552.smpl_task || !sp_p6_ia_v552_quiescent())) ||
       (o->active && current!=o->task)){
        g->fault|=256;unlock(p);return SP_P6_PROJECT_DEFERRED;
    }
    command.task=current;command.token=0;
    if(o->held || g->count){
        uint32_t token=o->held?o->token:g->commands[g->head].token;
        if(!o->capture || !token || (o->held && token<=o->last_retired) ||
           g->count>=SP_P6_PROJECT_QUEUE_CAPACITY || g->retained==UINT32_MAX){
            g->fault|=512;unlock(p);return SP_P6_PROJECT_DEFERRED;
        }
        command.token=token;g->commands[(g->head+g->count)%SP_P6_PROJECT_QUEUE_CAPACITY]=command;
        g->count++;g->retained++;o->pending=1;unlock(p);return SP_P6_PROJECT_DEFERRED;
    }
    if(o->fault || sp_p6_record_files_v552.active || sp_p6_record_token_v552_current()){
        g->fault|=1024;unlock(p);return SP_P6_PROJECT_DEFERRED;
    }
    g->generation++;g->active=1;g->task=current;unlock(p);return execute(command);
}
uint32_t sp_p6_tx_gate_service(uint32_t current){
    SpP6RecordProjectGateV552 *g=&sp_p6_record_project_gate_v552;
    SpP6RecordProducerV552 *o=&sp_p6_record_producer_v552;
    uint32_t p=lock(),remaining=g->count;unlock(p);
    while(remaining--){
        p=lock();
        if(!g->count){unlock(p);return 1;}
        SpP6ProjectCommandV552 command=g->commands[g->head];
        if(!sp_p6_tx_v552_command(command)){unlock(p);return 0;}
        if(g->fault || g->active || o->active || o->held || o->fault || !o->capture ||
           !installed() || !sp_p6_ia_v552_quiescent() || current!=command.task || current!=sp_p6_record_contexts_v552.smpl_task ||
           !command.token || command.token>o->last_retired ||
           sp_p6_record_files_v552.active || sp_p6_record_token_v552_current() ||
           g->generation==UINT32_MAX || g->replayed==UINT32_MAX){unlock(p);return 0;}
        g->generation++;g->active=1;g->task=current;unlock(p);(void)execute(command);p=lock();
        if(g->fault){unlock(p);return 0;}
        g->head=(g->head+1)%SP_P6_PROJECT_QUEUE_CAPACITY;g->count--;g->replayed++;unlock(p);
    }
    return 1;
}
