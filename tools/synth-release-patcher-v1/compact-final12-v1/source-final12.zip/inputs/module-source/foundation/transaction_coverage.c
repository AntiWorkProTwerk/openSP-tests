#include "sp_p6_transaction_ingress_v552.h"
uint32_t sp_p6_tx_v552_coverage(void){
if(*(volatile const uint32_t*)0x8004D8B8u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x8004D8BCu!=((uint32_t)(uintptr_t)sp_p6_tx_v552_packet|1u) ||
*(volatile const uint16_t*)0x8004D8C0u!=0x7800u)return 0;
if(*(volatile const uint32_t*)0x800554D0u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x800554D4u!=((uint32_t)(uintptr_t)sp_p6_tx_v552_load|1u) ||
*(volatile const uint16_t*)0x800554D8u!=0xBF00u)return 0;
if(*(volatile const uint32_t*)0x8004C230u!=0xF000F8DFu ||
*(volatile const uint32_t*)0x8004C234u!=((uint32_t)(uintptr_t)sp_p6_tx_v552_dequeue|1u) ||
*(volatile const uint16_t*)0x8004C238u!=0xBF00u)return 0;
return 1;}
