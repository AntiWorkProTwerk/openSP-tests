#ifndef SP_P6_RECORD_PRODUCER_V552_H
#define SP_P6_RECORD_PRODUCER_V552_H
#include "sp_synth_capture_timed_v552.h"

typedef struct {
    SpSynthCaptureTimedV552 *capture;
    uint32_t held,token,active,task,pending,fault,callbacks,dispatches,replays,wakes,last_retired,drain_requested;
} SpP6RecordProducerV552;
extern SpP6RecordProducerV552 sp_p6_record_producer_v552;

/* Called only by the checked intrinsic init/BEGIN/retirement derivation.
 * Pointer publication is once-only. Neither callback takes a ready flag,
 * caller token, project-loaded flag or an exclusive-owner assertion. */
int sp_p6_record_producer_v552_bind(SpSynthCaptureTimedV552 *);
int sp_p6_record_producer_v552_begin(SpSynthCaptureTimedV552 *);
int sp_p6_record_producer_v552_released(SpSynthCaptureTimedV552 *);
/* Bounded native event8 attempt; pending clears only at a real empty drain. */
int sp_p6_record_producer_v552_wake(void);
uint32_t sp_p6_record_producer_v552_callback(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_producer_v552_dispatch(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_rp_dispatch_original_v552(uint32_t,uint32_t,uint32_t,uint32_t);
#endif
