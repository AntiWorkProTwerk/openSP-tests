#ifndef SP_P6_RECORD_FILES_V552_H
#define SP_P6_RECORD_FILES_V552_H
#include <stdint.h>

enum { SP_P6_RF_NONE=0,SP_P6_RF_TEMP=1,SP_P6_RF_READER=2,SP_P6_RF_PROJECT=3,SP_P6_RF_CACHE=4,SP_P6_RF_DIRECTORY=5,SP_P6_RF_PROJECT_READER=6 };
enum { SP_P6_RF_EMPTY=0,SP_P6_RF_LIVE=1,SP_P6_RF_CLOSED=2,SP_P6_RF_UNCERTAIN=3 };
enum { SP_P6_RF_START=1,SP_P6_RF_RECORD=2,SP_P6_RF_SAVE=3,SP_P6_RF_DISCARD=4 };
enum { SP_P6_RF_CONTEXT=1,SP_P6_RF_IDENTITY=2,SP_P6_RF_IO=4,SP_P6_RF_SCOPE=8,SP_P6_RF_FULL=16 };
typedef struct {
    uint32_t kind,state,fd,file,context,task,operation,calls,close_attempted; /* bit0 public, bit1 lower consumed */
    int32_t close_raw;
    uint32_t directory_context;
} SpP6RecordFileIdentityV552;
typedef struct {
    uint32_t active,fault,serial,project,pad,smpl_operation,record_operation;
    uint32_t native_calls,refusals,retirements,cache_depth;
    char path[5][64]; /* temporary, SMP/WAV/AIF, PADCONF */
    SpP6RecordFileIdentityV552 files[15];
} SpP6RecordFilesV552;
extern SpP6RecordFilesV552 sp_p6_record_files_v552;

/* These are operation and identity observers for exact native entry routing.
 * They do not acquire project/cache producer admission. Complete readiness
 * remains0 until those boundaries, alternate allocation and bulk close join. */
uint32_t sp_p6_record_files_v552_admission(void);
uint32_t sp_p6_record_files_v552_start(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_save(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_discard(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_record(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_open(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_read(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_write(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_close(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_lower_close(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_sync(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_directory_open(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_directory_close(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_directory_read(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_cache(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_rename(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_unlink(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_alternate_open(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_copy(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_bulk_close(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_bulk_close_external(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_files_v552_cache_clear(uint32_t,uint32_t,uint32_t,uint32_t);
/* Observed obligation counts, not a release of capture token or cache ownership. */
uint32_t sp_p6_record_files_v552_outstanding(void);
#endif
