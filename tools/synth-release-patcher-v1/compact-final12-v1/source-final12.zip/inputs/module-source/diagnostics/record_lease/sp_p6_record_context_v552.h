#ifndef SP_P6_RECORD_CONTEXT_V552_H
#define SP_P6_RECORD_CONTEXT_V552_H
#include <stdint.h>

enum { SP_P6_RC_EMPTY=0, SP_P6_RC_REGISTERED=1, SP_P6_RC_TERMINAL=2 };
enum { SP_P6_RC_NATIVE_CONTEXT_BYTES=0x1218, SP_P6_RC_CONTEXT_COUNT=2 };
typedef struct {
    uint32_t state, fault, activations, smpl_task, record_task, fileif_task, prior_head;
    uint32_t native[SP_P6_RC_CONTEXT_COUNT][SP_P6_RC_NATIVE_CONTEXT_BYTES/4];
} SpP6RecordContextsV552;

/* Permanent source-owned storage, initialized by the normal image BSS clear.
 * The pinned FS activation hook calls this before native GLOBAL becomes1.
 * No public setter or initialized/project-ready input exists. */
extern SpP6RecordContextsV552 sp_p6_record_contexts_v552;
void sp_p6_record_context_v552_activating(uint32_t global,uint32_t marker);
void sp_p6_record_context_v552_initializing(void);
void sp_p6_record_context_v552_init_entry(void);
uint32_t sp_p6_record_context_v552_registered(void);
/* Resolves through the actual native resolver, and rejects shared fallback.
 * Caller still needs a complete operation/file owner. */
uint32_t sp_p6_record_context_v552_current(uint32_t role);
void sp_p6_record_context_v552_revoke(uint32_t reason);

/* Four-byte BL replacement at800B3BAA. Preserves original MOVS R0,0 and
 * STR R7,[R4], R1..R12/LR/stack, including the original flags after MOVS. */
void sp_p6_record_context_v552_activate(void);
#endif
