#include "sp_p6_record_context_v552.h"
#include <stddef.h>

#define GLOBAL 0x802E7BC8u
#define GATE 0x802E7BF8u
#define FALLBACK 0x802E7C08u
#define HEAD 0x802E8E20u
#define NEXT 0x120Cu
#define ERROR 0x11E8u
#define SMPL 0x202ACD00u
#define RECORD 0x202ACFA0u
#define FILEIF 0x80596768u
SpP6RecordContextsV552 sp_p6_record_contexts_v552;
_Static_assert(sizeof(SpP6RecordContextsV552)==9292,"two permanent native contexts and activation receipt");
static uint32_t rd(uint32_t a) { return *(volatile const uint32_t *)(uintptr_t)a; }
static void wr(uint32_t a,uint32_t n) { *(volatile uint32_t *)(uintptr_t)a=n; }
static uint32_t mask(void) { uint32_t p;__asm__ volatile("mrs %0, primask\n cpsid i":"=r"(p)::"memory");return p; }
static void unmask(uint32_t p) { __asm__ volatile("msr primask, %0"::"r"(p):"memory"); }
static uint32_t task(void) {
    uint32_t ipsr,primask,basepri,faultmask;
    __asm__ volatile("mrs %0, ipsr":"=r"(ipsr));
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, basepri":"=r"(basepri));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    if(ipsr || primask || basepri || faultmask || rd(0x202BBBF8u) || rd(0x80245764u))return 0;
    return ((uint32_t (*)(void))(uintptr_t)0x800D3163u)();
}
void sp_p6_record_context_v552_revoke(uint32_t reason) {
    uint32_t p=mask();
    sp_p6_record_contexts_v552.fault|=reason?reason:1;
    sp_p6_record_contexts_v552.state=SP_P6_RC_TERMINAL;
    __asm__ volatile("dmb":::"memory");unmask(p);
}
static int ids(const SpP6RecordContextsV552 *o) {
    return o->smpl_task && o->smpl_task<=32 && o->record_task && o->record_task<=32 &&
        o->fileif_task && o->fileif_task<=32 && o->smpl_task!=o->record_task &&
        o->fileif_task!=o->smpl_task && o->fileif_task!=o->record_task &&
        rd(SMPL)==0x8022D244u && rd(RECORD)==0x8021F380u && rd(FILEIF)==0x8021D158u &&
        rd(SMPL+4)==o->smpl_task && rd(RECORD+4)==o->record_task && rd(FILEIF+4)==o->fileif_task;
}
static int node(uint32_t p) {
    uint32_t a=(uint32_t)(uintptr_t)&sp_p6_record_contexts_v552;
    return p>=0x80000000u && p<=0x84000000u-SP_P6_RC_NATIVE_CONTEXT_BYTES && !(p&3u) &&
        p!=FALLBACK && (p+SP_P6_RC_NATIVE_CONTEXT_BYTES<=a || p>=a+sizeof(sp_p6_record_contexts_v552));
}
static int prior_list(const SpP6RecordContextsV552 *o) {
    uint32_t seen=0,count=0;
    for(uint32_t p=o->prior_head;p;p=rd(p+NEXT)) {
        if(++count>32 || !node(p))return 0;
        uint32_t t=rd(p);
        if(!t || t>32 || t==o->smpl_task || t==o->record_task || (seen&(1u<<(t-1))))return 0;
        seen|=1u<<(t-1);
    }
    return 1;
}
void sp_p6_record_context_v552_initializing(void) {
    if(sp_p6_record_contexts_v552.state || sp_p6_record_contexts_v552.activations || rd(GLOBAL))
        sp_p6_record_context_v552_revoke(8);
}
void sp_p6_record_context_v552_activating(uint32_t global,uint32_t marker) {
    SpP6RecordContextsV552 *o=&sp_p6_record_contexts_v552;
    /* Called only after the native reset and gate construction, immediately
     * before the first activation store. Repeat initialization grants nothing. */
    if(o->state || o->fault || o->activations) { sp_p6_record_context_v552_revoke(1);return; }
    o->activations=1;o->smpl_task=rd(SMPL+4);o->record_task=rd(RECORD+4);
    o->fileif_task=rd(FILEIF+4);o->prior_head=rd(HEAD);
    if(global!=GLOBAL || marker!=1 || rd(GLOBAL) || !ids(o) || task()!=o->fileif_task ||
       rd(GATE)!=1 || rd(GATE+4) || !rd(GATE+8) || rd(GATE+12) ||
       rd(FALLBACK+4) || rd(FALLBACK+NEXT) || !prior_list(o)) {
        sp_p6_record_context_v552_revoke(2);return;
    }
    for(unsigned k=0;k<2;k++) {
        for(unsigned i=0;i<SP_P6_RC_NATIVE_CONTEXT_BYTES/4;i++)o->native[k][i]=rd(FALLBACK+4*i);
        o->native[k][0]=k?o->record_task:o->smpl_task;
        o->native[k][ERROR/4]=0;
        o->native[k][NEXT/4]=k?o->prior_head:(uint32_t)(uintptr_t)o->native[1];
    }
    uint32_t p=mask();
    if(rd(GLOBAL) || !ids(o) || rd(HEAD)!=o->prior_head || o->fault || rd(GATE+4) || rd(GATE+12)) {
        unmask(p);sp_p6_record_context_v552_revoke(4);return;
    }
    __asm__ volatile("dmb":::"memory");wr(HEAD,(uint32_t)(uintptr_t)o->native[0]);
    o->state=SP_P6_RC_REGISTERED;__asm__ volatile("dmb":::"memory");unmask(p);
}
uint32_t sp_p6_record_context_v552_registered(void) {
    const SpP6RecordContextsV552 *o=&sp_p6_record_contexts_v552;
    uint32_t a=(uint32_t)(uintptr_t)o->native[0],b=(uint32_t)(uintptr_t)o->native[1];
    return o->state==SP_P6_RC_REGISTERED && !o->fault && o->activations==1 && rd(GLOBAL)==1 &&
        ids(o) && rd(HEAD)==a && rd(a)==o->smpl_task && rd(a+NEXT)==b &&
        rd(b)==o->record_task && rd(b+NEXT)==o->prior_head;
}
uint32_t sp_p6_record_context_v552_current(uint32_t role) {
    SpP6RecordContextsV552 *o=&sp_p6_record_contexts_v552;
    if(role<1 || role>2 || !sp_p6_record_context_v552_registered())return 0;
    uint32_t t=task(),wanted=role==1?o->smpl_task:o->record_task,id=0;
    if(t!=wanted)return 0;
    uint32_t found=((uint32_t (*)(uint32_t *))(uintptr_t)0x800B3FB3u)(&id);
    if(id!=wanted || found!=(uint32_t)(uintptr_t)o->native[role-1] ||
       task()!=wanted || !sp_p6_record_context_v552_registered())return 0;
    return found;
}
