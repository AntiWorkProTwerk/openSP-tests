#ifndef SP_P6_RECORD_PROJECT_V552_H
#define SP_P6_RECORD_PROJECT_V552_H
#include <stdint.h>
/* A native whole-load observation. This supplies no producer/file admission. */
uint32_t sp_p6_record_project_v552_observed_generation(void);
uint32_t sp_p6_record_project_v552_load(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_project_v552_loop(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_project_v552_metadata(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_record_project_v552_prefetch(uint32_t,uint32_t,uint32_t,uint32_t);
#endif
