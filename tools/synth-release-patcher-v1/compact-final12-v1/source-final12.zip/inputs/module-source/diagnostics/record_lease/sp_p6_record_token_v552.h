#ifndef SP_P6_RECORD_TOKEN_V552_H
#define SP_P6_RECORD_TOKEN_V552_H
#include "sp_synth_capture_timed_v552.h"
/* Called by the checked derived source init/BEGIN/discard route. This binds
 * actual source fields and native retirement; it does not grant a project. */
int sp_p6_record_token_v552_bind(SpSynthCaptureTimedV552 *);
int sp_p6_record_token_v552_prepare(SpSynthCaptureTimedV552 *);
/* 0 ordinary unowned path,1 exact prepared BEGIN,-1 retained refusal. */
int sp_p6_record_token_v552_native_begin(void);
int sp_p6_record_token_v552_current(void);
/* SMPL observation only; zero means unavailable. This is not admission. */
uint32_t sp_p6_record_token_v552_actual_token(void);
int sp_p6_record_token_v552_discard_enter(SpSynthCaptureTimedV552 *);
int sp_p6_record_token_v552_discard_retired(SpSynthCaptureTimedV552 *);
#endif
