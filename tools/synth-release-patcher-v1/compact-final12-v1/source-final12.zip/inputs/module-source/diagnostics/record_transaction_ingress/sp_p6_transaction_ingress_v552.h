#ifndef SP_P6_TRANSACTION_INGRESS_V552_H
#define SP_P6_TRANSACTION_INGRESS_V552_H
#include "sp_p6_record_project_gate_v552.h"
#define SP_P6_TX_LOAD UINT32_C(0xFFFFFFFB)
/* Four actual packet words fit the shared 24-byte record beside task/token.
 * Packet identity is derived from its native class and command, not a tag
 * replacing any producer byte. */
static inline uint32_t sp_p6_tx_v552_command(SpP6ProjectCommandV552 c){
    uint32_t command=c.object>>16;
    if((c.object&255u)==0xA4u && (command==3u || command==0x1F9u))return 1;
    return c.operation==SP_P6_TX_LOAD && !c.object && !c.project && !c.selector?2:0;
}
uint32_t sp_p6_tx_v552_packet(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_tx_v552_load(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_tx_v552_dequeue(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_tx_v552_service(void);
uint32_t sp_p6_tx_v552_wake(void);
uint32_t sp_p6_tx_v552_quiescent(void);
uint32_t sp_p6_tx_v552_coverage(void);
uint32_t sp_p6_tx_v552_original(SpP6ProjectCommandV552);
uint32_t sp_p6_tx_v552_nested(uint32_t,uint32_t);
uint32_t sp_p6_tx_v552_admission(void);
#endif
