#include "sp_p6_record_ingress_alias_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_record_token_v552.h"
#include "sp_p6_record_context_v552.h"
#include <stddef.h>
#define QUEUE 0x82E0D624u
#define SERVICE 0x82E0E5F8u
#define PARAM 0x8300A4D8u
typedef uint32_t (*Call)(uint32_t,uint32_t,uint32_t,uint32_t);
#define ORIG(n) extern uint32_t sp_p6_ia_##n##_original(uint32_t,uint32_t,uint32_t,uint32_t)
ORIG(outer);ORIG(inner);ORIG(handler);ORIG(lower_rename);ORIG(lower_unlink);ORIG(media);
extern uint32_t sp_p6_ia_v552_hook_coverage(void);
SpP6RecordIngressAliasV552 sp_p6_record_ingress_alias_v552;
_Static_assert(sizeof(SpP6RecordIngressAliasV552)==356,"Bounded ingress storage");
static uint32_t rd(uint32_t a){return *(volatile const uint32_t *)(uintptr_t)a;}
static uint16_t rh(uint32_t a){return *(volatile const uint16_t *)(uintptr_t)a;}
static void wh(uint32_t a,uint16_t v){*(volatile uint16_t *)(uintptr_t)a=v;}
static uint32_t native(uint32_t p,uint32_t a,uint32_t b,uint32_t c,uint32_t d){return ((Call)(uintptr_t)(p|1u))(a,b,c,d);}
static uint32_t mask(void){uint32_t p;__asm__ volatile("mrs %0, primask\n cpsid i\n dmb":"=r"(p)::"memory");return p;}
static void unmask(uint32_t p){__asm__ volatile("dmb\n msr primask, %0"::"r"(p):"memory");}
static uint32_t ptr(const void *p){return (uint32_t)(uintptr_t)p;}
static int span(uint32_t a,uint32_t n){return a>=0x80000000u && n<=0x4000000u && a<=0x84000000u-n;}
static uint32_t task(void){uint32_t i,p,b,f;
    __asm__ volatile("mrs %0, ipsr":"=r"(i));__asm__ volatile("mrs %0, primask":"=r"(p));
    __asm__ volatile("mrs %0, basepri":"=r"(b));__asm__ volatile("mrs %0, faultmask":"=r"(f));
    if(i||p||b||f||rd(0x202BBBF8u)||rd(0x80245764u))return 0;
    uint32_t t=native(0x800D3162u,0,0,0,0);return t<=32?t:0;
}
static int held(void){return sp_p6_record_producer_v552.held || sp_p6_record_files_v552.active;}
static void fail(uint32_t f){uint32_t p=mask();sp_p6_record_ingress_alias_v552.fault|=f;unmask(p);}
static int enter(int exclusive){SpP6RecordIngressAliasV552 *o=&sp_p6_record_ingress_alias_v552;uint32_t p=mask();
    if(o->active==UINT32_MAX || (exclusive && o->busy)){o->fault|=1;unmask(p);return 0;}
    ++o->active;if(exclusive)o->busy=1;unmask(p);return 1;
}
static void leave(int exclusive){SpP6RecordIngressAliasV552 *o=&sp_p6_record_ingress_alias_v552;uint32_t p=mask();
    if(!o->active)o->fault|=2;else --o->active;if(exclusive)o->busy=0;unmask(p);
}
uint32_t sp_p6_ia_v552_quiescent(void){return !sp_p6_record_ingress_alias_v552.active &&
    !sp_p6_record_ingress_alias_v552.fault && sp_p6_ia_v552_hook_coverage();}
uint32_t sp_p6_ia_v552_admission(void){return 0;}
static int queue_ok(void){return rd(PARAM)==0x8021D034u && rd(PARAM+4)>0 && rd(PARAM+4)<=32 &&
    rd(QUEUE+48)==rd(PARAM+4) && rd(QUEUE+52)==0x80064E39u &&
    rd(QUEUE+12)==0x80B0D538u && rd(QUEUE+36)==0x80B14F00u &&
    rh(QUEUE+22)==128 && rh(QUEUE+46)==128 && rh(QUEUE+20)<=128 && rh(QUEUE+44)<=128 &&
    rh(QUEUE+16)<128 && rh(QUEUE+18)<128 && rh(QUEUE+40)<128 && rh(QUEUE+42)<128;}
static int envelope(uint32_t b){
    if(!span(b,12) || (b&3u))return 0;
    if(!(rd(b)&1u))return 1;
    uint32_t node=rd(b+8);
    if(node==rd(0x80246F2Cu))return 1;
    return span(node,8) && !(node&3u) && rd(node)>0 && rd(node)<UINT32_MAX && span(node+8,rd(node+4));
}
/* Native copy assignment retains the source allocation reference. All payload
 * bytes remain in their native allocation, including requests over256 bytes. */
static int retain_outer(uint32_t b,uint32_t kind){SpP6RecordIngressAliasV552 *o=&sp_p6_record_ingress_alias_v552;
    if(o->outer_count==4){fail(4);++o->refused;return 0;}
    uint32_t i=o->outer_count;
    native(0x10070u,ptr(o->outer[i]),b,0,0);o->outer_kind[i]=kind;++o->outer_count;++o->retained;return 1;
}
/* Nonblocking normal publication uses the native semaphore/mutex and copy
 * assignment, with the stock reverse cursor/count rules. Wait errors retain
 * the owned envelope; neither kernel success nor wake acknowledges a command. */
static int publish(uint32_t b,uint32_t kind){uint32_t off=kind?24:0;
    if(!envelope(b) || !queue_ok()){fail(16);return 0;}
    if(rh(QUEUE+20+off)==128)return 0;
    if(!kind){
        if(native(0x2F86u,rd(QUEUE+28),1,0,0))return 0;
        if(native(0x2A9Eu,rd(QUEUE+32),0,0,0)){native(0x2E88u,rd(QUEUE+28),1,0,0);return 0;}
    }
    uint32_t p=mask();
    if(!queue_ok() || rh(QUEUE+20+off)==128){unmask(p);fail(8);
        if(!kind){native(0x2C04u,rd(QUEUE+32),0,0,0);native(0x2E88u,rd(QUEUE+28),1,0,0);}return 0;}
    uint16_t cursor=rh(QUEUE+18+off),count=rh(QUEUE+20+off);
    native(0x10070u,rd(QUEUE+12+off)+12u*cursor,b,0,0);
    wh(QUEUE+20+off,(uint16_t)(count+1));wh(QUEUE+18+off,cursor?(uint16_t)(cursor-1):127);
    if(!kind){if(rh(QUEUE+24)<count+1)wh(QUEUE+24,(uint16_t)(count+1));
        if(count+1==128)wh(QUEUE+26,(uint16_t)(rh(QUEUE+26)+1));}
    unmask(p);if(!kind)native(0x2C04u,rd(QUEUE+32),0,0,0);return 1;
}
uint32_t sp_p6_ia_v552_outer(uint32_t a,uint32_t b,uint32_t c,uint32_t d){
    if(a!=QUEUE)return sp_p6_ia_outer_original(a,b,c,d);
    uint32_t t=task();if(!t || !envelope(b) || !queue_ok() || !enter(1)){fail(16);return UINT32_MAX;}
    uint32_t kind=!c && t==rd(QUEUE+48);SpP6RecordIngressAliasV552 *o=&sp_p6_record_ingress_alias_v552;
    int ok=o->outer_count?retain_outer(b,kind):publish(b,kind);
    if(!ok && o->outer_count<4)ok=retain_outer(b,kind);
    leave(1);return ok?0:UINT32_MAX;
}
static int service_ok(void){return rd(SERVICE)==0x8022CFE8u && rd(SERVICE+4)<=8 && rd(SERVICE+8)<=8;}
static int full(void){uint32_t w=rd(SERVICE+4);return (w==8?0:w+1)==rd(SERVICE+8);}
static int packet(uint32_t b,uint32_t n){return n>=4 && n<=22528 && span(b,n) &&
    *(const uint8_t *)(uintptr_t)b==0xF0 && *(const uint8_t *)(uintptr_t)(b+1)==0x41 &&
    *(const uint8_t *)(uintptr_t)(b+2)==0x7A;}
uint32_t sp_p6_ia_v552_inner(uint32_t a,uint32_t b,uint32_t c,uint32_t d){
    if(a!=SERVICE){fail(32);return held()?0:sp_p6_ia_inner_original(a,b,c,d);}
    if(!packet(b,c) || !service_ok() || task()!=rd(PARAM+4)){fail(32);return 0;}
    if(!enter(0))return 0;
    uint32_t r=0;
    if(full()){fail(64);++sp_p6_record_ingress_alias_v552.refused;}
    else r=sp_p6_ia_inner_original(a,b,c,d);
    leave(0);return r;
}
uint32_t sp_p6_ia_v552_handler(uint32_t a,uint32_t b,uint32_t c,uint32_t d){
    SpP6RecordIngressAliasV552 *o=&sp_p6_record_ingress_alias_v552;
    if(a!=SERVICE || !packet(b,c) || !service_ok() || task()!=rd(PARAM+4) || !enter(1)){fail(128);return 0;}
    uint32_t r=0;
    if(full() || o->inner_size){
        if(!o->inner_size && c<=sizeof(o->inner)){
            for(uint32_t i=0;i<c;++i)((uint8_t *)o->inner)[i]=*(const uint8_t *)(uintptr_t)(b+i);
            o->inner_size=c;++o->retained;r=1;
            /* Preserve the actual arriving trigger. An untriggered batch never
             * becomes a requested drain because it merely fills the ring. */
            if(((uint8_t *)o->inner)[3]==3)sp_p6_record_producer_v552_dispatch(SERVICE,0,0,0);
        }else {fail(256);++o->refused;}
    }else r=sp_p6_ia_handler_original(a,b,c,d);
    leave(1);return r;
}
uint32_t sp_p6_ia_v552_callback(uint32_t a,uint32_t b,uint32_t c,uint32_t d){
    if(!enter(0))return 0;
    uint32_t r=sp_p6_record_producer_v552_callback(a,b,c,d);
    SpP6RecordIngressAliasV552 *o=&sp_p6_record_ingress_alias_v552;
    if(a==PARAM && !b && !held() && !sp_p6_record_producer_v552.fault && task()==rd(PARAM+4) && !o->busy){
        if(enter(1)){
            if(o->inner_size && !(o->fault&512u) && service_ok() && !full()){
                uint32_t n=o->inner_size,w=rd(SERVICE+4);o->inner_size=0;
                (void)sp_p6_ia_handler_original(SERVICE,ptr(o->inner),n,0);
                int copied=service_ok() && rd(SERVICE+4)==(w==8?0:w+1);
                for(uint32_t i=0;copied && i<n;++i)
                    if(*(const uint8_t *)(uintptr_t)(0x80BCF2ACu+22528u*w+i)!=((uint8_t *)o->inner)[i])copied=0;
                /* A mode2 handler returns zero after successful publication.
                 * Observe its native cursor and copied bytes, not that result. */
                if(copied){++o->replayed;}
                else {o->inner_size=n;fail(512);}
            }
            for(unsigned n=0;n<4 && o->outer_count;++n){
                if(!publish(ptr(o->outer[0]),o->outer_kind[0]))break;
                native(0x800E2C30u,ptr(o->outer[0]),0,0,0);++o->replayed;--o->outer_count;
                for(unsigned i=0;i<o->outer_count;++i){o->outer_kind[i]=o->outer_kind[i+1];
                    for(unsigned k=0;k<3;++k)o->outer[i][k]=o->outer[i+1][k];}
                for(unsigned k=0;k<3;++k)o->outer[o->outer_count][k]=0;
            }
            leave(1);
            if(o->outer_count || rh(QUEUE+20) || rh(QUEUE+44))native(0x80064E38u,0,0,0,0);
        }
    }
    leave(0);return r;
}
static char fold(char c){if(c>='a' && c<='z')c=(char)(c-32);return c=='\\'?'/':c;}
/* Absolute A..D drive paths are bounded ASCII. Relative and drive-relative
 * paths cannot be resolved without the live per-task filesystem CWD contract.
 * Refuse them during ownership rather than guessing that they are unrelated. */
static int canonical(uint32_t a,char out[64]){
    if(!span(a,1))return 0;
    char raw[128];unsigned len=0;
    for(;len<sizeof(raw);++len){if(!span(a+len,1))return 0;raw[len]=fold(*(const char *)(uintptr_t)(a+len));
        if(!raw[len])break;
        if((uint8_t)raw[len]<32 || (uint8_t)raw[len]>=127)return 0;}
    if(len==sizeof(raw) || len<3 || raw[0]<'A' || raw[0]>'D' || raw[1]!=':' || raw[2]!='/')return 0;
    out[0]=raw[0];out[1]=':';out[2]='/';unsigned n=3,i=3;
    while(i<len){while(i<len && raw[i]=='/')++i;unsigned start=i;while(i<len && raw[i]!='/')++i;unsigned bytes=i-start;
        if(!bytes || (bytes==1 && raw[start]=='.'))continue;
        if(bytes==2 && raw[start]=='.' && raw[start+1]=='.'){
            if(n==3)return 0;
            while(n>3 && out[n-1]!='/')--n;
            if(n>3)--n;
            continue;}
        if(n>3){if(n==63)return 0;out[n++]='/';}
        if(bytes>63-n)return 0;
        for(unsigned k=0;k<bytes;++k){char ch=raw[start+k];if(ch==':' || ch=='*' || ch=='?' || ch==' ' || ch=='~')return 0;out[n++]=ch;}
        if(out[n-1]=='.')return 0;
    }
    out[n]=0;return 1;
}
static int match(const char *a,const char *b){unsigned i=0;for(;a[i] && a[i]==b[i];++i){}
    if(!a[i] && !b[i])return SP_P6_IA_PATH_TARGET;
    return !a[i] && (b[i]=='/' || (i==3 && a[2]=='/'))?SP_P6_IA_PATH_ANCESTOR:SP_P6_IA_PATH_OTHER;
}
uint32_t sp_p6_ia_v552_path(uint32_t a,uint32_t *which){char path[64],target[64];
    *which=5;
    if(held() && (!sp_p6_record_files_v552.active || !sp_p6_record_files_v552.path[0][0]))return SP_P6_IA_PATH_UNKNOWN;
    if(!canonical(a,path))return SP_P6_IA_PATH_UNKNOWN;
    uint32_t result=SP_P6_IA_PATH_OTHER;
    for(unsigned i=0;i<5;++i)if(sp_p6_record_files_v552.path[i][0]){
        if(!canonical(ptr(sp_p6_record_files_v552.path[i]),target))return SP_P6_IA_PATH_UNKNOWN;
        int m=match(path,target);if(m==SP_P6_IA_PATH_TARGET){*which=i;return (uint32_t)m;}
        if(m==SP_P6_IA_PATH_ANCESTOR)result=(uint32_t)m;
    }return result;
}
static uint32_t checked(uint32_t a,int *deny){uint32_t i,m=sp_p6_ia_v552_path(a,&i);
    *deny=m==SP_P6_IA_PATH_UNKNOWN || m==SP_P6_IA_PATH_ANCESTOR;
    return m==SP_P6_IA_PATH_TARGET?ptr(sp_p6_record_files_v552.path[i]):a;
}
uint32_t sp_p6_ia_v552_open(uint32_t a,uint32_t b,uint32_t c,uint32_t d){int deny=0;
    if(held() && (sp_p6_record_ingress_alias_v552.fault&1024u)){
        sp_p6_record_files_v552.fault|=SP_P6_RF_IO;++sp_p6_record_ingress_alias_v552.refused;return UINT32_MAX;}
    if(held()){b=checked(b,&deny);if(deny){++sp_p6_record_ingress_alias_v552.refused;return UINT32_MAX;}}
    if(!enter(0))return UINT32_MAX;
    uint32_t r=sp_p6_record_files_v552_open(a,b,c,d);leave(0);return r;
}
uint32_t sp_p6_ia_v552_alternate_open(uint32_t a,uint32_t b,uint32_t c,uint32_t d){int deny=0;
    if(held()){uint32_t i,m=sp_p6_ia_v552_path(a,&i);deny=m!=SP_P6_IA_PATH_OTHER;
        if(deny){++sp_p6_record_ingress_alias_v552.refused;return UINT32_MAX;}}
    if(!enter(0))return UINT32_MAX;
    uint32_t r=sp_p6_record_files_v552_alternate_open(a,b,c,d);leave(0);return r;
}
static uint32_t mutation(Call chain,uint32_t a,uint32_t b,uint32_t c,uint32_t d,int two){int x=0,y=0;
    if(held()){a=checked(a,&x);if(two)b=checked(b,&y);if(x||y){++sp_p6_record_ingress_alias_v552.refused;return UINT32_MAX;}}
    if(!enter(0))return UINT32_MAX;
    uint32_t r=chain(a,b,c,d);leave(0);return r;
}
uint32_t sp_p6_ia_v552_rename(uint32_t a,uint32_t b,uint32_t c,uint32_t d){return mutation(sp_p6_record_files_v552_rename,a,b,c,d,1);}
uint32_t sp_p6_ia_v552_unlink(uint32_t a,uint32_t b,uint32_t c,uint32_t d){return mutation(sp_p6_record_files_v552_unlink,a,b,c,d,0);}
static int own_mutation(void){return sp_p6_record_token_v552_current() && sp_p6_record_context_v552_current(1) &&
    (sp_p6_record_files_v552.smpl_operation==SP_P6_RF_START || sp_p6_record_files_v552.smpl_operation==SP_P6_RF_SAVE ||
     sp_p6_record_files_v552.smpl_operation==SP_P6_RF_DISCARD);}
static uint32_t lower(Call chain,uint32_t a,uint32_t b,uint32_t c,uint32_t d,int two){
    if(held()){uint32_t i,j;uint32_t x=sp_p6_ia_v552_path(a,&i),y=two?sp_p6_ia_v552_path(b,&j):SP_P6_IA_PATH_OTHER;
        if(x==SP_P6_IA_PATH_UNKNOWN || y==SP_P6_IA_PATH_UNKNOWN || x==SP_P6_IA_PATH_ANCESTOR || y==SP_P6_IA_PATH_ANCESTOR ||
           ((x==SP_P6_IA_PATH_TARGET || y==SP_P6_IA_PATH_TARGET) && !own_mutation())){
            ++sp_p6_record_ingress_alias_v552.refused;return UINT32_MAX;}}
    return mutation(chain,a,b,c,d,two);
}
uint32_t sp_p6_ia_v552_lower_rename(uint32_t a,uint32_t b,uint32_t c,uint32_t d){return lower(sp_p6_ia_lower_rename_original,a,b,c,d,1);}
uint32_t sp_p6_ia_v552_lower_unlink(uint32_t a,uint32_t b,uint32_t c,uint32_t d){return lower(sp_p6_ia_lower_unlink_original,a,b,c,d,0);}
uint32_t sp_p6_ia_v552_copy(uint32_t a,uint32_t b,uint32_t c,uint32_t d){
    if(held()){uint32_t i,j;if(sp_p6_ia_v552_path(b,&i)!=SP_P6_IA_PATH_OTHER || sp_p6_ia_v552_path(c,&j)!=SP_P6_IA_PATH_OTHER){
        ++sp_p6_record_ingress_alias_v552.refused;return UINT32_MAX;}}
    if(!enter(0))return UINT32_MAX;
    uint32_t r=sp_p6_record_files_v552_copy(a,b,c,d);leave(0);return r;
}
uint32_t sp_p6_ia_v552_media(uint32_t a,uint32_t b,uint32_t c,uint32_t d){
    if(!enter(0))return UINT32_MAX;
    /* Observed teardown invalidates provenance before the first native effect,
     * including a teardown that later fails. Physical removal is still outside
     * this software boundary. Never grant ownership from a new generation. */
    fail(1024);++sp_p6_record_ingress_alias_v552.media_epoch;
    if(held()){sp_p6_record_files_v552.fault|=SP_P6_RF_IO;leave(0);return UINT32_MAX;}
    uint32_t r=sp_p6_ia_media_original(a,b,c,d);leave(0);return r;
}
