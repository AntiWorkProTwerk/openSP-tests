#ifndef SP_P6_RECORD_INGRESS_ALIAS_V552_H
#define SP_P6_RECORD_INGRESS_ALIAS_V552_H
#include <stdint.h>
enum { SP_P6_IA_PATH_UNKNOWN=0, SP_P6_IA_PATH_OTHER=1,
       SP_P6_IA_PATH_TARGET=2, SP_P6_IA_PATH_ANCESTOR=3 };
/* Permanent cold BSS. No caller token, generation or ready Boolean. */
typedef struct {
    uint32_t active, fault, busy, refused, retained, replayed, media_epoch;
    uint32_t outer_count, outer_kind[4], outer[4][3];
    uint32_t inner_size, inner[64];
} SpP6RecordIngressAliasV552;
extern SpP6RecordIngressAliasV552 sp_p6_record_ingress_alias_v552;
uint32_t sp_p6_ia_v552_quiescent(void);
uint32_t sp_p6_ia_v552_admission(void);
uint32_t sp_p6_ia_v552_path(uint32_t,uint32_t *);
#define IA_DECL(n) uint32_t sp_p6_ia_v552_##n(uint32_t,uint32_t,uint32_t,uint32_t)
IA_DECL(outer); IA_DECL(inner); IA_DECL(handler); IA_DECL(callback);
IA_DECL(open); IA_DECL(alternate_open); IA_DECL(rename); IA_DECL(unlink);
IA_DECL(lower_rename); IA_DECL(lower_unlink); IA_DECL(copy); IA_DECL(media);
#undef IA_DECL
#endif
