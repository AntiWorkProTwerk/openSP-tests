#ifndef SP_P6_RECORD_PROJECT_GATE_V552_H
#define SP_P6_RECORD_PROJECT_GATE_V552_H
#include "sp_synth_capture_timed_v552.h"
#include <stdint.h>

#define SP_P6_PROJECT_DEFERRED UINT32_MAX
#define SP_P6_PROJECT_QUEUE_CAPACITY 8u
typedef struct {
    uint32_t object, operation, project, selector, task, token;
} SpP6ProjectCommandV552;
typedef struct {
    uint32_t generation, active, task, fault, head, count, retained, replayed;
    uint32_t prepared_generation, prepared_token, prepared_project;
    SpP6ProjectCommandV552 commands[SP_P6_PROJECT_QUEUE_CAPACITY];
} SpP6RecordProjectGateV552;
extern SpP6RecordProjectGateV552 sp_p6_record_project_gate_v552;

/* These three queries run inside producer26's existing PRIMASK section.
 * The checked producer derivation is required; no caller readiness flag is used. */
int sp_p6_record_project_gate_v552_bind_locked(void);
int sp_p6_record_project_gate_v552_prepare(SpSynthCaptureTimedV552 *);
int sp_p6_record_project_gate_v552_begin_locked(SpSynthCaptureTimedV552 *);
int sp_p6_record_project_gate_v552_pending_locked(void);
/* Called only from an admitted native ParamTask callback. It observes the
 * producer's genuine retirement receipt and removes a command after return. */
int sp_p6_record_project_gate_v552_replay(void);
uint32_t sp_p6_record_project_gate_v552_generation(void);
uint32_t sp_p6_record_project_gate_v552_setter(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t sp_p6_pg_setter_original_v552(uint32_t,uint32_t,uint32_t,uint32_t);
#endif
