#ifndef SP_SYNTH_PREVIEW_NATIVE_V552_H
#define SP_SYNTH_PREVIEW_NATIVE_V552_H
#include "sp_p4_controls.h"
/* Supplied UI semantic copy only; this fixture does not implement native IO. */
enum { SP_PREVIEW_NATIVE_ACTIVE=5 };
typedef struct {
    uint32_t state,fault,choice,held_pads,route_ticket,route_ack;
    uint32_t permission_ticket,permission_ack,stop_ack;
    SpP4ControlView controls;
} SpPreviewNativeView;
_Static_assert(sizeof(SpPreviewNativeView)==108,"P5 semantic view ABI");
#endif
