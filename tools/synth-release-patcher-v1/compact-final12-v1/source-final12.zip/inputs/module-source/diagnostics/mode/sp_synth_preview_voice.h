#ifndef SP_SYNTH_PREVIEW_VOICE_H
#define SP_SYNTH_PREVIEW_VOICE_H
#include "sp_synth_dsp.h"
#include "sp_synth_preview_visual.h"
#include <stdatomic.h>
#include <stddef.h>
#include <stdint.h>

enum { SP_PREVIEW_PADS=16, SP_PREVIEW_QUEUE=32, SP_PREVIEW_FRAMES=64,
       SP_PREVIEW_VOICES=4, SP_PREVIEW_PARAMETERS=12, SP_PREVIEW_PRESETS=16 };
enum { SP_PREVIEW_STOP=1u, SP_PREVIEW_OVERFLOW=2u, SP_PREVIEW_QUEUE_FAULT=4u,
       SP_PREVIEW_IDENTITY_FAULT=8u, SP_PREVIEW_RENDER_FAULT=16u,
       SP_PREVIEW_EXHAUSTED=32u, SP_PREVIEW_CONTROL_STALL=64u };
typedef enum { SP_PREVIEW_INVALID=0, SP_PREVIEW_OK=1,
               SP_PREVIEW_TERMINAL=2 } SpPreviewRenderResult;
typedef enum { SP_PREVIEW_PARAM_CUTOFF, SP_PREVIEW_PARAM_RESONANCE,
    SP_PREVIEW_PARAM_ENV_AMOUNT, SP_PREVIEW_PARAM_OSC_MIX,
    SP_PREVIEW_PARAM_DETUNE, SP_PREVIEW_PARAM_PULSE_WIDTH,
    SP_PREVIEW_PARAM_ATTACK, SP_PREVIEW_PARAM_DECAY, SP_PREVIEW_PARAM_RELEASE,
    SP_PREVIEW_PARAM_LFO_RATE, SP_PREVIEW_PARAM_LFO_DEPTH,
    SP_PREVIEW_PARAM_GLIDE } SpPreviewParameter;
typedef struct { uint32_t ticket; uint8_t kind,pad; uint16_t reserved; } SpPreviewEvent;
typedef struct {
    SpOsc oscillator[3]; SpEnvelope envelope,filter_envelope; SpFilter filter;
    SpNoise noise; uint32_t pad,ticket,age; float increment;
} SpPreviewPolyVoice;
typedef struct {
    float cutoff,resonance,env_amount,mix,detune,width,attack,decay,release;
    float lfo_increment,lfo_depth,glide_coefficient,sub,noise,sustain,filter_decay;
    float pulse_mean,pulse_scale;
    uint32_t wave_a,wave_b,filter_mode;
} SpPreviewPatch;
/* Immutable program metadata for a UI shadow. Values use the same enum and
 * 0..255 mix/sustain scales as the read-only preset data, never audio state. */
typedef struct {
    uint8_t wave_a,wave_b,sub,noise,sustain,filter_mode;
} SpPreviewPresetInfo;

/* Permanent zeroed storage, cold init before publication. One serialized
 * control producer and one nonrecursive audio consumer. Only stop() permits
 * an additional supervisor. Control APIs publish ordered events, never DSP. */
typedef struct {
    uint32_t initialized;
    _Atomic uint32_t write_index,read_index,terminal;
    SpPreviewEvent queue[SP_PREVIEW_QUEUE];
    uint32_t control_ids[SP_PREVIEW_PADS],next_ticket,control_admitted;
    uint32_t audio_ids[SP_PREVIEW_PADS],audio_admitted,active_pad;
    float increments[SP_PREVIEW_PADS];
    uint32_t permission_ticket,audio_permission_ticket;
    _Atomic uint32_t permission_ack,stop_ack,heartbeat;
    uint32_t lease_frames,lease_remaining,audio_heartbeat;
    uint32_t control_command_ticket,audio_command_ticket;
    _Atomic uint32_t command_ack;
    uint16_t parameters[SP_PREVIEW_PARAMETERS];
    uint32_t preset,mono,octave,age,modulation_countdown;
    float sample_rate,transpose,lfo_phase,modulation;
    float last_sample,transition_offset;
    uint32_t transition_frames,transition_remaining,transition_pending;
    SpPreviewPatch patch;
    SpPreviewPolyVoice voices[SP_PREVIEW_VOICES];
    SpPreviewVisualState visual;
} SpSynthPreviewVoice;

int sp_synth_preview_voice_init(SpSynthPreviewVoice *,uint32_t sample_rate);
int sp_synth_preview_voice_admit(SpSynthPreviewVoice *,int admitted);
uint32_t sp_synth_preview_voice_permission(const SpSynthPreviewVoice *);
uint32_t sp_synth_preview_voice_permission_ack(const SpSynthPreviewVoice *);
int sp_synth_preview_voice_lease(SpSynthPreviewVoice *,uint32_t frames);
int sp_synth_preview_voice_pulse(SpSynthPreviewVoice *);
uint32_t sp_synth_preview_voice_stop_ack(const SpSynthPreviewVoice *);
uint32_t sp_synth_preview_voice_down(SpSynthPreviewVoice *,unsigned pad);
int sp_synth_preview_voice_up(SpSynthPreviewVoice *,unsigned pad,uint32_t ticket);
void sp_synth_preview_voice_stop(SpSynthPreviewVoice *);
uint32_t sp_synth_preview_voice_faults(const SpSynthPreviewVoice *);

/* Normalized controls0..4095, program0..15, mono0/1, octave-2..2. Permission
 * must be published first. Success means queued; command_ack is audio receipt
 * for the exact monotonic command ticket. Presets restore all twelve values,
 * mono and octave defaults at one ordered boundary, preserving held IDs.
 * Reserved event payloads remain zero for old note/permission events. */
int sp_synth_preview_voice_parameter(SpSynthPreviewVoice *,unsigned param,uint32_t value);
int sp_synth_preview_voice_preset(SpSynthPreviewVoice *,unsigned program);
int sp_synth_preview_voice_mono(SpSynthPreviewVoice *,int mono);
int sp_synth_preview_voice_octave(SpSynthPreviewVoice *,int octave);
uint32_t sp_synth_preview_voice_command(const SpSynthPreviewVoice *);
uint32_t sp_synth_preview_voice_command_ack(const SpSynthPreviewVoice *);
const char *sp_synth_preview_preset_name(unsigned program);
uint16_t sp_synth_preview_preset_value(unsigned program,unsigned param);
unsigned sp_synth_preview_preset_mono(unsigned program);
int sp_synth_preview_preset_octave(unsigned program);
int sp_synth_preview_preset_info(unsigned program,SpPreviewPresetInfo *info);
SpPreviewVisualResult sp_synth_preview_voice_visual_read(const SpSynthPreviewVoice *,
    SpPreviewVisualReader *,SpPreviewVisualSnapshot *);

/* Audio owner only. Overwrite interleaved signed16 stereo, at most64 frames.
 * Validate output bounds/overlap before writing. Entry queue snapshot and at
 * most one event per sample preserve note and edit ordering. Four voices,
 * unused/quietest-release/oldest stealing; old UP cannot release its replacement. Mono has
 * last-held priority and legato fallback. AMP release can last up to4 seconds.
 * A cubic attack keeps its selected duration. A2 ms cubic output correction
 * removes destructive replacement jumps; pulse mean is removed and peak
 * normalized. Fixed per-voice headroom and final +/-0.45 limiter. A terminal observation
 * clears every voice and zeros the entire positive-frame output before ack.
 * Zero frames consumes no events and cannot acknowledge terminal silence. */
SpPreviewRenderResult sp_synth_preview_voice_render(SpSynthPreviewVoice *,
    int16_t *stereo,size_t sample_capacity,uint32_t frames);
#endif
