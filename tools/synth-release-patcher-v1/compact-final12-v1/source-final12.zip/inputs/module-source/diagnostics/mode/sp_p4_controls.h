#ifndef SP_P4_CONTROLS_H
#define SP_P4_CONTROLS_H
#include "sp_synth_preview_voice.h"
#include <stdint.h>

enum { SP_P4_PAGES=4, SP_P4_KNOBS=3 };
/* P5 retains the copied P4 view ABI. This UI-task shadow never reads audio
 * state. Native CTRL packets have 128 steps, normalized to 0..4095. */
typedef struct {
    uint32_t preset,page,mono;
    int32_t octave;
    uint32_t modified,known_mask,pickup_mask,baseline_mask;
    uint16_t values[SP_PREVIEW_PARAMETERS],knobs[SP_P4_KNOBS];
    uint32_t command_ticket,command_ack;
} SpP4ControlView;

typedef struct {
    uint32_t initialized;
    SpP4ControlView view;
    /* Fixed binding anchors avoid cumulative rounding drift on reversals. */
    uint16_t anchor_knobs[SP_P4_KNOBS],anchor_values[SP_P4_KNOBS];
} SpP4Controls;

int sp_p4_controls_init(SpP4Controls *);
/* Seed only from a validated native cached position or an unbound packet.
 * Never publish an edit. Reanchor the current page's parameter at that point. */
int sp_p4_controls_seed(SpP4Controls *,int32_t index,int32_t value);
int sp_p4_controls_forget(SpP4Controls *,int32_t index);
/* Piecewise scale around the binding anchor. Moving in either direction changes
 * the parameter immediately; a reached stop adopts absolute control. An
 * unknown first packet establishes a baseline without a guessed movement.
 * Publication rejection preserves the parameter, anchors and modified flag. */
int sp_p4_controls_ctrl(SpP4Controls *,SpSynthPreviewVoice *,int32_t index,int32_t value);
int sp_p4_controls_turn(SpP4Controls *,SpSynthPreviewVoice *,int32_t delta,int shift);
int sp_p4_controls_press(SpP4Controls *,SpSynthPreviewVoice *,int shift);
/* Explicit menu choice. mono is requested state; audio receipt and a
 * completed visual snapshot establish the applied state separately. */
int sp_p4_controls_mode(SpP4Controls *,SpSynthPreviewVoice *,int mono);
int sp_p4_controls_snapshot(const SpP4Controls *,SpP4ControlView *);
const char *sp_p4_controls_page_name(unsigned);
const char *sp_p4_controls_parameter_name(unsigned);
#endif
