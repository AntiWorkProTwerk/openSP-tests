#ifndef SP_SYNTH_PREVIEW_VISUAL_H
#define SP_SYNTH_PREVIEW_VISUAL_H
#include <stdatomic.h>
#include <stdint.h>
enum { SP_PREVIEW_VISUAL_COLUMNS=96,SP_PREVIEW_VISUAL_PEAK=14745,
       SP_PREVIEW_VISUAL_ABI=2,SP_PREVIEW_VISUAL_BYTES=232 };
enum { SP_VISUAL_TRIGGERED=1u,SP_VISUAL_ADMITTED=2u,
       SP_VISUAL_TERMINAL=4u,SP_VISUAL_SILENT=8u,SP_VISUAL_FALLBACK=16u,SP_VISUAL_MIXED=32u };
/* P6 applied preset/mode, activity and envelopes describe the completion
 * sample. command_ticket belongs to the first PCM sample; MIXED marks
 * command changes within the window. ABI2 appends stage/progress after
 * the old 224-byte prefix. Stage0..4 follows SpEnvStage; progress0..255
 * follows captured stage duration (idle0, sustain255). */
typedef struct {
    uint32_t sequence,frame_sequence,command_ticket,held_pad_mask;
    uint16_t span_frames,peak_i16,clipped_samples;
    uint8_t active_pad,flags,envelope[4];
    int8_t lfo;
    uint8_t active_voices;
    uint8_t applied_preset,applied_mono;
    int8_t minimum[SP_PREVIEW_VISUAL_COLUMNS],maximum[SP_PREVIEW_VISUAL_COLUMNS];
    uint8_t envelope_stage[4],envelope_progress[4];
} SpPreviewVisualSnapshot;
/* Exactly one serialized UI reader per permanent audio owner. Initialize
 * once from zeroed storage. Keep this context and output in presenter-owned
 * storage; neither initialization nor reads touch DSP state. */
typedef struct { uint32_t initialized,front_index,sequence,has_snapshot; } SpPreviewVisualReader;
typedef enum { SP_VISUAL_INVALID=0,SP_VISUAL_CACHED=1,SP_VISUAL_NEW=2 } SpPreviewVisualResult;
/* Internal ownership: audio writes back/collector; UI exclusively holds its
 * front index. Atomic middle exchange transfers complete buffers. Audio and
 * UI never access the same mutable snapshot. No extra readers are supported. */
typedef struct {
    SpPreviewVisualSnapshot buffers[3];
    _Atomic uint32_t middle;
    uint32_t initialized,back_index,rate,cadence_frames,frame_sequence,elapsed;
    uint32_t sequence,wait_frames,quiet_frames,window_samples,window_peak,window_clipped,window_command_ticket;
    uint32_t pending,last_clear_reason;
    uint16_t samples_per_column,samples_in_column,hint_samples_per_column;
    int16_t bin_minimum,bin_maximum;
    uint8_t column,capturing,trigger_armed,window_flags;
} SpPreviewVisualState;

int sp_synth_preview_visual_reader_init(SpPreviewVisualReader *reader);
SpPreviewVisualResult sp_preview_visual_read(const SpPreviewVisualState *state,
    SpPreviewVisualReader *reader,SpPreviewVisualSnapshot *snapshot);

/* Audio-only implementation helpers. Capture prepares the writer-owned
 * buffer. The caller supplies metadata at that precise completion sample,
 * then commits only after its whole PCM block has passed terminal checks. */
void sp_preview_visual_init(SpPreviewVisualState *state,uint32_t rate);
void sp_preview_visual_hint(SpPreviewVisualState *state,float nominal_increment);
void sp_preview_visual_reset_capture(SpPreviewVisualState *state);
int sp_preview_visual_capture(SpPreviewVisualState *state,int16_t sample,int clipped,uint32_t command_ticket);
SpPreviewVisualSnapshot *sp_preview_visual_pending(SpPreviewVisualState *state);
void sp_preview_visual_commit(SpPreviewVisualState *state);
int sp_preview_visual_clear_prepare(SpPreviewVisualState *state,uint32_t frame_end,int terminal);
#endif
