#ifndef SP_P6_NATIVE_SERVICE_V552_H
#define SP_P6_NATIVE_SERVICE_V552_H
#include <stdint.h>
#include <stdatomic.h>

/* Eight source blocks are a checked CPU schedule requirement. The platform
 * must still qualify the corresponding real task and storage deadlines. */
#define SP_P6_NATIVE_SERVICE_BLOCK_LIMIT 8u
#define SP_P6_NATIVE_SERVICE_COUNTER 1u
#define SP_P6_NATIVE_SERVICE_CADENCE 2u
#define SP_P6_NATIVE_SERVICE_QUEUE_FULL 4u
#define SP_P6_NATIVE_SERVICE_IDENTITY 8u
#define SP_P6_NATIVE_SERVICE_WAKE_CONTEXT 16u

typedef struct {
    atomic_uint blocks, last_service, visits, posts, retries, refusals;
    atomic_uint max_gap, max_ready, fault, active, installed;
    atomic_uint pcm_wakes, pcm_retries, pcm_refusals;
} SpP6NativeServiceV552;
extern SpP6NativeServiceV552 sp_p6_native_service_v552;

/* Invoke after the permanent source's final successful 64-frame PCM callback.
 * These calls observe progress and wake the existing source owner. They grant
 * no request, token, file lifetime, retirement or recording admission. */
void sp_p6_native_service_v552_pcm(uint32_t frames);
int sp_p6_native_service_v552_install(void);
int sp_p6_native_service_v552_smpl(void);
uint32_t sp_p6_native_service_v552_admission(void);
#endif
