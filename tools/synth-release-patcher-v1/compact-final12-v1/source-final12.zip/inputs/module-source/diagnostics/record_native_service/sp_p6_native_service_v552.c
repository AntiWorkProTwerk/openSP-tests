#include "sp_p6_native_service_v552.h"
#include "sp_p6_record_fullbar_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_producer_v552.h"

SpP6NativeServiceV552 sp_p6_native_service_v552;
_Static_assert(sizeof(SpP6NativeServiceV552)==56,"Permanent cadence observations");
static uint32_t rd(uint32_t p) { return *(volatile const uint32_t *)(uintptr_t)p; }
static uint32_t value(const atomic_uint *p) { return atomic_load_explicit(p,memory_order_acquire); }
static void fault(uint32_t bits) { atomic_fetch_or_explicit(&sp_p6_native_service_v552.fault,bits,memory_order_release); }
static void maximum(atomic_uint *p,uint32_t n) {
    uint32_t old=value(p);
    if(n>old)atomic_store_explicit(p,n,memory_order_release);
}
static void increment(atomic_uint *p) {
    uint32_t old=value(p);
    /* Each counter has exactly one installed writer: PCM or guarded SMPL. */
    if(old==UINT32_MAX) { fault(SP_P6_NATIVE_SERVICE_COUNTER);return; }
    atomic_store_explicit(p,old+1,memory_order_release);
}
void sp_p6_native_service_v552_pcm(uint32_t frames) {
    if(frames!=64)return;
    SpP6NativeServiceV552 *o=&sp_p6_native_service_v552;
    increment(&o->blocks);
    SpSynthCaptureTimedV552 *c=sp_p6_record_producer_v552.capture;
    if(!value(&o->installed) || !c || !value(&c->token))return;
    uint32_t blocks=value(&o->blocks),last=value(&o->last_service);
    if(blocks<last) { fault(SP_P6_NATIVE_SERVICE_COUNTER);return; }
    uint32_t gap=blocks-last;
    if(gap>SP_P6_NATIVE_SERVICE_BLOCK_LIMIT)fault(SP_P6_NATIVE_SERVICE_CADENCE);
    if(gap<SP_P6_NATIVE_SERVICE_BLOCK_LIMIT)return;
    uint32_t pm,fm,bp,ip;
    __asm__ volatile("mrs %0, primask":"=r"(pm));
    __asm__ volatile("mrs %0, faultmask":"=r"(fm));
    __asm__ volatile("mrs %0, basepri":"=r"(bp));
    __asm__ volatile("mrs %0, ipsr":"=r"(ip));
    if(pm || fm || bp || ip || rd(0x202BBBF8u)) {
        fault(SP_P6_NATIVE_SERVICE_WAKE_CONTEXT);increment(&o->pcm_refusals);return;
    }
    if(!(rd(0x202ACD0Cu)&128u) || rd(0x202ACD4Cu)!=4u) {
        fault(SP_P6_NATIVE_SERVICE_IDENTITY);increment(&o->pcm_refusals);return;
    }
    /* One nonblocking event post at most per source block. Until actual SMPL
     * service advances last_service, retries coalesce in the stock kernel. */
    uint32_t result=((uint32_t (*)(uint32_t,uint32_t))(uintptr_t)0x800D30A5u)(0x202ACD00u,128u);
    if(result==1)increment(&o->pcm_wakes);else increment(&o->pcm_retries);
}
static int context(void) {
    uint32_t primask,faultmask,basepri,ipsr;
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    __asm__ volatile("mrs %0, basepri":"=r"(basepri));
    __asm__ volatile("mrs %0, ipsr":"=r"(ipsr));
    if(primask || faultmask || basepri || ipsr || rd(0x202BBBF8u) ||
       !sp_p6_record_context_v552_current(1))return 0;
    return 1;
}
int sp_p6_native_service_v552_install(void) {
    if(!context())return 0;
    SpP6NativeServiceV552 *o=&sp_p6_native_service_v552;
    uint32_t mask=rd(0x202ACD0Cu),action=rd(0x202ACD4Cu);
    if(!(mask&128u) && !value(&o->installed)) {
        (void)((uint32_t (*)(uint32_t,uint32_t,uint32_t))(uintptr_t)0x800CC1E1u)(0x202ACD00u,128u,4u);
        mask=rd(0x202ACD0Cu);action=rd(0x202ACD4Cu);
    }
    if(!(mask&128u) || action!=4u) { fault(SP_P6_NATIVE_SERVICE_IDENTITY);return 0; }
    atomic_store_explicit(&o->installed,1,memory_order_release);
    return 1;
}
int sp_p6_native_service_v552_smpl(void) {
    SpP6NativeServiceV552 *o=&sp_p6_native_service_v552;
    if(!context() || !value(&o->installed))return 0;
    if(!(rd(0x202ACD0Cu)&128u) || rd(0x202ACD4Cu)!=4u) {
        fault(SP_P6_NATIVE_SERVICE_IDENTITY);return 0;
    }
    uint32_t expected=0;
    if(!atomic_compare_exchange_strong_explicit(&o->active,&expected,1,memory_order_acquire,memory_order_relaxed))return 0;
    increment(&o->visits);
    uint32_t blocks=value(&o->blocks),last=value(&o->last_service);
    if(blocks<last)fault(SP_P6_NATIVE_SERVICE_COUNTER);
    else {
        uint32_t gap=blocks-last;
        maximum(&o->max_gap,gap);
        SpSynthCaptureTimedV552 *c=sp_p6_record_producer_v552.capture;
        if(c && value(&c->token) && gap>SP_P6_NATIVE_SERVICE_BLOCK_LIMIT)
            fault(SP_P6_NATIVE_SERVICE_CADENCE);
    }
    atomic_store_explicit(&o->last_service,blocks,memory_order_release);
    uint32_t ready=0;
    for(unsigned i=0;i<30;i++)if(*(volatile const uint8_t *)(uintptr_t)(0x82FE4F08u+60u+12u*i))ready++;
    maximum(&o->max_ready,ready);
    if(ready==30)fault(SP_P6_NATIVE_SERVICE_QUEUE_FULL);
    /* This is one checked native post, outside all masks. A failed post leaves
     * the existing source/queue/retirement identity intact for the next visit. */
    int result=sp_p6_record_fullbar_v552_service();
    if(result>0)increment(&o->posts);
    else if(result<0)increment(&o->retries);
    else increment(&o->refusals);
    atomic_store_explicit(&o->active,0,memory_order_release);
    return result;
}
uint32_t sp_p6_native_service_v552_admission(void) { return 0; }
