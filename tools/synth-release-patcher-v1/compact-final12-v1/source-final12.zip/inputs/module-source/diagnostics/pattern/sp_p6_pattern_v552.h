#ifndef SP_P6_PATTERN_V552_H
#define SP_P6_PATTERN_V552_H
#include <stdint.h>

/* Read-only observations of pristine v5.52 object getters. pattern_state and
 * transport_state are raw values, without invented running/downbeat labels.
 * coarse_time is a resettable stock transport counter, not a PCM sample index.
 * Neither this snapshot nor empty_pad acquires recorder/project/file ownership
 * or proves that an existing pattern survives Synth entry. */
typedef struct {
    uint32_t project,tempo100,storage_mode;
    int32_t pattern_state;
    uint32_t transport_state,coarse_time;
} SpP6PatternSnapshotV552;
typedef struct {
    uint32_t project,bank,pad,index,channels,cache_busy;
} SpP6EmptyPadSnapshotV552;

/* Exact selected PANEL task in ordinary unmasked context only. A brief mask
 * makes the pure native getters coherent without holding the scheduler gate
 * or doing file I/O. The caller owns a valid stable output span. No snapshot
 * or mutation is published on refusal. Known native sources cannot be used
 * as the output span; this check does not allocate or establish RAM ownership. */
int sp_p6_pattern_v552_snapshot(SpP6PatternSnapshotV552 *);
/* Native channels getter101 plus the selected cache's38 descriptor slots.
 * A1..J16 only, and only current internal storage. channels0/cache_busy0 is an
 * empty/idle observation; native admissions can change it after return. Requery
 * under the narrower actual take/destination lease before native SAVE. */
int sp_p6_pattern_v552_empty_pad(uint32_t bank,uint32_t pad,SpP6EmptyPadSnapshotV552 *);
#endif
