#include "sp_p6_pattern_v552.h"
#include <stddef.h>

_Static_assert(sizeof(void *)==4,"Roland5.52 ARM32 ABI");
typedef uint32_t (*Native)(uint32_t,uint32_t,uint32_t,uint32_t);
static uint32_t native(uintptr_t p,uint32_t a,uint32_t b,uint32_t c,uint32_t d) {
    return ((Native)(p|1u))(a,b,c,d);
}
static uint32_t rd(uintptr_t p){return *(const volatile uint32_t *)p;}
static uint32_t context(void) {
    uint32_t ipsr,primask,basepri,faultmask;
    __asm__ volatile("mrs %0, ipsr":"=r"(ipsr));
    __asm__ volatile("mrs %0, primask":"=r"(primask));
    __asm__ volatile("mrs %0, basepri":"=r"(basepri));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    if(ipsr || primask || basepri || faultmask || (int32_t)rd(0x80245764)>0 || rd(0x202BBBF8))return 0;
    uint32_t id=native(0x800D3162,0,0,0,0);
    return id>=1 && id<=32 && id==rd(0x8300A3E8);
}
static uint32_t lock(void) {
    uint32_t v;__asm__ volatile("mrs %0, primask\n\tcpsid i\n\tdmb sy":"=r"(v)::"memory");return v;
}
static void unlock(uint32_t v) {
    __asm__ volatile("dmb sy\n\tmsr primask, %0"::"r"(v):"memory");
}
static int output(const void *p,size_t bytes) {
    uintptr_t a=(uintptr_t)p;
    if(!a || (a&3u) || a>UINTPTR_MAX-bytes)return 0;
    /* Prevent a snapshot destination from overwriting its native source data. */
    const uintptr_t lo[]={0x82DFFC88,0x82E01144,0x82E2CD08,0x82E111C8,
        0x82E495E4,0x80592244,0x805923FC};
    const size_t n[]={0xD48,0x600,0x17000,304*160,36*160,0x38,4};
    for(unsigned i=0;i<7;++i)if(a<lo[i]+n[i] && a+bytes>lo[i])return 0;
    return 1;
}
int sp_p6_pattern_v552_snapshot(SpP6PatternSnapshotV552 *out) {
    if(!output(out,sizeof(*out)) || !context())return 0;
    uint32_t mask=lock();
    SpP6PatternSnapshotV552 s;
    s.project=native(0x800E1190,0,0,0,0);
    s.tempo100=native(0x800D94D8,0x82E01144,27,0,0);
    s.storage_mode=native(0x800D94D8,0x82E01144,132,0,0);
    s.pattern_state=(int32_t)native(0x800E26D0,0x82DFFC88,119,0,0);
    s.transport_state=*(const volatile uint8_t *)(uintptr_t)0x80592244;
    s.coarse_time=rd(0x8059226C);
    unlock(mask);
    if(s.project>=128 || s.tempo100<2000 || s.tempo100>30000 || s.storage_mode)return 0;
    *out=s;return 1;
}
int sp_p6_pattern_v552_empty_pad(uint32_t bank,uint32_t pad,SpP6EmptyPadSnapshotV552 *out) {
    if(bank>=10 || !pad || pad>16 || !output(out,sizeof(*out)) || !context())return 0;
    uint32_t index=bank*16+pad-1,mask=lock();
    SpP6EmptyPadSnapshotV552 s={native(0x800E1190,0,0,0,0),bank,pad,index,0,0};
    uint32_t storage=native(0x800D94D8,0x82E01144,132,0,0);
    s.channels=native(0x800DC6B8,0x82E2CD08,101,index,0);
    for(unsigned i=0;i<38;++i) {
        uintptr_t row=0x82E111C8+304*index+8*i;
        if(*(const volatile uint8_t *)row || rd(row+4)!=UINT32_MAX)s.cache_busy=1;
    }
    unlock(mask);
    if(s.project>=128 || storage || s.channels>2)return 0;
    *out=s;return 1;
}
