#include "sp_p6_pattern_clock_v552.h"
#include <stddef.h>
#include <limits.h>

typedef uint32_t (*Native)(uint32_t,uint32_t,uint32_t,uint32_t);
typedef struct {
    uint32_t epoch,depth,fault,voice,pcm,valid,seen,sequence;
    SpP6ClockReceiptV552 receipt;
} Clock;
static Clock clock;
_Static_assert(sizeof(SpP6ClockReceiptV552)==80,"receipt ABI1");
static uint32_t rd(uint32_t a){return *(volatile const uint32_t *)(uintptr_t)a;}
static uint16_t rh(uint32_t a){return *(volatile const uint16_t *)(uintptr_t)a;}
static uint8_t rb(uint32_t a){return *(volatile const uint8_t *)(uintptr_t)a;}
static uint32_t native(uint32_t a,uint32_t b,uint32_t c,uint32_t d,uint32_t e){
    return ((Native)(uintptr_t)(a|1u))(b,c,d,e);
}
static uint32_t mask(void){uint32_t p;__asm__ volatile("mrs %0, primask\n cpsid i\n dmb sy":"=r"(p)::"memory");return p;}
static void unmask(uint32_t p){__asm__ volatile("dmb sy\n msr primask, %0"::"r"(p):"memory");}
static uint32_t task(void){
    uint32_t i,p,b,f;
    __asm__ volatile("mrs %0, ipsr":"=r"(i));__asm__ volatile("mrs %0, primask":"=r"(p));
    __asm__ volatile("mrs %0, basepri":"=r"(b));__asm__ volatile("mrs %0, faultmask":"=r"(f));
    if(i||p||b||f||rd(0x202BBBF8)||rd(0x80245764))return 0;
    return native(0x800D3162,0,0,0,0);
}
static int worker(void){uint32_t t=task();return t>1&&t<=32&&rd(0x202ACD00)==0x8022D244&&t==rd(0x202ACD04);}
static void invalidate(void){
    clock.valid=0;clock.seen=0;
    if(clock.epoch==UINT32_MAX){clock.fault=1;return;}
    ++clock.epoch;
}
uint32_t sp_p6_clock_v552_mutation_enter(uint32_t route,uint32_t request){
    if(route>=16 || (route==13 && request!=132))return 0;
    uint32_t p=mask();invalidate();
    if(clock.depth==UINT32_MAX)clock.fault=1;else ++clock.depth;
    unmask(p);return 1;
}
void sp_p6_clock_v552_mutation_leave(uint32_t observed){
    if(!observed)return;
    uint32_t p=mask();if(!clock.depth)clock.fault=1;else --clock.depth;unmask(p);
}
uint32_t sp_p6_clock_v552_epoch(void){uint32_t p=mask(),e=clock.epoch;unmask(p);return e;}
static int span(const void *p,size_t n){
    uintptr_t a=(uintptr_t)p,c=(uintptr_t)&clock;
    if(a<0x80000000u || (a&3u) || a>0x84000000u-n ||
       (a+n>c && a<c+sizeof(clock)))return 0;
    const uint32_t lo[]={0x80591D54,0x80592244,0x805923F8,0x82DFFC88,0x82E01144,0x833B875C,0x80245B28};
    const uint32_t bytes[]={0x250,0x54,8,0xD48,0x600,4,16};
    for(unsigned i=0;i<7;++i)if(a<lo[i]+bytes[i] && a+n>lo[i])return 0;
    return 1;
}
int sp_p6_clock_v552_bind(const SpSynthPreviewVoice *v,const int16_t *pcm){
    if(!worker()||!span(v,sizeof(*v))||!span(pcm,256)||v->initialized!=UINT32_C(0x50563531)||
       v->sample_rate!=48000.0f||v->visual.rate!=48000||
       ((uintptr_t)pcm<(uintptr_t)v+sizeof(*v) && (uintptr_t)pcm+256>(uintptr_t)v) ||
       !sp_p6_clock_v552_hook_coverage())return 0;
    uint32_t p=mask();
    if(clock.fault||clock.depth){unmask(p);return 0;}
    if(clock.voice && (clock.voice!=(uint32_t)(uintptr_t)v||clock.pcm!=(uint32_t)(uintptr_t)pcm)){unmask(p);return 0;}
    clock.voice=(uint32_t)(uintptr_t)v;clock.pcm=(uint32_t)(uintptr_t)pcm;invalidate();unmask(p);return 1;
}
static int observe(SpP6ClockReceiptV552 *s){
    if(clock.fault||clock.depth||!clock.epoch||!sp_p6_clock_v552_hook_coverage()||
       native(0x800C1A50,0,0,0,0)!=2||rb(0x80592245)!=0||
       rd(0x80591F60)!=0x80591F68||rd(0x82E01144+0x568))return 0;
    s->project=native(0x800E1190,0,0,0,0);
    s->pattern=native(0x800CEC50,2,0,0,0);
    s->tempo100=rh(0x80592250);s->ticks_per_bar=rh(0x80591E0C);s->ticks_per_beat=rh(0x80591E10);
    s->native_position=rd(0x833B875C);s->native_consumed=rd(0x80245B28);
    s->native_musical=rd(0x80592258);s->native_coarse=rd(0x8059226C);
    if(s->project>=128||s->pattern>=160||s->tempo100<4000||s->tempo100>20000||
       !s->ticks_per_beat||s->ticks_per_beat>960||!s->ticks_per_bar||
       s->ticks_per_bar>6720||s->ticks_per_bar%s->ticks_per_beat||
       s->native_position>INT32_MAX||s->native_musical<s->native_consumed||
       s->native_musical-s->native_consumed>8)return 0;
    uint16_t pos[3];native(0x80040820,s->native_position,(uint32_t)(uintptr_t)pos,0,0);
    s->bar=pos[0];s->beat=pos[1];s->tick=pos[2];
    if(!s->bar||!s->beat||s->beat>s->ticks_per_bar/s->ticks_per_beat||s->tick>=s->ticks_per_beat)return 0;
    return 1;
}
static int identity(const SpP6ClockReceiptV552 *a,const SpP6ClockReceiptV552 *b){
    return a->project==b->project&&a->pattern==b->pattern&&a->tempo100==b->tempo100&&
        a->ticks_per_bar==b->ticks_per_bar&&a->ticks_per_beat==b->ticks_per_beat;
}
static void copy(SpP6ClockReceiptV552 *to,const SpP6ClockReceiptV552 *from){
    volatile uint32_t *d=(volatile uint32_t *)to;
    const uint32_t *s=(const uint32_t *)from;
    for(unsigned i=0;i<20;++i)d[i]=s[i];
}
int sp_p6_clock_v552_pcm(const SpSynthPreviewVoice *v,const int16_t *pcm,uint32_t frames){
    if(task()!=1||frames!=64||clock.voice!=(uint32_t)(uintptr_t)v||clock.pcm!=(uint32_t)(uintptr_t)pcm||
       !v)return 0;
    uint32_t p=mask();SpP6ClockReceiptV552 s;s.pcm_end=v->visual.frame_sequence;
    if(v->initialized!=UINT32_C(0x50563531)||v->sample_rate!=48000.0f||v->terminal){invalidate();unmask(p);return 0;}
    if(s.pcm_end<64||!observe(&s)){clock.valid=0;clock.seen=0;unmask(p);return 0;}
    s.abi=SP_P6_CLOCK_ABI;s.epoch=clock.epoch;s.flags=SP_P6_CLOCK_NOMINAL|SP_P6_CLOCK_BLOCK_BOUNDARY;
    s.pcm_begin=s.pcm_end-64;s.pcm_rate=48000;s.maximum_block_frames=64;
    SpP6ClockReceiptV552 *old=&clock.receipt;
    if(clock.seen){
        uint32_t d=s.native_consumed-old->native_consumed;
        uint32_t phase=old->native_position%old->ticks_per_bar;
        if(old->epoch!=s.epoch||!identity(old,&s)||s.pcm_end-old->pcm_end!=64||
           s.native_coarse-old->native_coarse!=32||d>8||
           s.native_position%s.ticks_per_bar!=(phase+d)%s.ticks_per_bar){
            invalidate();unmask(p);return 0;
        }
        if(phase+d>=s.ticks_per_bar)s.flags|=SP_P6_CLOCK_DOWNBEAT;
        clock.valid=1;
    }else clock.valid=0;
    if(clock.sequence==UINT32_MAX){clock.fault=1;clock.valid=0;unmask(p);return 0;}
    s.sequence=++clock.sequence;copy(&clock.receipt,&s);clock.seen=1;int ok=clock.valid;unmask(p);return ok;
}
int sp_p6_clock_v552_read(SpP6ClockReceiptV552 *out,uint32_t epoch){
    if(!span(out,sizeof(*out))||!worker())return 0;
    uint32_t p=mask();SpP6ClockReceiptV552 s;
    if(!clock.valid||clock.receipt.epoch!=clock.epoch||(epoch&&epoch!=clock.epoch)||
       !observe(&s)||!identity(&s,&clock.receipt)||
       s.native_coarse!=clock.receipt.native_coarse||s.native_consumed!=clock.receipt.native_consumed||
       s.native_position!=clock.receipt.native_position){unmask(p);return 0;}
    copy(out,&clock.receipt);unmask(p);return 1;
}
