#ifndef SP_P6_PATTERN_CLOCK_V552_H
#define SP_P6_PATTERN_CLOCK_V552_H
#include "sp_synth_preview_voice.h"
#include <stdint.h>

enum { SP_P6_CLOCK_ABI=1,SP_P6_CLOCK_NOMINAL=1,SP_P6_CLOCK_BLOCK_BOUNDARY=2,
       SP_P6_CLOCK_DOWNBEAT=4 };
typedef struct {
    uint32_t abi,epoch,sequence,flags,project,pattern,tempo100;
    uint32_t ticks_per_bar,ticks_per_beat,bar,beat,tick;
    uint32_t native_position,native_consumed,native_musical,native_coarse;
    uint32_t pcm_begin,pcm_end,pcm_rate,maximum_block_frames;
} SpP6ClockReceiptV552;

/* Exact SMPL task, with the already initialized permanent P6 voice and final
 * PCM buffer. Native hook coverage is read from the actual entry bytes. No
 * task/ready/downbeat/token argument exists. Binding grants no resource. */
int sp_p6_clock_v552_bind(const SpSynthPreviewVoice *,const int16_t *);
/* Actual successful final64-frame P6 render only, audio task1. The cursor is
 * read from the audio-owned voice. A duplicate, skipped DMA/callback, changed
 * epoch, stopped/external clock or incoherent pattern consumer clears receipt.
 * A downbeat is the observed native bar crossing. pcm_end names the exact
 * subsequent render boundary; it does not claim a measured acoustic instant.
 * Capture starts after this boundary, never by appending the preceding block. */
int sp_p6_clock_v552_pcm(const SpSynthPreviewVoice *,const int16_t *,uint32_t);
/* SMPL reads only a current, unchanged epoch and native identity. Output is
 * unchanged on refusal. expected_epoch0 means latest; another value must match.
 * This is an observation, with no file/take grant or START effect. */
int sp_p6_clock_v552_read(SpP6ClockReceiptV552 *,uint32_t expected_epoch);
/* Mutation wrappers call these around their pinned original continuations.
 * They invalidate before any native wait. Generic project setter watches only
 * request132. No public function publishes a positive coverage receipt. */
uint32_t sp_p6_clock_v552_mutation_enter(uint32_t route,uint32_t request);
void sp_p6_clock_v552_mutation_leave(uint32_t observed);
uint32_t sp_p6_clock_v552_hook_coverage(void);
uint32_t sp_p6_clock_v552_epoch(void);
#endif
