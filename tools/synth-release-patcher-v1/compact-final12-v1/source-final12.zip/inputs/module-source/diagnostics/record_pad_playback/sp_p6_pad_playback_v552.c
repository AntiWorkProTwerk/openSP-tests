#include "sp_p6_pad_playback_v552.h"
static uint32_t be32(const uint8_t *p) {
    return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];
}
int sp_p6_playback_v552_format(const uint8_t *h, uint32_t n, uint32_t file,
                             SpP6PadPlaybackFormat *out) {
    uint32_t channels, frame_bytes, pcm;
    if (!h || !out || n < 512 || file <= 512 || h[0]!='R' || h[1]!='F' ||
        h[2]!='W' || h[3]!='V' || be32(h+4)!=file-8 ||
        be32(h+8)!=48000 || be32(h+16)!=16) return 0;
    channels=be32(h+12);
    if (channels!=1 && channels!=2) return 0;
    frame_bytes=2*channels; pcm=file-512;
    if (pcm%frame_bytes) return 0;
    out->sample_rate=48000; out->channels=channels; out->bits=16;
    out->first_byte=512; out->pcm_bytes=pcm; out->frames=pcm/frame_bytes;
    return 1;
}
uint32_t sp_p6_playback_v552_admission(void) { return 0; }
