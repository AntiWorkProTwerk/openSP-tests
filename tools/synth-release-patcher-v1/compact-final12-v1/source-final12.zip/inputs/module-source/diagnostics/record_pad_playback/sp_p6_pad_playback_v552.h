#ifndef SP_P6_PAD_PLAYBACK_V552_H
#define SP_P6_PAD_PLAYBACK_V552_H
#include <stdint.h>
typedef struct {
    uint32_t sample_rate, channels, bits, first_byte, pcm_bytes, frames;
} SpP6PadPlaybackFormat;
/* Format inspection only. Native digest/metadata, lifetime and audio owners
 * must be validated by their existing services. No recording grant. */
int sp_p6_playback_v552_format(const uint8_t *header, uint32_t header_bytes,
                             uint32_t file_bytes, SpP6PadPlaybackFormat *out);
uint32_t sp_p6_playback_v552_admission(void);
#endif
