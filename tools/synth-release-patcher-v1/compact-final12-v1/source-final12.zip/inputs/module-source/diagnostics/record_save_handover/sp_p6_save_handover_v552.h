#ifndef SP_P6_SAVE_HANDOVER_V552_H
#define SP_P6_SAVE_HANDOVER_V552_H
#include "sp_synth_capture_timed_v552.h"
#include "sp_p6_record_files_v552.h"
enum { SP_P6_SAVE_IDLE, SP_P6_SAVE_WRITING, SP_P6_SAVE_WAIT,
       SP_P6_SAVE_RETIRING, SP_P6_SAVE_TRANSFERRED, SP_P6_SAVE_FAULT };
enum { SP_P6_SAVE_IO=1, SP_P6_SAVE_IDENTITY=2, SP_P6_SAVE_METADATA=4,
       SP_P6_SAVE_CONTEXT=8, SP_P6_SAVE_EXHAUSTED=16 };
typedef struct {
    SpSynthCaptureTimedV552 *capture;
    uint32_t state,fault,token,generation,project,pad,frames,bytes;
    uint32_t sequence,wait_sequence,ack_sequence,project_seen,project_bytes;
    SpP6RecordFileIdentityV552 cache;
    uint8_t record[172],metadata[36],name[24];
} SpP6SaveHandoverV552;
extern SpP6SaveHandoverV552 sp_p6_save_handover_v552;
int sp_p6_save_v552_bind(SpSynthCaptureTimedV552 *capture);
/* SMPL only. Pad is zero-based; owner and token are derived from native state. */
int sp_p6_save_v552_write(SpSynthCaptureTimedV552 *capture,uint32_t pad);
int sp_p6_save_v552_poll(SpSynthCaptureTimedV552 *capture);
void sp_p6_save_v552_before_wait(void *record);
void sp_p6_save_v552_record_return(uint32_t record,uint32_t action);
int sp_p6_save_v552_old_drain(void);
uint32_t sp_p6_save_v552_project(uint32_t,uint32_t,uint32_t,uint32_t);
int sp_p6_save_v552_retirement_ready(SpSynthCaptureTimedV552 *capture);
int sp_p6_record_token_v552_save_retired(SpSynthCaptureTimedV552 *capture);
int sp_p6_record_producer_v552_save_release_ready(SpSynthCaptureTimedV552 *capture);
int sp_p6_record_producer_v552_saved_released(SpSynthCaptureTimedV552 *capture);
/* Always zero: this component has no production admission authority. */
uint32_t sp_p6_save_v552_admission(void);
#endif
