#include "sp_p6_record_mutation_closure_v552.h"
#include "sp_p6_pattern_clock_v552.h"

uint32_t sp_p6_mc_v552_original(SpP6ProjectCommandV552 command) {
    if(command.operation==132 && command.object==UINT32_C(0x82E009D0))
        return sp_p6_pg_setter_original_v552(command.object,132,command.project,command.selector);
    if((command.operation!=SP_P6_MC_RESET && command.operation!=SP_P6_MC_INITIALIZE) ||
       command.object || command.project || command.selector) {
        sp_p6_record_project_gate_v552.fault|=128;
        return SP_P6_PROJECT_DEFERRED;
    }
    /* The same clock project route observes direct stores only after admission. */
    uint32_t watched=sp_p6_clock_v552_mutation_enter(command.operation==SP_P6_MC_RESET?14:15,0);
    uint32_t result=command.operation==SP_P6_MC_RESET?
        sp_p6_mc_v552_reset_original():sp_p6_mc_v552_initialize_original();
    sp_p6_clock_v552_mutation_leave(watched);
    return result;
}
uint32_t sp_p6_mc_v552_admission(void) { return 0; }
