#ifndef SP_P6_RECORD_MUTATION_CLOSURE_V552_H
#define SP_P6_RECORD_MUTATION_CLOSURE_V552_H
#include "sp_p6_record_project_gate_v552.h"

/* Private command tags in the existing gate FIFO; never stock operations. */
#define SP_P6_MC_RESET UINT32_C(0xFFFFFFFE)
#define SP_P6_MC_INITIALIZE UINT32_C(0xFFFFFFFD)
uint32_t sp_p6_mc_v552_reset(void);
uint32_t sp_p6_mc_v552_initialize(void);
uint32_t sp_p6_mc_v552_original(SpP6ProjectCommandV552);
uint32_t sp_p6_mc_v552_reset_original(void);
uint32_t sp_p6_mc_v552_initialize_original(void);
int sp_p6_mc_v552_hook_coverage(void);
uint32_t sp_p6_mc_v552_admission(void);
#endif
