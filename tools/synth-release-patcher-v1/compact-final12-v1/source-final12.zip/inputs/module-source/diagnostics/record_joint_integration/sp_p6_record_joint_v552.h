#ifndef SP_P6_RECORD_JOINT_V552_H
#define SP_P6_RECORD_JOINT_V552_H
#include "sp_p6_pattern_clock_v552.h"

/* Permanent SMPL binding after the actual timed source has initialized. */
int sp_p6_record_joint_v552_bind(const SpSynthPreviewVoice *, const int16_t *);
/* Successful final P6 render, audio task1, before the next native TX block.
 * Clock observation and the sole synth capture producer share this envelope.
 * A lost clock receipt faults an active take without appending that block. */
int sp_p6_record_joint_v552_pcm(const SpSynthPreviewVoice *, const int16_t *, uint32_t);
/* SMPL observation only. No START, token, project or resource grant. */
int sp_p6_record_joint_v552_read(SpP6ClockReceiptV552 *, uint32_t);
/* Actual SMPL schedules the stock REC drain event. Caller cadence remains a
 * production join requirement. This never services FILE IO from the audio task. */
int sp_p6_record_joint_v552_service(void);
uint32_t sp_p6_record_joint_v552_admission(void);
#endif
