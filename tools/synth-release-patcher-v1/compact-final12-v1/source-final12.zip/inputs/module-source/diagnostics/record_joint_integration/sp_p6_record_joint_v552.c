#include "sp_p6_record_joint_v552.h"
#include "sp_p6_capture_bridge.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_token_v552.h"
#include <stdint.h>
extern int sp_p6_capture_v552_manual_clock(const int16_t *,uint32_t);

typedef struct {
    atomic_uint voice;
    atomic_uint pcm;
} Joint;
static Joint joint;
_Static_assert(sizeof(Joint)==8,"Joint permanent publication budget");

int sp_p6_record_joint_v552_bind(const SpSynthPreviewVoice *voice, const int16_t *pcm) {
    if (atomic_load_explicit(&joint.voice,memory_order_acquire) || atomic_load_explicit(&joint.pcm,memory_order_relaxed)) return 0;
    if (!sp_p6_clock_v552_bind(voice, pcm)) return 0;
    if (!sp_p6_capture_v552_source(SP_P6_SOURCE_SYNTH_ONLY, pcm, 1)) return 0;
    atomic_store_explicit(&joint.pcm,(uint32_t)(uintptr_t)pcm,memory_order_relaxed);
    atomic_store_explicit(&joint.voice,(uint32_t)(uintptr_t)voice,memory_order_release);
    return 1;
}
int sp_p6_record_joint_v552_pcm(const SpSynthPreviewVoice *voice, const int16_t *pcm, uint32_t frames) {
    uint32_t bound=atomic_load_explicit(&joint.voice,memory_order_acquire);
    if (!bound || (uintptr_t)voice!=bound || (uintptr_t)pcm!=atomic_load_explicit(&joint.pcm,memory_order_relaxed) || frames != 64) return 0;
    int manual=sp_p6_capture_v552_manual_clock(pcm,frames);
    if(manual<0)return sp_p6_capture_v552_tx_fault(pcm,frames);
    if(manual==1)return sp_p6_capture_v552_tx(pcm,frames);
    if (!sp_p6_clock_v552_pcm(voice, pcm, frames))
        return sp_p6_capture_v552_tx_fault(pcm, frames);
    return sp_p6_capture_v552_tx(pcm, frames);
}
int sp_p6_record_joint_v552_read(SpP6ClockReceiptV552 *out, uint32_t epoch) {
    if (!atomic_load_explicit(&joint.voice,memory_order_acquire)) return 0;
    return sp_p6_clock_v552_read(out, epoch);
}
int sp_p6_record_joint_v552_service(void) {
    uint32_t mask, faultmask;
    __asm__ volatile("mrs %0, primask":"=r"(mask));
    __asm__ volatile("mrs %0, faultmask":"=r"(faultmask));
    SpSynthCaptureTimedV552 *capture=sp_p6_record_producer_v552.capture;
    if (!atomic_load_explicit(&joint.voice,memory_order_acquire) || mask || faultmask || !capture ||
        *(volatile const uint32_t *)(uintptr_t)0x202BBBF8u ||
        !sp_p6_record_context_v552_current(1)) return 0;
    uint32_t phase=atomic_load_explicit(&capture->state,memory_order_acquire)&255u;
    uint32_t token=atomic_load_explicit(&capture->token,memory_order_acquire);
    if ((phase!=SP_TCAP_RUNNING && phase!=SP_TCAP_STOP_PENDING) || !token ||
        atomic_load_explicit(&capture->fault,memory_order_acquire) ||
        atomic_load_explicit(&capture->handoff_fault,memory_order_acquire) ||
        !sp_p6_record_producer_v552.held || sp_p6_record_producer_v552.active || sp_p6_record_producer_v552.fault || sp_p6_record_producer_v552.token!=token ||
        sp_p6_record_token_v552_actual_token()!=token) return 0;
    return ((uint32_t (*)(void))(uintptr_t)0x800933A1u)()==1 ? 1 : -1;
}
uint32_t sp_p6_record_joint_v552_admission(void) { return 0; }
