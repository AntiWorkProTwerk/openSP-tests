#include "sp_p6_session_join.h"
#include "sp_synth_session_v552.h"
#include "sp_synth_capture_timed_v552.h"
#include <stddef.h>

uint32_t sp_p6_session_join_admission(void) { return 0; }

const SpP6SessionJoinLayout sp_p6_session_join_layout = {
    sizeof(SpSynthSessionV552), sizeof(SpSynthRuntimeStorage),
    offsetof(SpSynthSessionV552, ready),
    offsetof(SpSynthSessionV552, control_ready),
    offsetof(SpSynthSessionV552, terminal),
    offsetof(SpSynthSessionV552, startup.ready),
    offsetof(SpSynthSessionV552, startup.memory.attached),
    offsetof(SpSynthSessionV552, backend),
    offsetof(SpSynthRuntimeStorage, clock),
    offsetof(SpSynthCaptureTimedV552, backend)
};
_Static_assert(sizeof(SpP6SessionJoinLayout)==40,"Offline layout evidence ABI");
