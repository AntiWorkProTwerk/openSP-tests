#ifndef SP_P6_PRODUCTION_JOIN_H
#define SP_P6_PRODUCTION_JOIN_H
#include "sp_synth_preview_native_v552.h"
#include "sp_synth_capture_timed_v552.h"
#include <stdint.h>

uint32_t sp_p6_production_admission(void);
uint32_t sp_p6_production_cold_started(void);
uint64_t sp_p6_production_cold_result(void);
void sp_p6_production_cold_done(uint64_t result);
void sp_p6_production_smpl(void);
void sp_p6_production_pcm(const SpSynthPreviewVoice *,const int16_t *,uint32_t);
extern SpSynthCaptureTimedV552 sp_p6_production_capture;
extern SpSynthSessionV552 sp_p6_production_session;
#endif
