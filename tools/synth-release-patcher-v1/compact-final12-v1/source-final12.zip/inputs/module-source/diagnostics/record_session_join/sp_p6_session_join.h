#ifndef SP_P6_SESSION_JOIN_H
#define SP_P6_SESSION_JOIN_H
#include <stdint.h>

/* This source-owned package has no complete request/retirement contract yet.
 * Successful scheduling and private intent cannot alter this admission. */
uint32_t sp_p6_session_join_admission(void);

/* Compiled layout evidence for offline inspectors. These are offsets and sizes,
 * never READY inputs, tokens or retirement attestations. */
typedef struct {
    uint32_t session_bytes, runtime_bytes;
    uint32_t session_ready, session_control_ready, session_terminal;
    uint32_t startup_ready, startup_attached, session_backend;
    uint32_t runtime_clock, capture_backend;
} SpP6SessionJoinLayout;
extern const SpP6SessionJoinLayout sp_p6_session_join_layout;
#endif
