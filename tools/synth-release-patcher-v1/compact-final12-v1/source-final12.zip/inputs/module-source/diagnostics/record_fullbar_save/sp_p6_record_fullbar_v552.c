#include "sp_p6_record_fullbar_v552.h"
#include "sp_p6_record_joint_v552.h"
#include "sp_p6_record_context_v552.h"
#include "sp_p6_record_producer_v552.h"
#include "sp_p6_record_token_v552.h"
#include "sp_p6_record_files_v552.h"
#include "sp_p6_save_handover_v552.h"

#define OUTER 0x82E0E71Cu
#define NORMAL 0x82FE4F08u
#define TABLE 0x80B5F3B4u
static uint32_t rd(uint32_t p) { return *(volatile const uint32_t *)(uintptr_t)p; }
static uint32_t val(const atomic_uint *p) { return atomic_load_explicit(p,memory_order_acquire); }
static int unmasked(void) {
    uint32_t p,f;
    __asm__ volatile("mrs %0, primask":"=r"(p));
    __asm__ volatile("mrs %0, faultmask":"=r"(f));
    return !p && !f && !rd(0x202BBBF8u);
}
static int stopped(SpSynthCaptureTimedV552 *c,uint32_t record_operation) {
    SpP6RecordProducerV552 *p=&sp_p6_record_producer_v552;
    SpP6RecordFilesV552 *j=&sp_p6_record_files_v552;
    if(!c || c!=p->capture || !unmasked())return 0;
    uint32_t phase=val(&c->state)&255u,token=val(&c->token);
    if((phase!=SP_TCAP_STOP_PENDING && phase!=SP_TCAP_HELD) || !token ||
       c->last_token!=token || c->plan.take_token!=token || !c->file_owned ||
       val(&c->fault) || val(&c->handoff_fault) || val(&c->rx_active) || c->window.inflight ||
       val(&c->rx_ack)!=token || !p->held || p->token!=token || p->active || p->fault ||
       !j->active || j->fault || j->smpl_operation || j->record_operation!=record_operation || j->cache_depth ||
       !sp_p6_record_token_v552_current() || c->handle<1 || c->handle>=1024 ||
       rd(OUTER+72)!=c->handle || rd(OUTER+596)!=NORMAL || rd(NORMAL)!=0x8021E020u ||
       rd(NORMAL+432)!=c->handle || rd(TABLE+4*c->handle)!=c->descriptor ||
       c->descriptor<0x80000000u || c->descriptor>0x83FFFFDCu || !(rd(c->descriptor)&1u) ||
       *(volatile const uint8_t *)(uintptr_t)(OUTER+590) || rd(OUTER+592))return 0;
    return 1;
}
int sp_p6_record_fullbar_v552_drain_ready(SpSynthCaptureTimedV552 *c) {
    return stopped(c,SP_P6_RF_RECORD) && sp_p6_record_context_v552_current(2);
}
static int ready(SpSynthCaptureTimedV552 *c,uint32_t lease) {
    if(!stopped(c,0) || val(&c->state)!=SP_TCAP_HELD+lease ||
       !sp_p6_record_context_v552_current(1) ||
       sp_p6_record_token_v552_actual_token()!=val(&c->token) ||
       c->window.start.take_token!=val(&c->token) ||
       c->window.accepted_frames>(UINT32_MAX-512u)/4u ||
       rd(NORMAL+512)!=(uint32_t)c->window.accepted_frames || rd(NORMAL+516) ||
       rd(NORMAL+420)>=30 || rd(NORMAL+424)>=30)return 0;
    uint32_t total=(uint32_t)c->window.accepted_frames*4u,buffered=0;
    uint32_t written=rd(NORMAL+52);
    if(written>total)return 0;
    for(unsigned i=0;i<30;i++) {
        uint32_t p=NORMAL+60+12*i,n=rd(p+4);
        uint8_t ready=*(volatile const uint8_t *)(uintptr_t)p;
        if(n>5120 || (n&1u) || ready>1 || (ready && n!=5120) ||
           rd(p+8)!=0x20261D00u+10240u*i ||
           (n && !ready && i!=rd(NORMAL+420)))return 0;
        buffered+=2*n;
    }
    return buffered==total-written;
}
int sp_p6_record_fullbar_v552_save_ready(SpSynthCaptureTimedV552 *c) {
    return ready(c,0);
}
int sp_p6_record_fullbar_v552_post_ready(SpSynthCaptureTimedV552 *c) {
    /* Exactly this post wrapper's lease; another callback still blocks. */
    return ready(c,256);
}
int sp_p6_record_fullbar_v552_service(void) {
    SpSynthCaptureTimedV552 *c=sp_p6_record_producer_v552.capture;
    if(!c || !unmasked() || !sp_p6_record_context_v552_current(1))return 0;
    uint32_t phase=val(&c->state)&255u;
    SpP6SaveHandoverV552 *save=&sp_p6_save_handover_v552;
    if(val(&c->state)==SP_TCAP_FINALIZED && save->capture==c && save->state==SP_P6_SAVE_WAIT &&
       !save->fault && save->sequence && save->ack_sequence!=save->sequence &&
       save->token==val(&c->token) && c->file_owned && c->plan.take_token==save->token &&
       sp_p6_record_token_v552_actual_token()==save->token &&
       !val(&c->fault) && !val(&c->handoff_fault) && !val(&c->rx_active) &&
       !c->window.inflight && val(&c->rx_ack)==save->token) {
        return ((uint32_t (*)(uint32_t,uint32_t))(uintptr_t)0x800D30A5u)(0x202ACFA0u,64)==1 ? 1 : -1;
    }
    if(phase==SP_TCAP_RUNNING || phase==SP_TCAP_STOP_PENDING)
        return sp_p6_record_joint_v552_service();
    if(!stopped(c,0) || sp_p6_record_token_v552_actual_token()!=val(&c->token))return 0;
    return ((uint32_t (*)(void))(uintptr_t)0x800933A1u)()==1 ? 1 : -1;
}
uint32_t sp_p6_record_fullbar_v552_admission(void) { return 0; }
