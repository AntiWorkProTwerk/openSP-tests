#ifndef SP_P6_RECORD_FULLBAR_V552_H
#define SP_P6_RECORD_FULLBAR_V552_H
#include "sp_synth_capture_timed_v552.h"

/* Called only by the checked timed REC entry for action1. It grants no token. */
int sp_p6_record_fullbar_v552_drain_ready(SpSynthCaptureTimedV552 *);
/* HELD SMPL snapshot: written PCM plus real queued halfwords must equal the
 * accepted stereo frame total. Native SAVE still performs the final flush. */
int sp_p6_record_fullbar_v552_save_ready(SpSynthCaptureTimedV552 *);
/* Checked stock drain post after the timed wrapper takes exactly one lease. */
int sp_p6_record_fullbar_v552_post_ready(SpSynthCaptureTimedV552 *);
/* Actual SMPL retries the stock REC wake in RUNNING/STOP_PENDING/HELD,
 * and the fresh SAVE retirement event while FINALIZED/WAIT.
 * 1: post accepted; -1: post failed; 0: refused. A post is never retirement. */
int sp_p6_record_fullbar_v552_service(void);
uint32_t sp_p6_record_fullbar_v552_admission(void);
#endif
