#include "sp_p6_phrase.h"

void sp_p6_phrase_defaults(SpP6PhraseSettings *out) {
    if(out)*out=(SpP6PhraseSettings){SP_P6_SOURCE_SYNTH_ONLY,SP_P6_PHRASE_BARS,
        4,1,1,0,1,SP_P6_PHRASE_ALIGN_PATTERN_BAR};
}
int sp_p6_phrase_settings_valid(const SpP6PhraseSettings *s) {
    return s && (s->source==SP_P6_SOURCE_SYNTH_ONLY || s->source==SP_P6_SOURCE_NATIVE_MIX) &&
        s->mode<=SP_P6_PHRASE_MANUAL && s->bars>=1 && s->bars<=16 &&
        s->count_in_bars<=4 && s->include_release_tail<=1 &&
        s->destination_bank<10 && s->destination_pad>=1 && s->destination_pad<=16 &&
        s->alignment<=SP_P6_PHRASE_ALIGN_PATTERN_BAR;
}
int sp_p6_phrase_capture_profile(const SpP6PhraseSettings *s,uint32_t tempo100,SpAppCapture *out) {
    if(!out || !sp_p6_phrase_settings_valid(s) || tempo100<2000 || tempo100>30000 ||
       s->alignment!=SP_P6_PHRASE_ALIGN_CALLBACK)return 0;
    SpAppCapture next={s->mode==SP_P6_PHRASE_BARS?1u:0u,
        s->mode==SP_P6_PHRASE_MANUAL?120.0f:4.0f,(float)s->bars,(float)tempo100/100.0f,
        s->count_in_bars,s->include_release_tail};
    *out=next;return 1;
}
