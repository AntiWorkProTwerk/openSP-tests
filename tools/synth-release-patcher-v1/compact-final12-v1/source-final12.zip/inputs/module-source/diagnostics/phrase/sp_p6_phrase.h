#ifndef SP_P6_PHRASE_H
#define SP_P6_PHRASE_H
#include "sp_synth_app.h"
#include "sp_p6_capture_bridge.h"

enum { SP_P6_PHRASE_BARS=0,SP_P6_PHRASE_MANUAL=1 };
enum { SP_P6_PHRASE_ALIGN_CALLBACK=0,SP_P6_PHRASE_ALIGN_PATTERN_BAR=1 };
typedef struct {
    uint32_t source,mode,bars,count_in_bars,include_release_tail;
    uint32_t destination_bank,destination_pad,alignment;
} SpP6PhraseSettings;

/* All fields are UI/SMPL-owned. Defaults choose synth-only, four bars, one bar
 * count-in, captured release tail and pad A1. A1 must be queried as empty under
 * the actual destination lease before admission; defaults never authorize it. */
void sp_p6_phrase_defaults(SpP6PhraseSettings *);
int sp_p6_phrase_settings_valid(const SpP6PhraseSettings *);

/* Build the immutable existing timed-recorder START profile from observed
 * native hundredths-BPM. Manual recording is bounded at120seconds and can use
 * ordinary tokened STOP sooner. Bar mode admits1..16bars. This transforms
 * settings only; the native recorder still requires its actual owner/lease.
 * ALIGN_PATTERN_BAR is retained in settings but refuses here because a native
 * pattern downbeat-to-PCM receipt has not yet been established. The snapshot
 * getter's tempo and state alone cannot supply that receipt. Output remains
 * unchanged on refusal. Successful planning supplies no file effects or UI
 * recording/saved acknowledgment. SYNTH_ONLY tail is the synth voice release;
 * stock effects are outside that direct final-PCM source. */
int sp_p6_phrase_capture_profile(const SpP6PhraseSettings *,uint32_t tempo100,SpAppCapture *);
#endif
