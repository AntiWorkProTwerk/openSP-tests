#ifndef SP_P6_CAPTURE_BRIDGE_H
#define SP_P6_CAPTURE_BRIDGE_H
#include <stdint.h>

enum { SP_P6_SOURCE_SYNTH_ONLY=1, SP_P6_SOURCE_NATIVE_MIX=2 };

/* This extends the v5.52 timed recorder owner; it does not acquire its file,
 * project or recorder resources. Bind from its actual serialized SMPL owner
 * while FREE/EXCLUSIVE_IDLE, before BEGIN. pcm is the permanent final-P5-PCM
 * buffer; audio_task is the separately identified P5 TX task. The source and
 * pointer remain immutable until the take has retired. A failed binding leaves
 * them unchanged. Native mix still uses the original RX recorder source.
 * SYNTH_ONLY contains post-filter/envelope/limiter PCM, before stock effects.
 * A native mixed-source choice needs physical source/routing qualification.
 */
int sp_p6_capture_v552_source(uint32_t source,const int16_t *pcm,uint32_t audio_task);

/* Exact final-P5-PCM TX envelope, after successful voice rendering. Called
 * only once per native 64-frame TX block, with the bound permanent pointer.
 * The existing timed owner retains every lease and measures the native frame
 * counter after the real normal stereo recorder returns. Its native RX entry
 * still runs; owned SYNTH_ONLY normal-recorder consumption is suppressed there
 * so RX cannot append the same take a second time. Returns1 after that owned TX
 * envelope returned,0 when this route is inactive, and-1 for a retained failure.
 * It cannot prepare/open/save/discard a take or grant a resource lease.
 */
int sp_p6_capture_v552_tx(const int16_t *pcm,uint32_t frames);

/* The same serialized final-PCM owner reports that its render failed or ended
 * before another successful block. Latches capture failure, then acknowledges
 * STOP only after this exact TX envelope returns. It appends no failed/silent
 * replacement block, performs no file work and leaves the retained token for
 * ordinary worker failure/discard handling. Wrong context cannot retire it. */
int sp_p6_capture_v552_tx_fault(const int16_t *pcm,uint32_t frames);

/* Audio owner, after the same successful P5 render and before tx(). released
 * must be the current audio-owned all-keys-up observation. The exact bound
 * PCM block must also be entirely zero. Only an already-entered TAIL window
 * receives its boundary at this block's end; quiet count-in/body cannot shorten
 * the phrase. This observes natural release and does not force note-off, include
 * stock effects, acquire resources or replace the current five-second cap. */
int sp_p6_capture_v552_tail_idle(const int16_t *pcm,uint32_t frames,uint32_t released);
#endif
