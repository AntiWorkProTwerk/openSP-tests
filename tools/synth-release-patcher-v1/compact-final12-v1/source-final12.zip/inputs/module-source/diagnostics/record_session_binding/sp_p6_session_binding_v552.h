#ifndef SP_P6_SESSION_BINDING_V552_H
#define SP_P6_SESSION_BINDING_V552_H
#include "sp_p6_phrase.h"
#include "sp_p6_pattern_v552.h"
#include "sp_p6_pattern_clock_v552.h"
#include "sp_synth_session_v552.h"

enum { SP_P6_SB_EMPTY, SP_P6_SB_PREPARING, SP_P6_SB_PREPARED, SP_P6_SB_FAILED };
enum { SP_P6_SB_RUNTIME=1, SP_P6_SB_CONTROL_CLOCK=2, SP_P6_SB_BACKEND=4,
       SP_P6_SB_DOWNBEAT=8, SP_P6_SB_DESTINATION=16, SP_P6_SB_RETIREMENT=32,
       SP_P6_SB_NATIVE_SERVICE=64 };
typedef struct {
    atomic_uint phase, fault, pending, blocked;
    uint32_t task, sequence, visit, page;
    int32_t prepare_result;
    SpP6PhraseSettings settings;
    SpP6PatternSnapshotV552 pattern;
    SpP6EmptyPadSnapshotV552 destination;
    SpP6ClockReceiptV552 clock;
} SpP6SessionBindingV552;
extern SpP6SessionBindingV552 sp_p6_session_binding_v552;

/* Installed panel wait only. Source-owned deferred preparation uses the
 * existing3824-byte session and pins its native-pool runtime once. It never
 * publishes session.ready/control_ready or admits a take. No task/ready/config
 * argument is accepted. A failed attempt and every identity remain permanent. */
void sp_p6_session_binding_v552_panel(void);
/* Installed native RECORD page value-button only, after the existing source
 * input offer. Publishes a bounded intent, not SpAppRequest or capture token.
 * Settings come from the phrase provider's defaults. Native getters snapshot
 * that explicit A1 destination. Pending intent is never replaced by another
 * press or page visit. Refusal leaves existing native input consumption intact. */
int sp_p6_session_binding_v552_record_press(void *page);
/* Installed native SMPL owner. Resolves the source clock receipt and records
 * the missing contract before any START/file effect. Successful scheduling or
 * a downbeat never grants new admission. No caller supplies a receipt. */
void sp_p6_session_binding_v552_smpl(void);
uint32_t sp_p6_session_binding_v552_admission(void);
/* Source-owned backend link exposure. These accessors remain unavailable while
 * the control/audio/backend/retirement graph is incomplete. No copied request,
 * ready flag, token or completion argument can activate this owner. */
SpSynthSessionV552 *sp_p6_session_binding_v552_session(void);
const SpAppRequest *sp_p6_session_binding_v552_request(void);
#endif
