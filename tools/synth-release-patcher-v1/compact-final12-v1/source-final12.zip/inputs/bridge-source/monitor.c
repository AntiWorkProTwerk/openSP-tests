#include "local_input.h"
#include "usb_upload.h"
#include "flash.h"
#include "named_input.h"
#include "audio_probe.h"
/* Original bring-up code. This is a standalone APP1 experiment, not a sampler.
 * It expects boot firmware to have enabled the FlexSPI mapping and OCRAM.
 * No vendor code, decompiler output, or original firmware bytes are linked.
 */
#include <stdint.h>
#include <stddef.h>
#include "board.h"

#define REG32(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define REG16(a) (*(volatile uint16_t *)(uintptr_t)(a))
#define SCB_CCR 0xe000ed14u
#define SCB_DCCMVAC 0xe000ef68u
#define MAGIC 0x53503443u

struct diagnostic_mailbox {
    uint32_t magic, abi_version, state, heartbeat;
    uint32_t incoming_r0, incoming_sp, incoming_lr, incoming_control;
    uint32_t cpuid, vtor, ccr, mpu_ctrl;
    uint32_t data_test, bss_test, fault_number, cfsr;
    uint32_t hfsr, mmfar, bfar, build_marker;
};

__attribute__((section(".mailbox"), used, aligned(32)))
volatile struct diagnostic_mailbox mailbox;
/* These force real initialized-data copying and BSS clearing to be tested. */
volatile uint32_t initialized_probe = 0x404552a5u;
volatile uint32_t zero_probe;

extern uint32_t __stack_top;
extern void app1_entry(void);
extern void fault_entry(void);

__attribute__((section(".vectors"), used, aligned(1024)))
const uintptr_t vector_table[256] = {
    [0] = (uintptr_t)&__stack_top,
    [1] = (uintptr_t)app1_entry,
    [2 ... 37] = (uintptr_t)fault_entry,
    [38] = (uintptr_t)uart_irq_handler, /* external IRQ22 */
    [39 ... 255] = (uintptr_t)fault_entry
};

static inline void dsb(void) { __asm__ volatile("dsb sy" ::: "memory"); }

static void publish_mailbox(void) {
    /* Make diagnostics visible to a debug probe if inherited D-cache is on.
       Addresses written here are Cortex cache registers, not device flash. */
    if (REG32(SCB_CCR) & (1u << 16)) {
        uintptr_t end = (uintptr_t)&mailbox + sizeof(mailbox);
        for (uintptr_t p = (uintptr_t)&mailbox; p < end; p += 32)
            REG32(SCB_DCCMVAC) = (uint32_t)p;
    }
    dsb();
}

static void disable_watchdogs(void) {
    /* Widths and unlock sequence match the observed APP1 startup and NXP
       RT1060 register definitions. Actual fuse/boot configuration is unknown. */
    REG16(0x400b8008u) &= (uint16_t)~1u;
    REG16(0x400d0008u) &= (uint16_t)~1u;
    if (REG16(0x400b8000u) & 4u) REG16(0x400b8000u) &= (uint16_t)~4u;
    if (REG16(0x400d0000u) & 4u) REG16(0x400d0000u) &= (uint16_t)~4u;
    if (REG32(0x400bc000u) & (1u << 13)) {
        REG32(0x400bc004u) = 0xd928c520u;
    } else {
        REG32(0x400bc004u) = 0xc520u;
        REG32(0x400bc004u) = 0xd928u;
    }
    REG32(0x400bc008u) = 0xffffu;
    REG32(0x400bc000u) = (REG32(0x400bc000u) & ~0xa0u) | 0x20u;
}

__attribute__((noreturn))
void record_fault(uint32_t exception) {
    mailbox.magic = MAGIC;
    mailbox.state = 0xe0000000u | exception;
    mailbox.fault_number = exception;
    mailbox.cfsr = REG32(0xe000ed28u);
    mailbox.hfsr = REG32(0xe000ed2cu);
    mailbox.mmfar = REG32(0xe000ed34u);
    mailbox.bfar = REG32(0xe000ed38u);
    publish_mailbox();
    for (;;) __asm__ volatile("nop");
}

__attribute__((noreturn))
void firmware_main(uint32_t r0, uint32_t sp, uint32_t lr, uint32_t control) {
    volatile uint32_t *words = (volatile uint32_t *)&mailbox;
    for (size_t i = 0; i < sizeof(mailbox) / sizeof(uint32_t); ++i) words[i] = 0;
    mailbox.magic = MAGIC;
    mailbox.abi_version = 1;
    mailbox.state = 1;
    mailbox.incoming_r0 = r0;
    mailbox.incoming_sp = sp;
    mailbox.incoming_lr = lr;
    mailbox.incoming_control = control;
    mailbox.cpuid = REG32(0xe000ed00u);
    mailbox.vtor = REG32(0xe000ed08u);
    mailbox.ccr = REG32(SCB_CCR);
    mailbox.mpu_ctrl = REG32(0xe000ed94u);
    mailbox.data_test = initialized_probe;
    mailbox.bss_test = zero_probe;
    mailbox.build_marker = 0x52420001u;
    publish_mailbox();
    if (initialized_probe != 0x404552a5u || zero_probe != 0) record_fault(0x100u);
    disable_watchdogs();
    named_reset();
    board_init();
    oled_init();
    local_init();
    usb_init();
    audio_probe_init();
    mailbox.state = 2;
    for (;;) {
        ++mailbox.heartbeat;
        publish_mailbox();
        board_service();
        render_frame(mailbox.heartbeat);
        oled_frame(framebuffer);
        board_delay_ms(50);
        flash_service();
    }
}
