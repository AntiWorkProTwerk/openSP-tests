#pragma once
#include "controls.h"
struct named_view {uint32_t id,action,raw,level;int32_t delta;uint32_t ticks,events,held,pad_mask,encoder_invalid;};
void named_reset(void);
/* Caller serializes feed (UART IRQ and thread); snapshot masks IRQ briefly. */
void named_feed(unsigned source,unsigned slot,unsigned value,uint32_t ticks);
void named_snapshot(struct named_view *);
