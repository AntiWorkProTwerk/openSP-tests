/* Original bounded observations. No physical labels or velocity assumptions. */
#include "control_capture.h"
#include "local_input.h"
#include "board.h"
#include "named_input.h"
#define TICKS (*(volatile uint32_t *)0x401ec024u)
struct event {uint32_t ticks,sequence;uint16_t value;uint8_t source,slot;};
_Static_assert(sizeof(struct event)==12,"event wire size");
static struct event ring[128];
static uint32_t head,tail,sequence,snapshot_id,scan_stamp,scan_last,scan_min,scan_max,epoch;
static uint8_t snapshot[168];
uint32_t capture_enabled,capture_dropped;
static uint32_t lock(void) {uint32_t mask;__asm__ volatile("mrs %0, primask\ncpsid i":"=r"(mask)::"memory");return mask;}
static void unlock(uint32_t mask) {__asm__ volatile("msr primask, %0"::"r"(mask):"memory");}
static void put32(uint8_t *p,uint32_t v) {for(unsigned i=0;i<4;++i)p[i]=v>>(8*i);}
void capture_config(unsigned enabled) {
    uint32_t mask=lock();capture_enabled=enabled;head=tail=0;capture_dropped=0;
    scan_stamp=0;scan_last=0;scan_min=0;scan_max=0;++epoch;unlock(mask);
}
void capture_event(unsigned source,unsigned slot,unsigned value) {
    uint32_t mask=lock();
    uint32_t ticks=TICKS;
    named_feed(source,slot,value,ticks);
    if(capture_enabled) {
        uint32_t seq=++sequence;
        if(head-tail==128)++capture_dropped;
        else {struct event *e=&ring[head++&127];e->ticks=ticks;e->sequence=seq;e->value=value;e->source=source;e->slot=slot;}
    }
    unlock(mask);
}
void capture_scan(uint32_t ticks) {
    if(!capture_enabled)return;
    if(scan_stamp) {scan_last=ticks-scan_stamp;if(!scan_min || scan_last<scan_min)scan_min=scan_last;if(scan_last>scan_max)scan_max=scan_last;}
    scan_stamp=ticks;
}
void capture_snapshot(void) {
    uint32_t mask=lock();
    for(unsigned i=0;i<sizeof(snapshot);++i)snapshot[i]=0;
    put32(snapshot,++snapshot_id);put32(snapshot+4,TICKS);put32(snapshot+8,local.scans);
    put32(snapshot+12,scan_last);put32(snapshot+16,scan_min);put32(snapshot+20,scan_max);
    put32(snapshot+24,capture_dropped);put32(snapshot+28,local.adc_status);put32(snapshot+32,local.adc_errors);
    put32(snapshot+36,input.timer_running);put32(snapshot+40,input.errors);put32(snapshot+44,input.shutdown_requested);
    for(unsigned i=0;i<8;++i)snapshot[48+i]=local.matrix[i];
    for(unsigned i=0;i<32;++i) {snapshot[56+i*2]=local.raw[i];snapshot[57+i*2]=local.raw[i]>>8;}
    put32(snapshot+120,local.shift);put32(snapshot+124,local.encoder);put32(snapshot+128,sequence);
    put32(snapshot+132,head-tail);put32(snapshot+136,capture_enabled);put32(snapshot+140,epoch);
    unlock(mask);
}
void capture_snapshot_page(uint8_t *p,unsigned page) {
    p[0]='S';p[1]='P';p[2]='I';p[3]='S';put32(p+4,page);
    for(unsigned i=0;i<56;++i)p[8+i]=snapshot[page*56+i];
}
void capture_events_report(uint8_t *p) {
    uint32_t mask=lock();unsigned n=head-tail;if(n>4)n=4;
    p[0]='S';p[1]='P';p[2]='E';p[3]='V';put32(p+4,n);put32(p+8,capture_dropped);put32(p+12,head-tail-n);
    for(unsigned i=0;i<n;++i) {
        const uint8_t *e=(const uint8_t *)&ring[tail++&127];
        for(unsigned b=0;b<12;++b)p[16+i*12+b]=e[b];
    }
    unlock(mask);
}
