#include "named_input.h"
#include "audio_probe.h"
static struct controls_state named_controls;
static struct named_view named;
static void publish(const struct control_event *e,void *unused) {
    (void)unused;
    if(e->action==CONTROL_DOWN && control_map[e->id].source==1 && control_map[e->id].slot==17)audio_probe.page^=1;
    named.id=e->id;named.action=e->action;named.raw=e->raw;named.level=e->level;
    named.delta=e->delta;named.ticks=e->ticks;++named.events;
    if(e->action==CONTROL_INVALID)++named.encoder_invalid;
    int pad=control_map[e->id].pad_index;
    if(e->action==CONTROL_DOWN) {++named.held;if(pad>=0)named.pad_mask|=1u<<pad;}
    if(e->action==CONTROL_UP) {if(named.held)--named.held;if(pad>=0)named.pad_mask&=~(1u<<pad);}
}
void named_reset(void) {
    controls_reset(&named_controls);
    volatile uint8_t *bytes=(volatile uint8_t *)&named;
    for(unsigned i=0;i<sizeof(named);++i)bytes[i]=0;
    named.id=CONTROL_COUNT;
}
void named_feed(unsigned source,unsigned slot,unsigned value,uint32_t ticks) {
    controls_feed(&named_controls,source,slot,value,ticks,publish,0);
}
void named_snapshot(struct named_view *out) {
    uint32_t mask;__asm__ volatile("mrs %0, primask\ncpsid i":"=r"(mask)::"memory");
    *out=named;
    __asm__ volatile("msr primask, %0"::"r"(mask):"memory");
}
