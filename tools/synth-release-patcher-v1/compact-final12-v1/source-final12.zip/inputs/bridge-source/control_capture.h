#pragma once
#include <stdint.h>
/* Raw sources: 1 matrix(col*5+row), 2 ADC slot, 3 encoder state, 4 SHIFT. */
void capture_event(unsigned source,unsigned slot,unsigned value);
void capture_scan(uint32_t ticks);
void capture_config(unsigned enabled);
void capture_snapshot(void);
void capture_snapshot_page(uint8_t *p,unsigned page);
void capture_events_report(uint8_t *p);
extern uint32_t capture_enabled,capture_dropped;
