#pragma once
#include <stdint.h>
struct upload_state {
    uint32_t state, error, length, received, expected_crc, crc, packets;
};
extern volatile struct upload_state upload;
extern volatile uint32_t usb_ready, usb_configured, usb_setups, usb_resets, usb_errors;
void usb_init(void);
void usb_poll(void);
int usb_idle(void);
void upload_reset(void);
void upload_command(const uint8_t *report);
void upload_status(uint8_t *report);
