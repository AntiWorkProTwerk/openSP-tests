/* Original raw input diagnostic. Contracts/provenance in BOARD.md.
 * No stock callbacks, DMA, ADC_ETC, pad-ID tables or velocity algorithms.
 */
#include "board.h"
#include "local_input.h"
#include "control_capture.h"
#define R(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define GPIO 0x401bc000u
#define ADC 0x400c4000u
#define ROWS ((7u<<20)|(1u<<26)|(1u<<28))
#define DIGITAL (7u<<23)
#define ANALOG ((1u<<27)|(3u<<30))
volatile struct local_state local;
static uint32_t enabled, column, stage, stamp, spins, seeded;
static uint8_t candidate[8];
static uint16_t anchor[32];
static const uint8_t channels[4]={4,5,6,3};

static void select_column(void) {
    /* Preserve OLED bits: only dedicated mux address outputs are changed. */
    R(GPIO+0x88)=DIGITAL|ANALOG;
    R(GPIO+0x84)=(column<<23)|((column&1)<<27)|((column&6)<<29);
    stamp=R(0x401ec024); spins=0; stage=0;
}

void local_init(void) {
    enabled=0;
    R(0x400ac06c)&=~(ROWS|DIGITAL|ANALOG|(3u<<18));
    R(GPIO+0x88)=DIGITAL|ANALOG;
    R(GPIO+4)=(R(GPIO+4)&~(ROWS|(3u<<18)))|DIGITAL|ANALOG;
    for(unsigned bit=18;bit<32;++bit) {
        if(bit==29) continue;
        R(0x401f813cu+4*bit)=5;
    }
    /* Only this matrix input has an explicit stock pad write. Other matrix
       pads retain their resident/reset electrical settings, as stock does. */
    R(0x401f8394)=0x10b0;
    /* Stock ADC channels 3..6 share GPIO1 bits14..17. Inputs, pulls disabled. */
    R(0x400ac068)&=~0x3c000u;
    R(0x401b8004)&=~0x3c000u;
    for(unsigned bit=14;bit<18;++bit) {
        R(0x401f80bcu+4*bit)=5;
        R(0x401f82acu+4*bit)=0;
    }
    R(0x400fc06c)|=3u<<16; /* ADC1 CCGR1 CG8 */
    R(ADC+0x48)=1; /* ADACK running; no continuous/DMA/compare */
    R(ADC+0x44)=0x1b; /* ADACK /1, 12-bit, long sample, software trigger */
    for(unsigned i=0;i<8;++i) R(ADC+4*i)=31;
    R(ADC+0x4c)=2; /* clear calibration failure, W1C */
    R(ADC+0x48)=0x81;
    unsigned n;
    for(n=0;n<100000;++n) {
        if(!(R(ADC+0x48)&0x80) || (R(ADC+0x4c)&2)) break;
        if(!(n&63)) board_poll();
    }
    local.adc_status=(n<100000 && !(R(ADC+0x48)&0x80) &&
                      !(R(ADC+0x4c)&2) && (R(ADC+0x20)&1))?1:2;
    (void)R(ADC+0x24); /* consume calibration result */
    if(local.adc_status!=1) { ++local.adc_errors; R(ADC+0x48)=1; }
    for(unsigned i=0;i<32;++i) local.raw[i]=0xffff;
    local.last_slot=0xff; local.last_key=0xffff;
    column=0; seeded=0; select_column(); enabled=1;
}

static void digital_sample(void) {
    uint32_t p=R(GPIO+8);
    uint8_t rows=(uint8_t)(~(((p>>20)&7) | ((p>>25)&8) | ((p>>22)&16)))&31;
    unsigned encoder=(p>>18)&3;
    if(encoder!=local.encoder && seeded)capture_event(3,0,encoder);
    local.encoder=encoder;
    if(candidate[column]==rows && local.matrix[column]!=rows) {
        uint8_t changed=local.matrix[column]^rows;
        local.matrix[column]=rows;
        for(unsigned row=0;row<5;++row) if(changed&(1u<<row)) {
            ++local.key_events;
            local.last_key=(column<<8)|(row<<4)|((rows>>row)&1);
            capture_event(1,column*5+row,(rows>>row)&1);
        }
    }
    candidate[column]=rows;
}

static void advance(void) {
    if(++column==8) {column=0; ++local.scans; seeded=1;capture_scan(R(0x401ec024));}
    select_column();
}

void local_poll(void) {
    if(!enabled) return; /* called from thread context only, never UART ISR */
    uint32_t now=R(0x401ec024), elapsed=now-stamp;
    ++spins;
    if(!stage) {
        /* >=100 us at R7's selected 24 MHz clock; bounded fallback if stuck. */
        if(elapsed<2400 && spins<4096) return;
        digital_sample();
        if(local.adc_status!=1) {advance(); return;}
        (void)R(ADC+0x24); /* discard any stale completion */
        R(ADC)=channels[0]; stage=1; stamp=now; spins=0;
        return;
    }
    if(!(R(ADC+0x20)&1)) {
        if(elapsed>=48000 || spins>=4096) {
            local.adc_status=3; ++local.adc_errors; R(ADC)=31; advance();
        }
        return;
    }
    uint16_t value=R(ADC+0x24)&4095;
    unsigned slot=(stage-1)*8+column;
    local.raw[slot]=value;
    unsigned delta=value>anchor[slot]?value-anchor[slot]:anchor[slot]-value;
    if(!seeded) anchor[slot]=value;
    /* The four rotary pots have only ~8-13 counts idle noise in owner takes.
       R14's shared64-count gate delayed reversal by up to116 raw counts.
       Keep pads on the old gate; use16 counts for knob display/events. */
    else if(delta>=((slot>=16u && slot<=19u)?16u:64u)) {
        local.last_slot=slot; local.last_value=value; local.last_delta=delta;
        ++local.analog_events; anchor[slot]=value;
        capture_event(2,slot,value);
    }
    if(stage==4) {advance(); return;}
    R(ADC)=channels[stage++]; stamp=now; spins=0;
}
