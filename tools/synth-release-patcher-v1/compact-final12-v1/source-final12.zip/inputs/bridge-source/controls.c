#include "controls.h"
void controls_reset(struct controls_state *s) {
    for(unsigned i=0;i<CONTROL_COUNT;++i) {s->raw[i]=0;s->held[i]=0;s->seen[i]=0;}
}
static unsigned scale(int value,unsigned span) {
    if(value<=0 || !span)return 0;
    if((unsigned)value>=span)return 1000;
    return (unsigned)value*1000/span;
}
void controls_feed(struct controls_state *s,unsigned source,unsigned slot,unsigned raw,uint32_t ticks,control_sink sink,void *user) {
    int id=control_id(source,slot);
    if(id<0 || !sink)return;
    const struct control_desc *c=&control_map[id];
    if((source==2 && raw>4095) || (source==3 && raw>3) || ((source==1 || source==4) && raw>1))return;
    struct control_event e={.ticks=ticks,.id=(uint16_t)id,.raw=(uint16_t)raw};
    if(c->kind==CONTROL_ENCODER) {
        unsigned previous=s->raw[id];s->raw[id]=raw;
        if(s->seen[id] && previous!=raw) {
            static const int8_t quadrature[16]={0,1,-1,0,-1,0,0,1,1,0,0,-1,0,-1,1,0};
            e.delta=quadrature[previous*4+raw];e.action=e.delta?CONTROL_STEP:CONTROL_INVALID;sink(&e,user);
        }
        s->seen[id]=1;return;
    }
    if(c->kind==CONTROL_KNOB) {
        e.level=scale((int)raw-c->low,c->high-c->low);e.action=CONTROL_CHANGED;
        if(c->inverted)e.level=1000-e.level;
        if(!s->seen[id] || s->raw[id]!=raw)sink(&e,user);
        s->raw[id]=raw;s->seen[id]=1;return;
    }
    unsigned down;
    if(source==2) {
        int delta=((int)raw*2-c->baseline2)*c->polarity;
        down=delta>(s->held[id]?c->off2:c->on2);e.level=scale(delta,c->span2);
    } else {down=raw!=0;e.level=down?1000:0;}
    if(down!=s->held[id]) {e.action=down?CONTROL_DOWN:CONTROL_UP;sink(&e,user);}
    if(down && source==2) {e.action=CONTROL_LEVEL;sink(&e,user);}
    s->held[id]=down;s->raw[id]=raw;s->seen[id]=1;
}
