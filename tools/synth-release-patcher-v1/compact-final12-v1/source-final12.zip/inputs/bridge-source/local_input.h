#pragma once
#include <stdint.h>
struct local_state {
    uint32_t scans, key_events, last_key, adc_status, adc_errors;
    uint32_t last_slot, last_value, last_delta, analog_events, encoder, shift;
    uint16_t raw[32];
    uint8_t matrix[8];
};
extern volatile struct local_state local;
void local_init(void);
void local_poll(void);
