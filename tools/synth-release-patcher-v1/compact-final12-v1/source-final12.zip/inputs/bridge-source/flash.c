/* Original RAM-resident SPI NOR updater. Registers: FLASH.md.
 * No resident updater calls, status-register writes, chip erase or APP0 writes.
 */
#include "flash.h"
#include "audio_probe.h"
#include "usb_upload.h"
#include "board.h"
#define R(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define F(o) R(0x402a8000u+(o))
#define STAGE ((volatile uint8_t *)0x83000000u)
#define START 0x80000u
#define MAXLEN 0x37f000u /* resident APP1 region, excluding the last flash sector */
#define BRIDGE_OFFSET 0x288000u
#define BRIDGE_MAX 0x10000u
#define BRIDGE_HOOK 0xbffef287u /* B.W 0x60308000 from 0x60080000 */
volatile struct flash_state flash;
struct flash_diagnostic flash_diagnostic;
_Static_assert(sizeof(struct flash_diagnostic)==112,"diagnostic wire size");
static void diagnostic_reset(void) {
    uint8_t *p=(uint8_t *)&flash_diagnostic;
    for(unsigned i=0;i<sizeof(flash_diagnostic);++i)p[i]=0;
}
static uint32_t saved_lut[4],saved_clock,saved_gate,saved_mcr,saved_dll,saved_rx,saved_tx;
static unsigned owned;
static uint8_t scratch[256];
static uint32_t word(const volatile uint8_t *p) {
    return p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}
uint32_t image_crc(const volatile uint8_t *p,uint32_t length) {
    uint32_t c=0xffffffffu;
    for(uint32_t i=0;i<length;++i) {
        c^=p[i];for(unsigned b=0;b<8;++b)c=(c>>1)^((0u-(c&1))&0xedb88320u);
    }
    return c^0xffffffffu;
}
uint32_t image_valid(const volatile uint8_t *p,uint32_t n) {
    /* Only images carrying the same boot-time USB recovery bridge are accepted.
     * The host additionally pins complete image hashes before transmission. */
    if(n<BRIDGE_OFFSET+0x800u || n>BRIDGE_OFFSET+BRIDGE_MAX || (n&3) ||
       word(p)!=BRIDGE_HOOK)return 0;
    const volatile uint8_t *h=p+BRIDGE_OFFSET+0x200;
    uint32_t runtime=word(h+20);
    return word(h)==0x41555053 && word(h+4)==0x30315746 && word(h+8)==1 &&
        word(h+12)==n-BRIDGE_OFFSET && word(h+16)==0x80000000 && runtime>=0x400 &&
        runtime<=n-BRIDGE_OFFSET-0x400 && word(h+24)==0x400 &&
        word(h+28)==0x20243000 && word(p+BRIDGE_OFFSET+0x400)==0x20243000;
}
static int fail(uint32_t error) {if(!flash.error)flash.error=error;return 0;}
static int idle(void) {
    for(unsigned n=0;n<100000;++n)if((F(0xe0)&3)==3)return 1;
    return fail(1);
}
static int reset_controller(void) {
    F(0)|=1;
    for(unsigned n=0;n<100000;++n)if(!(F(0)&1))return 1;
    return fail(2);
}
static int begin(void) {
    owned=0;
    if(!idle())return 0;
    /* No inherited instruction stream may use our temporary sequence15. */
    if((F(0x80)&0xef) || (F(0x60)&0x7fffff)!=4096 ||
       F(0x64) || F(0x68) || F(0x6c) || (F(0)&0x2000))return fail(3);
    for(unsigned i=0;i<4;++i)saved_lut[i]=F(0x2f0+4*i);
    saved_clock=R(0x400fc01c);saved_gate=R(0x400fc080);
    saved_mcr=F(0);saved_dll=F(0xc0);saved_rx=F(0xb8);saved_tx=F(0xbc);
    owned=1;F(0)|=2;
    R(0x400fc080)=saved_gate&~0xc00u;
    /* USB PLL480 /8; SDR half-speed commands -> nominal30MHz. */
    R(0x400fc01c)=(saved_clock&~0x63800000u)|0x23800000u;
    R(0x400fc080)=saved_gate|0xc00u;
    F(0)=(saved_mcr&~0x32u)|0x800;F(0xc0)=0x100;
    F(0xb8)=1;F(0xbc)=1; /* 8-byte watermarks, DMA off */
    return reset_controller();
}
static void finish(void) {
    if(!owned)return;
    /* Stay in RAM even when cleanup fails; never resume a flash instruction. */
    if(!idle())reset_controller();
    F(0x18)=0x5af05af0;F(0x1c)=2;
    for(unsigned i=0;i<4;++i)F(0x2f0+4*i)=saved_lut[i];
    F(0x18)=0x5af05af0;F(0x1c)=1;
    F(0)|=2;R(0x400fc080)=saved_gate&~0xc00u;
    R(0x400fc01c)=saved_clock;R(0x400fc080)=saved_gate;
    F(0)=saved_mcr&~2u;F(0xc0)=saved_dll;F(0xb8)=saved_rx|1;F(0xbc)=saved_tx|1;
    reset_controller();owned=0;
    /* Drop old APP1 cache lines before a later restart. */
    __asm__ volatile("dsb sy" ::: "memory");
    for(uint32_t a=0x60080000;a<0x60090000;a+=32)R(0xe000ef5c)=a;
    R(0xe000ef50)=0;__asm__ volatile("dsb sy\nisb" ::: "memory");
}
/* One bounded IP command, using only temporary LUT15. */
static int command(unsigned op,uint32_t address,uint8_t *data,unsigned n,unsigned write) {
    if(n>256 || !idle())return fail(4);
    uint16_t ins[8];for(unsigned i=0;i<8;++i)ins[i]=0;
    unsigned k=0;ins[k++]=0x400|op;
    if(op==3 || op==2 || op==0x20 || op==0x5a)ins[k++]=0x818;
    if(op==0x5a)ins[k++]=0x3008;
    if(n)ins[k++]=(write?0x2000:0x2400)|4;
    F(0x18)=0x5af05af0;F(0x1c)=2;
    for(unsigned i=0;i<4;++i)F(0x2f0+i*4)=ins[i*2]|((uint32_t)ins[i*2+1]<<16);
    F(0x18)=0x5af05af0;F(0x1c)=1;
    F(0x80)|=0x80000000u;F(0x14)=0x83f;
    F(0xb8)=1;F(0xbc)=1;F(0xa0)=address;F(0xa4)=(15u<<16)|n;F(0xb0)=1;
    unsigned off=0,budget=200000;
    while(budget--) {
        uint32_t irq=F(0x14);
        if(irq&0x80a)return fail(5);
        if(off<n && (write?(irq&0x40):((F(0xf0)&255)!=0))) {
            unsigned take=n-off;if(take>8)take=8;
            for(unsigned w=0;w<2 && w*4<take;++w) {
                uint32_t v=write?0:F(0x100+4*w);
                for(unsigned b=0;b<4 && w*4+b<take;++b) {
                    if(write)v|=(uint32_t)data[off+w*4+b]<<(8*b);
                    else data[off+w*4+b]=(uint8_t)(v>>(8*b));
                }
                if(write)F(0x180+4*w)=v;
            }
            F(0x14)=write?0x40:0x20;off+=take;
        }
        if(off==n && (F(0x14)&1))return idle();
    }
    return fail(6);
}
static int status(void) {
    uint8_t s;
    if(!command(5,0,&s,1,0))return 0;
    flash.status=s;return 1;
}
static int wait_ready(void) {
    uint32_t start=R(0x401ec024);
    for(unsigned i=0;i<200000;++i) {
        if(!status())return 0;
        if(!(flash.status&1))return 1;
        if((uint32_t)(R(0x401ec024)-start)>48000000u)return fail(7);
    }
    return fail(7); /* timer failure cannot create an unbounded wait */
}
static int check_chip(void) {
    uint8_t id[3];
    if(!command(0x9f,0,id,3,0))return 0;
    flash.jedec=((uint32_t)id[0]<<16)|((uint32_t)id[1]<<8)|id[2];
    flash_diagnostic.phase=1;
    if(id[0]==0 || id[0]==255 || id[2]!=0x16)return fail(8);
    if(!wait_ready() || (flash.status&~0x42u))return fail(9);
    if(!command(3,0,scratch,256,0))return 0;
    if(word(scratch)!=0x42464346 || word(scratch+0x50)!=0x400000)return fail(10);
    if(!command(3,0x100,scratch,256,0))return 0;
    if(word(scratch+0xc0)!=256 || word(scratch+0xc4)!=4096)return fail(10);
    flash_diagnostic.phase=2;
    if(!command(0x5a,0,scratch,32,0))return 0;
    for(unsigned i=0;i<32;++i)flash_diagnostic.header[i]=scratch[i];
    flash_diagnostic.phase=3;
    unsigned length=scratch[11];
    uint32_t ptr=scratch[12]|((uint32_t)scratch[13]<<8)|((uint32_t)scratch[14]<<16);
    flash_diagnostic.length=length;flash_diagnostic.pointer=ptr;
    if(word(scratch)!=0x50444653 || scratch[5]!=1 || scratch[8]!=0 ||
       scratch[10]!=1 || (length!=9 && length<11) || scratch[15]!=255)return fail(11);
    /* JESD216 v1.0 has no DWORD11 page field. Only accept the documented
     * Macronix C22016 legacy profile, with its exact two parameter headers.
     * Page256 comes from that vendor contract AND the checked FCB above.
     * FLASH.md cites the primary datasheet; this does not identify an exact part. */
    if(length==9) {
        if(flash.jedec!=0xc22016 || scratch[4]!=0 || scratch[6]!=1 ||
           scratch[7]!=255 || scratch[9]!=0 || ptr!=0x30 ||
           scratch[16]!=0xc2 || scratch[17]!=0 || scratch[18]!=1 ||
           scratch[19]!=4 || scratch[20]!=0x60 || scratch[21]!=0 ||
           scratch[22]!=0 || scratch[23]!=255)return fail(11);
        flash_diagnostic.legacy=1;
    }
    if(ptr>0xffff00)return fail(11);
    unsigned bytes=length==9?36:44;
    if(!command(0x5a,ptr,scratch,bytes,0))return 0;
    for(unsigned i=0;i<bytes;++i)flash_diagnostic.bfpt[i]=scratch[i];
    flash_diagnostic.phase=4;
    uint32_t d1=word(scratch);
    if(word(scratch+4)!=0x1ffffff || ((d1>>17)&3)>1 ||
       (length!=9 && ((word(scratch+40)>>4)&15)!=8))return fail(12);
    unsigned erase=0;
    for(unsigned i=0;i<4;++i)if((scratch[28+i*2]==12) && (scratch[29+i*2]==0x20))erase=1;
    if(!erase || (d1&3)!=1 || ((d1>>8)&255)!=0x20)return fail(13);
    flash_diagnostic.phase=5;
    return 1;
}
void flash_probe(void) {
    flash.ready=0;flash.error=0;
    diagnostic_reset();
    uint32_t mask;__asm__ volatile("mrs %0, primask\ncpsid i":"=r"(mask)::"memory");
    if(begin() && check_chip())flash.ready=1;
    finish();if(flash.error)flash.ready=0;
    __asm__ volatile("msr primask, %0"::"r"(mask):"memory");
}
static int write_enable(void) {
    if(!wait_ready() || (flash.status&~0x42u))return fail(9);
    if(!command(6,0,0,0,0) || !status())return 0;
    return (flash.status&2)?1:fail(14);
}
static uint32_t program_end;
void flash_program_start(void) {
    flash.error=0;flash.progress=0;flash.crc=0;flash.ready=0;
    diagnostic_reset();
    uint32_t n=upload.length;
    if(!image_valid(STAGE,n) || image_crc(STAGE,n)!=upload.expected_crc) {fail(15);return;}
    program_end=(n+4095u)&~4095u;
    if(!program_end || program_end>MAXLEN) {fail(16);return;}
    flash.ready=1;
}
void flash_program_step(void) {
    uint32_t n=upload.length;
    if(!flash.ready || flash.error || flash.progress>=program_end) {fail(18);return;}
    uint32_t step=flash.progress+4096u;
    uint32_t off=step==program_end?0:step;
    if(off>=MAXLEN || START+off+4096u>0x3ff000u) {fail(16);return;}
    uint32_t mask;__asm__ volatile("mrs %0, primask\ncpsid i":"=r"(mask)::"memory");
    if(!begin() || !check_chip())goto done;
    /* First sector last reduces the time with a blank entry; not atomic. */
    if(!write_enable() || !command(0x20,START+off,0,0,0) || !wait_ready())goto done;
    for(uint32_t p=0;p<4096;p+=256) {
        for(unsigned b=0;b<256;++b)scratch[b]=off+p+b<n?STAGE[off+p+b]:255;
        if(!write_enable() || !command(2,START+off+p,scratch,256,1) || !wait_ready())goto done;
    }
    /* Verify this complete sector by IP reads before advancing progress. */
    for(uint32_t p=0;p<4096;p+=256) {
        if(!command(3,START+off+p,scratch,256,0))goto done;
        for(unsigned b=0;b<256;++b)
            if(scratch[b]!=(off+p+b<n?STAGE[off+p+b]:255)) {fail(17);goto done;}
    }
    flash.progress=step;
    if(step==program_end)flash.crc=upload.expected_crc;
done:
    finish();__asm__ volatile("msr primask, %0"::"r"(mask):"memory");
    if(flash.error)flash.ready=0;
}
void flash_service(void) {
    if(!flash.job || !usb_idle())return;
    unsigned job=flash.job;flash.job=0;
    if(job==1) {flash_probe();return;}
    if(job==2 && upload.state==4 && !input.shutdown_requested) {
        audio_probe_stop();flash_program_start();
        if(flash.error)upload.state=7;
        else {upload.state=5;flash.job=3;}
    } else if(job==3 && upload.state==5) {
        flash_program_step();
        if(flash.error)upload.state=7;
        else if(flash.progress==program_end)upload.state=6;
        else flash.job=3;
    } else {flash.error=18;upload.state=7;}
}
