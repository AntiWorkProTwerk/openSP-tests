/* Original bounded RAM receiver and deferred APP1 commit protocol. */
#include "usb_upload.h"
#include "flash.h"
#include "control_capture.h"
#include "audio_probe.h"
#define STAGE ((volatile uint8_t *)0x83000000u)
#define MAX_IMAGE 0x37f000u
volatile struct upload_state upload;
static unsigned diagnostic_page; /* zero=normal; 1/2=one-shot snapshot pages */
static unsigned input_report; /* 1..3 snapshot pages, 4 events */
static unsigned audio_frame_report; /* 1..4 data pages, 5 arm acknowledgement */
static uint32_t get32(const uint8_t *p) {
    return p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}
static void put32(uint8_t *p,uint32_t v) {
    for(unsigned i=0;i<4;++i) p[i]=(uint8_t)(v>>(8*i));
}
void upload_reset(void) {
    input_report=0;capture_config(0);
    audio_frame_report=0;audio_window_reset();
    diagnostic_page=0;
    if(upload.state==4 || upload.state==5 || upload.state==6 || upload.state==7)
        return; /* keep an in-progress job and its result across USB bus reset */
    flash.job=0;
    upload.state=0;upload.error=0;upload.length=0;upload.received=0;
    upload.expected_crc=0;upload.crc=0xffffffffu;upload.packets=0;
}
void upload_command(const uint8_t *p) {
    input_report=0;
    audio_frame_report=0;
    diagnostic_page=0;
    ++upload.packets;
    if(upload.state==4 || upload.state==5)return; /* immutable queued image */
    if(p[1]!=1) {upload.error=1;upload.state=3;return;}
    uint32_t arg=get32(p+4);
    if(p[0]==1) {
        upload.state=0;
        upload_reset();
        if(arg<4 || arg>MAX_IMAGE) {upload.error=2;upload.state=3;return;}
        upload.length=arg;upload.expected_crc=get32(p+8);upload.state=1;
    } else if(p[0]==2) {
        unsigned n=p[2];
        if(upload.state!=1 || n==0 || n>56 || arg!=upload.received ||
           n>upload.length-upload.received) {upload.error=3;upload.state=3;return;}
        uint32_t crc=upload.crc;
        for(unsigned i=0;i<n;++i) {
            uint8_t b=p[8+i]; STAGE[arg+i]=b;crc^=b;
            for(unsigned bit=0;bit<8;++bit) crc=(crc>>1)^((0u-(crc&1))&0xedb88320u);
        }
        upload.crc=crc;upload.received+=n;
    } else if(p[0]==3) {
        if(upload.state!=1 || upload.received!=upload.length ||
           (upload.crc^0xffffffffu)!=upload.expected_crc) {upload.error=4;upload.state=3;return;}
        /* Re-read staged RAM as well as checking the transport CRC. */
        for(uint32_t a=0x83000000u;a<0x83000000u+upload.length;a+=32)
            *(volatile uint32_t *)0xe000ef70u=a;
        __asm__ volatile("dsb sy\nisb" ::: "memory");
        uint32_t crc=0xffffffffu;
        for(uint32_t i=0;i<upload.length;++i) {
            crc^=STAGE[i];
            for(unsigned bit=0;bit<8;++bit) crc=(crc>>1)^((0u-(crc&1))&0xedb88320u);
        }
        if((crc^0xffffffffu)!=upload.expected_crc) {upload.error=5;upload.state=3;return;}
        upload.state=2;
    } else if(p[0]==4) {upload.state=0;upload_reset();}
    else if(p[0]==5) {flash.ready=0;flash.error=0;flash.job=1;}
    else if(p[0]==6) {
        if(upload.state!=2 || !flash.ready || arg!=(upload.expected_crc^0x46534c48u) ||
           !image_valid(STAGE,upload.length)) {upload.error=7;upload.state=3;return;}
        upload.state=4;flash.job=2;
    }
    else if(p[0]==7) {
        if(arg>1) {upload.error=8;upload.state=3;return;}
        diagnostic_page=arg+1;
    }
    else if(p[0]==8) {
        if(arg>2) {upload.error=8;upload.state=3;return;}
        if(!arg)capture_snapshot();
        input_report=arg+1;
    }
    else if(p[0]==9)input_report=4;
    else if(p[0]==10) {
        if(arg>1) {upload.error=8;upload.state=3;return;}
        capture_config(arg);
    }
    else if(p[0]==11)input_report=5;
    else if(p[0]==12) {
        if(arg==0xffffffffu) {audio_window_arm();audio_frame_report=5;}
        else if(arg<4u)audio_frame_report=arg+1u;
        else {upload.error=8;upload.state=3;return;}
    }
    else {upload.error=6;upload.state=3;}
}
void upload_status(uint8_t *p) {
    for(unsigned i=0;i<64;++i) p[i]=0;
    if(audio_frame_report) {
        unsigned page=audio_frame_report==5?0xffffffffu:audio_frame_report-1u;
        audio_frame_report=0;audio_window_report(p,page);return;
    }
    if(input_report==5) {input_report=0;audio_probe_report(p);return;}
    if(input_report) {
        unsigned report=input_report;input_report=0;
        if(report==4)capture_events_report(p);else capture_snapshot_page(p,report-1);
        return;
    }
    if(diagnostic_page) {
        unsigned page=diagnostic_page-1;diagnostic_page=0;
        flash_diagnostic.jedec=flash.jedec;flash_diagnostic.status=flash.status;
        flash_diagnostic.error=flash.error;flash_diagnostic.ready=flash.ready;
        p[0]='S';p[1]='P';p[2]='D';p[3]='G';put32(p+4,page);
        const uint8_t *raw=(const uint8_t *)&flash_diagnostic;
        for(unsigned i=0;i<56;++i)p[8+i]=raw[page*56+i];
        return;
    }
    p[0]='S';p[1]='P';p[2]='1';p[3]='7';
    put32(p+4,2);put32(p+8,upload.state);put32(p+12,upload.error);
    put32(p+16,upload.length);put32(p+20,upload.received);
    put32(p+24,upload.crc^0xffffffffu);put32(p+28,MAX_IMAGE);
    put32(p+32,1); /* capability: bounded APP1 flash; no uploaded-code execution */
    put32(p+36,flash.jedec);put32(p+40,flash.status);put32(p+44,flash.error);
    put32(p+48,flash.progress);put32(p+52,flash.ready);put32(p+56,flash.crc);
    put32(p+60,0x52420001);
}
