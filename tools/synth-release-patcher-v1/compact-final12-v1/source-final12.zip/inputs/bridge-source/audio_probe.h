/* Receive-only SAI1 observation. No output synthesis, IRQ or DMA. */
#pragma once
#include <stdint.h>
struct audio_probe_state {
    uint32_t enabled,words,nonzero,changes,overruns,sync_errors,last_word,csr;
    uint32_t rate_words,elapsed_ticks,page,first_word,word_starts,polls,started_ticks;
};
extern struct audio_probe_state audio_probe;
void audio_probe_init(void);
void audio_probe_poll(void);
void audio_probe_stop(void);
void audio_probe_report(uint8_t *out);
void audio_window_reset(void);
void audio_window_arm(void);
void audio_window_report(uint8_t *out,uint32_t page);
