#pragma once
#include <stdint.h>
struct input_state {
    uint32_t packets, events, errors, last, last_event;
    uint32_t partial, used, tx_errors;
    uint32_t previous, older, last_error, bytes, shutdown_requested, shutdown_sent;
    uint32_t timer_running, timer_before, timer_delta, irq_calls, ready_seen;
};
extern volatile struct input_state input;
void board_init(void);
void board_poll(void);
void uart_irq_handler(void);
void board_service(void);
void board_delay_ms(uint32_t ms);
void oled_init(void);
void oled_frame(const uint8_t *frame);
void render_frame(uint32_t heartbeat);
extern uint8_t framebuffer[1024];
