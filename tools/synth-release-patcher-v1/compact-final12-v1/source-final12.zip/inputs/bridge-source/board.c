/* Original polled board support. Register/pin contracts: BOARD.md.
 * No vendor functions or binary blobs. All waits are bounded.
 */
#include "board.h"
#include "local_input.h"
#include "usb_upload.h"
#include "control_capture.h"
#include "audio_probe.h"
#define R(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define GPIO 0x401bc000u
#define GPT 0x401ec000u
#define UART 0x4018c000u
#define CS 1u
#define DC 2u
#define MOSI 4u
#define CLK 8u
#define RESET 1024u
#define OLED_PINS (CS|DC|MOSI|CLK|RESET)
volatile struct input_state input;
static uint32_t timer_ok, uart_ok;

static void receive(void) {
    if (!uart_ok) return;
    /* Limit work even if a failed peripheral asserts RDRF continuously. */
    for (unsigned n=0; n<32; ++n) {
        uint32_t status=R(UART+0x14);
        if (status & 0x000f0000u) {
            input.last_error=status & 0x000f0000u;
            R(UART+0x14)=status & 0x000f0000u;
            R(UART+0x28)=0x88u|0x4000u; /* RX FIFO flush, keep FIFO enables */
            ++input.errors; input.used=0; input.partial=0;
            break;
        }
        if (!(status & (1u<<21))) break;
        uint32_t b=R(UART+0x1c)&255;
        ++input.bytes;
        input.partial |= b << (8*input.used);
        if (++input.used==4) {
            uint32_t p=input.partial, cls=p&0xf0, midi=(p>>8)&0xf0;
            input.older=input.previous; input.previous=input.last;
            input.last=p; ++input.packets;
            /* Stock class0 FF/00/01 selects shutdown page3, not ready ACK. */
            if ((p&0xfffffff0u)==0x0100ff00u) input.shutdown_requested=1;
            if(p==0x01ffff01u && !local.shift) {local.shift=1;capture_event(4,0,1);}
            if(p==0x00ffff01u && local.shift) {local.shift=0;capture_event(4,0,0);}
            if ((cls==0x80 || cls==0x90) &&
                (midi==0x80 || midi==0x90 || midi==0xb0)) {
                input.last_event=p; ++input.events;
            }
            input.used=0; input.partial=0;
        }
    }
}

void uart_irq_handler(void) { ++input.irq_calls; receive(); }

void board_poll(void) {
    /* Polling is a bounded fallback; protect packet assembly against IRQ22. */
    uint32_t mask;
    __asm__ volatile("mrs %0, primask\ncpsid i" : "=r"(mask) :: "memory");
    receive();
    __asm__ volatile("msr primask, %0" :: "r"(mask) : "memory");
    local_poll();
    audio_probe_poll();
    usb_poll();
}

__attribute__((noinline)) static void half_clock(void) {
    if (timer_ok) {
        uint32_t start=R(GPT+0x24);
        for (unsigned n=0;n<1000;++n)
            if ((uint32_t)(R(GPT+0x24)-start)>=12) return;
        timer_ok=0;
        input.timer_running=0;
    }
    /* Conservative fallback if the oscillator timer is unavailable. */
    for (volatile unsigned n=0;n<100;++n) __asm__ volatile("nop");
}

void board_delay_ms(uint32_t ms) {
    while (ms--) {
        if (timer_ok) {
            uint32_t start=R(GPT+0x24), n;
            for (n=0;n<200000;++n) {
                board_poll();
                if ((uint32_t)(R(GPT+0x24)-start)>=24000) break;
            }
            if (n==200000) { timer_ok=0; input.timer_running=0; }
        } else {
            for (volatile unsigned n=0;n<2000;++n)
                if (!(n&63)) board_poll();
        }
    }
}

static void send_word(uint32_t word) {
    if (input.tx_errors) return; /* Do not append packets after a partial TX failure. */
    for (unsigned b=0;b<4;++b) {
        unsigned n;
        for (n=0;n<100000;++n) {
            board_poll();
            if (R(UART+0x14)&(1u<<23)) break;
        }
        if (n==100000) { ++input.tx_errors; return; }
        R(UART+0x1c)=(word>>(8*b))&255;
    }
}

void board_init(void) {
    R(0x400fc068)|=0xc0003000u; /* GPIO2, UART3 */
    R(0x400fc06c)|=0x00f00000u; /* GPT1 bus+serial */
    R(0x400fc06c)|=0x0c000000u; /* GPIO1 CG13 */
    R(0x400fc078)|=0x3cu;       /* IOMUXC + GPR */
    R(0x400ac06c)&=~OLED_PINS;  /* select GPIO2 rather than GPIO7 */
    R(GPIO+0x84)=CS|RESET;     /* idle CS high, reset inactive */
    R(GPIO+0x88)=CLK|DC|MOSI;
    R(GPIO+4)|=OLED_PINS;
    for (unsigned pin=0;pin<=10;++pin) {
        if (!(OLED_PINS&(1u<<pin))) continue;
        R(0x401f813cu+4*pin)=5;
        R(0x401f832cu+4*pin)=0x1008; /* observed display drive/pad value */
    }
    /* APP1 normal-mode handshake output: bit12 low, bit13 high.
       Signal names unknown; do not touch the board-ID scan or other outputs. */
    R(0x400ac068)&=~0x3000u;
    R(0x401b8088)=0x1000;
    R(0x401b8084)=0x2000;
    R(0x401b8004)|=0x3000;
    R(0x401f80ec)=5; R(0x401f80f0)=5;
    R(0x401f82dc)=0x30b0; R(0x401f82e0)=0x30b0;
    R(0x400ac068)&=~1u;
    R(0x401f80bc)=5; R(0x401b8004)&=~1u; /* stock ready pin, input */

    /* GPT high-frequency input from explicitly selected oscillator PERCLK.
       R6 assumed its inherited oscillator path; measure/report this selection. */
    R(0x400fc01c)=(R(0x400fc01c)&~0x7fu)|0x40u;
    R(0x400ac014)&=~0x10000000u;
    R(GPT)=0x8000; /* reset, bounded */
    for (unsigned n=0;n<10000 && (R(GPT)&0x8000);++n) {}
    R(GPT+4)=0; R(GPT+0xc)=0; R(GPT+8)=0x3f;
    R(GPT)=0x283; /* high-frequency PERCLK /1, free-run, reset-on-enable */
    timer_ok=1; input.timer_running=1;
    half_clock(); /* marks failed timer for fallback */
    input.timer_before=R(GPT+0x24);
    for (volatile unsigned n=0;n<1024;++n) __asm__ volatile("nop");
    input.timer_delta=R(GPT+0x24)-input.timer_before;

    /* A known 24 MHz UART root avoids dependence on inherited PLL dividers. */
    R(0x400fc024)=(R(0x400fc024)&~0x7fu)|0x40;
    R(0x401f815c)=3; R(0x401f8160)=3;
    R(0x401f853c)=2; R(0x401f8538)=2;
    R(0x401f834c)=0x10b0; R(0x401f8350)=0x10b0;
    R(UART+8)=2; R(UART+8)=0; /* global reset */
    R(UART+0x18)=0;
    R(UART+0x10)=(23u<<24)|1u; /* OSR24 / SBR1 -> 1 Mbaud */
    R(UART+0x28)=0xc088; /* flush/enable both FIFOs */
    R(UART+0x2c)=0; /* RX watermark0 */
    R(UART+0x18)=0xc0000; /* TE+RE, 8N1, interrupts off */
    uart_ok=1;
    /* RX/errors wake the CPU regardless of the drawing/delay loop. */
    *(volatile uint8_t *)(uintptr_t)0xe000e416=0x70; /* IRQ22 priority7 */
    R(0xe000e280)=1u<<22;
    R(UART+0x18)|=(1u<<21)|0x0f000000u;
    R(0xe000e100)=1u<<22;
    __asm__ volatile("dsb sy\nisb\ncpsie i" ::: "memory");
    for (unsigned n=0;n<1000;++n) {
        if (R(0x401b8008)&1) { input.ready_seen=1; break; }
        board_delay_ms(1);
    }
    board_delay_ms(500);
}

static void spi_byte(uint8_t byte) {
    for (unsigned bit=0;bit<8;++bit) {
        R(GPIO+0x88)=CLK;
        R(GPIO+((byte&0x80)?0x84:0x88))=MOSI;
        half_clock();
        R(GPIO+0x84)=CLK;
        half_clock(); byte<<=1;
        board_poll(); /* service 1 Mbaud RX even during slow GPIO SPI */
    }
    R(GPIO+0x88)=CLK;
}
static void transfer(const uint8_t *data,unsigned length,unsigned pixels) {
    R(GPIO+(pixels?0x84:0x88))=DC;
    R(GPIO+0x88)=CS;
    while(length--) spi_byte(*data++);
    R(GPIO+0x84)=CS;
}
void oled_init(void) {
    /* 26 observed command/parameter bytes, including final contrast 0x20.
       These are protocol constants; font and framebuffer are original. */
    static const uint8_t setup[]={0xfd,0x12,0xae,0xd5,0xa0,0xa8,0x3f,
        0xd3,0,0x40,0x20,0,0xa1,0xc8,0xda,0x12,0x81,0xdf,
        0xd9,0x82,0xdb,0x34,0xa4,0xa6,0x81,0x20};
    static const uint8_t on[]={0xaf};
    R(GPIO+0x88)=RESET; board_delay_ms(100);
    R(GPIO+0x84)=RESET; board_delay_ms(100);
    transfer(setup,sizeof(setup),0);
    /* Initial all-zero framebuffer clears power-on RAM. */
    oled_frame(framebuffer);
    send_word(0x0105ff01); /* observed display-start controller message */
    board_delay_ms(100);
    transfer(on,1,0);
    /* Normal stock receive-task startup follows display initialization. */
    send_word(0x0100ff01);
    send_word(0x1000ff01);
}
void oled_frame(const uint8_t *frame) {
    static const uint8_t window[]={0x21,0,127,0x22,0,7};
    transfer(window,sizeof(window),0);
    transfer(frame,1024,1);
}

void board_service(void) {
    if (input.shutdown_requested && !input.shutdown_sent) {
        input.shutdown_sent=1;
        /* Exact reply from stock shutdown page callback 0x80104ED8.
           Flash service is synchronous; this runs after any active write. */
        send_word(0x0000ff01);
        unsigned n;
        for (n=0;n<100000;++n) {
            board_poll();
            if (R(UART+0x14)&(1u<<22)) break; /* actual transmission complete */
        }
        if (n==100000) ++input.tx_errors;
        if (input.tx_errors) input.shutdown_sent=2;
    }
}
