/* Original compact 5x7 lettering, row masks; no stock font assets. */
#include "board.h"
#include "local_input.h"
#include "usb_upload.h"
#include "flash.h"
#include "control_capture.h"
#include "named_input.h"
#include "audio_probe.h"
uint8_t framebuffer[1024];
static const uint8_t glyphs[39][7]={
 {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},
 {30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},
 {14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},
 {14,17,17,15,1,1,14},
 {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},
 {30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
 {14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},
 {7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
 {17,27,21,21,17,17,17},{17,25,25,21,19,19,17},{14,17,17,17,17,17,14},
 {30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
 {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},
 {17,17,17,17,17,10,4},{17,17,17,21,21,27,17},{17,17,10,4,10,17,17},
 {17,17,10,4,4,4,4},{31,1,2,4,8,16,31},
 {0,4,4,31,4,4,0},{0,0,0,31,0,0,0},{1,2,2,4,8,8,16}
};
static void text(unsigned page,unsigned column,const char *s) {
    while (*s && column<21) {
        char c=*s++; unsigned index;
        if(c>='0'&&c<='9') index=(unsigned)(c-'0');
        else if(c>='A'&&c<='Z') index=(unsigned)(c-'A')+10;
        else if(c=='+')index=36;
        else if(c=='-')index=37;
        else if(c=='/')index=38;
        else {++column;continue;}
        for(unsigned x=0;x<5;++x) {
            uint8_t v=0;
            for(unsigned y=0;y<7;++y)
                if(glyphs[index][y]&(16u>>x)) v|=1u<<y;
            framebuffer[page*128+column*6+x]=v;
        }
        ++column; board_poll();
    }
}
static void hex(unsigned page,unsigned column,uint32_t v,unsigned digits) {
    char s[9]; s[digits]=0;
    for(unsigned i=digits;i;--i) {s[i-1]="0123456789ABCDEF"[v&15];v>>=4;}
    text(page,column,s);
}
static void decimal(unsigned page,unsigned column,unsigned value,unsigned digits) {
    char s[11];s[digits]=0;
    for(unsigned i=digits;i;--i) {s[i-1]='0'+value%10;value/=10;}
    text(page,column,s);
}
__attribute__((noinline)) static const char *control_label(unsigned id) {
    if(id>=CONTROL_COUNT)return "PRESS ANY CONTROL";
    return control_map[id].label;
}
void render_frame(uint32_t heartbeat) {
    struct named_view view;named_snapshot(&view);
    for(unsigned i=0;i<1024;++i) framebuffer[i]=0;
    const char *title="USB BRIDGE B1";
    text(0,0,input.shutdown_sent==2?"POWER OFF FAIL":input.shutdown_sent?"POWER OFF SENT":title);
    text(0,14,"T");hex(0,15,input.timer_running,1);
    text(0,17,"R");hex(0,18,input.ready_seen,1);
    if(audio_probe.page) {
        text(1,0,!audio_probe.enabled?"RX STOPPED":audio_probe.words?"AUDIO RX SEEN":"WAIT AUDIO DATA");
        text(2,0,"WORDS");hex(2,7,audio_probe.words,8);
        text(3,0,"RATE");decimal(3,5,audio_probe.rate_words,7);text(3,13,"WORDS/S");
        text(4,0,"OVR");hex(4,4,audio_probe.overruns,4);text(4,10,"SYNC");hex(4,15,audio_probe.sync_errors,4);
        text(5,0,"LAST");hex(5,5,audio_probe.last_word,8);
        text(6,0,upload.state==6?"FLASH VERIFIED":upload.state==7?"FLASH ERROR":"REMAIN FOR CONTROLS");
        text(7,0,"RX ONLY");hex(7,9,audio_probe.csr,8);
        framebuffer[7*128+(heartbeat%128)]|=0x80;return;
    }
    text(1,0,control_label(view.id));
    const char *action=view.action==CONTROL_DOWN?"DOWN":view.action==CONTROL_UP?"UP":
        view.action==CONTROL_LEVEL?"PAD LEVEL NOT VEL":view.action==CONTROL_CHANGED?"KNOB POSITION":
        view.action==CONTROL_STEP?(view.delta>0?"TURN +":"TURN -"):
        view.action==CONTROL_INVALID?"ENCODER INVALID":"55 CONTROLS MAPPED";
    text(2,0,action);
    text(3,0,"RAW");decimal(3,4,view.raw,4);text(3,10,"LEVEL");decimal(3,16,view.level/10,3);
    text(4,0,"HELD");decimal(4,5,view.held,2);text(4,9,"EVT");hex(4,13,view.events,6);
    text(5,0,upload.state==6?"FLASH VERIFIED":upload.state==7?"FLASH ERROR":upload.state==5?"FLASH WRITING":upload.state==4?"FLASH QUEUED":upload.state==2?"RAM VERIFIED":upload.state==3?"UPLOAD ERROR":upload.state==1?"RECEIVING RAM":"NATIVE INPUT READY");
    if(upload.error)hex(5,19,upload.error,2);
    text(6,0,"ADC");hex(6,3,local.adc_status,1);text(6,5,"ERR");hex(6,9,local.adc_errors,2);
    text(6,12,"ENC");hex(6,16,view.encoder_invalid,4);
    /* Level is a measured raw range, not velocity. Independent heartbeat below. */
    for(unsigned x=0;x<128;++x)framebuffer[7*128+x]=x<view.level*128/1000?0x7f:0x40;
    framebuffer[7*128+(heartbeat%128)]|=0x80;
}
