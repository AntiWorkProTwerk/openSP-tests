#include "audio_probe.h"
#include "board.h"
#include "usb_upload.h"
#define R(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define SAI(o) R(0x40384000u+(o))
#define RUN 0x90000000u
#define FLAGS 0x001c0000u
struct audio_probe_state audio_probe;
static uint32_t rate_stamp,rate_count;
/* A host-armable, single32-word receive window. No phase/slot label implied. */
static uint32_t audio_window[32];
static uint32_t window_count,window_start,window_end,window_status,window_active;
void audio_window_reset(void) {
    window_count=0;window_start=0;window_end=0;window_status=2;window_active=0;
}
void audio_window_arm(void) {
    window_count=0;window_start=audio_probe.words;window_end=0;
    window_status=audio_probe.enabled?0:2;
    window_active=audio_probe.enabled?1:0;
}
void audio_probe_init(void) {
    volatile uint8_t *p=(volatile uint8_t *)&audio_probe;
    for(unsigned i=0;i<sizeof(audio_probe);++i)p[i]=0;
    audio_window_reset();
    R(0x400fc07c)|=0x000c0000u; /* SAI1 bus gate */
    SAI(0x08)=0x03000000u;SAI(0x08)=0;SAI(0x14)=0; /* TX held disabled */
    SAI(0x88)=0x03000000u;SAI(0x88)=0;
    /* Observed stock RX pin routes, corroborated by NXP mux/daisy definitions.
       Do not configure TX data/clock/MCLK pads or generate an audio clock. */
    R(0x401f817c)=3;R(0x401f8594)=2; /* B1_00 RX_DATA00 */
    R(0x401f81e4)=3;R(0x401f85a4)=0; /* SD_B1_04 RX_SYNC */
    R(0x401f81e8)=3;R(0x401f8590)=0; /* SD_B1_05 RX_BCLK */
    SAI(0x8c)=0; /* no watermark batching; drain by pointer occupancy */
    SAI(0x90)=0; /* asynchronous RX, external bit clock, observed polarity */
    SAI(0x94)=0x00010000u; /* RX channel0 only */
    SAI(0x98)=0x100f1f10u; /* 16 x32-clock slots, external frame sync */
    SAI(0x9c)=0x1f1f0f00u;SAI(0xe0)=0;
    audio_probe.started_ticks=R(0x401ec024);rate_stamp=audio_probe.started_ticks;rate_count=0;
    audio_probe.page=1;audio_probe.enabled=1;SAI(0x88)=RUN;
}
void audio_probe_stop(void) {
    if(!audio_probe.enabled)return;
    if(window_active) {window_active=0;window_status=2;}
    audio_probe.enabled=0;SAI(0x88)=0x03000000u;SAI(0x88)=0;
}
void audio_probe_poll(void) {
    if(!audio_probe.enabled)return;
    if(input.shutdown_requested || upload.state==4 || upload.state==5) {audio_probe_stop();return;}
    ++audio_probe.polls;
    uint32_t flags=SAI(0x88)&FLAGS;audio_probe.csr=SAI(0x88);
    if(flags&0x40000u)++audio_probe.overruns;
    if(flags&0x80000u)++audio_probe.sync_errors;
    if(flags&0x100000u)++audio_probe.word_starts; /* observed flags, not an exact frame counter */
    if((flags&0xc0000u) && window_active) {window_active=0;window_status=2;}
    for(unsigned i=0;i<32;++i) {
        uint32_t fifo=SAI(0xc0);
        if((fifo&63)==((fifo>>16)&63))break;
        uint32_t value=SAI(0xa0);
        if(!audio_probe.words)audio_probe.first_word=value;
        else if(value!=audio_probe.last_word)++audio_probe.changes;
        if(value)++audio_probe.nonzero;
        audio_probe.last_word=value;++audio_probe.words;
        if(window_active) {
            audio_window[window_count++]=value;
            if(window_count==32) {
                window_end=audio_probe.words;
                window_active=0;window_status=1;
            }
        }
    }
    /* Reset after overflow/sync loss: discarded words are not called received. */
    if(flags&0xc0000u)SAI(0x88)=RUN|0x02000000u;
    if(flags)SAI(0x88)=RUN|flags;
    uint32_t now=R(0x401ec024);audio_probe.elapsed_ticks=now-audio_probe.started_ticks;
    uint32_t elapsed=now-rate_stamp;
    if(elapsed>=24000000u) {
        unsigned ms=elapsed/24000,words=audio_probe.words-rate_count;
        audio_probe.rate_words=(words/ms)*1000+(words%ms)*1000/ms;
        rate_stamp=now;rate_count=audio_probe.words;
    }
}
void audio_probe_report(uint8_t *out) {
    out[0]='S';out[1]='P';out[2]='A';out[3]='U';
    const uint8_t *src=(const uint8_t *)&audio_probe;
    for(unsigned i=0;i<sizeof(audio_probe);++i)out[4+i]=src[i];
}
static void window_put32(uint8_t *p,uint32_t value) {
    for(unsigned i=0;i<4;++i)p[i]=(uint8_t)(value>>(8*i));
}
void audio_window_report(uint8_t *out,uint32_t page) {
    out[0]='S';out[1]='P';out[2]='A';out[3]='F';
    window_put32(out+4,page);
    window_put32(out+8,window_status);
    window_put32(out+12,window_count);
    window_put32(out+16,window_start);
    window_put32(out+20,window_end);
    if(window_status==1 && page<4)
        for(unsigned i=0;i<8;++i)window_put32(out+24+4*i,audio_window[page*8+i]);
    window_put32(out+56,audio_probe.overruns);
    window_put32(out+60,audio_probe.sync_errors);
}
_Static_assert(sizeof(struct audio_probe_state)==60,"audio report payload");
