#pragma once
#include <stdint.h>
struct flash_state {
    uint32_t jedec, status, error, progress, ready, crc, job;
};
extern volatile struct flash_state flash;
/* Fixed diagnostic snapshot, never a host-selected memory address. */
struct flash_diagnostic {
    uint8_t header[32], bfpt[44];
    uint32_t phase, length, pointer, legacy, jedec, status, error, ready, reserved;
};
extern struct flash_diagnostic flash_diagnostic;
uint32_t image_valid(const volatile uint8_t *p,uint32_t length);
uint32_t image_crc(const volatile uint8_t *p,uint32_t length);
void flash_service(void);
void flash_probe(void);
void flash_program_start(void);
void flash_program_step(void);
