/* Original bounded B2 envelope validator. No payload execution is provided. */
#include <stdint.h>

#define BRIDGE_OFFSET 0x288000u
#define LEGACY_MAX 0x10000u
#define APP1_MAX 0x37f000u
#define BRIDGE_HOOK 0xbffef287u

static uint32_t word(const volatile uint8_t *p) {
    return p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

uint32_t image_valid(const volatile uint8_t *p, uint32_t n) {
    /* Test length and the full pointer interval before reading the envelope. */
    if (!p || n < BRIDGE_OFFSET + 0x800u || n > APP1_MAX || (n & 3u) ||
        (uintptr_t)p > UINT32_MAX - n)
        return 0;
    if (word(p) != BRIDGE_HOOK) return 0;
    const volatile uint8_t *h = p + BRIDGE_OFFSET + 0x200u;
    uint32_t tail = n - BRIDGE_OFFSET;
    uint32_t version = word(h + 8u);
    uint32_t runtime = word(h + 20u);
    if (word(h) != 0x41555053u || word(h + 4u) != 0x30315746u ||
        word(h + 12u) != tail || word(h + 16u) != 0x80000000u ||
        runtime < 0x400u || runtime > tail - 0x400u ||
        word(h + 24u) != 0x400u || word(h + 28u) != 0x20243000u ||
        word(p + BRIDGE_OFFSET + 0x400u) != 0x20243000u)
        return 0;
    /* Preserve B1's bounded format, including acceptance of its actual images. */
    if (version == 1u) return tail <= LEGACY_MAX;
    if (version != 2u || word(h + 32u) != 0x32425053u ||
        word(h + 56u) || word(h + 60u))
        return 0;

    uint32_t bridge = word(h + 36u);
    uint32_t data_address = word(h + 40u);
    uint32_t data_size = word(h + 44u);
    uint32_t payload = word(h + 48u);
    uint32_t payload_size = word(h + 52u);
    /* The larger image never enlarges the bridge's copy or its runtime regions.
     * Subtractions below follow interval checks, so hostile fields cannot wrap. */
    if (bridge < 0x800u || bridge > LEGACY_MAX || (bridge & 3u) ||
        runtime > 0x10000u || (runtime & 31u) || runtime > bridge - 0x400u ||
        data_size != bridge - 0x400u - runtime || (data_size & 3u) ||
        data_address < 0x2023f000u || data_address > 0x20242000u ||
        (data_address & 3u) || data_size > 0x20242000u - data_address ||
        payload < ((bridge + 31u) & ~31u) || (payload & 31u) || payload > tail ||
        !payload_size || (payload_size & 3u) || payload_size != tail - payload)
        return 0;
    return 1;
}
