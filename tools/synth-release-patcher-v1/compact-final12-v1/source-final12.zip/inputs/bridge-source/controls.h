/* Original portable named-input decoder. Caller owns state and event sink. */
#pragma once
#include <stdint.h>
#define CONTROL_COUNT 55
enum control_kind {CONTROL_PAD=1,CONTROL_BUTTON,CONTROL_KNOB,CONTROL_ENCODER};
enum control_action {CONTROL_DOWN=1,CONTROL_UP,CONTROL_LEVEL,CONTROL_CHANGED,CONTROL_STEP,CONTROL_INVALID};
struct control_desc {
    const char *label;
    uint16_t baseline2,span2,on2,off2,low,high;
    int8_t polarity,pad_index;
    uint8_t kind,source,slot,inverted;
};
struct control_event {uint32_t ticks;uint16_t id,raw,level;int8_t delta;uint8_t action;};
struct controls_state {uint16_t raw[CONTROL_COUNT];uint8_t held[CONTROL_COUNT],seen[CONTROL_COUNT];};
typedef void (*control_sink)(const struct control_event *,void *);
extern const struct control_desc control_map[CONTROL_COUNT];
int control_id(unsigned source,unsigned slot);
void controls_reset(struct controls_state *);
void controls_feed(struct controls_state *,unsigned source,unsigned slot,unsigned raw,uint32_t ticks,control_sink,void *);
