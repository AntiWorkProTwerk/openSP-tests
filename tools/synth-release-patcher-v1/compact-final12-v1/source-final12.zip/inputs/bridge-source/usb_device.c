/* Original minimal USB1 full-speed HID feature-report transport.
 * RT1062 register contracts and limitations: USB.md. No vendor stack linked.
 */
#include "usb_upload.h"
#define R(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define U(o) R(0x402e0000u+(o))
volatile uint32_t usb_ready, usb_configured, usb_setups, usb_resets, usb_errors;
/* Cache-line ownership: QH64, TD32 and packet64 never share unrelated data. */
static volatile uint32_t heads[16][16] __attribute__((aligned(2048)));
static volatile uint32_t transfers[2][8] __attribute__((aligned(32)));
static uint8_t packet[64] __attribute__((aligned(32)));
static uint32_t phase;
static const uint8_t device[]={18,1,0,2,0,0,0,64,0xfe,0xca,0x50,0x40,0x18,0,1,2,0,1};
static const uint8_t hid_report[]={0x06,0x00,0xff,0x09,1,0xa1,1,0x15,0,0x26,0xff,0,
    0x75,8,0x95,64,0x09,1,0xb1,2,0xc0};
static const uint8_t configuration[]={9,2,34,0,1,1,0,0x80,50,
    9,4,0,0,1,3,0,0,0,9,0x21,0x11,1,0,1,0x22,sizeof(hid_report),0,
    7,5,0x81,3,64,0,10};
static void cache(const volatile void *p,unsigned n,unsigned invalidate) {
    uintptr_t a=(uintptr_t)p & ~31u,end=((uintptr_t)p+n+31)&~31u;
    __asm__ volatile("dsb sy" ::: "memory");
    for(;a<end;a+=32) R(invalidate?0xe000ef5c:0xe000ef68)=a;
    __asm__ volatile("dsb sy\nisb" ::: "memory");
}
static int wait_clear(unsigned offset,uint32_t mask) {
    for(unsigned n=0;n<10000;++n) if(!(U(offset)&mask)) return 1;
    ++usb_errors;return 0;
}
static int flush(uint32_t mask) {
    /* A packet in progress can reject one flush; retry within a shared bound. */
    unsigned budget=10000;
    while(budget) {
        --budget;U(0x1b4)=mask;
        while((U(0x1b4)&mask) && budget) --budget;
        if(budget && !(U(0x1b8)&mask)) return 1;
    }
    ++usb_errors;return 0;
}
static void queue(unsigned in,unsigned length) {
    uint32_t addr=(uint32_t)(uintptr_t)packet;
    for(unsigned i=0;i<8;++i) transfers[in][i]=0;
    transfers[in][0]=1;transfers[in][1]=(length<<16)|0x8080;
    transfers[in][2]=addr;
    for(unsigned i=1;i<5;++i) transfers[in][2+i]=(addr&~4095u)+4096*i;
    heads[in][2]=(uint32_t)(uintptr_t)transfers[in];heads[in][3]=0;
    cache(packet,64,0);cache(transfers[in],32,0);cache(heads[in],64,0);
    U(0x1b0)=1u<<(in?16:0);
}
static void stall(void) {U(0x1c0)|=0x00010001;phase=0;}
static void send(const uint8_t *p,unsigned n,unsigned requested) {
    if(n>requested)n=requested;
    if(n>64)n=64;
    for(unsigned i=0;i<n;++i) packet[i]=p[i];
    phase=1;queue(1,n);
}
static void status_in(void) {phase=3;queue(1,0);}
static void reset_endpoints(void) {
    usb_configured=0;phase=0;upload_reset();
    U(0x1ac)=U(0x1ac);U(0x1bc)=U(0x1bc);
    if(!wait_clear(0x1b0,0xffffffffu) || !flush(0xffffffffu)) {
        usb_ready=0;U(0x140)&=~1u;return;
    }
    for(unsigned h=0;h<16;++h) for(unsigned w=0;w<16;++w) heads[h][w]=0;
    heads[0][0]=(64u<<16)|(1u<<29)|(1u<<15);
    heads[1][0]=(64u<<16)|(1u<<29);
    heads[0][2]=heads[1][2]=1;
    heads[3][0]=(64u<<16)|(1u<<29);heads[3][2]=1;
    for(unsigned e=1;e<8;++e) U(0x1c0+e*4)=0x00080008;
    U(0x1c0)=0x00800080;
    cache(heads,sizeof(heads),0);
    U(0x158)=(uint32_t)(uintptr_t)heads;
    U(0x154)=0;U(0x1ac)=U(0x1ac);U(0x1bc)=U(0x1bc);
}
static void setup(void) {
    uint8_t req[8];unsigned attempt;
    if(!flush(0x00010001)) {stall();return;}
    U(0x1bc)=0x00010001;
    for(attempt=0;attempt<1000;++attempt) {
        U(0x140)|=1u<<13; /* setup tripwire guards concurrent host SETUP */
        cache(heads[0],64,1);
        for(unsigned i=0;i<8;++i) req[i]=((volatile uint8_t *)heads[0])[40+i];
        if(U(0x140)&(1u<<13)) break;
    }
    U(0x140)&=~(1u<<13);
    U(0x1ac)=1;
    if(attempt==1000) {++usb_errors;stall();return;}
    ++usb_setups;phase=0;
    U(0x1c0)&=~0x00010001u;
    unsigned type=req[0],op=req[1],value=req[2]|req[3]<<8;
    unsigned index=req[4]|req[5]<<8,length=req[6]|req[7]<<8;
    if(type==0x80 && op==6) {
        switch(value>>8) {
            case 1:send(device,sizeof(device),length);return;
            case 2:send(configuration,sizeof(configuration),length);return;
            case 3: {
                uint8_t text[64];unsigned n=4;
                text[0]=4;text[1]=3;text[2]=9;text[3]=4;
                if((value&255)!=0) {
                    const char *s=(value&255)==1?"SP Community Lab":(value&255)==2?"SP404 USB BRIDGE B1":0;
                    if(!s){stall();return;}
                    n=2;while(*s && n<62) {text[n++]=*s++;text[n++]=0;}text[0]=n;text[1]=3;
                }
                send(text,n,length);return;
            }
            default:stall();return;
        }
    }
    if(type==0x81 && op==6 && index==0) {
        if(value==0x2200) {send(hid_report,sizeof(hid_report),length);return;}
        if(value==0x2100) {send(configuration+18,9,length);return;}
    }
    if(type==0 && op==5 && value<128 && length==0) {
        U(0x154)=(value<<25)|(1u<<24); /* activate on status ACK */
        status_in();return;
    }
    if(type==0 && op==9 && value<=1 && length==0) {
        usb_configured=value;U(0x1c4)=value?0x00cc0008:0x00080008;
        status_in();return;
    }
    if(type==0x80 && op==8 && length==1) {uint8_t v=usb_configured;send(&v,1,1);return;}
    if((type==0x80 || type==0x81 || type==0x82) && op==0 && length==2) {
        static const uint8_t zero[2]={0,0};send(zero,2,2);return;
    }
    if(type==0xa1 && op==1 && value==0x300 && index==0 && length==64 && usb_configured) {
        upload_status(packet);phase=1;queue(1,64);return;
    }
    if(type==0x21 && op==9 && value==0x300 && index==0 && length==64 && usb_configured) {
        phase=2;queue(0,64);return;
    }
    if(type==0x21 && op==10 && index==0 && length==0) {status_in();return;} /* HID idle */
    stall();
}
int usb_idle(void) {return phase==0 && !(U(0x1ac)&1);}
void usb_poll(void) {
    if(!usb_ready) return;
    uint32_t status=U(0x144);U(0x144)=status;
    if(status&(1u<<6)) {++usb_resets;reset_endpoints();return;}
    if(U(0x1ac)&1) {setup();return;}
    uint32_t done=U(0x1bc)&0x00010001; if(!done)return;
    U(0x1bc)=done;
    unsigned in=(done&0x10000)?1:0;
    cache(transfers[in],32,1);
    uint32_t token=transfers[in][1];
    if(token&0xe8) {++usb_errors;stall();return;}
    if(phase==1 && in) {phase=4;queue(0,0);}
    else if(phase==2 && !in) {
        if(token>>16) {++usb_errors;stall();return;}
        cache(packet,64,1);upload_command(packet);status_in();
    } else if(phase==3 && in) {
        phase=0;
    } else if(phase==4 && !in) phase=0;
}
void usb_init(void) {
    usb_ready=0;usb_errors=0;upload_reset();
    R(0x400fc080)|=3;
    R(0x400d8010)=(R(0x400d8010)&~0x1c002u)|0x3040;
    unsigned n;
    for(n=0;n<1000000;++n) if(R(0x400d8010)&0x80000000u)break;
    if(n==1000000){++usb_errors;return;}
    R(0x400d8010)&=~0x10000u;
    R(0x400d8120)=(R(0x400d8120)&0xffffe0feu)|0x1701;
    R(0x400d81b4)=0x180000; /* disable charger detector */
    R(0x400d9030)&=~0xc0000000u;R(0x400d9000)=0;
    R(0x400d9030)|=0x18c000;
    U(0x140)=2;
    if(!wait_clear(0x140,2))return;
    U(0x1a8)=2; /* device mode, setup-lockout default enabled */
    U(0x90)=7; /* AHB INCR16; unspecified-length remainder */
    U(0x1a4)=8; /* device termination, no VBUS charge/discharge */
    U(0x184)|=1u<<24; /* force full speed: one descriptor set */
    U(0x148)=0; /* polled by board_poll, no new NVIC IRQ */
    reset_endpoints();
    if(usb_errors)return;
    usb_ready=1;U(0x140)|=1;
}
