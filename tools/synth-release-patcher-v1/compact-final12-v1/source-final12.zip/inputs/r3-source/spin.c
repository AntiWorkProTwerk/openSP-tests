/* Project an extruded 3x5 text model into a tiny ASCII character grid.
 * No heap, floating point, waits, hardware timers, or audio parameter writes.
 * The widget owns one explicitly allocated extra uint32_t at offset 228.
 */
#include <stdint.h>

extern int param_get(void *, int, unsigned);
extern int external_mode(unsigned);
extern void *stock_tick(void *);
extern void *stock_ctor(void *, void *);
extern void *mark_dirty(void *);
extern int set_color(void *, unsigned, unsigned);
extern int set_font(void *, unsigned);
extern int clear_rect(void *, int, int, int, int);
extern int draw_text(void *, int, int, const char *);
extern int horizontal_line(void *, int, int, int);

#define BACKEND ((void *)0x82e2cd08u)
#define W 36
#define H 14

/* Signed Q8 sine, 64 steps: one revolution per 64 widget timer callbacks. */
static const int16_t sine[64] = {
  0,25,50,74,98,121,142,162,181,198,213,226,237,245,251,255,
  256,255,251,245,237,226,213,198,181,162,142,121,98,74,50,25,
  0,-25,-50,-74,-98,-121,-142,-162,-181,-198,-213,-226,-237,-245,-251,-255,
  -256,-255,-251,-245,-237,-226,-213,-198,-181,-162,-142,-121,-98,-74,-50,-25
};

/* Filled 3x5 letter cells, row-major, low bit first. AntiWork / ProTwerk.
 * Mixed case is represented by compact uppercase/lowercase glyph shapes. */
#define G(a,b,c,d,e) ((a) | ((b)<<3) | ((c)<<6) | ((d)<<9) | ((e)<<12))
static const uint16_t letters[16] = {
  G(2,5,7,5,5), G(0,0,3,5,5), G(2,7,2,2,6), G(2,0,2,2,2),
  G(5,5,5,7,5), G(0,0,7,5,7), G(0,0,3,1,1), G(1,5,3,5,5),
  G(3,5,3,1,1), G(0,0,3,1,1), G(0,0,7,5,7), G(7,2,2,2,2),
  G(0,0,5,7,5), G(0,7,5,3,7), G(0,0,3,1,1), G(1,5,3,5,5)
};

static int project(int numerator, int denominator) {
    return (numerator + (numerator < 0 ? -denominator / 2 : denominator / 2)) / denominator;
}

void *spin_ctor(void *widget, void *args) {
    void *result = stock_ctor(widget, args);
    *(uint32_t *)((uint8_t *)widget + 228) = 0;
    return result;
}

void *spin_tick(void *widget) {
    void *result = stock_tick(widget);
    if (param_get(BACKEND, 1, 0) == 0 && !external_mode(18)) {
        uint32_t *phase = (uint32_t *)((uint8_t *)widget + 228);
        *phase = (*phase + 1) & 63u;
        mark_dirty(widget);
    }
    return result;
}

void spin_grid(uint8_t *grid, unsigned phase) {
    int8_t depth[W * H];
    for (unsigned i = 0; i < W * H; ++i) {
        grid[i] = 0;
        depth[i] = 127;
    }
    int s = sine[phase & 63], c = sine[(phase + 16) & 63];
    for (int letter = 0; letter < 16; ++letter) {
        int row = letter / 8;
        int col = letter % 8;
        int center = 15;
        for (int bit = 0; bit < 15; ++bit) {
            if (!(letters[letter] & (1u << bit))) continue;
            int x = (col * 4 + bit % 3 - center) * 4;
            int y = (row * 6 + bit / 3 - 5) * 4;
            for (int z = -6; z <= 6; z += 6) {
                int rx = (x * c + z * s) / 256;
                int rz = (z * c - x * s) / 256;
                int den = 320 + rz;
                int gx = W / 2 + project(rx * 80, den);
                int gy = H / 2 + project((y * 256 - rz * 40) * 80, den * 256);
                if ((unsigned)gx >= W || (unsigned)gy >= H) continue;
                unsigned cell = gy * W + gx;
                if (rz < depth[cell]) {
                    depth[cell] = rz;
                    grid[cell] = rz < -25 ? 4 : rz < -5 ? 3 : rz < 20 ? 2 : 1;
                }
            }
        }
    }
}

void spin_render(void *canvas, unsigned phase) {
    uint8_t grid[W * H];
    /* Each occupied cell is a 3x3 ASCII-style glyph: '.', ':', '+', '#'. */
    static const uint16_t glyphs[5] = {0, 0x080, 0x082, 0x0ba, 0x17d};
    spin_grid(grid, phase);
    set_color(canvas, 0xffffffu, 0);
    clear_rect(canvas, 20, 9, 128, 64);
    for (unsigned cell = 0; cell < W * H; ++cell) {
        unsigned bits = glyphs[grid[cell]];
        if (!bits) continue;
        int x = 20 + (cell % W) * 3;
        int y = 10 + (cell / W) * 3;
        for (int bit = 0; bit < 9; ++bit)
            if (bits & (1u << bit))
                horizontal_line(canvas, x + bit % 3, y + bit / 3, x + bit % 3);
    }
    set_font(canvas, 29);
    draw_text(canvas, 22, 55, "AntiWorkProTwerk");
}
