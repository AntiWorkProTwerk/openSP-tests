/* Revision 3: retain R2 details and select the spinning logo on pad 1.
 * Vendor function addresses are fixed in hooks.S and verified by CPU tests.
 * Sample fields are read through the existing backend getter; no setters used.
 */
#include <stdint.h>

extern int param_get(void *backend, int parameter, unsigned pad);
extern const char *sample_name(void *backend, unsigned pad);
extern int set_color(void *canvas, unsigned color, unsigned mode);
extern int set_font(void *canvas, unsigned font);
extern int clear_rect(void *canvas, int left, int top, int right, int bottom);
extern int draw_text(void *canvas, int x, int y, const char *text);
extern int format_text(char *output, const char *format, ...);
extern int stock_widget_render(void *widget);
extern int external_mode(unsigned parameter);
extern void spin_render(void *canvas, unsigned phase);

#define BACKEND ((void *)0x82e2cd08u)

static int render_details(void *canvas) {
    int bank = param_get(BACKEND, 0, 0);
    int pad = param_get(BACKEND, 1, 0);
    int x = 22;
    int y = 10;
    char text[32];
    unsigned id;

    set_color(canvas, 0xffffffu, 0);
    /* Keep stock top header, left status icons, and bottom status marker. */
    clear_rect(canvas, 20, 9, 128, 50);
    set_font(canvas, 29);
    if ((unsigned)bank >= 10 || (unsigned)pad >= 16) {
        draw_text(canvas, x, y, "NO PAD SELECTED");
        return 0;
    }
    id = (unsigned)(bank * 16 + pad);
    int channels = param_get(BACKEND, 101, id);
    if (channels != 1 && channels != 2) {
        draw_text(canvas, x, y, "EMPTY PAD");
        return 0;
    }
    const char *name = sample_name(BACKEND, id);
    unsigned i = 0, limit = 17;
    while (i < limit && name[i]) {
        unsigned char c = (unsigned char)name[i];
        text[i++] = c >= 32 && c <= 126 ? (char)c : '?';
    }
    text[i] = 0;
    draw_text(canvas, x, y, text);

    unsigned bpm = (unsigned)param_get(BACKEND, 111, id);
    if (bpm > 99999) bpm = 0;
    format_text(text, "SRC %u.%02u %s", bpm / 100, bpm % 100, channels == 2 ? "ST" : "MO");
    draw_text(canvas, x, y + 10, text);

    unsigned start = (unsigned)param_get(BACKEND, 103, id);
    unsigned end = (unsigned)param_get(BACKEND, 104, id);
    unsigned centiseconds = end > start ? (end - start) / 480 : 0;
    format_text(text, "LEN %u.%02us", centiseconds / 100, centiseconds % 100);
    draw_text(canvas, x, y + 20, text);

    unsigned gate = param_get(BACKEND, 106, id) != 0;
    unsigned loop = param_get(BACKEND, 107, id) != 0;
    unsigned reverse = (unsigned)param_get(BACKEND, 117, id) & 1;
    format_text(text, "G:%u L:%u R:%u", gate, loop, reverse);
    draw_text(canvas, x, y + 30, text);
    return 0;
}

/* Preserve the retired page's entry contract if it is reached. Its parameter
 * event handler is stock again; the new hook belongs to the current widget. */
__attribute__((section(".entry")))
int pad_info_render(void *page) {
    return render_details(*(void **)((uint8_t *)page + 52));
}

int pad_info_widget(void *widget) {
    int result = stock_widget_render(widget);
    /* The original renderer also serves external-control tempo displays. */
    if (!external_mode(18)) {
        void *canvas = *(void **)((uint8_t *)widget + 132);
        if (param_get(BACKEND, 1, 0) == 0)
            spin_render(canvas, *(uint32_t *)((uint8_t *)widget + 228));
        else
            render_details(canvas);
    }
    return result;
}
