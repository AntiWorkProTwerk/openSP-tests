"""Source-built B2 and symbolic native patch replay using supplied official APP1."""
import json
from pathlib import Path
import struct
import subprocess
from portable_r3 import sha,elf_sections

def symbols(elf):
    data=elf.read_bytes();off=struct.unpack_from('<I',data,32)[0];stride,count=struct.unpack_from('<HH',data,46)
    rows=[struct.unpack_from('<10I',data,off+i*stride) for i in range(count)];result={}
    for row in rows:
        if row[1]!=2:continue
        strings=rows[row[6]];names=data[strings[4]:strings[4]+strings[5]]
        for at in range(row[4],row[4]+row[5],16):
            name,value,size,info,other,section=struct.unpack_from('<IIIBBH',data,at)
            label=names[name:].split(b'\0',1)[0].decode()
            if label and section:result[label]=(value,size,info&15)
    return result

def reference(ref, syms):
    if 'address' in ref:return ref['address']
    value=syms[ref['symbol']][0]+ref.get('addend',0)
    return value|1 if ref.get('thumb') else value

def encode_bl(address,target):
    offset=(target&~1)-(address+4)
    if offset%2 or not -(1<<24)<=offset<(1<<24):raise ValueError('BL range/alignment differs')
    value=offset&0x1ffffff;s=(value>>24)&1;i1=(value>>23)&1;i2=(value>>22)&1
    return struct.pack('<HH',0xF000|(s<<10)|((value>>12)&1023),
                       0xD000|((~(i1^s)&1)<<13)|((~(i2^s)&1)<<11)|((value>>1)&2047))

def decode_bl(address,data):
    a,b=struct.unpack('<HH',data);s=(a>>10)&1;i1=(~((b>>13)^s))&1;i2=(~((b>>11)^s))&1
    value=(s<<24)|(i1<<23)|(i2<<22)|((a&1023)<<12)|((b&2047)<<1)
    return address+4+(value-(1<<25) if s else value)

def scatter(stock):
    begin,end=[0x80+x for x in struct.unpack_from('<II',stock,0x80)]
    if (begin,end)!=(0x62c,0x6ec):raise ValueError('Official scatter table differs')
    rows=[]
    for index,at in enumerate(range(begin,end,16)):
        src,dst,size,handler=struct.unpack_from('<4I',stock,at)
        mode={0x60080088:'decompress',0x600800e4:'copy',0x60080100:'zero'}.get(handler)
        if mode is None:raise ValueError('Scatter handler differs')
        rows.append(dict(index=index,destination=dst,size=size,mode=mode,file_offset=src-0x60080000))
    return rows

def derive_recipe(base,stock,module,contract):
    sections=elf_sections(module.read_bytes());syms=symbols(module);rows=scatter(stock);writes=[]
    for row in contract['patches']:
        address,size=row['address'],row['bytes']
        owners=[r for r in rows if r['mode']=='copy' and r['destination']<=address and address+size<=r['destination']+r['size']]
        if len(owners)!=1:raise ValueError('Patch lacks one official copied-region owner')
        owner=owners[0];at=owner['file_offset']+address-owner['destination']
        if sha(base[at:at+size])!=row['before_sha256']:raise ValueError('Fresh R3 preimage differs')
        spec=row['source'];kind=spec['kind']
        if kind=='elf':
            section=sections[spec['section']];offset=spec['offset']
            payload=bytes(section['size']) if section['type']==8 else section['payload']
            after=payload[offset:offset+size]
        elif kind=='pointer':after=struct.pack('<I',reference(spec['target'],syms))
        elif kind=='bl':after=encode_bl(address,reference(spec['target'],syms))
        elif kind=='veneer':
            prefix=b'\0\xbf'*spec['prefix_nops']
            if spec.get('prefix_load_r1_r1_8'):prefix=struct.pack('<H',0x6800|(2<<6)|(1<<3)|1)
            if spec.get('preserved_prefix'):prefix=base[at:at+spec['preserved_prefix']]
            literal=struct.pack('<I',reference(spec['target'],syms))
            after=prefix+struct.pack('<HH',0xF8DF,0xF000|spec['literal_imm'])
            after+=b'\0\xbf'*spec['middle_nops']+literal+b'\0\xbf'*spec['suffix_nops']
            if spec.get('preserved_suffix'):after+=base[at+size-spec['preserved_suffix']:at+size]
        elif kind=='pool_mov':
            value=spec['value'];reg=spec['register'];high=spec['high_half']
            after=struct.pack('<HH',(0xF2C0 if high else 0xF240)|((value>>12)&15)|((value>>11&1)<<10),
                              ((value>>8&7)<<12)|(reg<<8)|(value&255))
        else:raise ValueError('Unknown source patch contract')
        if len(after)!=size:raise ValueError('Derived patch extent differs')
        writes.append(dict(name=row['name'],address=address,record=owner['index'],file_offset=at,
                           before=base[at:at+size].hex(),after=after.hex()))
    ordered=sorted(writes,key=lambda w:w['file_offset'])
    if any(a['file_offset']+len(bytes.fromhex(a['after']))>b['file_offset'] for a,b in zip(ordered,ordered[1:])):
        raise ValueError('Native contract intervals overlap')
    source=bytearray(base)
    for row in writes:
        data=bytes.fromhex(row['after']);source[row['file_offset']:row['file_offset']+len(data)]=data
    return bytes(source),writes

def build_b2(source,contract,tool_prefix,output):
    output.mkdir();staged=output/'source';staged.mkdir()
    for name,digest in contract['inputs'].items():
        raw=(source/name).read_bytes()
        if sha(raw)!=digest:raise ValueError('Original B2 input differs: '+name)
        data=raw
        if name=='flash.c':
            begin=data.index(b'uint32_t image_valid(');end=data.index(b'static int fail(',begin);data=data[:begin]+data[end:]
        if name in ('monitor.c','usb_upload.c'):
            if data.count(b'0x52420001')!=1:raise ValueError('B1 marker occurrence differs')
            data=data.replace(b'0x52420001',b'0x52420201')
        if name in ('screen.c','usb_device.c'):
            if data.count(b'USB BRIDGE B1')!=1:raise ValueError('B1 title occurrence differs')
            data=data.replace(b'USB BRIDGE B1',b'USB BRIDGE B2')
        (staged/name).write_bytes(data)
    def tool(name):
        p=Path(tool_prefix+name)
        if not p.is_file():p=Path(str(p)+'.exe')
        if not p.is_file():raise FileNotFoundError('Explicit tool missing')
        return str(p.resolve())
    command=[tool('gcc'),*contract['flags'],'-T','source/app1.ld',
             *['source/'+n for n in contract['compile_inputs']],'-Wl,-Map=link.map','-o','usb_bridge_b2.elf']
    run=subprocess.run(command,cwd=output,capture_output=True,text=True)
    (output/'compiler.private.log').write_text(run.stdout+run.stderr)
    if run.returncode:raise RuntimeError('B2 source build failed')
    for name,flag in [('tail','--remove-section=.hook'),('hook','--only-section=.hook')]:
        subprocess.run([tool('objcopy'),'-O','binary',flag,'usb_bridge_b2.elf',name+'.bin'],cwd=output,check=True)
    return (output/'tail.bin').read_bytes(),(output/'hook.bin').read_bytes(),symbols(output/'usb_bridge_b2.elf')

def make_image(source,module,tail,hook,syms,identity):
    bridge=0x288000;payload=0x290000
    if len(source)!=2652672 or len(tail)!=17412 or len(hook)!=4 or len(module)<=0:
        raise ValueError('APP1 component extent differs')
    if payload+len(module)>0x37f000 or bridge+len(tail)>payload:raise ValueError('APP1 component overlap/capacity')
    if not 1<=len(identity)<=12 or any(not 32<=ord(c)<=126 for c in identity):raise ValueError('Identity differs')
    image=bytearray(source);image[:4]=hook;image[0x160560:0x16056d]=identity.encode().ljust(12,b' ')+b'\0'
    image.extend(b'\xff'*(bridge-len(image)));image.extend(tail);image.extend(b'\xff'*(payload-len(image)));image.extend(module)
    h=bridge+0x200;struct.pack_into('<II',image,h+8,2,len(image)-bridge)
    start=syms['__data_start'][0];end=syms['__data_end'][0]
    struct.pack_into('<8I',image,h+32,0x32425053,len(tail),start,end-start,payload-bridge,len(module),0,0)
    return bytes(image)
