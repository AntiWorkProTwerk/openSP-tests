"""Bound the compact builder's parent reads and explicit compiler launches.

Python/OS imports before the hook and child compiler internal reads remain
outside this receipt. Every admitted compiler byte/search namespace is checked
separately before any launch.
"""
import os
from pathlib import Path
import re
import sys


def install(bundle, output, official, tools, tool_files):
    accesses=set();children=[];runtime=Path(sys.base_prefix).resolve()
    launcher=Path(sys.executable).resolve()
    allowed_tools={'arm-none-eabi-'+name+'.exe' for name in ('gcc','nm','objcopy','objdump')}
    def label(value):
        path=Path(os.fsdecode(value)).resolve()
        if path==official:return path,'owner-official'
        if path.is_relative_to(bundle):return path,'source-kit/'+path.relative_to(bundle).as_posix()
        if path.is_relative_to(output):return path,'output/'+path.relative_to(output).as_posix()
        if path.is_relative_to(tools):
            name=path.relative_to(tools).as_posix()
            if name in tool_files:return path,'pinned-tool/'+name
            raise PermissionError('Parent access to undeclared compiler input')
        if path.is_relative_to(runtime):return path,'python-runtime/'+path.relative_to(runtime).as_posix()
        if path==launcher:return path,'reviewed-python-launcher'
        raise PermissionError('Parent Python access escaped compact build roles')
    def endpoints(source,destination):
        _,src=label(source);dst_path,dst=label(destination)
        if not dst_path.is_relative_to(output):raise PermissionError('Copy destination escaped owned output')
        accesses.update((src,dst))
    def audit(event,args):
        if event=='open':
            if not isinstance(args[0],(str,bytes,os.PathLike)):return
            path,tag=label(args[0])
            writing=bool(args[2]&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            if writing and not path.is_relative_to(output):raise PermissionError('Parent write escaped owned output')
            accesses.add(tag)
        elif event in ('shutil.copyfile','shutil.copytree','_winapi.CopyFile2'):
            endpoints(args[0],args[1])
        elif event=='subprocess.Popen':
            executable,argv,cwd,environment=args
            if isinstance(argv,str):
                match=re.match(r'^(?:"([^"]+)"|(\S+))',argv)
                if match is None:raise PermissionError('Child lacks explicit compiler role')
                program=next(value for value in match.groups() if value is not None)
            else:program=argv[0]
            path,tag=label(executable or program)
            if path.parent!=tools/'bin' or path.name not in allowed_tools:
                raise PermissionError('Child escaped admitted compiler role')
            if cwd is not None and not Path(cwd).resolve().is_relative_to(output):
                raise PermissionError('Compiler working directory escaped owned output')
            accesses.add(tag);children.append(path.relative_to(tools).as_posix())
    sys.addaudithook(audit)
    return accesses,children
