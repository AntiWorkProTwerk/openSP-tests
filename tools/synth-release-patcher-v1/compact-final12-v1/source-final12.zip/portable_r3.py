"""Compile the pinned original R3 patch and normalize owner-supplied v5.52 locally.

Only Python's standard library and an explicitly supplied Arm GNU toolchain are
used. Source files remain caller supplied; this helper grants no redistribution
permission. The result is a private build input, with delivery held.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import struct
import subprocess
import zipfile

ARCHIVE_SHA = "ffe5cbbbc971383bcbef34959ea32cb36470d3c9eadad296f52bc4ea6a3cb3c5"
STOCK_SHA = "4a3d67711e14dcc97d50249a4eee7dd6df0251a2f37757cbbe2556c233730d80"
R3_SHA = "2740e108d710217a3203b964a9433c123d2bb62800896dc10ae40d13b8b7dbdc"
SOURCES = {
    "hooks.S": "8796d889f2565ee52bf3018dd7ab052f99712fda51e95eab802bb00513e14872",
    "pad_info.c": "8967949b93883317399cdb0c07dd78ddd6a02c2111f2374ff9549acbe0a66eed",
    "spin.c": "590dac37bec6e8d26fe77e765c78f039f0d9164ad035b41fd17fb1bbeaca627d",
    "spin.ld": "d3dacf81377519d9971b69fd6f8f43b220c0db8ec988a05e09640f49965523f2",
}
# Addresses, lengths and hashes describe original project patch output. The
# preimages below are hashes, so no native firmware instructions are embedded.
PATCHES = [
    ("menu", 0x8013EAA0, 1443168, 13, "498457bf801f35c46bbb3f0074a8565c4032cf8ebfb4f3314021498d0445fc60"),
    (".draw_hook", 0x8014A038, 1489656, 4, "1a5143b34618fdd8505734005fc044fff1f74f094ad5ca483e67ea7af72e5a91"),
    (".ctor_hook", 0x80055272, 486706, 4, "6c6a587e8b92fb6bae6ef07c937c191ba813502d7eaa31fa1cbf3c823f49a087"),
    (".tick_pointer", 0x80226E60, 2394400, 4, "24956c74c1331f391a0dac6b546751ae81af5aa509d538d6c2d30bb57e7ac967"),
    (".allocation", 0x80055268, 486696, 2, "d07bbfd87ec90e0dc5b29d7467c5d857f5808ea4dfe13a7b62eeacaa649295f3"),
    (".ram_patch", 0x80103138, 1199096, 760, "11fcea69fc1a578b6c0a3881982add2588b475500226085a69ea5c0b06901a36"),
    (".flash_patch", 0x60307260, 2650720, 914, "cc3e6b9545dc8256b5169eb5b94aa1ab4701fa0ffc990373168ad8941030afe0"),
]
FLAGS = ["-mcpu=cortex-m7", "-mthumb", "-mfloat-abi=soft", "-std=c11", "-Os",
         "-ffreestanding", "-fno-builtin", "-fno-unwind-tables",
         "-fno-asynchronous-unwind-tables", "-ffunction-sections", "-fdata-sections",
         "-Wall", "-Wextra", "-Werror"]


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def official_app1(path: Path) -> tuple[bytes, str]:
    raw = path.read_bytes()
    if sha(raw) == STOCK_SHA and len(raw) == 2652672:
        return raw, "official-app1"
    if sha(raw) != ARCHIVE_SHA or len(raw) != 1966465:
        raise ValueError("Expected the pinned official v5.52 ZIP or unchanged APP1")
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        members = [n for n in archive.namelist() if n.rsplit("/", 1)[-1] == "SP404MKII_APP1.bin"]
        if len(members) != 1 or archive.getinfo(members[0]).file_size != 2652672:
            raise ValueError("Official archive APP1 extent/member count differs")
        app1 = archive.read(members[0])
    if sha(app1) != STOCK_SHA:
        raise ValueError("Official archive APP1 hash differs")
    return app1, "official-zip"


def elf_sections(raw: bytes) -> dict[str, dict]:
    if raw[:7] != b"\x7fELF\x01\x01\x01" or struct.unpack_from("<H", raw, 18)[0] != 40:
        raise ValueError("Expected little-endian ELF32 ARM")
    offset = struct.unpack_from("<I", raw, 32)[0]
    stride, count, strings_index = struct.unpack_from("<HHH", raw, 46)
    if stride != 40 or count == 0 or strings_index >= count or offset + stride * count > len(raw):
        raise ValueError("Invalid ELF section table")
    rows = [struct.unpack_from("<10I", raw, offset + i * stride) for i in range(count)]
    string_row = rows[strings_index]
    strings = raw[string_row[4]:string_row[4] + string_row[5]]
    sections = {}
    for row in rows[1:]:
        if row[0] >= len(strings):
            raise ValueError("Invalid ELF section name")
        end = strings.find(b"\0", row[0])
        if end < 0 or (row[1] != 8 and row[4] + row[5] > len(raw)):
            raise ValueError("Invalid ELF section extent")
        name = strings[row[0]:end].decode("ascii")
        if name in sections:
            raise ValueError("Duplicate ELF section")
        sections[name] = {"type": row[1], "flags": row[2], "address": row[3],
                          "size": row[5], "payload": raw[row[4]:row[4] + row[5]] if row[1] != 8 else b""}
    return sections


def build(official: Path, source: Path, tool_prefix: str, output: Path) -> dict:
    stock, kind = official_app1(official)
    source_bytes = {}
    for name, digest in SOURCES.items():
        raw = (source / name).read_bytes()
        if sha(raw) != digest:
            raise ValueError("Pinned original R3 source differs: " + name)
        source_bytes[name] = raw
    # Probe an explicit executable; no download, PATH fallback or workspace
    # inference. This accepts platform-specific executable suffixes naturally.
    def tool(name: str) -> str:
        path = Path(tool_prefix + name)
        if path.is_file():
            return str(path.resolve())
        windows = Path(str(path) + ".exe")
        if windows.is_file():
            return str(windows.resolve())
        raise FileNotFoundError("Explicit Arm GNU tool is absent: " + name)
    gcc = tool("gcc")
    version = subprocess.check_output([gcc, "--version"], text=True).splitlines()[0]
    if "14.3.Rel1" not in version or "14.3.1" not in version:
        raise ValueError("Exact R3 reproduction requires Arm GNU 14.3.Rel1 / GCC 14.3.1")
    output = output.resolve()
    # Build outputs cannot overwrite supplied source or firmware inputs.
    if output == source.resolve() or source.resolve().is_relative_to(output) or official.resolve().is_relative_to(output):
        raise ValueError("Output would contain supplied inputs")
    output.mkdir(parents=True, exist_ok=False)
    staged = output / "source"
    staged.mkdir()
    for name, raw in source_bytes.items():
        (staged / name).write_bytes(raw)
    objects = [name + ".o" for name in ("pad_info", "spin", "hooks")]
    commands = []
    for name, obj in zip(("pad_info.c", "spin.c", "hooks.S"), objects):
        commands.append([gcc, *FLAGS, "-c", "source/" + name, "-o", obj])
    commands.append([gcc, *FLAGS, "-nostdlib", "-Wl,--gc-sections", "-Wl,--orphan-handling=warn",
                     "-T", "source/spin.ld", *objects, "-o", "spin.elf"])
    logs = []
    for command in commands:
        result = subprocess.run(command, cwd=output, capture_output=True, text=True)
        # Diagnostics can mention compiler include roots. Keep them only in a
        # private log; the portable receipt itself has no absolute paths.
        logs.append(result.stdout + result.stderr)
        (output / "compiler.private.log").write_text("".join(logs), encoding="utf-8")
        if result.returncode:
            raise RuntimeError("Original R3 compile/link failed; inspect the private compiler log")
    elf = (output / "spin.elf").read_bytes()
    sections = elf_sections(elf)
    if any(r["size"] and r["flags"] & 3 == 3 for r in sections.values()):
        raise ValueError("Original R3 ELF has allocated writable storage")
    image = bytearray(stock)
    receipts = []
    for name, address, offset, size, expected in PATCHES:
        if name == "menu":
            if stock[offset:offset + size] != b"UTILITY MENU\0":
                raise ValueError("Stock Utility title preimage differs")
            data = b"ASCII SPIN3!\0"
        else:
            section = sections.get(name)
            if section is None or section["address"] != address or section["type"] != 1:
                raise ValueError("Original R3 linked section mapping differs: " + name)
            data = section["payload"]
            if name == ".ram_patch":
                if not 0 < len(data) <= size:
                    raise ValueError("Original R3 RAM reservation overflow")
                data = data.ljust(size, b"\0")
            if name == ".flash_patch" and any(stock[offset:]):
                raise ValueError("Stock trailing padding is occupied")
        if len(data) != size or sha(data) != expected:
            raise ValueError("Exact original R3 patch output differs: " + name)
        image[offset:offset + size] = data
        receipts.append({"name": name, "offset": offset, "bytes": size, "sha256": sha(data)})
    normalized = bytes(image)
    if len(normalized) != len(stock) or sha(normalized) != R3_SHA:
        raise ValueError("Exact normalized R3 baseline differs")
    (output / "baseline-r3.disabled.bin").write_bytes(normalized)
    report = {
        "schema": "opensp-portable-original-r3-normalizer-v1",
        "status": "PASS_EXACT_R3_FROM_ORIGINAL_SOURCE_AND_SUPPLIED_OFFICIAL",
        "official_input_kind": kind, "stock_app1_sha256": STOCK_SHA,
        "source_sha256": SOURCES, "compiler_version": version.replace(".exe", ""),
        "compile_units": 3, "commands": [["arm-none-eabi-gcc", *c[1:]] for c in commands],
        "elf_sha256": sha(elf), "patches": receipts,
        "normalized_sha256": sha(normalized), "normalized_bytes": len(normalized),
        "normalized_path": "baseline-r3.disabled.bin", "private_candidate_read": False,
        "captured_image_read": False, "device_operations": False, "delivery": "DO_NOT_DELIVER",
        "public_source16_build_ready": False, "native_hardware_qualified": False,
    }
    (output / "REPORT.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--official", required=True, type=Path)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--tool-prefix", required=True, help="Explicit path ending in arm-none-eabi-")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    report = build(args.official, args.source, args.tool_prefix, args.output)
    print(json.dumps({k: report[k] for k in ("status", "normalized_sha256", "public_source16_build_ready")}, indent=2))
