# openSynth N1 compact source review kit

This fixed local builder joins the P6S four-voice, 16-sound preview renderer to
the source-owned direct pad-recording path. It accepts the unchanged official
Roland v5.52 ZIP or APP1, authenticated Python 3.12.14 and Arm GNU 14.3.Rel1
installation roles, and a new private output directory. It contains source,
relative manifests and official extraction recipes. It contains no supplied
Roland image, compiler executable or historical compiled module.

Run the outer patcher only after it authenticates this exact archive and entry.
The entry command is `python -I -S -B build_candidate.py --inputs inputs
--official OWNER_V552.zip --tool-prefix ARM_BIN/arm-none-eabi- --output NEW_OUTPUT`.
The command belongs on one line. No alternate source or feature configuration
is admitted by this kit.

A passing build records source/package consistency. Owner-test eligibility
also needs exact linked audio64, clear-memory, lifetime, runtime and B2 writer
reviews. Public release remains false until the new image passes physical
record/save/pad playback/pattern/persistence/reentry and cold DEL recovery.
The plan records the actual capture bound; unlimited recording is not established.

Exact P6S recovery is separately source-reproducible and already physically
tested. This builder records its image identity, but does not rebuild or supply
that recovery image. The restoration source archive is a separate required
patcher input when the owner needs to regenerate recovery locally.

The audit records parent Python reads after its hook and explicit compiler
launches. OS/standard-library imports and child compiler internal reads remain
untraced. Compiler binaries and six search namespaces are authenticated before
launch. LICENSE and NOTICE retain the original-code scope and vendor exclusions;
source promotion and firmware redistribution are not granted by this review kit.
